const cron = require("node-cron");
const store = require("./store");
const { publishPost } = require("./publisher");

function start() {
  // Runs every minute. Fine for a personal-scale scheduler; tighten if needed.
  cron.schedule("* * * * *", async () => {
    const due = store.duePosts();
    for (const post of due) {
      console.log(`[scheduler] publishing post ${post.id}`);
      try {
        await publishPost(post);
      } catch (err) {
        console.error(`[scheduler] post ${post.id} failed:`, err.message);
        store.updatePost(post.id, { status: "failed", error: err.message });
      }
    }
  });
  console.log("[scheduler] started (checks every minute)");
}

module.exports = { start };
