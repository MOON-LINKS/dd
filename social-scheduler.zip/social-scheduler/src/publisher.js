const store = require("./store");
const cryptoUtil = require("./crypto");
const platformModules = require("./platforms");

// Map an account's stored "platform" value to the module that knows how to
// publish for it. Facebook and Instagram both go through the "meta" module.
function moduleFor(platform) {
  if (platform === "facebook" || platform === "instagram") return platformModules.meta;
  if (platform === "linkedin") return platformModules.linkedin;
  if (platform === "tiktok") return platformModules.tiktok;
  throw new Error(`No publisher for platform: ${platform}`);
}

async function publishPost(post) {
  store.updatePost(post.id, { status: "posting" });
  const results = {};
  let anySuccess = false;
  let anyFailure = false;

  for (const accountId of post.accountIds) {
    const account = store.getAccount(accountId);
    if (!account) {
      results[accountId] = { ok: false, error: "Account no longer connected." };
      anyFailure = true;
      continue;
    }
    try {
      const mod = moduleFor(account.platform);
      const decrypted = {
        ...account,
        accessToken: cryptoUtil.decrypt(account.accessToken),
        refreshToken: account.refreshToken ? cryptoUtil.decrypt(account.refreshToken) : null,
      };
      const result = await mod.publish(decrypted, post);
      results[accountId] = { ok: true, platform: account.platform, result };
      anySuccess = true;
    } catch (err) {
      console.error(`Publish failed for account ${accountId}:`, err.message);
      results[accountId] = { ok: false, platform: account.platform, error: err.message };
      anyFailure = true;
    }
  }

  const status = anySuccess && !anyFailure ? "posted" : anySuccess ? "partial" : "failed";
  return store.updatePost(post.id, { status, results, publishedAt: new Date().toISOString() });
}

module.exports = { publishPost };
