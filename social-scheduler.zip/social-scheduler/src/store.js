const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "..", "data");
const ACCOUNTS_FILE = path.join(DATA_DIR, "accounts.json");
const POSTS_FILE = path.join(DATA_DIR, "posts.json");

function ensureFile(file) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, "[]", "utf8");
}

function readJson(file) {
  ensureFile(file);
  const raw = fs.readFileSync(file, "utf8");
  try {
    return JSON.parse(raw || "[]");
  } catch {
    return [];
  }
}

function writeJson(file, data) {
  ensureFile(file);
  // Write to a temp file then rename, so a crash mid-write can't corrupt the store.
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
  fs.renameSync(tmp, file);
}

function newId() {
  return crypto.randomBytes(8).toString("hex");
}

// ---------- Accounts ----------

function listAccounts() {
  return readJson(ACCOUNTS_FILE);
}

function getAccount(id) {
  return listAccounts().find((a) => a.id === id) || null;
}

function upsertAccount(account) {
  const accounts = listAccounts();
  const idx = accounts.findIndex(
    (a) => a.platform === account.platform && a.platformAccountId === account.platformAccountId
  );
  if (idx >= 0) {
    accounts[idx] = { ...accounts[idx], ...account, id: accounts[idx].id };
  } else {
    accounts.push({ id: newId(), createdAt: new Date().toISOString(), ...account });
  }
  writeJson(ACCOUNTS_FILE, accounts);
  return accounts;
}

function deleteAccount(id) {
  const accounts = listAccounts().filter((a) => a.id !== id);
  writeJson(ACCOUNTS_FILE, accounts);
}

// ---------- Posts ----------

function listPosts() {
  return readJson(POSTS_FILE).sort((a, b) =>
    (a.scheduledAt || a.createdAt).localeCompare(b.scheduledAt || b.createdAt)
  );
}

function getPost(id) {
  return listPosts().find((p) => p.id === id) || null;
}

function createPost(post) {
  const posts = readJson(POSTS_FILE);
  const record = {
    id: newId(),
    createdAt: new Date().toISOString(),
    status: "scheduled", // scheduled | posting | posted | partial | failed | canceled
    results: {},
    ...post,
  };
  posts.push(record);
  writeJson(POSTS_FILE, posts);
  return record;
}

function updatePost(id, patch) {
  const posts = readJson(POSTS_FILE);
  const idx = posts.findIndex((p) => p.id === id);
  if (idx === -1) return null;
  posts[idx] = { ...posts[idx], ...patch };
  writeJson(POSTS_FILE, posts);
  return posts[idx];
}

function deletePost(id) {
  const posts = readJson(POSTS_FILE).filter((p) => p.id !== id);
  writeJson(POSTS_FILE, posts);
}

function duePosts() {
  const now = new Date().toISOString();
  return readJson(POSTS_FILE).filter(
    (p) => p.status === "scheduled" && p.scheduledAt && p.scheduledAt <= now
  );
}

module.exports = {
  listAccounts,
  getAccount,
  upsertAccount,
  deleteAccount,
  listPosts,
  getPost,
  createPost,
  updatePost,
  deletePost,
  duePosts,
};
