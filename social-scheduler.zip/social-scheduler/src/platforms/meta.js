// Meta Graph API: Facebook Pages + Instagram (Business/Creator accounts
// connected to a Page). Uses "Facebook Login for Business".
// Docs: https://developers.facebook.com/docs/instagram-platform/overview/

const GRAPH_VERSION = "v21.0";
const GRAPH = `https://graph.facebook.com/${GRAPH_VERSION}`;

const SCOPES = [
  "pages_show_list",
  "pages_read_engagement",
  "pages_manage_posts",
  "instagram_basic",
  "instagram_content_publish",
].join(",");

function getAuthUrl(state) {
  const params = new URLSearchParams({
    client_id: process.env.META_APP_ID,
    redirect_uri: process.env.META_REDIRECT_URI,
    scope: SCOPES,
    response_type: "code",
    state,
  });
  return `https://www.facebook.com/${GRAPH_VERSION}/dialog/oauth?${params.toString()}`;
}

async function fetchJson(url) {
  const res = await fetch(url);
  const json = await res.json();
  if (!res.ok || json.error) {
    throw new Error(`Meta API error: ${JSON.stringify(json.error || json)}`);
  }
  return json;
}

// Exchanges the OAuth `code` for accounts, and returns an array of
// account records ready to be saved via store.upsertAccount.
async function handleCallback(code) {
  // 1. Short-lived user token
  const shortLived = await fetchJson(
    `${GRAPH}/oauth/access_token?` +
      new URLSearchParams({
        client_id: process.env.META_APP_ID,
        client_secret: process.env.META_APP_SECRET,
        redirect_uri: process.env.META_REDIRECT_URI,
        code,
      })
  );

  // 2. Exchange for a long-lived user token (~60 days)
  const longLived = await fetchJson(
    `${GRAPH}/oauth/access_token?` +
      new URLSearchParams({
        grant_type: "fb_exchange_token",
        client_id: process.env.META_APP_ID,
        client_secret: process.env.META_APP_SECRET,
        fb_exchange_token: shortLived.access_token,
      })
  );
  const userToken = longLived.access_token;

  // 3. List Facebook Pages the user manages (page tokens returned here are
  //    already long-lived / effectively non-expiring when derived from a
  //    long-lived user token).
  const pagesRes = await fetchJson(`${GRAPH}/me/accounts?access_token=${userToken}`);

  const accounts = [];
  for (const page of pagesRes.data || []) {
    accounts.push({
      platform: "facebook",
      platformAccountId: page.id,
      label: `Facebook: ${page.name}`,
      accessToken: page.access_token,
      expiresAt: null, // page tokens from a long-lived user token don't expire
    });

    // 4. Check for a connected Instagram Business/Creator account
    const igCheck = await fetchJson(
      `${GRAPH}/${page.id}?fields=instagram_business_account{id,username}&access_token=${page.access_token}`
    );
    const ig = igCheck.instagram_business_account;
    if (ig) {
      accounts.push({
        platform: "instagram",
        platformAccountId: ig.id,
        label: `Instagram: @${ig.username}`,
        accessToken: page.access_token, // IG publishing uses the linked Page's token
        expiresAt: null,
        meta: { pageId: page.id },
      });
    }
  }
  return accounts;
}

async function publishFacebook(account, post) {
  const { accessToken, platformAccountId } = account;
  if (post.mediaUrl && post.mediaType === "image") {
    const res = await fetch(`${GRAPH}/${platformAccountId}/photos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: post.mediaUrl,
        caption: post.content || "",
        access_token: accessToken,
      }),
    });
    const json = await res.json();
    if (!res.ok || json.error) throw new Error(`Facebook publish failed: ${JSON.stringify(json.error || json)}`);
    return json;
  }
  // text-only (or link) post
  const res = await fetch(`${GRAPH}/${platformAccountId}/feed`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: post.content || "", access_token: accessToken }),
  });
  const json = await res.json();
  if (!res.ok || json.error) throw new Error(`Facebook publish failed: ${JSON.stringify(json.error || json)}`);
  return json;
}

async function publishInstagram(account, post) {
  const { accessToken, platformAccountId } = account;
  if (!post.mediaUrl) {
    throw new Error("Instagram requires an image or video URL -- text-only posts aren't supported by the API.");
  }
  const isVideo = post.mediaType === "video";
  const createRes = await fetch(`${GRAPH}/${platformAccountId}/media`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      [isVideo ? "video_url" : "image_url"]: post.mediaUrl,
      media_type: isVideo ? "REELS" : undefined,
      caption: post.content || "",
      access_token: accessToken,
    }),
  });
  const created = await createRes.json();
  if (!createRes.ok || created.error) {
    throw new Error(`Instagram media create failed: ${JSON.stringify(created.error || created)}`);
  }

  const publishRes = await fetch(`${GRAPH}/${platformAccountId}/media_publish`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ creation_id: created.id, access_token: accessToken }),
  });
  const published = await publishRes.json();
  if (!publishRes.ok || published.error) {
    throw new Error(`Instagram publish failed: ${JSON.stringify(published.error || published)}`);
  }
  return published;
}

async function publish(account, post) {
  if (account.platform === "facebook") return publishFacebook(account, post);
  if (account.platform === "instagram") return publishInstagram(account, post);
  throw new Error(`Unsupported Meta platform: ${account.platform}`);
}

module.exports = { getAuthUrl, handleCallback, publish };
