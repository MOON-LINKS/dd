const meta = require("./meta");
const linkedin = require("./linkedin");
const tiktok = require("./tiktok");

// "meta" isn't a platform value we store accounts under (we store
// "facebook" / "instagram" separately) but it's a single OAuth flow that
// can produce both, so it gets its own entry for the /auth/* routes.
module.exports = { meta, linkedin, tiktok };
