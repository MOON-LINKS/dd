// TikTok Content Posting API. Requires PKCE. Until your app passes TikTok's
// audit, posts are forced to SELF_ONLY visibility (only you can see them).
// Set TIKTOK_PRIVACY_LEVEL=PUBLIC_TO_EVERYONE in .env once audited.
// Docs: https://developers.tiktok.com/doc/content-posting-api-get-started

const crypto = require("crypto");

function base64url(buffer) {
  return buffer.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function makePkcePair() {
  const verifier = base64url(crypto.randomBytes(32));
  const challenge = base64url(crypto.createHash("sha256").update(verifier).digest());
  return { verifier, challenge };
}

function getAuthUrl(state, codeChallenge) {
  const params = new URLSearchParams({
    client_key: process.env.TIKTOK_CLIENT_KEY,
    scope: "user.info.basic,video.publish",
    response_type: "code",
    redirect_uri: process.env.TIKTOK_REDIRECT_URI,
    state,
    code_challenge: codeChallenge,
    code_challenge_method: "S256",
  });
  return `https://www.tiktok.com/v2/auth/authorize/?${params.toString()}`;
}

async function handleCallback(code, codeVerifier) {
  const res = await fetch("https://open.tiktokapis.com/v2/oauth/token/", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_key: process.env.TIKTOK_CLIENT_KEY,
      client_secret: process.env.TIKTOK_CLIENT_SECRET,
      code,
      grant_type: "authorization_code",
      redirect_uri: process.env.TIKTOK_REDIRECT_URI,
      code_verifier: codeVerifier,
    }),
  });
  const token = await res.json();
  if (!res.ok || token.error) {
    throw new Error(`TikTok token exchange failed: ${JSON.stringify(token)}`);
  }

  const expiresAt = new Date(Date.now() + token.expires_in * 1000).toISOString();

  return [
    {
      platform: "tiktok",
      platformAccountId: token.open_id,
      label: `TikTok: ${token.open_id}`,
      accessToken: token.access_token,
      refreshToken: token.refresh_token || null,
      expiresAt,
    },
  ];
}

async function refresh(account) {
  const res = await fetch("https://open.tiktokapis.com/v2/oauth/token/", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_key: process.env.TIKTOK_CLIENT_KEY,
      client_secret: process.env.TIKTOK_CLIENT_SECRET,
      grant_type: "refresh_token",
      refresh_token: account.refreshToken,
    }),
  });
  const token = await res.json();
  if (!res.ok || token.error) throw new Error(`TikTok refresh failed: ${JSON.stringify(token)}`);
  return {
    accessToken: token.access_token,
    refreshToken: token.refresh_token || account.refreshToken,
    expiresAt: new Date(Date.now() + token.expires_in * 1000).toISOString(),
  };
}

async function publish(account, post) {
  if (!post.mediaUrl || post.mediaType !== "video") {
    throw new Error("TikTok posting in this app supports video only (a publicly reachable video URL).");
  }
  const privacyLevel = process.env.TIKTOK_PRIVACY_LEVEL || "SELF_ONLY";

  const res = await fetch("https://open.tiktokapis.com/v2/post/publish/video/init/", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${account.accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      post_info: {
        title: post.content || "",
        privacy_level: privacyLevel,
        disable_duet: false,
        disable_comment: false,
        disable_stitch: false,
        video_cover_timestamp_ms: 1000,
      },
      source_info: {
        source: "PULL_FROM_URL",
        video_url: post.mediaUrl,
      },
    }),
  });
  const json = await res.json();
  if (!res.ok || json.error?.code !== "ok") {
    throw new Error(`TikTok publish failed: ${JSON.stringify(json)}`);
  }
  return json.data;
}

module.exports = { getAuthUrl, handleCallback, publish, refresh, makePkcePair };
