// LinkedIn Posts API. Personal-profile posting via w_member_social is
// self-serve -- no partner review needed.
// Docs: https://learn.microsoft.com/en-us/linkedin/consumer/integrations/self-serve/sign-in-with-linkedin-v2

const SCOPES = "openid profile w_member_social";

function linkedinVersionHeader() {
  // LinkedIn expects a "YYYYMM" version header. Using the current month
  // keeps this valid without manual updates.
  const now = new Date();
  const yyyy = now.getUTCFullYear();
  const mm = String(now.getUTCMonth() + 1).padStart(2, "0");
  return `${yyyy}${mm}`;
}

function getAuthUrl(state) {
  const params = new URLSearchParams({
    response_type: "code",
    client_id: process.env.LINKEDIN_CLIENT_ID,
    redirect_uri: process.env.LINKEDIN_REDIRECT_URI,
    scope: SCOPES,
    state,
  });
  return `https://www.linkedin.com/oauth/v2/authorization?${params.toString()}`;
}

async function handleCallback(code) {
  const tokenRes = await fetch("https://www.linkedin.com/oauth/v2/accessToken", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: process.env.LINKEDIN_REDIRECT_URI,
      client_id: process.env.LINKEDIN_CLIENT_ID,
      client_secret: process.env.LINKEDIN_CLIENT_SECRET,
    }),
  });
  const token = await tokenRes.json();
  if (!tokenRes.ok || token.error) {
    throw new Error(`LinkedIn token exchange failed: ${JSON.stringify(token)}`);
  }

  const meRes = await fetch("https://api.linkedin.com/v2/userinfo", {
    headers: { Authorization: `Bearer ${token.access_token}` },
  });
  const me = await meRes.json();
  if (!meRes.ok) throw new Error(`LinkedIn userinfo failed: ${JSON.stringify(me)}`);

  const expiresAt = new Date(Date.now() + token.expires_in * 1000).toISOString();

  return [
    {
      platform: "linkedin",
      platformAccountId: me.sub,
      label: `LinkedIn: ${me.name}`,
      accessToken: token.access_token,
      refreshToken: token.refresh_token || null,
      expiresAt,
    },
  ];
}

async function uploadImage(account, mediaUrl) {
  const version = linkedinVersionHeader();
  const initRes = await fetch("https://api.linkedin.com/rest/images?action=initializeUpload", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${account.accessToken}`,
      "LinkedIn-Version": version,
      "X-Restli-Protocol-Version": "2.0.0",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      initializeUploadRequest: { owner: `urn:li:person:${account.platformAccountId}` },
    }),
  });
  const init = await initRes.json();
  if (!initRes.ok) throw new Error(`LinkedIn image init failed: ${JSON.stringify(init)}`);

  const imageBytesRes = await fetch(mediaUrl);
  if (!imageBytesRes.ok) throw new Error(`Could not fetch mediaUrl for LinkedIn upload: ${mediaUrl}`);
  const imageBuffer = Buffer.from(await imageBytesRes.arrayBuffer());

  const uploadUrl = init.value.uploadUrl;
  const putRes = await fetch(uploadUrl, { method: "PUT", body: imageBuffer });
  if (!putRes.ok) throw new Error("LinkedIn image binary upload failed");

  return init.value.image; // image URN, e.g. urn:li:image:...
}

async function publish(account, post) {
  const version = linkedinVersionHeader();
  const body = {
    author: `urn:li:person:${account.platformAccountId}`,
    commentary: post.content || "",
    visibility: "PUBLIC",
    distribution: {
      feedDistribution: "MAIN_FEED",
      targetEntities: [],
      thirdPartyDistributionChannels: [],
    },
    lifecycleState: "PUBLISHED",
    isReshareDisabledByAuthor: false,
  };

  if (post.mediaUrl && post.mediaType === "image") {
    const imageUrn = await uploadImage(account, post.mediaUrl);
    body.content = { media: { id: imageUrn } };
  }

  const res = await fetch("https://api.linkedin.com/rest/posts", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${account.accessToken}`,
      "LinkedIn-Version": version,
      "X-Restli-Protocol-Version": "2.0.0",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`LinkedIn publish failed (${res.status}): ${text}`);
  }
  // LinkedIn returns the created post's URN in the x-restli-id / x-linkedin-id header
  const postId = res.headers.get("x-restli-id") || res.headers.get("x-linkedin-id");
  return { id: postId };
}

module.exports = { getAuthUrl, handleCallback, publish };
