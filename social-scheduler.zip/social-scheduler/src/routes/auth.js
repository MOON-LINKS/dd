const express = require("express");
const crypto = require("crypto");
const store = require("../store");
const cryptoUtil = require("../crypto");
const platforms = require("../platforms");

const router = express.Router();

function randomState() {
  return crypto.randomBytes(16).toString("hex");
}

function saveAccounts(rawAccounts) {
  for (const acc of rawAccounts) {
    store.upsertAccount({
      ...acc,
      accessToken: cryptoUtil.encrypt(acc.accessToken),
      refreshToken: acc.refreshToken ? cryptoUtil.encrypt(acc.refreshToken) : null,
    });
  }
}

// ---- Meta (Facebook + Instagram) ----

router.get("/auth/meta", (req, res) => {
  const state = randomState();
  req.session.metaState = state;
  res.redirect(platforms.meta.getAuthUrl(state));
});

router.get("/auth/meta/callback", async (req, res) => {
  try {
    const { code, state } = req.query;
    if (!state || state !== req.session.metaState) return res.status(400).send("Invalid OAuth state.");
    const accounts = await platforms.meta.handleCallback(code);
    saveAccounts(accounts);
    res.redirect("/?connected=meta");
  } catch (err) {
    console.error(err);
    res.status(500).send(`Meta connect failed: ${err.message}`);
  }
});

// ---- LinkedIn ----

router.get("/auth/linkedin", (req, res) => {
  const state = randomState();
  req.session.linkedinState = state;
  res.redirect(platforms.linkedin.getAuthUrl(state));
});

router.get("/auth/linkedin/callback", async (req, res) => {
  try {
    const { code, state } = req.query;
    if (!state || state !== req.session.linkedinState) return res.status(400).send("Invalid OAuth state.");
    const accounts = await platforms.linkedin.handleCallback(code);
    saveAccounts(accounts);
    res.redirect("/?connected=linkedin");
  } catch (err) {
    console.error(err);
    res.status(500).send(`LinkedIn connect failed: ${err.message}`);
  }
});

// ---- TikTok ----

router.get("/auth/tiktok", (req, res) => {
  const state = randomState();
  const { verifier, challenge } = platforms.tiktok.makePkcePair();
  req.session.tiktokState = state;
  req.session.tiktokVerifier = verifier;
  res.redirect(platforms.tiktok.getAuthUrl(state, challenge));
});

router.get("/auth/tiktok/callback", async (req, res) => {
  try {
    const { code, state } = req.query;
    if (!state || state !== req.session.tiktokState) return res.status(400).send("Invalid OAuth state.");
    const accounts = await platforms.tiktok.handleCallback(code, req.session.tiktokVerifier);
    saveAccounts(accounts);
    res.redirect("/?connected=tiktok");
  } catch (err) {
    console.error(err);
    res.status(500).send(`TikTok connect failed: ${err.message}`);
  }
});

module.exports = router;
