const express = require("express");
const store = require("../store");

const router = express.Router();

router.get("/api/accounts", (req, res) => {
  const accounts = store.listAccounts().map((a) => ({
    id: a.id,
    platform: a.platform,
    label: a.label,
    connectedAt: a.createdAt,
    expiresAt: a.expiresAt,
  }));
  res.json(accounts);
});

router.delete("/api/accounts/:id", (req, res) => {
  store.deleteAccount(req.params.id);
  res.status(204).end();
});

module.exports = router;
