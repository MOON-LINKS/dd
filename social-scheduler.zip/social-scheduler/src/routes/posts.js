const express = require("express");
const store = require("../store");
const { publishPost } = require("../publisher");

const router = express.Router();

router.get("/api/posts", (req, res) => {
  res.json(store.listPosts());
});

router.post("/api/posts", async (req, res) => {
  const { content, mediaUrl, mediaType, accountIds, scheduledAt } = req.body;

  if (!accountIds || !accountIds.length) {
    return res.status(400).json({ error: "Select at least one connected account." });
  }
  if (!content && !mediaUrl) {
    return res.status(400).json({ error: "Post needs text content and/or a media URL." });
  }

  const isImmediate = !scheduledAt;
  const post = store.createPost({
    content: content || "",
    mediaUrl: mediaUrl || null,
    mediaType: mediaType || null, // "image" | "video"
    accountIds,
    scheduledAt: isImmediate ? new Date().toISOString() : new Date(scheduledAt).toISOString(),
    status: "scheduled",
  });

  if (isImmediate) {
    const updated = await publishPost(post);
    return res.status(201).json(updated);
  }
  res.status(201).json(post);
});

router.delete("/api/posts/:id", (req, res) => {
  const post = store.getPost(req.params.id);
  if (!post) return res.status(404).end();
  if (post.status === "scheduled") {
    store.updatePost(post.id, { status: "canceled" });
  } else {
    store.deletePost(post.id);
  }
  res.status(204).end();
});

module.exports = router;
