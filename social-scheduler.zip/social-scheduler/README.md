# Social Scheduler

A small, self-hosted scheduler for your own LinkedIn, Instagram, Facebook, and
TikTok accounts. Runs locally now; deploy the same code to your own server
later with no architecture changes.

Everything is stored in plain JSON files under `data/` (not a real database —
this is a single-user tool, no need for one). Access/refresh tokens are
encrypted at rest with AES-256-GCM.

## 1. Install

```bash
npm install
cp .env.example .env
```

Generate the two secrets `.env` needs:

```bash
openssl rand -hex 32   # use for SESSION_SECRET
openssl rand -hex 32   # use for ENCRYPTION_KEY
```

Paste both into `.env`.

## 2. Register a developer app on each platform

You do **not** need a registered business/agency for any of these — a free
individual developer account is enough. For all three, register the redirect
URI **exactly** as `http://localhost:3000/auth/<platform>/callback` while
testing locally (swap to your real domain once hosted).

### Meta (Instagram + Facebook)
1. https://developers.facebook.com/apps → Create App → type "Business".
2. Add the **Instagram Graph API** product.
3. Under Facebook Login for Business settings, add the redirect URI:
   `http://localhost:3000/auth/meta/callback`
4. Copy the App ID and App Secret into `META_APP_ID` / `META_APP_SECRET`.
5. Make sure the Instagram account you want to post to is a **Business or
   Creator** account (free, in the IG app: Settings → Account type) and is
   linked to a Facebook Page you manage.
6. Add yourself as a Tester/Admin on the app (Roles tab) — this alone is
   enough to use it for yourself without Business Verification.

### LinkedIn
1. https://www.linkedin.com/developers/apps → Create app.
2. It'll ask for an associated LinkedIn Page — create a bare-minimum free
   Page if you don't have one; no registered business needed.
3. Under Products, add **"Sign In with LinkedIn using OpenID Connect"** and
   **"Share on LinkedIn"** — both are self-serve, no review/waiting.
4. Under Auth settings, add the redirect URI:
   `http://localhost:3000/auth/linkedin/callback`
5. Copy Client ID / Client Secret into `.env`.

### TikTok
1. https://developers.tiktok.com/ → register, create an app.
2. Add the **Content Posting API** product.
3. Add the redirect URI: `http://localhost:3000/auth/tiktok/callback`
4. Copy Client Key / Client Secret into `.env`.
5. **Important:** until your app passes TikTok's audit, every post it
   publishes is forced to `SELF_ONLY` visibility (only you can see it).
   For a single-user tool this is usually fine — you can manually flip a
   post to public afterward in the TikTok app. If you want the API to
   publish public posts directly, apply for the audit from your app's
   dashboard once you've tested the flow (see the code comment in
   `src/platforms/tiktok.js` for the `TIKTOK_PRIVACY_LEVEL` override).

## 3. Run it

```bash
npm start
```

Open http://localhost:3000, click "Connect" for each platform, and you're in.

## 4. Using it

- **Media**: the "Media URL" field needs a publicly reachable `https://` link
  (an image or video). This is a Meta/TikTok API requirement — they pull
  media from a URL rather than accepting raw file uploads in this version.
  While developing locally, upload media somewhere temporarily (a private S3
  bucket, Cloudinary, even a GitHub raw link) and paste the URL. Once you
  host this app on your own server, the natural next step is to add a local
  `/uploads` static route so you can upload straight from the compose form —
  the publishing code doesn't change, only where the URL comes from.
- **Instagram** requires media (no text-only posts). **Facebook** and
  **LinkedIn** support text-only. **TikTok** in this app is video-only.
- Leave "Schedule for" blank to post immediately; set a future date/time to
  queue it — a background check runs every minute and publishes anything due.

## 5. Moving to your server later

Nothing changes structurally:
1. Copy the folder to your server, `npm install`, set real values in `.env`
   (especially `BASE_URL` and the three `*_REDIRECT_URI` values — they must
   match what's registered in each developer app).
2. Update each platform's redirect URI in its developer dashboard to your
   real domain.
3. Put it behind HTTPS (e.g. Caddy/nginx + Let's Encrypt) — OAuth redirect
   URIs generally must be HTTPS in production.
4. Add basic auth or a login screen in front of it (`express-session` is
   already wired up, so bolting on a single hardcoded admin password is a
   small addition) since this exposes posting-as-you to whoever reaches it.
5. Run it under `pm2` or a systemd service so it survives reboots.

## Notes / limits of this version

- No refresh-token rotation job yet (Meta page tokens don't expire; LinkedIn
  and TikTok tokens do — `src/platforms/tiktok.js` already has a `refresh()`
  helper, wire it into the scheduler if you hit expired-token errors).
- Single admin user, no auth on the local UI by design (add it before you
  expose this to the internet — see step 4 above).
- Content policies of each platform still apply — the API automates the
  click, it doesn't bypass platform rules.
