async function fetchJson(url, opts) {
  const res = await fetch(url, opts);
  if (res.status === 204) return null;
  const json = await res.json().catch(() => null);
  if (!res.ok) throw new Error((json && json.error) || `Request failed: ${res.status}`);
  return json;
}

function platformIcon(platform) {
  return { facebook: "FB", instagram: "IG", linkedin: "LI", tiktok: "TT" }[platform] || platform;
}

async function loadAccounts() {
  const accounts = await fetchJson("/api/accounts");
  const list = document.getElementById("accounts-list");
  const checkboxes = document.getElementById("account-checkboxes");
  list.innerHTML = "";
  checkboxes.innerHTML = "";

  if (!accounts.length) {
    list.innerHTML = '<li style="color:var(--muted)">No accounts connected yet.</li>';
  }

  for (const acc of accounts) {
    const li = document.createElement("li");
    li.innerHTML = `<span>[${platformIcon(acc.platform)}] ${acc.label}</span>`;
    const removeBtn = document.createElement("button");
    removeBtn.textContent = "Disconnect";
    removeBtn.className = "remove";
    removeBtn.onclick = async () => {
      if (!confirm(`Disconnect ${acc.label}?`)) return;
      await fetchJson(`/api/accounts/${acc.id}`, { method: "DELETE" });
      loadAccounts();
    };
    li.appendChild(removeBtn);
    list.appendChild(li);

    const cbLabel = document.createElement("label");
    cbLabel.innerHTML = `<input type="checkbox" value="${acc.id}" /> [${platformIcon(acc.platform)}] ${acc.label}`;
    checkboxes.appendChild(cbLabel);
  }
}

function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString();
}

async function loadPosts() {
  const posts = await fetchJson("/api/posts");
  const tbody = document.getElementById("posts-tbody");
  tbody.innerHTML = "";

  for (const post of posts.slice().reverse()) {
    const tr = document.createElement("tr");
    const platforms = (post.accountIds || [])
      .map((id) => id)
      .join(", ");

    tr.innerHTML = `
      <td>${formatDate(post.scheduledAt)}</td>
      <td>${(post.content || "").slice(0, 80)}${post.mediaUrl ? " 📎" : ""}</td>
      <td>${post.accountIds.length} account(s)</td>
      <td><span class="status-pill status-${post.status}">${post.status}</span></td>
      <td></td>
    `;

    if (post.status === "scheduled") {
      const cancelBtn = document.createElement("button");
      cancelBtn.textContent = "Cancel";
      cancelBtn.className = "btn small-btn";
      cancelBtn.onclick = async () => {
        await fetchJson(`/api/posts/${post.id}`, { method: "DELETE" });
        loadPosts();
      };
      tr.lastElementChild.appendChild(cancelBtn);
    }

    if (post.results && Object.keys(post.results).length) {
      const errs = Object.values(post.results)
        .filter((r) => !r.ok)
        .map((r) => r.error);
      if (errs.length) {
        tr.title = errs.join(" | ");
      }
    }

    tbody.appendChild(tr);
  }
}

document.getElementById("compose-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = document.getElementById("compose-status");
  status.textContent = "Saving…";

  const accountIds = Array.from(
    document.querySelectorAll("#account-checkboxes input[type=checkbox]:checked")
  ).map((cb) => cb.value);

  const scheduledAtRaw = document.getElementById("scheduledAt").value;

  const body = {
    content: document.getElementById("content").value,
    mediaUrl: document.getElementById("mediaUrl").value || null,
    mediaType: document.getElementById("mediaType").value || null,
    accountIds,
    scheduledAt: scheduledAtRaw ? new Date(scheduledAtRaw).toISOString() : null,
  };

  try {
    await fetchJson("/api/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    status.textContent = "Saved.";
    document.getElementById("compose-form").reset();
    loadPosts();
  } catch (err) {
    status.textContent = `Error: ${err.message}`;
  }
});

loadAccounts();
loadPosts();
setInterval(loadPosts, 15000);
