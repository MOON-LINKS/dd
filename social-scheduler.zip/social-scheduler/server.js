require("dotenv").config();
const path = require("path");
const express = require("express");
const session = require("express-session");

const authRoutes = require("./src/routes/auth");
const accountRoutes = require("./src/routes/accounts");
const postRoutes = require("./src/routes/posts");
const scheduler = require("./src/scheduler");

const app = express();

app.use(express.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET || "dev-secret-change-me",
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: "lax" },
  })
);

app.use(express.static(path.join(__dirname, "public")));

app.use(authRoutes);
app.use(accountRoutes);
app.use(postRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Social scheduler running at http://localhost:${PORT}`);
  scheduler.start();
});
