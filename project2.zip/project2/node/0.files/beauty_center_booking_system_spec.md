# Beauty Center / Clinic Booking System — Full Technical Specification

## 1. Overview & Mission

A multi-tenant SaaS booking platform for independent beauty and wellness businesses (stylists, salons, spa studios, clinics). Each business ("owner") gets:

- A management dashboard (Flutter app: web, mobile, eventually desktop) to run their schedule, services, clients, expenses, and revenue.
- A public, branded booking page on its own subdomain (`{business}.domain.com`), built as a standalone vanilla HTML/CSS/JS page — no marketplace, no commission, no competing listings.

Core principle: the owner controls the brand, the client relationship, and the data. The platform is infrastructure, not a marketplace.

## 2. Plans

| | Standard | Pro |
|---|---|---|
| Price | ~$19.99/mo or ~$200/yr | ~$40/mo or ~$450/yr |
| Staff accounts | ❌ | ✅ (multi-staff scheduling, filter by staff on booking page) |
| "Powered by [us]" branding on public page | Shown | Removed |
| Support | Standard | 24/7 |
| Data retention / backups | 1 year | 2 years |
| Public price catalogue block (e.g. nail polish shades with prices) | ❌ | ✅ |
| Staff ratings/feedback on bio page (feedback emailed to owner) | ❌ | ✅ |

Rules:
- One plan per account at a time — no stacking Standard + Pro.
- Auto-renew toggle (on/off).
- Upgrade path from Standard → Pro.
- When a plan lapses, a 5-day grace period applies before the account is marked inactive.
- One free trial per customer, enforced via the Paddle customer ID stored on the user — a customer who churns and resubscribes does not get a second trial.
- Payments processed via **Paddle** (not Stripe).

## 3. Technology Stack

| Layer | Technology |
|---|---|
| Database | MySQL 8+ (via Laragon in dev) |
| Backend | Node.js |
| Real-time | Socket.io |
| Owner dashboard app | Flutter/Dart — targets iOS, Android, Web at launch; Desktop planned later from the same codebase |
| Frontend state management | Riverpod + Hive (local persistence, tied to socket state) |
| Public booking page | Vanilla HTML/CSS/JS — one static, generated file per business, served from its subdomain |
| Payments | Paddle |
| Auth | bcryptjs (hashing) + JWT + Redis (session store) |
| Localization | English, Arabic, French — locale persisted in Hive |

### 3.1 Why a separate vanilla HTML/CSS/JS page for the public booking page

The owner-facing dashboard is a full Flutter app, but each business's *public* page is generated as a lightweight static-first HTML/CSS/JS file rather than shipped inside the Flutter web build. This keeps public pages fast to load on mobile data (client's first touchpoint from an Instagram bio link), SEO/Open-Graph friendly, and independent of the dashboard app's release cycle.

## 4. Database Schema (MySQL)

See accompanying `schema.sql` for full DDL. Summary of tables and their purpose:

### Identity & billing
- **users** — the business owner account. Holds `agency_name` (subdomain-safe, validated: lowercase, no spaces/special characters, cannot start or end with a digit), email, password hash, locale, theme, Paddle customer ID, free-trial flag.
- **plans** — Standard / Pro definitions: pricing, staff limits, backup retention days, branding/support flags.
- **subscriptions** — links a user to a plan; tracks `is_active`, `is_cancelled` (owner intent, separate from active status), `auto_renew`, `current_period_end`, `grace_period_end`, `was_free_trial`.
- **user_sessions** — active login sessions (see §6 Auth). Backs "logout" vs "logout from all devices."

### Staff (Pro feature, schema present now, dashboard access deferred)
- **staff** — staff person record: name, contact, optional login credentials for future use.
- **user_staff** — join table linking staff to an owner account (Pro-gated in application logic). Staff do **not** get Flutter app access at launch; this is schema groundwork for a later phase.

### Services
- **categories** — owner-defined service categories.
- **services** — individual bookable items: name, `duration_minutes`, `buffer_minutes` (auto-applied after the appointment), price + currency.

### Scheduling
- **weekly_hours** — the recurring weekly template (per business, optionally per staff once staff scheduling ships).
- **schedule_exceptions** — one-off overrides for a specific date (holiday, early close, emergency) — surfaced directly on the dashboard's live calendar, not as a separate nav page, since it's an in-the-moment action.
- **bookings** — the appointment record. Carries a **unique constraint on (user_id, staff_id, start_time)** — this is the concurrency safeguard: if two clients tap the same open slot at the same instant, the database rejects the second INSERT outright instead of allowing a double-booking to slip through a race condition. Supports guest bookings (`guest_name` + `guest_phone`, no `client_id`) alongside account-linked bookings.
- **booking_services** — junction table for multi-service bookings; a single appointment can bundle several services, with the slot's total duration equal to the sum of each service's duration (+ buffer). Durations/prices are snapshotted at booking time so later edits to a service don't rewrite history.
- **waitlist** — name, phone, email, requested date — for fully booked days; notify when a cancellation frees a slot.

### Clients
- **clients** — a client record. Email is optional (`NULL` allowed) since many clients will only ever give name + phone as guests; an account (email + password) is optional and opt-in.
- **user_client** — join table per business relationship: `visit_count`, loyalty discount snapshot, first/last visit. This is where repeat-visit tracking and the loyalty milestone live, **per business**, not globally.
- **loyalty_settings** — per-owner config: visits required to trigger a discount, discount percentage, on/off toggle.
- Client-list UX: the dashboard shows both account clients and guest (name+phone-only) clients in one list, with a filter/grouping toggle so the owner can distinguish "logged in" from "not logged in" and group guests by phone number or name to recognize repeat visitors who never created an account.

### Money
- **expenses** — label, value, currency, **exchange rate snapshot at time of entry**, expense date; full CRUD.
- **exchange_rates** — a live-updating table of USD↔LBP rates. Only used to convert **current** figures — every historical payment and expense already carries its own rate snapshot, so past months never silently change value when the rate moves.
- **daily_summary** — pre-aggregated per-business, per-day rollup (revenue in both currencies, expenses in both currencies, booking count). Written whenever a booking is paid or an expense is logged, so the analytics page is a fast indexed read instead of a live aggregation query — important given Socket.io is already carrying real-time load.

### Retention / cleanup
- **bookings_archive** — mirrors the bookings table. A scheduled job (monthly or biweekly) moves bookings past the owner's plan-specific retention window (1 year Standard, 2 years Pro) into archive, then purges from archive once the *full* retention period has passed. This is what lets the cleanup job keep the live `bookings` table small and fast without breaking Pro's 2-year backup promise.

### Public page / appearance
- **bio_pages** — logo, banner, bio text, social links (JSON), background/accent colors, `show_powered_by` (forced off automatically when plan = Pro), `catalogue_enabled` (Pro).
- **catalogue_items** — Pro-only public price list (e.g. nail polish shades with prices) shown on the public page.
- **staff_ratings** *(Pro, future-facing schema)* — client feedback tied to a staff member; on submission, triggers a direct email to the owner rather than (or in addition to) a public display, depending on how public-facing you want ratings to be.

### Audit
- **audit_log** — who/what/when for schedule and booking changes (cancel, reschedule, exception added, etc.) — cheap insurance once staff accounts exist and more than one person can act on a calendar.

## 5. Real-Time Layer (Socket.io)

Socket.io is the backbone for anything the client or owner needs to see instantly without a refresh:

- **Owner dashboard**: new booking appears in the live appointment view the instant a client confirms.
- **Public booking page**: slot picker updates in real time as slots fill, so a client never sees a slot that's already taken.
- **Schedule changes**: an exception added on the dashboard (e.g. "closing early today") propagates immediately to anyone currently viewing the public page.
- **Waitlist notification**: when a booking is cancelled, waitlisted clients for that date can be notified in real time (or via the existing email pipeline).

### 5.1 Preventing double-booking (the core race condition)

Two layers of defense, not one:

1. **Database-level**: the unique constraint on `bookings(user_id, staff_id, start_time)` makes a duplicate booking for the same slot impossible at the storage layer, regardless of what the application code does.
2. **Application-level**: wrap the booking creation (check availability → insert booking → emit socket event) in a single database transaction, so a slot is validated and reserved atomically. On conflict, return a clear "just booked" response to the losing client and have their UI silently refresh the slot picker rather than showing a raw error.

This combination means even if the real-time layer briefly shows a slot as open to two clients simultaneously (network lag, etc.), only one booking can ever be persisted — the second client is corrected the moment their request hits the database.

## 6. Authentication & Session Security

Modeled on a persistent, Instagram-style login experience that behaves identically across web and desktop clients.

- **Password hashing**: bcryptjs.
- **Tokens**: JWT access tokens, short-lived, used for API authorization.
- **Long-lived sessions**: backed by Redis, not just a long JWT expiry — Redis holds the session state so sessions can be individually revoked (see below), which a stateless long-lived JWT alone cannot do.
- **user_sessions table** (MySQL, source of truth alongside Redis): records each active session — device/user-agent, IP, created_at, last_seen_at, revoked_at. Powers:
  - **"Logout"** — revoke the current session only (delete/expire its Redis entry, mark revoked in `user_sessions`).
  - **"Logout from all devices"** — revoke every session tied to the user in both Redis and the sessions table; on next request from any other device, the auth middleware sees no valid session and forces re-login.
- **Cookies over local-only tokens**: session identifier delivered via an HTTP-only, Secure cookie so behavior is uniform across the Flutter web build and a future desktop build — cookies are handled by the browser/webview layer consistently, rather than relying on platform-specific secure storage for the *session* token. (Hive/Riverpod still hold local app state and cached data, not the auth secret itself.)
- **Auth middleware**: validates the session cookie/JWT on every protected route, checks Redis for revocation, attaches the authenticated user (and, later, staff/role) to the request context.
- **Rate limiting**: applied at minimum to login, signup, and the public booking-creation endpoint — the last one is unauthenticated and reachable by bots, so it's the highest-risk surface for spam bookings.
- **Staff auth**: schema (`staff.password_hash`) exists now but staff login is explicitly deferred — no staff-facing auth flow ships at launch.

## 7. Backend Structure (Node.js)

Suggested module boundaries (not prescriptive folder names, just responsibilities):

- **Auth module** — signup, login, logout, logout-all, session refresh, middleware.
- **Booking module** — availability calculation (weekly hours + exceptions + buffer + existing bookings), slot creation with transactional locking, cancel/reschedule/complete/block-time actions, Socket.io event emission.
- **Scheduling module** — weekly hours CRUD, exception CRUD.
- **Client module** — client CRUD, guest matching by phone/name, loyalty tracking.
- **Money module** — expenses CRUD, payment recording (with rate snapshot), daily_summary writer, exchange-rate updater (scheduled job pulling current USD/LBP rate).
- **Billing module** — Paddle webhook handling (subscription created/renewed/cancelled/payment failed), plan upgrade/downgrade, grace-period enforcement, free-trial eligibility check.
- **Bio/public-page module** — bio page settings, catalogue items (Pro), triggers regeneration of the static public HTML/CSS/JS output when settings change.
- **Notifications module** — booking confirmation email, 24-hour reminder job, waitlist notification, staff feedback email (Pro).
- **Retention/cron module** — the archive-then-purge job described in §4, run monthly or biweekly, plan-aware.

## 8. Flutter Dashboard App

### 8.1 Foundations (from day one)
- **Theming**: dark and light mode built in from the start.
- **State management**: Riverpod, with Hive for local persistence — caching dashboard data and tying local state to incoming socket events so the UI updates live without manual refresh logic scattered everywhere.
- **Localization**: English, Arabic, French from day one, using Flutter's localization setup; selected language persisted in Hive so it survives app restarts.
- **Navigation shape**: a left vertical sidebar, modern SaaS style (Stripe-like), not a bottom tab bar — appropriate for a data-dense dashboard used mostly on larger screens (web/desktop-first, mobile-friendly).

### 8.2 Navigation structure

1. **Account** (own top-level section) — name, email, password.
2. **Dashboard** — the main live view: today's/upcoming appointments streamed via Socket.io, quick actions (confirm/cancel/reschedule/complete/block-time), and the schedule-exception control lives here directly on the calendar.
3. **Categories & Items** — services with duration, buffer, and optional price; also where the weekly hours template can reasonably live.
4. **Clients** — client list with logged-in vs guest filter, grouping by phone/name for guests, visit history, loyalty status.
5. **Staff** — locked behind an "Upgrade to Pro" button on Standard; full staff management on Pro (schedules ship in a later phase even for Pro accounts, per §4).
6. **Expenses** — monthly view, add/edit/delete, each entry dated.
7. **Analytics** — month picker showing revenue, expenses, and net across both USD and LBP.
8. **Bio / Appearance** — logo, banner, bio text, social links, page colors; catalogue items and staff ratings display toggle on Pro.
9. **Billing** — current plan, renewal date, Paddle-linked card info, auto-renew toggle, upgrade button.
10. **Settings** — logout / logout from all devices, theme, language, about, terms, danger zone (delete account).

### 8.3 Signup constraint

At signup, the owner provides an "agency/center name" used directly to build their public subdomain. Validated (client-side and server-side) to be lowercase alphanumeric with hyphens only, no spaces, and not starting or ending with a digit.

## 9. Public Booking Page (per business)

- Generated as a standalone HTML/CSS/JS file served at `{agency_name}.domain.com`.
- Shows: logo, business name, bio, banner, service categories/prices, live hours, service picker (supports selecting multiple services, with combined duration reflected in the slot picker), live slot picker (Socket.io-driven, hides unavailable times instantly), client name + optional email + phone form, submit → creates booking.
- Optional client account creation (email + password) for return visits and loyalty tracking; guests can still book with just name + phone.
- Waitlist option shown when a requested day is fully booked.
- "Powered by [us]" footer link — visible on Standard, removed on Pro.
- **Pro only**: public price catalogue block (e.g. product/shade listing with prices), staff filter (once multi-staff ships), staff ratings/feedback display or collection (feedback also emails the owner directly).
- Open Graph meta tags (logo + name + short description) so the page previews well when shared as an Instagram bio link or in a chat.

## 10. Notifications

- Automated booking confirmation email on creation.
- Automated 24-hour reminder before the appointment.
- Waitlist notification when a slot opens up.
- Staff feedback/rating submissions emailed directly to the owner (Pro).

## 11. Open Items / Deferred to Later Phases

- Staff login and in-app schedule access (schema exists; feature deferred).
- Multi-staff live scheduling on the public booking page (staff filter: All / Staff 1 / Staff 2).
- Deposits / no-show protection via Paddle-held payment at booking time.
- WhatsApp/SMS reminders with explicit per-customer opt-in (regulatory: TCPA/GDPR-style consent required depending on region).
- Custom domain mapping (owner's own URL instead of the platform subdomain).
