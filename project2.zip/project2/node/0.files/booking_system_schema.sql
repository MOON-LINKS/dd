-- ============================================================
-- BEAUTY CENTER / CLINIC BOOKING SYSTEM — MySQL schema
-- (Laragon / MySQL 8+)
-- ============================================================
-- Notes on design choices:
--   * All money columns are DECIMAL with a paired currency enum
--     ('USD','LBP') — never a shared float across currencies.
--   * Every payment/expense row stores the exchange rate used AT
--     THAT MOMENT, so historical analytics never drift when the
--     live rate changes later.
--   * Soft-archive pattern (not hard DELETE) for retention, so
--     Pro's 2-year window and Standard's 1-year window can both
--     be honored by the same cron job.
--   * Sessions are backed by both this table (source of truth /
--     auditability) and Redis (fast revocation check) — see
--     application-layer notes at the bottom of §Sessions.
-- ============================================================

CREATE DATABASE IF NOT EXISTS booking_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE booking_system;

-- ------------------------------------------------------------
-- PLANS & SUBSCRIPTIONS
-- ------------------------------------------------------------

CREATE TABLE plans (
    id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code                    ENUM('standard', 'pro') NOT NULL UNIQUE,
    name                    VARCHAR(50) NOT NULL,
    price_monthly_usd       DECIMAL(10,2) NOT NULL,
    price_yearly_usd        DECIMAL(10,2) NOT NULL,
    max_staff               INT UNSIGNED NULL,               -- NULL = unlimited, 0 = staff feature locked (standard)
    backup_retention_days   INT UNSIGNED NOT NULL DEFAULT 365, -- 730 for pro
    removes_branding        TINYINT(1) NOT NULL DEFAULT 0,
    support_247             TINYINT(1) NOT NULL DEFAULT 0,
    catalogue_enabled_default TINYINT(1) NOT NULL DEFAULT 0,
    staff_ratings_enabled_default TINYINT(1) NOT NULL DEFAULT 0,
    created_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    agency_name         VARCHAR(63) NOT NULL UNIQUE,     -- subdomain-safe: enforce format server-side too
    email               VARCHAR(255) NOT NULL UNIQUE,
    password_hash       VARCHAR(255) NOT NULL,           -- bcryptjs
    full_name           VARCHAR(150) NOT NULL,
    phone               VARCHAR(30) NULL,
    locale              ENUM('en','ar','fr') NOT NULL DEFAULT 'en',
    theme               ENUM('light','dark') NOT NULL DEFAULT 'light',
    paddle_customer_id  VARCHAR(100) NULL UNIQUE,
    has_used_free_trial TINYINT(1) NOT NULL DEFAULT 0,
    is_active           TINYINT(1) NOT NULL DEFAULT 1,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_agency_name_format CHECK (agency_name REGEXP '^[a-z][a-z0-9-]*[a-z]$')
) ENGINE=InnoDB;

CREATE TABLE subscriptions (
    id                      BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id                 BIGINT UNSIGNED NOT NULL,
    plan_id                 INT UNSIGNED NOT NULL,
    paddle_subscription_id  VARCHAR(100) NULL UNIQUE,
    billing_cycle           ENUM('monthly','yearly') NOT NULL,
    is_active               TINYINT(1) NOT NULL DEFAULT 1,
    is_cancelled            TINYINT(1) NOT NULL DEFAULT 0,   -- owner-intent flag, separate from is_active
    auto_renew              TINYINT(1) NOT NULL DEFAULT 1,
    started_at              DATETIME NOT NULL,
    current_period_end      DATETIME NOT NULL,
    grace_period_end        DATETIME NULL,                   -- current_period_end + 5 days
    was_free_trial          TINYINT(1) NOT NULL DEFAULT 0,
    created_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES plans(id),
    INDEX idx_active_sub_per_user (user_id, is_active)
    -- App layer enforces "no two active subscriptions per user" on insert/update
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- SESSIONS (Instagram-style persistent login, Redis-backed)
-- ------------------------------------------------------------
-- This table is the durable/auditable record of every session.
-- Redis holds the same session keyed by session_token for fast
-- per-request revocation checks (auth middleware checks Redis
-- first; this table is written on create/revoke and used for
-- "show my devices" / audit purposes).

CREATE TABLE user_sessions (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,
    session_token   VARCHAR(255) NOT NULL UNIQUE,       -- opaque token stored in the HTTP-only cookie; mirrors Redis key
    user_agent      VARCHAR(255) NULL,
    ip_address      VARCHAR(45) NULL,                   -- IPv4/IPv6
    platform        ENUM('web','desktop','mobile') NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    revoked_at      DATETIME NULL,                      -- set on logout; set for ALL rows on logout-all
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sessions_user_active (user_id, revoked_at)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- STAFF (Pro-gated; login/app access deferred to a later phase)
-- ------------------------------------------------------------

CREATE TABLE staff (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(150) NOT NULL,
    email           VARCHAR(255) NULL,
    phone           VARCHAR(30) NULL,
    password_hash   VARCHAR(255) NULL,                  -- reserved for future staff login; unused at launch
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE user_staff (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,          -- owner
    staff_id        BIGINT UNSIGNED NOT NULL,
    role_label      VARCHAR(50) NULL,                  -- e.g. "Senior stylist"
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
    UNIQUE KEY uq_user_staff (user_id, staff_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- CATEGORIES & SERVICES
-- ------------------------------------------------------------

CREATE TABLE categories (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,
    name            VARCHAR(100) NOT NULL,
    sort_order      INT UNSIGNED NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE services (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id         BIGINT UNSIGNED NOT NULL,
    name                VARCHAR(150) NOT NULL,
    duration_minutes    SMALLINT UNSIGNED NOT NULL,
    buffer_minutes      SMALLINT UNSIGNED NOT NULL DEFAULT 0,  -- auto-applied after the booking
    price_value          DECIMAL(10,2) NULL,
    price_currency       ENUM('USD','LBP') NULL,
    is_active            TINYINT(1) NOT NULL DEFAULT 1,
    created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- HOURS: weekly template + one-off exceptions
-- ------------------------------------------------------------

CREATE TABLE weekly_hours (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,
    staff_id        BIGINT UNSIGNED NULL,             -- NULL = business-wide default
    day_of_week     TINYINT UNSIGNED NOT NULL,        -- 0=Sunday..6=Saturday
    open_time       TIME NULL,
    close_time      TIME NULL,
    is_closed       TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
    UNIQUE KEY uq_weekly (user_id, staff_id, day_of_week)
) ENGINE=InnoDB;

CREATE TABLE schedule_exceptions (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id             BIGINT UNSIGNED NOT NULL,
    staff_id            BIGINT UNSIGNED NULL,
    exception_date      DATE NOT NULL,
    is_closed           TINYINT(1) NOT NULL DEFAULT 0,
    custom_open_time    TIME NULL,
    custom_close_time   TIME NULL,
    reason              VARCHAR(255) NULL,             -- "emergency", "holiday", etc.
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
    INDEX idx_exception_lookup (user_id, exception_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- CLIENTS
-- ------------------------------------------------------------

CREATE TABLE clients (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email           VARCHAR(255) NULL UNIQUE,          -- NULL for guests who never provide one
    phone           VARCHAR(30) NULL,
    full_name       VARCHAR(150) NOT NULL,
    password_hash   VARCHAR(255) NULL,                 -- set only if the client created an account
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_client_phone (phone),
    INDEX idx_client_name (full_name)
) ENGINE=InnoDB;

CREATE TABLE user_client (
    id                      BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id                 BIGINT UNSIGNED NOT NULL,
    client_id               BIGINT UNSIGNED NOT NULL,
    visit_count              INT UNSIGNED NOT NULL DEFAULT 0,
    loyalty_discount_pct     DECIMAL(5,2) NULL,          -- snapshot of owner's current offer, if any
    first_visit_at           DATETIME NULL,
    last_visit_at            DATETIME NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    UNIQUE KEY uq_user_client (user_id, client_id)
) ENGINE=InnoDB;

CREATE TABLE loyalty_settings (
    user_id             BIGINT UNSIGNED PRIMARY KEY,
    visits_required     INT UNSIGNED NOT NULL DEFAULT 6,
    discount_pct        DECIMAL(5,2) NOT NULL DEFAULT 10.00,
    is_enabled          TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- BOOKINGS (appointments)
-- ------------------------------------------------------------

CREATE TABLE bookings (
    id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id             BIGINT UNSIGNED NOT NULL,          -- owner/business
    staff_id            BIGINT UNSIGNED NULL,              -- Pro only
    client_id           BIGINT UNSIGNED NULL,              -- NULL if guest with no account
    guest_name          VARCHAR(150) NULL,                 -- filled when client_id is NULL
    guest_phone         VARCHAR(30) NULL,
    start_time          DATETIME NOT NULL,
    end_time            DATETIME NOT NULL,                 -- = start + sum(service durations) + buffer
    status              ENUM('pending','confirmed','cancelled','completed','no_show') NOT NULL DEFAULT 'pending',
    paid_value          DECIMAL(12,2) NULL,
    paid_currency       ENUM('USD','LBP') NULL,
    paid_usd_lbp_rate   DECIMAL(12,2) NULL,                -- rate snapshot at time of payment
    paid_at             DATETIME NULL,
    reminder_sent_at    DATETIME NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
    -- Concurrency safeguard: makes a duplicate booking for the same owner+staff+slot
    -- impossible at the storage layer, regardless of application-level races.
    UNIQUE KEY uq_slot_lock (user_id, staff_id, start_time),
    INDEX idx_booking_range (user_id, start_time)
) ENGINE=InnoDB;

CREATE TABLE booking_services (
    id                              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_id                      BIGINT UNSIGNED NOT NULL,
    service_id                      BIGINT UNSIGNED NOT NULL,
    duration_minutes_at_booking     SMALLINT UNSIGNED NOT NULL,  -- snapshot so later service edits don't rewrite history
    price_value_at_booking          DECIMAL(10,2) NULL,
    price_currency_at_booking       ENUM('USD','LBP') NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id)
) ENGINE=InnoDB;

CREATE TABLE waitlist (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,
    name            VARCHAR(150) NOT NULL,
    phone           VARCHAR(30) NOT NULL,
    email           VARCHAR(255) NULL,
    requested_date  DATE NOT NULL,
    notified_at     DATETIME NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_waitlist_date (user_id, requested_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- EXPENSES
-- ------------------------------------------------------------

CREATE TABLE expenses (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,
    label           VARCHAR(150) NOT NULL,
    value           DECIMAL(12,2) NOT NULL,
    currency        ENUM('USD','LBP') NOT NULL,
    usd_lbp_rate    DECIMAL(12,2) NOT NULL,            -- rate snapshot at time of entry
    expense_date    DATE NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_expense_month (user_id, expense_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- EXCHANGE RATE — live-updating, used only to convert TODAY'S
-- figures; every past transaction already carries its own
-- snapshot rate (see bookings.paid_usd_lbp_rate, expenses.usd_lbp_rate)
-- ------------------------------------------------------------

CREATE TABLE exchange_rates (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usd_to_lbp      DECIMAL(12,2) NOT NULL,
    effective_at    DATETIME NOT NULL,
    source          VARCHAR(100) NULL,                 -- which feed/API set this rate
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_rate_effective (effective_at)
) ENGINE=InnoDB;
-- App layer: a scheduled job updates this table periodically (e.g. hourly/daily);
-- the current rate = the row with the latest effective_at.

-- ------------------------------------------------------------
-- ANALYTICS: pre-aggregated daily rollup, written whenever a
-- booking is paid or an expense is added, so the analytics page
-- never has to run heavy aggregation queries live.
-- ------------------------------------------------------------

CREATE TABLE daily_summary (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,
    summary_date    DATE NOT NULL,
    revenue_usd     DECIMAL(12,2) NOT NULL DEFAULT 0,
    revenue_lbp     DECIMAL(14,2) NOT NULL DEFAULT 0,
    expenses_usd    DECIMAL(12,2) NOT NULL DEFAULT 0,
    expenses_lbp    DECIMAL(14,2) NOT NULL DEFAULT 0,
    bookings_count  INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uq_daily_summary (user_id, summary_date)
) ENGINE=InnoDB;
-- net_usd / net_lbp = revenue - expenses, computed at query time (no need to store)

-- ------------------------------------------------------------
-- BIO PAGE / PUBLIC APPEARANCE
-- ------------------------------------------------------------

CREATE TABLE bio_pages (
    user_id             BIGINT UNSIGNED PRIMARY KEY,
    logo_url            VARCHAR(500) NULL,
    banner_url          VARCHAR(500) NULL,
    bio_text            TEXT NULL,
    social_links        JSON NULL,                     -- {"instagram": "...", "tiktok": "..."}
    bg_color            VARCHAR(7) NULL,
    accent_color        VARCHAR(7) NULL,
    show_powered_by     TINYINT(1) NOT NULL DEFAULT 1,  -- forced 0 automatically when plan = pro
    catalogue_enabled   TINYINT(1) NOT NULL DEFAULT 0,  -- pro-only price catalogue block
    ratings_enabled     TINYINT(1) NOT NULL DEFAULT 0,  -- pro-only staff ratings/feedback
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE catalogue_items (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,
    name            VARCHAR(150) NOT NULL,              -- e.g. a nail polish shade
    price_value     DECIMAL(10,2) NULL,
    price_currency  ENUM('USD','LBP') NULL,
    image_url       VARCHAR(500) NULL,
    sort_order      INT UNSIGNED NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- STAFF RATINGS (Pro) — client feedback on a staff member,
-- emailed directly to the owner on submission.
-- ------------------------------------------------------------

CREATE TABLE staff_ratings (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,           -- owner/business, for quick scoping
    staff_id        BIGINT UNSIGNED NOT NULL,
    booking_id      BIGINT UNSIGNED NULL,               -- optional link to the appointment being rated
    client_id       BIGINT UNSIGNED NULL,               -- NULL if a guest submitted it
    rating          TINYINT UNSIGNED NOT NULL,          -- e.g. 1-5
    comment         TEXT NULL,
    emailed_at      DATETIME NULL,                      -- when the owner-notification email was sent
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
    CONSTRAINT chk_rating_range CHECK (rating BETWEEN 1 AND 5),
    INDEX idx_ratings_staff (staff_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- AUDIT LOG (schedule/booking changes — cheap insurance once
-- more than one actor, owner or staff, can touch a calendar)
-- ------------------------------------------------------------

CREATE TABLE audit_log (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED NOT NULL,
    actor_type      ENUM('owner','staff','system') NOT NULL,
    actor_id        BIGINT UNSIGNED NULL,
    action          VARCHAR(100) NOT NULL,              -- e.g. "booking.cancel", "hours.exception_added"
    entity_type     VARCHAR(50) NOT NULL,
    entity_id       BIGINT UNSIGNED NULL,
    meta            JSON NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_lookup (user_id, created_at)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- ARCHIVE TABLE + PLAN-AWARE RETENTION
-- ------------------------------------------------------------
-- bookings older than the owner's plan-specific retention window
-- get MOVED here (not deleted), then purged from archive once the
-- FULL retention window has passed. Standard = 1 year total,
-- Pro = 2 years total — both driven by plans.backup_retention_days.

CREATE TABLE bookings_archive LIKE bookings;

-- ------------------------------------------------------------
-- Example cron logic (run monthly or biweekly):
--
-- For each user:
--   1. Look up their current plan's `backup_retention_days`
--      (join subscriptions -> plans; 365 for standard, 730 for pro).
--   2. Move bookings older than that window into archive:
--        INSERT INTO bookings_archive
--        SELECT * FROM bookings
--        WHERE user_id = ? AND start_time < NOW() - INTERVAL @retention_days DAY;
--
--        DELETE FROM bookings
--        WHERE user_id = ? AND start_time < NOW() - INTERVAL @retention_days DAY;
--
--   3. Purge from archive once the SAME window has passed again
--      since the row was archived (i.e. fully past retention):
--        DELETE FROM bookings_archive
--        WHERE user_id = ? AND start_time < NOW() - INTERVAL @retention_days DAY;
--
-- This keeps the live `bookings` table small and fast for both
-- plans, while Pro rows simply survive twice as long before the
-- final purge — satisfying the 1-year / 2-year split from a
-- single shared job rather than two separate code paths.
-- ------------------------------------------------------------
