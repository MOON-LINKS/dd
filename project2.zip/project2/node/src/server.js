const http = require('http');

const config = require('./config/env');
const logger = require('./utils/logger');
const createApp = require('./app');
const initSocket = require('./sockets/index');
const { testConnection } = require('./config/db');
const { connectRedis } = require('./config/redis');

async function start() {
  await testConnection();
  await connectRedis();

  const app = createApp();
  const httpServer = http.createServer(app);

  // Socket.io attaches to the same HTTP server/port as the REST API —
  // simpler ops, and the two share the CORS/origin trust list.
  initSocket(httpServer);

  httpServer.listen(config.port, () => {
    logger.info(`Server listening on port ${config.port} [${config.nodeEnv}]`);
  });

  process.on('unhandledRejection', (reason) => {
    logger.error('Unhandled promise rejection', reason);
  });
  process.on('SIGTERM', () => {
    logger.info('SIGTERM received, shutting down');
    httpServer.close(() => process.exit(0));
  });
}

start().catch((err) => {
  logger.error('Failed to start server', err);
  process.exit(1);
});
