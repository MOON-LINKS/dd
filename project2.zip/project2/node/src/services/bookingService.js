const AppError = require('../utils/AppError');
const { withTransaction } = require('../config/db');
const bookingModel = require('../models/bookingModel');
const availabilityService = require('../services/availabilityService');
const { getIO } = require('../sockets/index');

// Staff scheduling is deferred — same STAFF_ID = null convention as
// scheduleService.js and availabilityService.js.
const STAFF_ID = null;

const ACTIVE_STATUSES = new Set(['pending', 'confirmed']);
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

function assertValidDate(value, fieldName) {
  if (typeof value !== 'string' || !DATE_REGEX.test(value) || Number.isNaN(Date.parse(value))) {
    throw AppError.badRequest(`${fieldName} must be a date in YYYY-MM-DD format.`, 'INVALID_DATE');
  }
}

/**
 * Emits to the owner's private dashboard room (full detail) and, for
 * events that change what's bookable, to the public room too (sanitized —
 * just enough for the slot picker to know to refetch). Never a no-op
 * failure for the caller: if sockets aren't up (io is null, e.g. a script
 * context), this is skipped silently rather than throwing, since a missed
 * live-update is not a reason to fail the booking itself.
 * @param {number} userId
 * @param {string} event
 * @param {object} ownerPayload
 * @param {object} [publicPayload]
 */
function emitBookingEvent(userId, event, ownerPayload, publicPayload) {
  const io = getIO();
  if (!io) return;
  io.to(`owner:${userId}`).emit(event, ownerPayload);
  if (publicPayload) {
    io.to(`public:${userId}`).emit('slot:updated', publicPayload);
  }
}

/**
 * Attaches each booking's services (snapshot rows) to the booking object.
 * Simple per-booking round trip — fine at dashboard scale; batch this
 * with a single IN-clause query if the calendar view ever needs to load
 * hundreds of bookings at once.
 * @param {object} booking
 */
async function attachServices(booking) {
  const services = await bookingModel.findServicesForBooking(booking.id);
  return { ...booking, services };
}

/**
 * Loads a booking and throws unless it exists and belongs to userId.
 * @param {number} id
 * @param {number} userId
 * @returns {Promise<object>}
 */
async function loadOwnedBooking(id, userId) {
  const booking = await bookingModel.findById(id);
  if (!booking || booking.user_id !== userId) {
    throw AppError.notFound('Booking not found.', 'BOOKING_NOT_FOUND');
  }
  return booking;
}

/**
 * Read-only slot picker query — public, unauthenticated.
 * @param {number} userId
 * @param {object} params
 * @param {string} params.date
 * @param {number[]} params.serviceIds
 */
async function getAvailability(userId, { date, serviceIds }) {
  return availabilityService.getAvailableSlots(userId, { date, serviceIds });
}

/**
 * Creates a booking. Public endpoint — reachable unauthenticated, so this
 * is the core of spec §5.1's double-booking defense: availability is
 * re-validated authoritatively (not trusted from the client), the overlap
 * check + INSERT run in one transaction, and the DB's `uq_slot_lock`
 * unique constraint is the final backstop if two requests still race past
 * the application-level check.
 *
 * Guest-only for now (`guestName` + `guestPhone`, no `clientId`) — per the
 * Batch 4 plan, account-linked bookings and returning-guest matching land
 * with the Client module (Batch 5). `bookings.client_id` stays NULL here.
 *
 * @param {number} userId - the business (owner) being booked
 * @param {object} input
 * @param {string} input.startTime - full ISO datetime
 * @param {number[]} input.serviceIds
 * @param {string} input.guestName
 * @param {string} input.guestPhone
 * @returns {Promise<object>} the created booking, with its services attached
 */
async function createBooking(userId, { startTime, serviceIds, guestName, guestPhone }) {
  if (typeof guestName !== 'string' || !guestName.trim()) {
    throw AppError.badRequest('guestName is required.', 'MISSING_GUEST_NAME');
  }
  if (typeof guestPhone !== 'string' || !guestPhone.trim()) {
    throw AppError.badRequest('guestPhone is required.', 'MISSING_GUEST_PHONE');
  }

  const { services, startTime: start, endTime: end } = await availabilityService.validateRequestedSlot(
    userId,
    { startTimeIso: startTime, serviceIds }
  );

  let bookingId;
  try {
    bookingId = await withTransaction(async (conn) => {
      // Overlap re-check inside the transaction — catches conflicts
      // between differently-timed/differently-durationed services that
      // the DB's exact-start-time unique constraint alone wouldn't
      // catch. See the decision note in bookingModel.findOverlapping.
      const conflict = await bookingModel.findOverlapping(conn, {
        userId,
        staffId: STAFF_ID,
        startTime: start,
        endTime: end,
      });
      if (conflict) {
        throw AppError.conflict(
          'That slot was just booked by someone else. Please pick another time.',
          'SLOT_TAKEN'
        );
      }

      const id = await bookingModel.createBooking(conn, {
        userId,
        staffId: STAFF_ID,
        clientId: null,
        guestName: guestName.trim(),
        guestPhone: guestPhone.trim(),
        startTime: start,
        endTime: end,
        // No owner-approval workflow exists yet, so a validated public
        // booking is confirmed immediately rather than left 'pending'.
        status: 'confirmed',
      });

      await bookingModel.addBookingServices(
        conn,
        id,
        services.map((s) => ({
          serviceId: s.id,
          durationMinutes: s.duration_minutes,
          priceValue: s.price_value,
          priceCurrency: s.price_currency,
        }))
      );

      return id;
    });
  } catch (err) {
    // Final backstop: two requests raced past the in-transaction overlap
    // check (extremely narrow window) and both hit the exact same
    // start_time — the DB constraint rejects the loser, which we surface
    // the same way as the application-level conflict above.
    if (err && err.code === 'ER_DUP_ENTRY') {
      throw AppError.conflict(
        'That slot was just booked by someone else. Please pick another time.',
        'SLOT_TAKEN'
      );
    }
    throw err;
  }

  const booking = await attachServices(await bookingModel.findById(bookingId));
  emitBookingEvent(userId, 'booking:created', { booking }, { date: startTime.slice(0, 10) });
  return booking;
}

/**
 * Owner dashboard calendar view.
 * @param {number} userId
 * @param {string} from - 'YYYY-MM-DD' inclusive
 * @param {string} to - 'YYYY-MM-DD' inclusive
 */
async function listBookings(userId, from, to) {
  assertValidDate(from, 'from');
  assertValidDate(to, 'to');
  if (from > to) {
    throw AppError.badRequest('from must not be after to.', 'INVALID_RANGE');
  }
  const rangeStart = new Date(`${from}T00:00:00.000Z`);
  const rangeEnd = new Date(`${to}T23:59:59.999Z`);
  const bookings = await bookingModel.findByUserInRange(userId, rangeStart, rangeEnd);
  return Promise.all(bookings.map(attachServices));
}

/**
 * Owner action — cancels a booking. Waitlist notification (spec §5) is
 * deferred to Batch 5, which introduces the waitlist model itself.
 * @param {number} id
 * @param {number} userId
 */
async function cancelBooking(id, userId) {
  const booking = await loadOwnedBooking(id, userId);
  if (booking.status === 'cancelled') {
    throw AppError.conflict('Booking is already cancelled.', 'ALREADY_CANCELLED');
  }
  if (booking.status === 'completed') {
    throw AppError.conflict('A completed booking cannot be cancelled.', 'INVALID_STATUS_TRANSITION');
  }

  await bookingModel.updateStatus(id, 'cancelled');
  const updated = await attachServices(await bookingModel.findById(id));
  emitBookingEvent(
    userId,
    'booking:cancelled',
    { booking: updated },
    { date: new Date(booking.start_time).toISOString().slice(0, 10) }
  );
  return updated;
}

/**
 * Owner action — marks a booking completed (post-appointment).
 * @param {number} id
 * @param {number} userId
 */
async function completeBooking(id, userId) {
  const booking = await loadOwnedBooking(id, userId);
  if (!ACTIVE_STATUSES.has(booking.status)) {
    throw AppError.conflict(
      `A booking with status "${booking.status}" cannot be marked completed.`,
      'INVALID_STATUS_TRANSITION'
    );
  }

  await bookingModel.updateStatus(id, 'completed');
  const updated = await attachServices(await bookingModel.findById(id));
  emitBookingEvent(userId, 'booking:completed', { booking: updated });
  return updated;
}

/**
 * Owner action — moves a booking to a new start time, keeping its
 * existing service selection (and therefore its existing blockMinutes —
 * re-derived from the booking's own snapshot rows, not re-fetched from
 * the live services table, so a service edited/deactivated after this
 * booking was made doesn't block rescheduling it).
 * @param {number} id
 * @param {number} userId
 * @param {string} newStartTimeIso
 */
async function rescheduleBooking(id, userId, newStartTimeIso) {
  const booking = await loadOwnedBooking(id, userId);
  if (!ACTIVE_STATUSES.has(booking.status)) {
    throw AppError.conflict(
      `A booking with status "${booking.status}" cannot be rescheduled.`,
      'INVALID_STATUS_TRANSITION'
    );
  }
  if (typeof newStartTimeIso !== 'string' || Number.isNaN(Date.parse(newStartTimeIso))) {
    throw AppError.badRequest('startTime must be a valid ISO datetime.', 'INVALID_START_TIME');
  }

  const existingServices = await bookingModel.findServicesForBooking(id);
  const blockMinutes = existingServices.reduce(
    (sum, s) => sum + s.duration_minutes_at_booking,
    0
  );
  if (blockMinutes === 0) {
    throw AppError.conflict('Booking has no services to preserve a duration for.', 'NO_SERVICES');
  }

  const date = newStartTimeIso.slice(0, 10);
  assertValidDate(date, 'startTime');
  const window = await availabilityService.resolveDayWindow(userId, date);
  if (!window) {
    throw AppError.conflict('The business is closed on the selected date.', 'DAY_CLOSED');
  }

  const newStart = new Date(newStartTimeIso);
  if (newStart.getTime() <= Date.now()) {
    throw AppError.badRequest('startTime must be in the future.', 'START_IN_PAST');
  }
  const newEnd = new Date(newStart.getTime() + blockMinutes * 60000);

  await withTransaction(async (conn) => {
    const conflict = await bookingModel.findOverlapping(conn, {
      userId,
      staffId: STAFF_ID,
      startTime: newStart,
      endTime: newEnd,
      excludeBookingId: id,
    });
    if (conflict) {
      throw AppError.conflict('That slot is already taken.', 'SLOT_TAKEN');
    }
    await bookingModel.updateTimes(conn, id, { startTime: newStart, endTime: newEnd });
  });

  const updated = await attachServices(await bookingModel.findById(id));
  const oldDate = new Date(booking.start_time).toISOString().slice(0, 10);
  emitBookingEvent(userId, 'booking:rescheduled', { booking: updated }, { date: oldDate });
  if (date !== oldDate) {
    emitBookingEvent(userId, 'booking:rescheduled', { booking: updated }, { date });
  }
  return updated;
}

/**
 * Owner action — reserves a span of the calendar with no client attached
 * (per the dashboard's block-time control, spec §8.2). Skips the
 * business-hours check that a client booking gets, since the owner may
 * deliberately want to block outside normal hours (e.g. an emergency
 * closure); still checked for overlap against existing bookings so it
 * can't silently swallow an already-booked slot.
 * @param {number} userId
 * @param {object} input
 * @param {string} input.startTime - full ISO datetime
 * @param {string} input.endTime - full ISO datetime
 * @param {string} [input.reason]
 */
async function blockTime(userId, { startTime, endTime, reason }) {
  if (typeof startTime !== 'string' || Number.isNaN(Date.parse(startTime))) {
    throw AppError.badRequest('startTime must be a valid ISO datetime.', 'INVALID_START_TIME');
  }
  if (typeof endTime !== 'string' || Number.isNaN(Date.parse(endTime))) {
    throw AppError.badRequest('endTime must be a valid ISO datetime.', 'INVALID_END_TIME');
  }
  const start = new Date(startTime);
  const end = new Date(endTime);
  if (end <= start) {
    throw AppError.badRequest('endTime must be after startTime.', 'INVALID_RANGE');
  }

  const bookingId = await withTransaction(async (conn) => {
    const conflict = await bookingModel.findOverlapping(conn, {
      userId,
      staffId: STAFF_ID,
      startTime: start,
      endTime: end,
    });
    if (conflict) {
      throw AppError.conflict('That time overlaps an existing booking.', 'SLOT_TAKEN');
    }
    return bookingModel.createBooking(conn, {
      userId,
      staffId: STAFF_ID,
      clientId: null,
      guestName: reason && reason.trim() ? `Blocked: ${reason.trim()}` : 'Blocked',
      guestPhone: null,
      startTime: start,
      endTime: end,
      status: 'confirmed',
    });
  });

  const booking = await attachServices(await bookingModel.findById(bookingId));
  emitBookingEvent(
    userId,
    'booking:created',
    { booking },
    { date: startTime.slice(0, 10) }
  );
  return booking;
}

module.exports = {
  getAvailability,
  createBooking,
  listBookings,
  cancelBooking,
  completeBooking,
  rescheduleBooking,
  blockTime,
};
