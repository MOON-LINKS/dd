const AppError = require('../utils/AppError');
const categoryModel = require('../models/categoryModel');
const serviceModel = require('../models/serviceModel');

const NAME_MAX_LENGTH = 150;
const MAX_DURATION_MINUTES = 1440; // one full day — generous ceiling, not a real-world expectation
const MAX_BUFFER_MINUTES = 480;
const VALID_CURRENCIES = ['USD', 'LBP'];

/**
 * Shared shape/range checks. `partial` skips required-field checks for
 * updates, where only the supplied fields are validated.
 */
function assertValidFields(
  { name, durationMinutes, bufferMinutes, priceValue, priceCurrency },
  { partial } = { partial: false }
) {
  if (!partial || name !== undefined) {
    if (!name || !name.trim()) {
      throw AppError.badRequest('Service name is required.', 'INVALID_SERVICE_NAME');
    }
    if (name.trim().length > NAME_MAX_LENGTH) {
      throw AppError.badRequest(
        `Service name must be ${NAME_MAX_LENGTH} characters or fewer.`,
        'INVALID_SERVICE_NAME'
      );
    }
  }

  if (!partial || durationMinutes !== undefined) {
    if (
      !Number.isInteger(durationMinutes) ||
      durationMinutes <= 0 ||
      durationMinutes > MAX_DURATION_MINUTES
    ) {
      throw AppError.badRequest(
        `Duration must be a whole number of minutes between 1 and ${MAX_DURATION_MINUTES}.`,
        'INVALID_DURATION'
      );
    }
  }

  if (bufferMinutes !== undefined) {
    if (
      !Number.isInteger(bufferMinutes) ||
      bufferMinutes < 0 ||
      bufferMinutes > MAX_BUFFER_MINUTES
    ) {
      throw AppError.badRequest(
        `Buffer must be a whole number of minutes between 0 and ${MAX_BUFFER_MINUTES}.`,
        'INVALID_BUFFER'
      );
    }
  }

  // price_value and price_currency are independently nullable in the schema,
  // but a price only makes sense with a currency attached — enforce that
  // pairing here even though the DB doesn't.
  const priceValueGiven = priceValue !== undefined && priceValue !== null;
  const priceCurrencyGiven = priceCurrency !== undefined && priceCurrency !== null;
  if (priceValueGiven !== priceCurrencyGiven) {
    throw AppError.badRequest(
      'price_value and price_currency must be provided together, or both omitted.',
      'INVALID_PRICE'
    );
  }
  if (priceValueGiven && (typeof priceValue !== 'number' || priceValue < 0)) {
    throw AppError.badRequest('price_value must be a non-negative number.', 'INVALID_PRICE');
  }
  if (priceCurrencyGiven && !VALID_CURRENCIES.includes(priceCurrency)) {
    throw AppError.badRequest(
      `price_currency must be one of: ${VALID_CURRENCIES.join(', ')}.`,
      'INVALID_PRICE'
    );
  }
}

/**
 * Loads a category and throws unless it exists and belongs to userId —
 * used to check ownership before attaching a service to it.
 * @param {number} categoryId
 * @param {number} userId
 */
async function assertOwnsCategory(categoryId, userId) {
  const category = await categoryModel.findById(categoryId);
  if (!category || category.user_id !== userId) {
    throw AppError.badRequest('Category not found.', 'CATEGORY_NOT_FOUND');
  }
}

/**
 * Loads a service and throws unless it exists and belongs (via its
 * category) to userId. Every mutating operation below goes through this.
 * @param {number} id
 * @param {number} userId
 * @returns {Promise<object>}
 */
async function loadOwnedService(id, userId) {
  const service = await serviceModel.findByIdWithOwner(id);
  if (!service || service.owner_user_id !== userId) {
    throw AppError.notFound('Service not found.', 'SERVICE_NOT_FOUND');
  }
  return service;
}

/**
 * @param {number} userId
 * @returns {Promise<object[]>}
 */
async function listServices(userId) {
  return serviceModel.findAllByUser(userId);
}

/**
 * @param {number} userId
 * @param {object} input
 */
async function createService(userId, input) {
  const name = (input.name || '').trim();
  const { categoryId, durationMinutes, bufferMinutes = 0, priceValue = null, priceCurrency = null } =
    input;

  if (!Number.isInteger(categoryId)) {
    throw AppError.badRequest('categoryId is required.', 'INVALID_CATEGORY_ID');
  }
  assertValidFields({ name, durationMinutes, bufferMinutes, priceValue, priceCurrency });
  await assertOwnsCategory(categoryId, userId);

  const id = await serviceModel.createService({
    categoryId,
    name,
    durationMinutes,
    bufferMinutes,
    priceValue,
    priceCurrency,
  });
  return serviceModel.findByIdWithOwner(id);
}

/**
 * @param {number} id
 * @param {number} userId
 * @param {object} input - only supplied fields are changed
 */
async function updateService(id, userId, input) {
  await loadOwnedService(id, userId);

  const fields = { ...input };
  if (fields.name !== undefined) fields.name = fields.name.trim();
  assertValidFields(fields, { partial: true });

  if (fields.categoryId !== undefined) {
    if (!Number.isInteger(fields.categoryId)) {
      throw AppError.badRequest('categoryId must be an integer.', 'INVALID_CATEGORY_ID');
    }
    await assertOwnsCategory(fields.categoryId, userId);
  }

  await serviceModel.updateService(id, fields);
  return serviceModel.findByIdWithOwner(id);
}

/**
 * Hides a service from the booking flow without deleting its history.
 * @param {number} id
 * @param {number} userId
 * @param {boolean} isActive
 */
async function setActive(id, userId, isActive) {
  await loadOwnedService(id, userId);
  await serviceModel.setActive(id, isActive);
  return serviceModel.findByIdWithOwner(id);
}

/**
 * Permanently removes a service. Fine today since no other table
 * references `services` yet (Batch 4 introduces `booking_services`) —
 * revisit whether this should become "deactivate only" once bookings can
 * point at a service, so a deleted service doesn't orphan booking history.
 * @param {number} id
 * @param {number} userId
 */
async function deleteService(id, userId) {
  await loadOwnedService(id, userId);
  await serviceModel.deleteService(id);
}

module.exports = { listServices, createService, updateService, setActive, deleteService };
