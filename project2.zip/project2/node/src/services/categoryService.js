const AppError = require('../utils/AppError');
const { withTransaction } = require('../config/db');
const categoryModel = require('../models/categoryModel');

const NAME_MAX_LENGTH = 100;

function assertValidName(name) {
  if (!name || !name.trim()) {
    throw AppError.badRequest('Category name is required.', 'INVALID_CATEGORY_NAME');
  }
  if (name.trim().length > NAME_MAX_LENGTH) {
    throw AppError.badRequest(
      `Category name must be ${NAME_MAX_LENGTH} characters or fewer.`,
      'INVALID_CATEGORY_NAME'
    );
  }
}

/**
 * Loads a category and throws if it doesn't exist or belong to userId.
 * Every mutating operation below goes through this first.
 * @param {number} id
 * @param {number} userId
 * @returns {Promise<object>}
 */
async function loadOwnedCategory(id, userId) {
  const category = await categoryModel.findById(id);
  if (!category || category.user_id !== userId) {
    throw AppError.notFound('Category not found.', 'CATEGORY_NOT_FOUND');
  }
  return category;
}

/**
 * @param {number} userId
 * @returns {Promise<object[]>}
 */
async function listCategories(userId) {
  return categoryModel.findAllByUser(userId);
}

/**
 * New categories are appended to the end of the owner's current order.
 * @param {number} userId
 * @param {string} name
 */
async function createCategory(userId, name) {
  const trimmedName = (name || '').trim();
  assertValidName(trimmedName);

  const existing = await categoryModel.findAllByUser(userId);
  const nextSortOrder = existing.length;

  const id = await categoryModel.createCategory({
    userId,
    name: trimmedName,
    sortOrder: nextSortOrder,
  });
  return categoryModel.findById(id);
}

/**
 * @param {number} id
 * @param {number} userId
 * @param {string} name
 */
async function renameCategory(id, userId, name) {
  const trimmedName = (name || '').trim();
  assertValidName(trimmedName);
  await loadOwnedCategory(id, userId);

  await categoryModel.updateCategory(id, { name: trimmedName });
  return categoryModel.findById(id);
}

/**
 * @param {number} id
 * @param {number} userId
 */
async function deleteCategory(id, userId) {
  await loadOwnedCategory(id, userId);
  // Cascades to the category's services at the DB level (ON DELETE CASCADE).
  await categoryModel.deleteCategory(id);
}

/**
 * Reorders every category for a user in one shot — the dashboard's drag-
 * and-drop list sends the full ordered list of ids each time.
 * @param {number} userId
 * @param {number[]} orderedIds
 */
async function reorderCategories(userId, orderedIds) {
  if (!Array.isArray(orderedIds) || orderedIds.length === 0) {
    throw AppError.badRequest('orderedIds must be a non-empty array.', 'INVALID_ORDER');
  }

  const existing = await categoryModel.findAllByUser(userId);
  const existingIds = new Set(existing.map((c) => c.id));
  const uniqueOrderedIds = new Set(orderedIds);

  if (
    orderedIds.length !== existing.length ||
    uniqueOrderedIds.size !== orderedIds.length ||
    orderedIds.some((id) => !existingIds.has(id))
  ) {
    throw AppError.badRequest(
      'orderedIds must contain exactly the caller\u2019s existing category ids, each once.',
      'INVALID_ORDER'
    );
  }

  await withTransaction((conn) => categoryModel.applySortOrder(conn, orderedIds));

  return categoryModel.findAllByUser(userId);
}

module.exports = {
  listCategories,
  createCategory,
  renameCategory,
  deleteCategory,
  reorderCategories,
  loadOwnedCategory,
};
