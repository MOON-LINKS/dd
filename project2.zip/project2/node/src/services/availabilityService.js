// Combines weekly_hours + schedule_exceptions + each requested service's
// duration/buffer + existing bookings for a date into either (a) a list of
// open slots for a slot picker, or (b) a pass/fail check for one specific
// requested start time. Pure calculation, no writes — bookingService owns
// the transactional INSERT that actually reserves a slot.

const AppError = require('../utils/AppError');
const weeklyHoursModel = require('../models/weeklyHoursModel');
const scheduleExceptionModel = require('../models/scheduleExceptionModel');
const serviceModel = require('../models/serviceModel');
const bookingModel = require('../models/bookingModel');

// Staff scheduling is deferred (see scheduleService.js) — every calculation
// here is business-wide-default only, same as Batch 3.
const STAFF_ID = null;

// Candidate slot granularity for the public slot picker. Not configurable
// per business yet; 15 minutes is a reasonable default for salon/clinic-
// length appointments (fine-grained enough, without generating an
// unusably long slot list for a service with a short duration).
const SLOT_STEP_MINUTES = 15;

const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

function assertValidDate(value, fieldName) {
  if (typeof value !== 'string' || !DATE_REGEX.test(value) || Number.isNaN(Date.parse(value))) {
    throw AppError.badRequest(`${fieldName} must be a date in YYYY-MM-DD format.`, 'INVALID_DATE');
  }
}

function timeToMinutes(time) {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

function minutesToTimeLabel(minutes) {
  const h = String(Math.floor(minutes / 60)).padStart(2, '0');
  const m = String(minutes % 60).padStart(2, '0');
  return `${h}:${m}`;
}

/**
 * NOTE on timezone: the schema has no per-business timezone column (see
 * spec §4 users table), and Batch 1 locked in UTC storage for everything.
 * weekly_hours.open_time/close_time are therefore treated here as UTC
 * clock times too, same as the DB. That's fine for a single-timezone
 * launch market but is a real gap the moment a business outside that
 * timezone signs up — flagging explicitly, same as Batch 3 flagged the
 * schedule_exceptions uniqueness gap, since it's the kind of thing that's
 * easy to paper over silently and hard to unwind later.
 *
 * @param {number} userId
 * @param {string} date - 'YYYY-MM-DD'
 * @returns {Promise<{openTime: string, closeTime: string}|null>} null means closed
 */
async function resolveDayWindow(userId, date) {
  const exception = await scheduleExceptionModel.findByUserStaffDate(userId, STAFF_ID, date);
  if (exception) {
    if (exception.is_closed) return null;
    return { openTime: exception.custom_open_time, closeTime: exception.custom_close_time };
  }

  const dayOfWeek = new Date(`${date}T00:00:00Z`).getUTCDay();
  const weeklyRows = await weeklyHoursModel.getForUser(userId, STAFF_ID);
  const dayRow = weeklyRows.find((row) => row.day_of_week === dayOfWeek);
  if (!dayRow || dayRow.is_closed) return null;
  return { openTime: dayRow.open_time, closeTime: dayRow.close_time };
}

/**
 * Validates that every requested service belongs to the owner and is
 * active, and resolves the combined appointment length.
 *
 * Decision: the total occupied block is sum(duration_minutes) for every
 * selected service, plus a single buffer at the end equal to the largest
 * buffer_minutes among them — not one buffer per service. The spec (§4)
 * describes buffer as auto-applied "after the booking" (singular), and a
 * multi-service appointment is performed back-to-back within one visit,
 * so only the final cleanup/gap before the next client's slot is needed.
 * Flagging this explicitly since the spec doesn't fully disambiguate
 * summed-vs-single buffer for the multi-service case.
 *
 * @param {number} userId
 * @param {number[]} serviceIds
 * @returns {Promise<{services: object[], totalDurationMinutes: number, bufferMinutes: number, blockMinutes: number}>}
 */
async function resolveServicesTotal(userId, serviceIds) {
  if (!Array.isArray(serviceIds) || serviceIds.length === 0) {
    throw AppError.badRequest('serviceIds must be a non-empty array.', 'MISSING_SERVICES');
  }
  const uniqueIds = [...new Set(serviceIds)];
  const services = await serviceModel.findManyByIdsForUser(uniqueIds, userId);

  if (services.length !== uniqueIds.length) {
    throw AppError.badRequest(
      'One or more selected services could not be found.',
      'SERVICE_NOT_FOUND'
    );
  }
  const inactive = services.find((s) => !s.is_active);
  if (inactive) {
    throw AppError.badRequest(
      `Service "${inactive.name}" is not currently available for booking.`,
      'SERVICE_INACTIVE'
    );
  }

  const totalDurationMinutes = services.reduce((sum, s) => sum + s.duration_minutes, 0);
  const bufferMinutes = services.reduce((max, s) => Math.max(max, s.buffer_minutes), 0);
  return { services, totalDurationMinutes, bufferMinutes, blockMinutes: totalDurationMinutes + bufferMinutes };
}

/**
 * @param {object} b - a bookings row (start_time/end_time as Date objects, from mysql2)
 * @returns {{start: number, end: number}} minutes-since-midnight, assumes the booking doesn't span midnight
 */
function toMinuteInterval(b) {
  const start = new Date(b.start_time);
  const end = new Date(b.end_time);
  return {
    start: start.getUTCHours() * 60 + start.getUTCMinutes(),
    end: end.getUTCHours() * 60 + end.getUTCMinutes(),
  };
}

/**
 * Computes the list of open slot start times (HH:MM) for a given date and
 * service selection — what the public slot picker calls on every date
 * change. Read-only.
 *
 * @param {number} userId
 * @param {object} params
 * @param {string} params.date - 'YYYY-MM-DD'
 * @param {number[]} params.serviceIds
 * @returns {Promise<{date: string, isClosed: boolean, blockMinutes: number, slots: string[]}>}
 */
async function getAvailableSlots(userId, { date, serviceIds }) {
  assertValidDate(date, 'date');
  const { blockMinutes } = await resolveServicesTotal(userId, serviceIds);

  const window = await resolveDayWindow(userId, date);
  if (!window) {
    return { date, isClosed: true, blockMinutes, slots: [] };
  }

  const openMinutes = timeToMinutes(window.openTime);
  const closeMinutes = timeToMinutes(window.closeTime);

  const rangeStart = new Date(`${date}T00:00:00.000Z`);
  const rangeEnd = new Date(`${date}T23:59:59.999Z`);
  const busyBookings = await bookingModel.findActiveByUserAndDateRange(
    userId,
    STAFF_ID,
    rangeStart,
    rangeEnd
  );
  const busyIntervals = busyBookings.map(toMinuteInterval);

  const now = new Date();
  const isToday = date === now.toISOString().slice(0, 10);
  const nowMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();

  const slots = [];
  for (let start = openMinutes; start + blockMinutes <= closeMinutes; start += SLOT_STEP_MINUTES) {
    if (isToday && start <= nowMinutes) continue; // no slots in the past
    const end = start + blockMinutes;
    const overlaps = busyIntervals.some((iv) => start < iv.end && end > iv.start);
    if (overlaps) continue;
    slots.push(minutesToTimeLabel(start));
  }

  return { date, isClosed: false, blockMinutes, slots };
}

/**
 * Authoritative validation for one specific requested start time — used
 * by bookingService right before it books, so a client can never book a
 * slot the server itself wouldn't have offered (stale slot picker, a
 * hand-crafted request, etc.). Does NOT check for booking overlap; that's
 * the transactional check in bookingService, since it has to happen
 * inside the same transaction as the INSERT to be race-safe.
 *
 * @param {number} userId
 * @param {object} params
 * @param {string} params.startTimeIso - full ISO datetime, e.g. '2026-09-10T14:00:00.000Z'
 * @param {number[]} params.serviceIds
 * @returns {Promise<{services: object[], startTime: Date, endTime: Date, blockMinutes: number}>}
 */
async function validateRequestedSlot(userId, { startTimeIso, serviceIds }) {
  if (typeof startTimeIso !== 'string' || Number.isNaN(Date.parse(startTimeIso))) {
    throw AppError.badRequest('startTime must be a valid ISO datetime.', 'INVALID_START_TIME');
  }
  const startTime = new Date(startTimeIso);
  const date = startTimeIso.slice(0, 10);
  assertValidDate(date, 'startTime');

  const { services, blockMinutes } = await resolveServicesTotal(userId, serviceIds);

  const window = await resolveDayWindow(userId, date);
  if (!window) {
    throw AppError.conflict('The business is closed on the selected date.', 'DAY_CLOSED');
  }

  const startMinutes = startTime.getUTCHours() * 60 + startTime.getUTCMinutes();
  const openMinutes = timeToMinutes(window.openTime);
  const closeMinutes = timeToMinutes(window.closeTime);
  if (startMinutes < openMinutes || startMinutes + blockMinutes > closeMinutes) {
    throw AppError.conflict('The selected time falls outside business hours.', 'OUTSIDE_HOURS');
  }

  if (startTime.getTime() <= Date.now()) {
    throw AppError.badRequest('startTime must be in the future.', 'START_IN_PAST');
  }

  const endTime = new Date(startTime.getTime() + blockMinutes * 60000);
  return { services, startTime, endTime, blockMinutes };
}

module.exports = {
  STAFF_ID,
  getAvailableSlots,
  validateRequestedSlot,
  resolveServicesTotal,
  resolveDayWindow,
};
