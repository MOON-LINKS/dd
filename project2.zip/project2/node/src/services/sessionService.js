// Owns the Instagram-style persistent session: an opaque token, mirrored
// in Redis (fast per-request revocation check) and in `user_sessions`
// (durable/auditable — "show my devices", logout-all).
//
// This is deliberately NOT a JWT. Batch 1's cookie/session decisions and
// this batch's plan call for a single opaque session token delivered via
// an HTTP-only cookie; JWT_SECRET stays provisioned in config/env.js for
// a future non-cookie API consumer but is unused here — see the note in
// 1.BATCH_PROGRESS.md.

const crypto = require('crypto');
const { redisClient } = require('../config/redis');
const config = require('../config/env');
const sessionModel = require('../models/sessionModel');

const SESSION_TTL_SECONDS = config.auth.sessionTtlDays * 24 * 60 * 60;

function redisKey(sessionToken) {
  return `session:${sessionToken}`;
}

function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Creates a new session: opaque token in Redis (TTL-bound) + a durable row
 * in user_sessions. Called right after signup/login.
 *
 * @param {object} params
 * @param {number} params.userId
 * @param {string|null} [params.userAgent]
 * @param {string|null} [params.ipAddress]
 * @param {'web'|'desktop'|'mobile'} [params.platform]
 * @param {import('mysql2/promise').PoolConnection} [conn] - pass when running inside withTransaction
 * @returns {Promise<string>} the session token to set as the cookie value
 */
async function createSession({ userId, userAgent, ipAddress, platform }, conn) {
  const sessionToken = generateToken();

  await sessionModel.createSession(
    { userId, sessionToken, userAgent, ipAddress, platform },
    conn
  );
  await redisClient.set(redisKey(sessionToken), String(userId), {
    EX: SESSION_TTL_SECONDS,
  });

  return sessionToken;
}

/**
 * Fast revocation/validity check used by every protected request.
 * @param {string} sessionToken
 * @returns {Promise<number|null>} userId if the session is valid, else null
 */
async function validateSession(sessionToken) {
  const userId = await redisClient.get(redisKey(sessionToken));
  if (!userId) return null;

  // Sliding expiration — an active user's session keeps renewing instead
  // of expiring mid-use at exactly SESSION_TTL_DAYS after login.
  await redisClient.expire(redisKey(sessionToken), SESSION_TTL_SECONDS);
  sessionModel.touchLastSeen(sessionToken).catch(() => {}); // best-effort, never block the request on this

  return parseInt(userId, 10);
}

/**
 * Revokes a single session ("Logout").
 * @param {string} sessionToken
 */
async function revokeSession(sessionToken) {
  await redisClient.del(redisKey(sessionToken));
  await sessionModel.revokeByToken(sessionToken);
}

/**
 * Revokes every session for a user ("Logout from all devices").
 * @param {number} userId
 */
async function revokeAllSessions(userId) {
  const tokens = await sessionModel.findActiveTokensForUser(userId);
  if (tokens.length > 0) {
    await Promise.all(tokens.map((token) => redisClient.del(redisKey(token))));
  }
  await sessionModel.revokeAllForUser(userId);
}

module.exports = {
  createSession,
  validateSession,
  revokeSession,
  revokeAllSessions,
  SESSION_TTL_SECONDS,
};
