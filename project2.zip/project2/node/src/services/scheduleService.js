const AppError = require('../utils/AppError');
const { withTransaction } = require('../config/db');
const weeklyHoursModel = require('../models/weeklyHoursModel');
const scheduleExceptionModel = require('../models/scheduleExceptionModel');

// staff-scoped hours/exceptions are schema-ready (nullable staff_id) but
// staff scheduling is deferred per the spec — every call in this batch
// hard-codes staffId to null (business-wide default).
const STAFF_ID = null;

const TIME_REGEX = /^([01]\d|2[0-3]):([0-5]\d)(:[0-5]\d)?$/;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

function assertValidTime(value, fieldName) {
  if (typeof value !== 'string' || !TIME_REGEX.test(value)) {
    throw AppError.badRequest(`${fieldName} must be a time in HH:MM (24h) format.`, 'INVALID_TIME');
  }
}

function assertValidDate(value, fieldName) {
  if (typeof value !== 'string' || !DATE_REGEX.test(value) || Number.isNaN(Date.parse(value))) {
    throw AppError.badRequest(`${fieldName} must be a date in YYYY-MM-DD format.`, 'INVALID_DATE');
  }
}

// ---------------------------------------------------------------
// Weekly hours (recurring template)
// ---------------------------------------------------------------

/**
 * @param {number} userId
 * @returns {Promise<object[]>} up to 7 rows, one per configured day
 */
async function getWeeklyHours(userId) {
  return weeklyHoursModel.getForUser(userId, STAFF_ID);
}

/**
 * Replaces the full weekly template in one transaction, so the dashboard
 * can never leave the week half-saved if one day's payload is bad.
 *
 * @param {number} userId
 * @param {object[]} days
 * @param {number} days[].dayOfWeek - 0 (Sunday) .. 6 (Saturday)
 * @param {boolean} days[].isClosed
 * @param {string|null} [days[].openTime] - required unless isClosed
 * @param {string|null} [days[].closeTime] - required unless isClosed
 */
async function setWeeklyHours(userId, days) {
  if (!Array.isArray(days) || days.length === 0) {
    throw AppError.badRequest('days must be a non-empty array.', 'INVALID_WEEKLY_HOURS');
  }

  const seenDays = new Set();
  const normalized = days.map((day) => {
    const { dayOfWeek, isClosed, openTime = null, closeTime = null } = day;

    if (!Number.isInteger(dayOfWeek) || dayOfWeek < 0 || dayOfWeek > 6) {
      throw AppError.badRequest(
        'dayOfWeek must be an integer 0 (Sunday) through 6 (Saturday).',
        'INVALID_DAY_OF_WEEK'
      );
    }
    if (seenDays.has(dayOfWeek)) {
      throw AppError.badRequest(`dayOfWeek ${dayOfWeek} was supplied more than once.`, 'DUPLICATE_DAY');
    }
    seenDays.add(dayOfWeek);

    if (isClosed) {
      return { dayOfWeek, isClosed: true, openTime: null, closeTime: null };
    }

    assertValidTime(openTime, 'openTime');
    assertValidTime(closeTime, 'closeTime');
    if (openTime >= closeTime) {
      throw AppError.badRequest('openTime must be earlier than closeTime.', 'INVALID_HOURS_RANGE');
    }
    return { dayOfWeek, isClosed: false, openTime, closeTime };
  });

  await withTransaction(async (conn) => {
    for (const day of normalized) {
      await weeklyHoursModel.upsertDay(conn, { userId, staffId: STAFF_ID, ...day });
    }
  });

  return weeklyHoursModel.getForUser(userId, STAFF_ID);
}

// ---------------------------------------------------------------
// Schedule exceptions (one-off overrides)
// ---------------------------------------------------------------

function assertValidExceptionInput({ exceptionDate, isClosed, customOpenTime, customCloseTime }) {
  assertValidDate(exceptionDate, 'exceptionDate');

  if (!isClosed) {
    // An exception that isn't a closure only makes sense as custom hours
    // for that date — otherwise there's nothing to override.
    assertValidTime(customOpenTime, 'customOpenTime');
    assertValidTime(customCloseTime, 'customCloseTime');
    if (customOpenTime >= customCloseTime) {
      throw AppError.badRequest(
        'customOpenTime must be earlier than customCloseTime.',
        'INVALID_HOURS_RANGE'
      );
    }
  }
}

/**
 * Loads an exception and throws unless it exists and belongs to userId.
 * @param {number} id
 * @param {number} userId
 * @returns {Promise<object>}
 */
async function loadOwnedException(id, userId) {
  const exception = await scheduleExceptionModel.findById(id);
  if (!exception || exception.user_id !== userId) {
    throw AppError.notFound('Schedule exception not found.', 'EXCEPTION_NOT_FOUND');
  }
  return exception;
}

/**
 * @param {number} userId
 * @param {string} from - 'YYYY-MM-DD'
 * @param {string} to - 'YYYY-MM-DD'
 */
async function listExceptions(userId, from, to) {
  assertValidDate(from, 'from');
  assertValidDate(to, 'to');
  if (from > to) {
    throw AppError.badRequest('from must not be after to.', 'INVALID_RANGE');
  }
  return scheduleExceptionModel.findByUserInRange(userId, from, to);
}

/**
 * @param {number} userId
 * @param {object} input
 */
async function createException(userId, input) {
  const {
    exceptionDate,
    isClosed = false,
    customOpenTime = null,
    customCloseTime = null,
    reason = null,
  } = input;

  assertValidExceptionInput({ exceptionDate, isClosed, customOpenTime, customCloseTime });

  // The table has no unique constraint for (user, staff, date) — enforced
  // here at the application level instead, since "one override per date"
  // is a business rule, not a storage one.
  const duplicate = await scheduleExceptionModel.findByUserStaffDate(
    userId,
    STAFF_ID,
    exceptionDate
  );
  if (duplicate) {
    throw AppError.conflict(
      'An exception already exists for this date. Update it instead of creating another.',
      'EXCEPTION_EXISTS'
    );
  }

  const id = await scheduleExceptionModel.createException({
    userId,
    staffId: STAFF_ID,
    exceptionDate,
    isClosed,
    customOpenTime: isClosed ? null : customOpenTime,
    customCloseTime: isClosed ? null : customCloseTime,
    reason,
  });
  return scheduleExceptionModel.findById(id);
}

/**
 * @param {number} id
 * @param {number} userId
 * @param {object} input - only supplied fields are changed
 */
async function updateException(id, userId, input) {
  const existing = await loadOwnedException(id, userId);

  const merged = {
    exceptionDate: existing.exception_date,
    isClosed: input.isClosed !== undefined ? input.isClosed : !!existing.is_closed,
    customOpenTime:
      input.customOpenTime !== undefined ? input.customOpenTime : existing.custom_open_time,
    customCloseTime:
      input.customCloseTime !== undefined ? input.customCloseTime : existing.custom_close_time,
  };
  assertValidExceptionInput(merged);

  await scheduleExceptionModel.updateException(id, {
    isClosed: merged.isClosed,
    customOpenTime: merged.isClosed ? null : merged.customOpenTime,
    customCloseTime: merged.isClosed ? null : merged.customCloseTime,
    reason: input.reason !== undefined ? input.reason : undefined,
  });
  return scheduleExceptionModel.findById(id);
}

/**
 * @param {number} id
 * @param {number} userId
 */
async function deleteException(id, userId) {
  await loadOwnedException(id, userId);
  await scheduleExceptionModel.deleteException(id);
}

module.exports = {
  getWeeklyHours,
  setWeeklyHours,
  listExceptions,
  createException,
  updateException,
  deleteException,
};
