const bcrypt = require('bcryptjs');

const AppError = require('../utils/AppError');
const { withTransaction } = require('../config/db');
const userModel = require('../models/userModel');
const sessionService = require('./sessionService');

const BCRYPT_ROUNDS = 12;

// Mirrors the DB's chk_agency_name_format CHECK constraint: lowercase,
// alphanumeric + hyphens, cannot start or end with a digit (or a hyphen,
// since the edges are restricted to [a-z]). Validate here too so a bad
// value fails fast with a clear message instead of a raw DB error.
const AGENCY_NAME_REGEX = /^[a-z][a-z0-9-]{1,61}[a-z]$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MIN_PASSWORD_LENGTH = 8;

function assertValidSignupInput({ agencyName, email, password, fullName }) {
  if (!agencyName || !AGENCY_NAME_REGEX.test(agencyName)) {
    throw AppError.badRequest(
      'Agency name must be lowercase letters, numbers and hyphens, cannot start or end with a digit or hyphen, and must be 3-63 characters.',
      'INVALID_AGENCY_NAME'
    );
  }
  if (!email || !EMAIL_REGEX.test(email)) {
    throw AppError.badRequest('A valid email address is required.', 'INVALID_EMAIL');
  }
  if (!password || password.length < MIN_PASSWORD_LENGTH) {
    throw AppError.badRequest(
      `Password must be at least ${MIN_PASSWORD_LENGTH} characters.`,
      'INVALID_PASSWORD'
    );
  }
  if (!fullName || !fullName.trim()) {
    throw AppError.badRequest('Full name is required.', 'INVALID_FULL_NAME');
  }
}

/**
 * @param {object} input - { agencyName, email, password, fullName, phone, locale }
 * @param {object} context - { userAgent, ipAddress, platform }
 * @returns {Promise<{ user: object, sessionToken: string }>}
 */
async function signup(input, context) {
  const agencyName = (input.agencyName || '').trim().toLowerCase();
  const email = (input.email || '').trim().toLowerCase();
  const { password, phone = null, locale = 'en' } = input;
  const fullName = (input.fullName || '').trim();

  assertValidSignupInput({ agencyName, email, password, fullName });

  const [existingByEmail, existingByAgencyName] = await Promise.all([
    userModel.findByEmail(email),
    userModel.findByAgencyName(agencyName),
  ]);
  if (existingByEmail) {
    throw AppError.conflict('An account with this email already exists.', 'EMAIL_TAKEN');
  }
  if (existingByAgencyName) {
    throw AppError.conflict('This agency name is already taken.', 'AGENCY_NAME_TAKEN');
  }

  const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);

  // User row + first session row must succeed or fail together, so a
  // half-created account can never exist without a valid session record.
  const { userId, sessionToken } = await withTransaction(async (conn) => {
    const insertedId = await userModel.createUser(
      { agencyName, email, passwordHash, fullName, phone, locale },
      conn
    );
    const token = await sessionService.createSession(
      { userId: insertedId, ...context },
      conn
    );
    return { userId: insertedId, sessionToken: token };
  });

  const user = userModel.toPublicUser(await userModel.findById(userId));
  return { user, sessionToken };
}

/**
 * @param {object} input - { email, password }
 * @param {object} context - { userAgent, ipAddress, platform }
 * @returns {Promise<{ user: object, sessionToken: string }>}
 */
async function login({ email, password }, context) {
  if (!email || !password) {
    throw AppError.badRequest('Email and password are required.', 'MISSING_CREDENTIALS');
  }

  const row = await userModel.findByEmail(String(email).trim().toLowerCase());
  // Same generic message whether the email doesn't exist or the password
  // is wrong — never reveal which one it was (avoids account enumeration).
  const invalidCredentials = () =>
    AppError.unauthorized('Invalid email or password.', 'INVALID_CREDENTIALS');

  if (!row) throw invalidCredentials();

  const passwordMatches = await bcrypt.compare(password, row.password_hash);
  if (!passwordMatches) throw invalidCredentials();

  if (!row.is_active) {
    throw AppError.forbidden('This account has been deactivated.', 'ACCOUNT_INACTIVE');
  }

  const sessionToken = await sessionService.createSession({ userId: row.id, ...context });
  return { user: userModel.toPublicUser(row), sessionToken };
}

/**
 * @param {string} sessionToken
 */
async function logout(sessionToken) {
  await sessionService.revokeSession(sessionToken);
}

/**
 * @param {number} userId
 */
async function logoutAll(userId) {
  await sessionService.revokeAllSessions(userId);
}

/**
 * @param {number} userId
 * @returns {Promise<object>}
 */
async function getCurrentUser(userId) {
  const row = await userModel.findById(userId);
  if (!row || !row.is_active) {
    throw AppError.unauthorized('Session is no longer valid.', 'INVALID_SESSION');
  }
  return userModel.toPublicUser(row);
}

module.exports = { signup, login, logout, logoutAll, getCurrentUser };
