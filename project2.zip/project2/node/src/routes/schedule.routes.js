const express = require('express');

const { requireAuth } = require('../middleware/auth');
const scheduleController = require('../controllers/scheduleController');

const router = express.Router();

// Owner-dashboard only, same reasoning as services.routes.js — the public
// page's live-hours display is a separate read endpoint, added later.
router.use(requireAuth);

router.get('/weekly-hours', scheduleController.getWeeklyHours);
router.put('/weekly-hours', scheduleController.setWeeklyHours);

router.get('/exceptions', scheduleController.listExceptions);
router.post('/exceptions', scheduleController.createException);
router.patch('/exceptions/:id', scheduleController.updateException);
router.delete('/exceptions/:id', scheduleController.removeException);

module.exports = router;
