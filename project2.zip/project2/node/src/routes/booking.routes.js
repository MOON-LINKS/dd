const express = require('express');

const { requireAuth } = require('../middleware/auth');
const { publicBookingLimiter, availabilityLimiter } = require('../middleware/rateLimiter');
const bookingController = require('../controllers/bookingController');

const router = express.Router();

// ---------------------------------------------------------------
// Public — unauthenticated, reached from a business's own subdomain
// booking page. Addressed by agency name, not a numeric id (see
// bookingController.resolveOwnerIdByAgencyName). Rate-limited: booking
// creation is the highest-risk surface for spam per spec §6; the
// read-only availability check gets a looser limiter since a slot picker
// re-fetches on every date change.
// ---------------------------------------------------------------
router.get(
  '/public/:agencyName/availability',
  availabilityLimiter,
  bookingController.publicAvailability
);
router.post(
  '/public/:agencyName',
  publicBookingLimiter,
  bookingController.publicCreateBooking
);

// ---------------------------------------------------------------
// Owner dashboard — everything below requires a session.
// ---------------------------------------------------------------
router.use(requireAuth);

router.get('/', bookingController.list);
router.get('/availability', bookingController.availability);
router.post('/block-time', bookingController.blockTime);
router.patch('/:id/cancel', bookingController.cancel);
router.patch('/:id/complete', bookingController.complete);
router.patch('/:id/reschedule', bookingController.reschedule);

module.exports = router;
