const express = require('express');

const { requireAuth } = require('../middleware/auth');
const categoryController = require('../controllers/categoryController');
const serviceController = require('../controllers/serviceController');

const router = express.Router();

// Every route here is owner-dashboard only — the public booking page
// reads services through a separate, unauthenticated read endpoint that
// a later batch (bio/public-page module) will add.
router.use(requireAuth);

router.get('/categories', categoryController.list);
router.post('/categories', categoryController.create);
router.patch('/categories/reorder', categoryController.reorder);
router.patch('/categories/:id', categoryController.rename);
router.delete('/categories/:id', categoryController.remove);

router.get('/', serviceController.list);
router.post('/', serviceController.create);
router.patch('/:id', serviceController.update);
router.patch('/:id/activate', serviceController.activate);
router.patch('/:id/deactivate', serviceController.deactivate);
router.delete('/:id', serviceController.remove);

module.exports = router;
