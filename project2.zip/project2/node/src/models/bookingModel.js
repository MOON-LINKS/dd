// Thin query functions for `bookings` and `booking_services`. No ORM —
// raw SQL via the pool from config/db.js, or via a transaction connection
// when passed in (booking creation/reschedule must be atomic — see
// bookingService.js and the concurrency notes in the spec §5.1).

const { pool } = require('../config/db');

/**
 * @param {import('mysql2/promise').PoolConnection} conn
 * @param {object} data
 * @param {number} data.userId
 * @param {number|null} data.staffId
 * @param {number|null} data.clientId
 * @param {string|null} data.guestName
 * @param {string|null} data.guestPhone
 * @param {Date} data.startTime
 * @param {Date} data.endTime
 * @param {'pending'|'confirmed'|'cancelled'|'completed'|'no_show'} data.status
 * @returns {Promise<number>} inserted booking id
 */
async function createBooking(
  conn,
  { userId, staffId, clientId, guestName, guestPhone, startTime, endTime, status }
) {
  const [result] = await conn.execute(
    `INSERT INTO bookings
       (user_id, staff_id, client_id, guest_name, guest_phone, start_time, end_time, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [userId, staffId, clientId, guestName, guestPhone, startTime, endTime, status]
  );
  return result.insertId;
}

/**
 * Bulk-inserts the services attached to a booking, each with its
 * duration/price snapshotted at booking time so a later edit to the
 * service itself never rewrites this booking's history.
 * @param {import('mysql2/promise').PoolConnection} conn
 * @param {number} bookingId
 * @param {object[]} snapshots
 * @param {number} snapshots[].serviceId
 * @param {number} snapshots[].durationMinutes
 * @param {number|null} snapshots[].priceValue
 * @param {'USD'|'LBP'|null} snapshots[].priceCurrency
 */
async function addBookingServices(conn, bookingId, snapshots) {
  if (!snapshots || snapshots.length === 0) return;
  const rowPlaceholders = [];
  const params = [];
  for (const s of snapshots) {
    rowPlaceholders.push('(?, ?, ?, ?, ?)');
    params.push(bookingId, s.serviceId, s.durationMinutes, s.priceValue, s.priceCurrency);
  }
  await conn.execute(
    `INSERT INTO booking_services
       (booking_id, service_id, duration_minutes_at_booking, price_value_at_booking, price_currency_at_booking)
     VALUES ${rowPlaceholders.join(', ')}`,
    params
  );
}

/**
 * @param {number} id
 * @returns {Promise<object|null>}
 */
async function findById(id) {
  const [rows] = await pool.execute('SELECT * FROM bookings WHERE id = ? LIMIT 1', [id]);
  return rows[0] || null;
}

/**
 * @param {number} bookingId
 * @returns {Promise<object[]>} booking_services rows, joined with the
 *   service's current name for display (duration/price stay snapshotted)
 */
async function findServicesForBooking(bookingId) {
  const [rows] = await pool.execute(
    `SELECT bs.*, s.name AS service_name
     FROM booking_services bs
     LEFT JOIN services s ON s.id = bs.service_id
     WHERE bs.booking_id = ?`,
    [bookingId]
  );
  return rows;
}

/**
 * Finds one conflicting booking, if any, for a user/staff slot — the
 * application-level half of double-booking prevention. Accepts either the
 * pool or a transaction connection so it can be used both as a pre-check
 * and, more importantly, inside the same transaction as the INSERT it's
 * guarding (see decision note in the Batch 4 doc: this overlap check is
 * a defense-in-depth measure, not a full replacement for the DB-level
 * `uq_slot_lock` constraint, which only catches *exact* start-time
 * collisions — not overlapping bookings of different durations).
 * @param {import('mysql2/promise').Pool|import('mysql2/promise').PoolConnection} executor
 * @param {object} params
 * @param {number} params.userId
 * @param {number|null} params.staffId
 * @param {Date} params.startTime
 * @param {Date} params.endTime
 * @param {number} [params.excludeBookingId] - skip this row (used on reschedule)
 * @returns {Promise<object|null>}
 */
async function findOverlapping(executor, { userId, staffId, startTime, endTime, excludeBookingId }) {
  const conditions = [
    'user_id = ?',
    `staff_id ${staffId === null || staffId === undefined ? 'IS NULL' : '= ?'}`,
    "status NOT IN ('cancelled', 'no_show')",
    'start_time < ?',
    'end_time > ?',
  ];
  const params = [userId];
  if (staffId !== null && staffId !== undefined) params.push(staffId);
  params.push(endTime, startTime);
  if (excludeBookingId !== undefined && excludeBookingId !== null) {
    conditions.push('id != ?');
    params.push(excludeBookingId);
  }
  const [rows] = await executor.execute(
    `SELECT id FROM bookings WHERE ${conditions.join(' AND ')} LIMIT 1`,
    params
  );
  return rows[0] || null;
}

/**
 * Every non-cancelled/no_show booking whose interval overlaps
 * [rangeStart, rangeEnd) — used by availabilityService to compute busy
 * intervals for a given day.
 * @param {number} userId
 * @param {number|null} staffId
 * @param {Date} rangeStart
 * @param {Date} rangeEnd
 * @returns {Promise<object[]>}
 */
async function findActiveByUserAndDateRange(userId, staffId, rangeStart, rangeEnd) {
  const conditions = [
    'user_id = ?',
    `staff_id ${staffId === null || staffId === undefined ? 'IS NULL' : '= ?'}`,
    "status NOT IN ('cancelled', 'no_show')",
    'start_time < ?',
    'end_time > ?',
  ];
  const params = [userId];
  if (staffId !== null && staffId !== undefined) params.push(staffId);
  params.push(rangeEnd, rangeStart);
  const [rows] = await pool.execute(
    `SELECT id, start_time, end_time FROM bookings WHERE ${conditions.join(' AND ')} ORDER BY start_time ASC`,
    params
  );
  return rows;
}

/**
 * Every booking (any status) overlapping a range — for the owner
 * dashboard's calendar view, which needs to show cancelled/completed
 * appointments too, not just open-slot math.
 * @param {number} userId
 * @param {Date} rangeStart
 * @param {Date} rangeEnd
 * @returns {Promise<object[]>}
 */
async function findByUserInRange(userId, rangeStart, rangeEnd) {
  const [rows] = await pool.execute(
    `SELECT * FROM bookings WHERE user_id = ? AND start_time < ? AND end_time > ? ORDER BY start_time ASC`,
    [userId, rangeEnd, rangeStart]
  );
  return rows;
}

/**
 * @param {number} id
 * @param {'pending'|'confirmed'|'cancelled'|'completed'|'no_show'} status
 */
async function updateStatus(id, status) {
  await pool.execute('UPDATE bookings SET status = ? WHERE id = ?', [status, id]);
}

/**
 * @param {import('mysql2/promise').PoolConnection} conn
 * @param {number} id
 * @param {object} times
 * @param {Date} times.startTime
 * @param {Date} times.endTime
 */
async function updateTimes(conn, id, { startTime, endTime }) {
  await conn.execute('UPDATE bookings SET start_time = ?, end_time = ? WHERE id = ?', [
    startTime,
    endTime,
    id,
  ]);
}

module.exports = {
  createBooking,
  addBookingServices,
  findById,
  findServicesForBooking,
  findOverlapping,
  findActiveByUserAndDateRange,
  findByUserInRange,
  updateStatus,
  updateTimes,
};
