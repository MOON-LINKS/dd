// Thin query functions for the `schedule_exceptions` table — one-off
// overrides for a specific date (holiday, early close, emergency).

const { pool } = require('../config/db');

/**
 * @param {object} data
 * @param {number} data.userId
 * @param {number|null} data.staffId
 * @param {string} data.exceptionDate - 'YYYY-MM-DD'
 * @param {boolean} data.isClosed
 * @param {string|null} data.customOpenTime
 * @param {string|null} data.customCloseTime
 * @param {string|null} data.reason
 * @returns {Promise<number>} inserted exception id
 */
async function createException({
  userId,
  staffId,
  exceptionDate,
  isClosed,
  customOpenTime,
  customCloseTime,
  reason,
}) {
  const [result] = await pool.execute(
    `INSERT INTO schedule_exceptions
       (user_id, staff_id, exception_date, is_closed, custom_open_time, custom_close_time, reason)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [userId, staffId, exceptionDate, isClosed ? 1 : 0, customOpenTime, customCloseTime, reason]
  );
  return result.insertId;
}

/**
 * @param {number} id
 * @returns {Promise<object|null>} full row, for ownership checks
 */
async function findById(id) {
  const [rows] = await pool.execute('SELECT * FROM schedule_exceptions WHERE id = ? LIMIT 1', [
    id,
  ]);
  return rows[0] || null;
}

/**
 * Finds an existing exception for a given user/staff/date, used to enforce
 * one-override-per-date at the application level (see decision note in
 * 5.BATCH_3_SCHEDULING.md — the table has no unique constraint for this).
 * @param {number} userId
 * @param {number|null} staffId
 * @param {string} exceptionDate
 * @param {number} [excludeId] - skip this row (used on update)
 */
async function findByUserStaffDate(userId, staffId, exceptionDate, excludeId = null) {
  const params = [userId, exceptionDate];
  let sql = `SELECT * FROM schedule_exceptions WHERE user_id = ? AND exception_date = ? AND staff_id ${
    staffId === null ? 'IS NULL' : '= ?'
  }`;
  if (staffId !== null) params.push(staffId);
  if (excludeId !== null) {
    sql += ' AND id != ?';
    params.push(excludeId);
  }
  sql += ' LIMIT 1';
  const [rows] = await pool.execute(sql, params);
  return rows[0] || null;
}

/**
 * @param {number} userId
 * @param {string} from - 'YYYY-MM-DD' inclusive
 * @param {string} to - 'YYYY-MM-DD' inclusive
 * @returns {Promise<object[]>}
 */
async function findByUserInRange(userId, from, to) {
  const [rows] = await pool.execute(
    `SELECT * FROM schedule_exceptions
     WHERE user_id = ? AND exception_date BETWEEN ? AND ?
     ORDER BY exception_date ASC`,
    [userId, from, to]
  );
  return rows;
}

/**
 * @param {number} id
 * @param {object} fields - only the keys present are updated
 */
async function updateException(id, { isClosed, customOpenTime, customCloseTime, reason }) {
  const sets = [];
  const params = [];
  const push = (column, value) => {
    sets.push(`${column} = ?`);
    params.push(value);
  };

  if (isClosed !== undefined) push('is_closed', isClosed ? 1 : 0);
  if (customOpenTime !== undefined) push('custom_open_time', customOpenTime);
  if (customCloseTime !== undefined) push('custom_close_time', customCloseTime);
  if (reason !== undefined) push('reason', reason);

  if (sets.length === 0) return;
  params.push(id);
  await pool.execute(`UPDATE schedule_exceptions SET ${sets.join(', ')} WHERE id = ?`, params);
}

/**
 * @param {number} id
 */
async function deleteException(id) {
  await pool.execute('DELETE FROM schedule_exceptions WHERE id = ?', [id]);
}

module.exports = {
  createException,
  findById,
  findByUserStaffDate,
  findByUserInRange,
  updateException,
  deleteException,
};
