// Thin query functions for the `categories` table. No ORM — raw SQL via
// the pool from config/db.js. Services own business logic/ownership
// checks; this module only knows how to read/write rows.

const { pool } = require('../config/db');

/**
 * @param {object} data
 * @param {number} data.userId
 * @param {string} data.name
 * @param {number} [data.sortOrder]
 * @returns {Promise<number>} inserted category id
 */
async function createCategory({ userId, name, sortOrder = 0 }) {
  const [result] = await pool.execute(
    'INSERT INTO categories (user_id, name, sort_order) VALUES (?, ?, ?)',
    [userId, name, sortOrder]
  );
  return result.insertId;
}

/**
 * @param {number} userId
 * @returns {Promise<object[]>} all categories for the owner, sorted for display
 */
async function findAllByUser(userId) {
  const [rows] = await pool.execute(
    'SELECT * FROM categories WHERE user_id = ? ORDER BY sort_order ASC, id ASC',
    [userId]
  );
  return rows;
}

/**
 * @param {number} id
 * @returns {Promise<object|null>} full row (includes user_id, for ownership checks)
 */
async function findById(id) {
  const [rows] = await pool.execute('SELECT * FROM categories WHERE id = ? LIMIT 1', [id]);
  return rows[0] || null;
}

/**
 * @param {number} id
 * @param {object} fields - only the keys present are updated
 * @param {string} [fields.name]
 * @param {number} [fields.sortOrder]
 */
async function updateCategory(id, { name, sortOrder }) {
  const sets = [];
  const params = [];
  if (name !== undefined) {
    sets.push('name = ?');
    params.push(name);
  }
  if (sortOrder !== undefined) {
    sets.push('sort_order = ?');
    params.push(sortOrder);
  }
  if (sets.length === 0) return;
  params.push(id);
  await pool.execute(`UPDATE categories SET ${sets.join(', ')} WHERE id = ?`, params);
}

/**
 * Deletes a category. Cascades to its services via ON DELETE CASCADE.
 * @param {number} id
 */
async function deleteCategory(id) {
  await pool.execute('DELETE FROM categories WHERE id = ?', [id]);
}

/**
 * Bulk-applies a new sort_order to a set of categories in one transaction
 * connection, keyed by array position. Caller (service layer) has already
 * verified every id belongs to the requesting user.
 * @param {import('mysql2/promise').PoolConnection} conn
 * @param {number[]} orderedIds
 */
async function applySortOrder(conn, orderedIds) {
  for (let i = 0; i < orderedIds.length; i += 1) {
    await conn.execute('UPDATE categories SET sort_order = ? WHERE id = ?', [i, orderedIds[i]]);
  }
}

module.exports = {
  createCategory,
  findAllByUser,
  findById,
  updateCategory,
  deleteCategory,
  applySortOrder,
};
