// Thin query functions for the `users` table. No ORM — raw SQL via the
// pool (or a transaction connection, when passed in) from config/db.js.
// Services own business logic; this module only knows how to read/write rows.

const { pool } = require('../config/db');

const PUBLIC_FIELDS = [
  'id',
  'agency_name',
  'email',
  'full_name',
  'phone',
  'locale',
  'theme',
  'has_used_free_trial',
  'is_active',
  'created_at',
];

/**
 * @param {object} data
 * @param {string} data.agencyName
 * @param {string} data.email
 * @param {string} data.passwordHash
 * @param {string} data.fullName
 * @param {string|null} [data.phone]
 * @param {string} [data.locale]
 * @param {import('mysql2/promise').PoolConnection} [conn] - pass when running inside withTransaction
 * @returns {Promise<number>} inserted user id
 */
async function createUser(
  { agencyName, email, passwordHash, fullName, phone = null, locale = 'en' },
  conn = pool
) {
  const [result] = await conn.execute(
    `INSERT INTO users (agency_name, email, password_hash, full_name, phone, locale)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [agencyName, email, passwordHash, fullName, phone, locale]
  );
  return result.insertId;
}

/**
 * @param {string} email
 * @returns {Promise<object|null>} full row (includes password_hash) — for login only, never return this to a client as-is
 */
async function findByEmail(email) {
  const [rows] = await pool.execute('SELECT * FROM users WHERE email = ? LIMIT 1', [email]);
  return rows[0] || null;
}

/**
 * @param {string} agencyName
 * @returns {Promise<object|null>}
 */
async function findByAgencyName(agencyName) {
  const [rows] = await pool.execute('SELECT id FROM users WHERE agency_name = ? LIMIT 1', [
    agencyName,
  ]);
  return rows[0] || null;
}

/**
 * @param {number} id
 * @returns {Promise<object|null>} full row (includes password_hash) — caller strips it via toPublicUser
 */
async function findById(id) {
  const [rows] = await pool.execute('SELECT * FROM users WHERE id = ? LIMIT 1', [id]);
  return rows[0] || null;
}

/**
 * Strips internal-only columns (password_hash, paddle_customer_id, updated_at)
 * before a user row is ever sent to the client.
 * @param {object} row
 */
function toPublicUser(row) {
  if (!row) return null;
  const publicUser = {};
  for (const field of PUBLIC_FIELDS) {
    if (field in row) publicUser[field] = row[field];
  }
  return publicUser;
}

module.exports = { createUser, findByEmail, findByAgencyName, findById, toPublicUser };
