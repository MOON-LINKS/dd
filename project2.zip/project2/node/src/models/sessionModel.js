// Thin query functions for `user_sessions` — the durable/auditable mirror
// of the Redis-held session state (see services/sessionService.js for the
// combined Redis + DB flow). This module never touches Redis.

const { pool } = require('../config/db');

/**
 * @param {object} data
 * @param {number} data.userId
 * @param {string} data.sessionToken
 * @param {string|null} [data.userAgent]
 * @param {string|null} [data.ipAddress]
 * @param {'web'|'desktop'|'mobile'} [data.platform]
 * @param {import('mysql2/promise').PoolConnection} [conn] - pass when running inside withTransaction
 */
async function createSession(
  { userId, sessionToken, userAgent = null, ipAddress = null, platform = 'web' },
  conn = pool
) {
  await conn.execute(
    `INSERT INTO user_sessions (user_id, session_token, user_agent, ip_address, platform)
     VALUES (?, ?, ?, ?, ?)`,
    [userId, sessionToken, userAgent, ipAddress, platform]
  );
}

/**
 * @param {string} sessionToken
 */
async function touchLastSeen(sessionToken) {
  await pool.execute(
    'UPDATE user_sessions SET last_seen_at = CURRENT_TIMESTAMP WHERE session_token = ? AND revoked_at IS NULL',
    [sessionToken]
  );
}

/**
 * Revokes a single session ("Logout").
 * @param {string} sessionToken
 */
async function revokeByToken(sessionToken) {
  await pool.execute(
    'UPDATE user_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE session_token = ? AND revoked_at IS NULL',
    [sessionToken]
  );
}

/**
 * Returns every currently-active session token for a user — used by
 * "logout from all devices" to know which Redis keys to delete before the
 * DB rows are marked revoked in one UPDATE.
 * @param {number} userId
 * @returns {Promise<string[]>}
 */
async function findActiveTokensForUser(userId) {
  const [rows] = await pool.execute(
    'SELECT session_token FROM user_sessions WHERE user_id = ? AND revoked_at IS NULL',
    [userId]
  );
  return rows.map((row) => row.session_token);
}

/**
 * Revokes every active session for a user ("Logout from all devices").
 * @param {number} userId
 */
async function revokeAllForUser(userId) {
  await pool.execute(
    'UPDATE user_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE user_id = ? AND revoked_at IS NULL',
    [userId]
  );
}

module.exports = {
  createSession,
  touchLastSeen,
  revokeByToken,
  findActiveTokensForUser,
  revokeAllForUser,
};
