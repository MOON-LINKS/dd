// Thin query functions for the `services` table. No ORM — raw SQL via
// the pool from config/db.js. A service belongs to a category, which
// belongs to a user — ownership checks join through `categories`.

const { pool } = require('../config/db');

/**
 * @param {object} data
 * @param {number} data.categoryId
 * @param {string} data.name
 * @param {number} data.durationMinutes
 * @param {number} [data.bufferMinutes]
 * @param {number|null} [data.priceValue]
 * @param {'USD'|'LBP'|null} [data.priceCurrency]
 * @returns {Promise<number>} inserted service id
 */
async function createService({
  categoryId,
  name,
  durationMinutes,
  bufferMinutes = 0,
  priceValue = null,
  priceCurrency = null,
}) {
  const [result] = await pool.execute(
    `INSERT INTO services (category_id, name, duration_minutes, buffer_minutes, price_value, price_currency)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [categoryId, name, durationMinutes, bufferMinutes, priceValue, priceCurrency]
  );
  return result.insertId;
}

/**
 * @param {number} userId
 * @returns {Promise<object[]>} every service belonging to the owner, joined
 *   with its category's user_id so callers never need a second query
 */
async function findAllByUser(userId) {
  const [rows] = await pool.execute(
    `SELECT s.* FROM services s
     JOIN categories c ON c.id = s.category_id
     WHERE c.user_id = ?
     ORDER BY s.category_id ASC, s.id ASC`,
    [userId]
  );
  return rows;
}

/**
 * Fetches a service along with the owning user_id (via its category), for
 * ownership checks in the service layer, in a single round trip.
 * @param {number} id
 * @returns {Promise<object|null>}
 */
async function findByIdWithOwner(id) {
  const [rows] = await pool.execute(
    `SELECT s.*, c.user_id AS owner_user_id FROM services s
     JOIN categories c ON c.id = s.category_id
     WHERE s.id = ?
     LIMIT 1`,
    [id]
  );
  return rows[0] || null;
}

/**
 * Fetches every requested service id that belongs to userId, in one round
 * trip — used by Batch 4's availability/booking calculation to validate a
 * multi-service booking request and pull each service's duration/buffer/
 * price for snapshotting. Silently drops ids that don't exist or belong
 * to another owner; the caller compares `result.length` against the
 * requested id count to detect that.
 * @param {number[]} ids
 * @param {number} userId
 * @returns {Promise<object[]>}
 */
async function findManyByIdsForUser(ids, userId) {
  if (!Array.isArray(ids) || ids.length === 0) return [];
  const placeholders = ids.map(() => '?').join(', ');
  const [rows] = await pool.execute(
    `SELECT s.* FROM services s
     JOIN categories c ON c.id = s.category_id
     WHERE c.user_id = ? AND s.id IN (${placeholders})`,
    [userId, ...ids]
  );
  return rows;
}

/**
 * @param {number} id
 * @param {object} fields - only the keys present are updated
 */
async function updateService(
  id,
  { categoryId, name, durationMinutes, bufferMinutes, priceValue, priceCurrency }
) {
  const sets = [];
  const params = [];
  const push = (column, value) => {
    sets.push(`${column} = ?`);
    params.push(value);
  };

  if (categoryId !== undefined) push('category_id', categoryId);
  if (name !== undefined) push('name', name);
  if (durationMinutes !== undefined) push('duration_minutes', durationMinutes);
  if (bufferMinutes !== undefined) push('buffer_minutes', bufferMinutes);
  if (priceValue !== undefined) push('price_value', priceValue);
  if (priceCurrency !== undefined) push('price_currency', priceCurrency);

  if (sets.length === 0) return;
  params.push(id);
  await pool.execute(`UPDATE services SET ${sets.join(', ')} WHERE id = ?`, params);
}

/**
 * @param {number} id
 * @param {boolean} isActive
 */
async function setActive(id, isActive) {
  await pool.execute('UPDATE services SET is_active = ? WHERE id = ?', [isActive ? 1 : 0, id]);
}

/**
 * @param {number} id
 */
async function deleteService(id) {
  await pool.execute('DELETE FROM services WHERE id = ?', [id]);
}

module.exports = {
  createService,
  findAllByUser,
  findByIdWithOwner,
  findManyByIdsForUser,
  updateService,
  setActive,
  deleteService,
};
