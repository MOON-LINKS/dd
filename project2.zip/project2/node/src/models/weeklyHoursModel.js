// Thin query functions for the `weekly_hours` table — the recurring
// weekly template. `staff_id` is always NULL for now (business-wide
// default); per-staff templates are schema-ready but out of scope until
// staff scheduling ships (see spec §4).

const { pool } = require('../config/db');

/**
 * @param {number} userId
 * @param {number|null} [staffId]
 * @returns {Promise<object[]>} up to 7 rows, one per configured day_of_week
 */
async function getForUser(userId, staffId = null) {
  const [rows] = await pool.execute(
    `SELECT * FROM weekly_hours WHERE user_id = ? AND staff_id ${
      staffId === null ? 'IS NULL' : '= ?'
    } ORDER BY day_of_week ASC`,
    staffId === null ? [userId] : [userId, staffId]
  );
  return rows;
}

/**
 * Upserts one day's row, keyed on the table's unique (user_id, staff_id,
 * day_of_week) constraint — the caller drives this per entry inside a
 * transaction so a partial week can never be left half-written.
 *
 * @param {import('mysql2/promise').PoolConnection} conn
 * @param {object} entry
 * @param {number} entry.userId
 * @param {number|null} entry.staffId
 * @param {number} entry.dayOfWeek
 * @param {string|null} entry.openTime
 * @param {string|null} entry.closeTime
 * @param {boolean} entry.isClosed
 */
async function upsertDay(conn, { userId, staffId, dayOfWeek, openTime, closeTime, isClosed }) {
  await conn.execute(
    `INSERT INTO weekly_hours (user_id, staff_id, day_of_week, open_time, close_time, is_closed)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE open_time = VALUES(open_time), close_time = VALUES(close_time),
       is_closed = VALUES(is_closed)`,
    [userId, staffId, dayOfWeek, openTime, closeTime, isClosed ? 1 : 0]
  );
}

module.exports = { getForUser, upsertDay };
