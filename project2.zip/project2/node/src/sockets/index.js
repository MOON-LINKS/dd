// Socket.io setup. Batch 4 wires the session-aware handshake auth that
// was left as a stub in Batch 1/2: an authenticated socket (the owner
// dashboard) auto-joins a private `owner:<userId>` room and receives full
// booking events; the unauthenticated public booking page joins a
// separate `public:<userId>` room by agency-name lookup only, so
// slot-availability broadcasts never carry booking PII (guest name/phone)
// to anyone but the owner's own dashboard. See bookingService.js for what
// gets emitted to each room.

const { Server } = require('socket.io');
const cookie = require('cookie');
const cookieSignature = require('cookie-signature');
const config = require('../config/env');
const logger = require('../utils/logger');
const sessionService = require('../services/sessionService');
const userModel = require('../models/userModel');

let ioInstance = null;

/**
 * Mirrors cookie-parser's signed-cookie format (`s:<value>.<hmac>`) so the
 * socket handshake can read the exact same session cookie the HTTP API
 * uses, without introducing a second auth mechanism to keep in sync.
 * @param {string|undefined} cookieHeader - raw `Cookie` header from the handshake
 * @returns {string|null} the session token, or null if absent/invalid
 */
function readSessionToken(cookieHeader) {
  if (!cookieHeader) return null;
  const parsed = cookie.parse(cookieHeader);
  const raw = parsed[config.auth.sessionCookieName];
  if (!raw || !raw.startsWith('s:')) return null; // only accept signed cookies, same as cookie-parser(secret)
  const unsigned = cookieSignature.unsign(raw.slice(2), config.auth.cookieSecret);
  return unsigned || null;
}

/**
 * @param {import('http').Server} httpServer
 * @returns {import('socket.io').Server}
 */
function initSocket(httpServer) {
  const io = new Server(httpServer, {
    cors: {
      origin: [config.clientOrigin, ...config.additionalOrigins],
      credentials: true,
    },
  });

  // Best-effort auth: a valid session attaches socket.data.userId and the
  // connection auto-joins the owner room below. An invalid/missing
  // session still connects (the public booking page never has one) — it
  // just doesn't get the owner room, and can only reach the public room
  // via the explicit subscribe event.
  io.use(async (socket, next) => {
    try {
      const sessionToken = readSessionToken(socket.handshake.headers.cookie);
      if (sessionToken) {
        const userId = await sessionService.validateSession(sessionToken);
        if (userId) socket.data.userId = userId;
      }
    } catch (err) {
      logger.warn('Socket handshake auth check failed', err);
    }
    next();
  });

  io.on('connection', (socket) => {
    logger.debug(`Socket connected: ${socket.id}`);

    if (socket.data.userId) {
      socket.join(`owner:${socket.data.userId}`);
    }

    // Public booking page: joins by agency name, which it already knows
    // (it's served from that business's own subdomain) — never by raw
    // userId, so a client can't enumerate or guess other businesses' rooms.
    socket.on('subscribe:business', async (payload, ack) => {
      const respond = typeof ack === 'function' ? ack : () => {};
      try {
        const agencyName = payload && payload.agencyName;
        if (typeof agencyName !== 'string' || !agencyName) {
          return respond({ ok: false });
        }
        const user = await userModel.findByAgencyName(agencyName);
        if (!user) {
          return respond({ ok: false });
        }
        socket.join(`public:${user.id}`);
        respond({ ok: true });
      } catch (err) {
        logger.warn('subscribe:business failed', err);
        respond({ ok: false });
      }
    });

    socket.on('disconnect', () => {
      logger.debug(`Socket disconnected: ${socket.id}`);
    });
  });

  ioInstance = io;
  return io;
}

/**
 * The live io instance, for services that need to emit outside the
 * request/response cycle (e.g. bookingService after a transaction
 * commits). Returns null before initSocket() has run — callers must
 * guard for that rather than assume it's always set (e.g. scripts/tests
 * that never start the HTTP server).
 * @returns {import('socket.io').Server|null}
 */
function getIO() {
  return ioInstance;
}

module.exports = initSocket;
module.exports.getIO = getIO;
