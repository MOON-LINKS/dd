// Reads the session cookie, validates it against Redis (fast revocation
// check), and attaches the authenticated user to the request. Throws
// AppError.unauthorized() for anything protected-route code downstream
// can rely on `req.user` being present.

const config = require('../config/env');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const sessionService = require('../services/sessionService');
const userModel = require('../models/userModel');
const { clearSessionCookie } = require('../utils/cookies');

const requireAuth = asyncHandler(async (req, res, next) => {
  const sessionToken = req.signedCookies?.[config.auth.sessionCookieName];

  if (!sessionToken) {
    throw AppError.unauthorized('Not authenticated.', 'NOT_AUTHENTICATED');
  }

  const userId = await sessionService.validateSession(sessionToken);
  if (!userId) {
    clearSessionCookie(res);
    throw AppError.unauthorized('Session expired or revoked.', 'SESSION_INVALID');
  }

  const userRow = await userModel.findById(userId);
  if (!userRow || !userRow.is_active) {
    clearSessionCookie(res);
    throw AppError.unauthorized('Session is no longer valid.', 'SESSION_INVALID');
  }

  req.user = userModel.toPublicUser(userRow);
  req.sessionToken = sessionToken;
  next();
});

module.exports = { requireAuth };
