const AppError = require('../utils/AppError');
const logger = require('../utils/logger');
const config = require('../config/env');

// Must be registered LAST, after all routes. Express recognizes it as an
// error handler because it takes 4 arguments.
function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  if (err instanceof AppError) {
    if (err.statusCode >= 500) logger.error(err.message, err);
    return res.status(err.statusCode).json({
      error: {
        message: err.message,
        code: err.code,
      },
    });
  }

  // Unknown/unexpected error — never leak internals to the client.
  logger.error('Unhandled error', err);
  return res.status(500).json({
    error: {
      message: config.isProduction ? 'Something went wrong' : err.message,
      code: 'INTERNAL_ERROR',
    },
  });
}

module.exports = errorHandler;
