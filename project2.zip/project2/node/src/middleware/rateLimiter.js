// Rate limiter factory built on express-rate-limit, backed by Redis so
// limits are consistent across multiple Node instances (not just
// per-process memory, which breaks the moment you scale horizontally).
//
// Concrete limiters are exported from here; specific TTLs/max values are
// tuned per endpoint in the batch that introduces that endpoint:
//   - authLimiter        -> Batch 2 (login/signup)
//   - publicBookingLimiter -> Batch 4 (booking creation is unauthenticated
//                             and public, so it's the highest-risk surface
//                             for spam/bot bookings)
//   - availabilityLimiter -> Batch 4 (also unauthenticated; looser than
//                             booking creation since it's read-only, but
//                             still worth capping against scraping/bots)

const rateLimit = require('express-rate-limit');
const { RedisStore } = require('rate-limit-redis');
const { redisClient } = require('../config/redis');
const AppError = require('../utils/AppError');

/**
 * @param {object} opts
 * @param {number} opts.windowMs
 * @param {number} opts.max
 * @param {string} opts.keyPrefix - namespaces the Redis keys per limiter
 */
function createRateLimiter({ windowMs, max, keyPrefix }) {
  return rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    store: new RedisStore({
      sendCommand: (...args) => redisClient.sendCommand(args),
      prefix: `rl:${keyPrefix}:`,
    }),
    handler: (req, res, next) => {
      next(AppError.tooMany('Too many requests, please try again later.', 'RATE_LIMITED'));
    },
  });
}

// Applied to /api/auth/login and /api/auth/signup. Keyed by IP (the
// express-rate-limit default) — generous enough not to lock out a real
// user fumbling their password, tight enough to blunt credential-stuffing
// and signup-spam bots.
const authLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 20,
  keyPrefix: 'auth',
});

// Applied to POST /api/bookings (public, unauthenticated). Tighter than
// authLimiter and keyed by IP — this is the endpoint the spec (§6) calls
// out as the highest-risk surface for spam bookings since anyone can hit
// it without logging in.
const publicBookingLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 10,
  keyPrefix: 'public-booking',
});

// Applied to GET /api/bookings/availability (public, unauthenticated).
// Read-only, so more generous than publicBookingLimiter, but still capped
// since a slot picker re-fetches on every date change.
const availabilityLimiter = createRateLimiter({
  windowMs: 5 * 60 * 1000,
  max: 60,
  keyPrefix: 'availability',
});

module.exports = { createRateLimiter, authLimiter, publicBookingLimiter, availabilityLimiter };
