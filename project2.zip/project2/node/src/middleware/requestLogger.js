const logger = require('../utils/logger');

// Lightweight request logger (kept dependency-free rather than pulling in
// morgan) — logs method, path, status, and duration for every request.
function requestLogger(req, res, next) {
  const start = process.hrtime.bigint();
  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    logger.info(`${req.method} ${req.originalUrl} ${res.statusCode} ${durationMs.toFixed(1)}ms`);
  });
  next();
}

module.exports = requestLogger;
