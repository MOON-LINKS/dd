const AppError = require('../utils/AppError');

// Registered after all routes, before errorHandler. Catches any request
// that didn't match a route.
function notFound(req, res, next) {
  next(AppError.notFound(`Route not found: ${req.method} ${req.originalUrl}`, 'ROUTE_NOT_FOUND'));
}

module.exports = notFound;
