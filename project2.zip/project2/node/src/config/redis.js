// Redis client — backs two things introduced in later batches:
//   1. Session storage for the Instagram-style persistent login
//      (fast revocation checks; user_sessions table in MySQL is
//      the durable/auditable mirror).
//   2. Distributed rate limiting (so limits hold across multiple
//      Node instances, not just per-process memory).
//
// Connected once at boot in server.js; every other module imports
// the same client instance from here.

const { createClient } = require('redis');
const config = require('./env');
const logger = require('../utils/logger');

const redisClient = createClient({ url: config.redis.url });

redisClient.on('error', (err) => {
  logger.error('Redis client error', err);
});

redisClient.on('reconnecting', () => {
  logger.warn('Redis reconnecting...');
});

async function connectRedis() {
  if (!redisClient.isOpen) {
    await redisClient.connect();
    logger.info('Redis connection OK');
  }
}

module.exports = { redisClient, connectRedis };
