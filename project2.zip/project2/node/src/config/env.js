// Loads and validates environment variables once, at process start.
// Every other module reads config from here — never process.env directly —
// so a missing/misnamed variable fails loudly at boot instead of silently
// at request time.

require('dotenv').config();

function required(name, fallback) {
  const value = process.env[name] ?? fallback;
  if (value === undefined) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

const isProduction = process.env.NODE_ENV === 'production';

const config = {
  nodeEnv: process.env.NODE_ENV || 'development',
  isProduction,
  port: parseInt(process.env.PORT || '4000', 10),

  clientOrigin: required('CLIENT_ORIGIN', 'http://localhost:5173'),
  additionalOrigins: (process.env.ADDITIONAL_ORIGINS || '')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean),

  db: {
    host: required('DB_HOST', '127.0.0.1'),
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: required('DB_USER', 'root'),
    password: process.env.DB_PASSWORD || '',
    database: required('DB_NAME', 'booking_system'),
    connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT || '10', 10),
  },

  redis: {
    url: required('REDIS_URL', 'redis://127.0.0.1:6379'),
  },

  auth: {
    jwtSecret: required('JWT_SECRET'),
    accessTokenTtl: process.env.JWT_ACCESS_TOKEN_TTL || '15m',
    sessionCookieName: process.env.SESSION_COOKIE_NAME || 'bcs_session',
    sessionCookieSameSite:
      process.env.SESSION_COOKIE_SAMESITE || (isProduction ? 'none' : 'lax'),
    sessionTtlDays: parseInt(process.env.SESSION_TTL_DAYS || '30', 10),
    cookieSecret: required('COOKIE_SECRET'),
  },

  paddle: {
    apiKey: process.env.PADDLE_API_KEY || null,
    webhookSecret: process.env.PADDLE_WEBHOOK_SECRET || null,
  },

  email: {
    apiKey: process.env.EMAIL_PROVIDER_API_KEY || null,
    fromAddress: process.env.EMAIL_FROM_ADDRESS || null,
  },
};

module.exports = config;
