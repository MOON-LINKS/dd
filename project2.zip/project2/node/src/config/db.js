// MySQL connection pool (mysql2/promise). Every query in the app goes
// through this pool — never opens ad-hoc connections — so we get
// connection reuse and predictable limits under Socket.io's concurrent load.

const mysql = require('mysql2/promise');
const config = require('./env');
const logger = require('../utils/logger');

const pool = mysql.createPool({
  host: config.db.host,
  port: config.db.port,
  user: config.db.user,
  password: config.db.password,
  database: config.db.database,
  connectionLimit: config.db.connectionLimit,
  waitForConnections: true,
  queueLimit: 0,
  dateStrings: false,
  timezone: 'Z', // store/read as UTC; convert to business timezone at the display layer
});

async function testConnection() {
  const conn = await pool.getConnection();
  try {
    await conn.ping();
    logger.info('MySQL connection OK');
  } finally {
    conn.release();
  }
}

/**
 * Run a callback inside a single transaction. Used anywhere multiple
 * writes must succeed or fail together — most importantly booking
 * creation (§ concurrency handling), where the availability check and
 * the INSERT must be atomic.
 *
 * @param {(conn: import('mysql2/promise').PoolConnection) => Promise<any>} work
 */
async function withTransaction(work) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await work(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

module.exports = { pool, testConnection, withTransaction };
