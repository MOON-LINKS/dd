// Assembles the Express app: global middleware, then routes (mounted
// batch by batch as they're built), then the 404 + error handlers, which
// must always stay last.

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const config = require('./config/env');
const requestLogger = require('./middleware/requestLogger');
const notFound = require('./middleware/notFound');
const errorHandler = require('./middleware/errorHandler');

function createApp() {
  const app = express();

  // Trust the first proxy hop (needed for correct req.ip / rate limiting
  // and secure cookies when deployed behind a reverse proxy/load balancer).
  app.set('trust proxy', 1);

  app.use(helmet());

  // Allow the owner dashboard (web build) and any additional trusted
  // origins (future desktop webview, etc.). `credentials: true` is required
  // because auth relies on an HTTP-only cookie, not a bearer header, so it
  // behaves identically across web and desktop clients.
  const allowedOrigins = [config.clientOrigin, ...config.additionalOrigins];
  app.use(
    cors({
      origin(origin, callback) {
        // Allow no-origin requests (mobile app / server-to-server / curl).
        if (!origin || allowedOrigins.includes(origin)) {
          return callback(null, true);
        }
        return callback(new Error('Not allowed by CORS'));
      },
      credentials: true,
    })
  );

  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));
  app.use(cookieParser(config.auth.cookieSecret));
  app.use(requestLogger);

  app.get('/health', (req, res) => {
    res.json({ status: 'ok', env: config.nodeEnv, time: new Date().toISOString() });
  });

  app.use('/api/auth', require('./routes/auth.routes'));
  app.use('/api/services', require('./routes/services.routes'));
  app.use('/api/schedule', require('./routes/schedule.routes'));
  app.use('/api/bookings', require('./routes/booking.routes'));

  // ---------------------------------------------------------------
  // Remaining feature routes are mounted here, one line per batch as they land:
  //   Batch 5 -> app.use('/api/clients', ...), app.use('/api/waitlist', ...)
  //   Batch 6 -> app.use('/api/expenses', ...), app.use('/api/analytics', ...)
  //   Batch 7 -> app.use('/api/billing', ...)
  //   Batch 8 -> app.use('/api/bio', ...), app.use('/api/staff-ratings', ...)
  // ---------------------------------------------------------------

  app.use(notFound);
  app.use(errorHandler);

  return app;
}

module.exports = createApp;
