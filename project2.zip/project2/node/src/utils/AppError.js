// A known, "expected" error (bad input, not found, unauthorized, conflict,
// etc.) as opposed to a bug. Route handlers/services throw this; the central
// error handler (middleware/errorHandler.js) knows how to render it safely.
// Anything that is NOT an AppError is treated as a bug and never leaks
// details to the client.

class AppError extends Error {
  /**
   * @param {string} message - safe to show to the client
   * @param {number} statusCode - HTTP status code
   * @param {string} [code] - stable machine-readable error code for the frontend, e.g. "SLOT_TAKEN"
   */
  constructor(message, statusCode = 400, code = 'BAD_REQUEST') {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }

  static badRequest(message, code) {
    return new AppError(message, 400, code || 'BAD_REQUEST');
  }
  static unauthorized(message = 'Unauthorized', code) {
    return new AppError(message, 401, code || 'UNAUTHORIZED');
  }
  static forbidden(message = 'Forbidden', code) {
    return new AppError(message, 403, code || 'FORBIDDEN');
  }
  static notFound(message = 'Not found', code) {
    return new AppError(message, 404, code || 'NOT_FOUND');
  }
  static conflict(message = 'Conflict', code) {
    return new AppError(message, 409, code || 'CONFLICT');
  }
  static tooMany(message = 'Too many requests', code) {
    return new AppError(message, 429, code || 'RATE_LIMITED');
  }
}

module.exports = AppError;
