// Single source of truth for the session cookie's name/options, so the
// options set on login/signup and the ones used to clear it on logout can
// never silently drift apart.

const config = require('../config/env');

function cookieOptions() {
  return {
    httpOnly: true,
    secure: config.isProduction,
    sameSite: config.auth.sessionCookieSameSite,
    signed: true,
    maxAge: config.auth.sessionTtlDays * 24 * 60 * 60 * 1000,
    path: '/',
  };
}

/**
 * @param {import('express').Response} res
 * @param {string} sessionToken
 */
function setSessionCookie(res, sessionToken) {
  res.cookie(config.auth.sessionCookieName, sessionToken, cookieOptions());
}

/**
 * @param {import('express').Response} res
 */
function clearSessionCookie(res) {
  const { maxAge, ...clearOptions } = cookieOptions(); // eslint-disable-line no-unused-vars
  res.clearCookie(config.auth.sessionCookieName, clearOptions);
}

module.exports = { setSessionCookie, clearSessionCookie };
