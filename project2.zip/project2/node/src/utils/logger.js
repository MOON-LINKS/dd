// Minimal structured logger. Swap the transport later (pino/winston) without
// touching call sites elsewhere in the app — everything logs through this
// module, never console.* directly.

const config = require('../config/env');

function timestamp() {
  return new Date().toISOString();
}

function format(level, message, meta) {
  const base = `[${timestamp()}] [${level}] ${message}`;
  if (meta === undefined) return base;
  if (meta instanceof Error) {
    return `${base}\n${meta.stack || meta.message}`;
  }
  try {
    return `${base} ${JSON.stringify(meta)}`;
  } catch {
    return base;
  }
}

const logger = {
  info: (message, meta) => console.log(format('INFO', message, meta)),
  warn: (message, meta) => console.warn(format('WARN', message, meta)),
  error: (message, meta) => console.error(format('ERROR', message, meta)),
  debug: (message, meta) => {
    if (!config.isProduction) console.debug(format('DEBUG', message, meta));
  },
};

module.exports = logger;
