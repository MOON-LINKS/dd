const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const bookingService = require('../services/bookingService');
const userModel = require('../models/userModel');

/**
 * Public routes are addressed by agency name (the subdomain the public
 * booking page is served from), not a raw numeric id — an unauthenticated
 * caller has no other legitimate way to know a business's internal id.
 * @param {string} agencyName
 * @returns {Promise<number>} userId
 */
async function resolveOwnerIdByAgencyName(agencyName) {
  const owner = await userModel.findByAgencyName(agencyName);
  if (!owner) {
    throw AppError.notFound('Business not found.', 'BUSINESS_NOT_FOUND');
  }
  return owner.id;
}

function parseServiceIds(raw) {
  if (Array.isArray(raw)) return raw.map(Number);
  if (typeof raw === 'string' && raw.trim()) {
    return raw.split(',').map((id) => Number(id.trim()));
  }
  return [];
}

// ---------------------------------------------------------------
// Public (unauthenticated) — reached from the business's own subdomain
// ---------------------------------------------------------------

const publicAvailability = asyncHandler(async (req, res) => {
  const ownerId = await resolveOwnerIdByAgencyName(req.params.agencyName);
  const { date } = req.query;
  if (!date) {
    throw AppError.badRequest('date query param is required.', 'MISSING_DATE');
  }
  const serviceIds = parseServiceIds(req.query.serviceIds);
  const availability = await bookingService.getAvailability(ownerId, { date, serviceIds });
  res.json({ availability });
});

const publicCreateBooking = asyncHandler(async (req, res) => {
  const ownerId = await resolveOwnerIdByAgencyName(req.params.agencyName);
  const { startTime, serviceIds, guestName, guestPhone } = req.body;
  const booking = await bookingService.createBooking(ownerId, {
    startTime,
    serviceIds: parseServiceIds(serviceIds),
    guestName,
    guestPhone,
  });
  res.status(201).json({ booking });
});

// ---------------------------------------------------------------
// Owner dashboard (requireAuth)
// ---------------------------------------------------------------

const list = asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) {
    throw AppError.badRequest('from and to query params are required.', 'MISSING_RANGE');
  }
  const bookings = await bookingService.listBookings(req.user.id, from, to);
  res.json({ bookings });
});

const availability = asyncHandler(async (req, res) => {
  const { date } = req.query;
  if (!date) {
    throw AppError.badRequest('date query param is required.', 'MISSING_DATE');
  }
  const serviceIds = parseServiceIds(req.query.serviceIds);
  const result = await bookingService.getAvailability(req.user.id, { date, serviceIds });
  res.json({ availability: result });
});

const cancel = asyncHandler(async (req, res) => {
  const booking = await bookingService.cancelBooking(Number(req.params.id), req.user.id);
  res.json({ booking });
});

const complete = asyncHandler(async (req, res) => {
  const booking = await bookingService.completeBooking(Number(req.params.id), req.user.id);
  res.json({ booking });
});

const reschedule = asyncHandler(async (req, res) => {
  const booking = await bookingService.rescheduleBooking(
    Number(req.params.id),
    req.user.id,
    req.body.startTime
  );
  res.json({ booking });
});

const blockTime = asyncHandler(async (req, res) => {
  const { startTime, endTime, reason } = req.body;
  const booking = await bookingService.blockTime(req.user.id, { startTime, endTime, reason });
  res.status(201).json({ booking });
});

module.exports = {
  publicAvailability,
  publicCreateBooking,
  list,
  availability,
  cancel,
  complete,
  reschedule,
  blockTime,
};
