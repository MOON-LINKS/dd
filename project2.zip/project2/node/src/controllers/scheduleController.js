const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const scheduleService = require('../services/scheduleService');

const getWeeklyHours = asyncHandler(async (req, res) => {
  const weeklyHours = await scheduleService.getWeeklyHours(req.user.id);
  res.json({ weeklyHours });
});

const setWeeklyHours = asyncHandler(async (req, res) => {
  const weeklyHours = await scheduleService.setWeeklyHours(req.user.id, req.body.days);
  res.json({ weeklyHours });
});

const listExceptions = asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) {
    throw AppError.badRequest('from and to query params are required.', 'MISSING_RANGE');
  }
  const exceptions = await scheduleService.listExceptions(req.user.id, from, to);
  res.json({ exceptions });
});

const createException = asyncHandler(async (req, res) => {
  const { exceptionDate, isClosed, customOpenTime, customCloseTime, reason } = req.body;
  const exception = await scheduleService.createException(req.user.id, {
    exceptionDate,
    isClosed,
    customOpenTime,
    customCloseTime,
    reason,
  });
  res.status(201).json({ exception });
});

const updateException = asyncHandler(async (req, res) => {
  const { isClosed, customOpenTime, customCloseTime, reason } = req.body;
  const exception = await scheduleService.updateException(Number(req.params.id), req.user.id, {
    isClosed,
    customOpenTime,
    customCloseTime,
    reason,
  });
  res.json({ exception });
});

const removeException = asyncHandler(async (req, res) => {
  await scheduleService.deleteException(Number(req.params.id), req.user.id);
  res.status(204).send();
});

module.exports = {
  getWeeklyHours,
  setWeeklyHours,
  listExceptions,
  createException,
  updateException,
  removeException,
};
