const asyncHandler = require('../utils/asyncHandler');
const authService = require('../services/authService');
const { setSessionCookie, clearSessionCookie } = require('../utils/cookies');

const VALID_PLATFORMS = ['web', 'desktop', 'mobile'];

/**
 * Pulls the request-context fields every session row wants to record.
 * @param {import('express').Request} req
 */
function sessionContext(req) {
  const platformHeader = req.get('X-Client-Platform');
  return {
    userAgent: req.get('User-Agent') || null,
    ipAddress: req.ip,
    platform: VALID_PLATFORMS.includes(platformHeader) ? platformHeader : 'web',
  };
}

const signup = asyncHandler(async (req, res) => {
  const { agencyName, email, password, fullName, phone, locale } = req.body;
  const { user, sessionToken } = await authService.signup(
    { agencyName, email, password, fullName, phone, locale },
    sessionContext(req)
  );

  setSessionCookie(res, sessionToken);
  res.status(201).json({ user });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const { user, sessionToken } = await authService.login(
    { email, password },
    sessionContext(req)
  );

  setSessionCookie(res, sessionToken);
  res.json({ user });
});

const logout = asyncHandler(async (req, res) => {
  await authService.logout(req.sessionToken);
  clearSessionCookie(res);
  res.status(204).send();
});

const logoutAll = asyncHandler(async (req, res) => {
  await authService.logoutAll(req.user.id);
  clearSessionCookie(res);
  res.status(204).send();
});

const me = asyncHandler(async (req, res) => {
  res.json({ user: req.user });
});

module.exports = { signup, login, logout, logoutAll, me };
