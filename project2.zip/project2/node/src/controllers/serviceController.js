const asyncHandler = require('../utils/asyncHandler');
const serviceService = require('../services/serviceService');

const list = asyncHandler(async (req, res) => {
  const services = await serviceService.listServices(req.user.id);
  res.json({ services });
});

const create = asyncHandler(async (req, res) => {
  const { categoryId, name, durationMinutes, bufferMinutes, priceValue, priceCurrency } = req.body;
  const service = await serviceService.createService(req.user.id, {
    categoryId,
    name,
    durationMinutes,
    bufferMinutes,
    priceValue,
    priceCurrency,
  });
  res.status(201).json({ service });
});

const update = asyncHandler(async (req, res) => {
  const { categoryId, name, durationMinutes, bufferMinutes, priceValue, priceCurrency } = req.body;
  const service = await serviceService.updateService(Number(req.params.id), req.user.id, {
    categoryId,
    name,
    durationMinutes,
    bufferMinutes,
    priceValue,
    priceCurrency,
  });
  res.json({ service });
});

const activate = asyncHandler(async (req, res) => {
  const service = await serviceService.setActive(Number(req.params.id), req.user.id, true);
  res.json({ service });
});

const deactivate = asyncHandler(async (req, res) => {
  const service = await serviceService.setActive(Number(req.params.id), req.user.id, false);
  res.json({ service });
});

const remove = asyncHandler(async (req, res) => {
  await serviceService.deleteService(Number(req.params.id), req.user.id);
  res.status(204).send();
});

module.exports = { list, create, update, activate, deactivate, remove };
