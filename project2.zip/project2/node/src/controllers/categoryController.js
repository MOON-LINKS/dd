const asyncHandler = require('../utils/asyncHandler');
const categoryService = require('../services/categoryService');

const list = asyncHandler(async (req, res) => {
  const categories = await categoryService.listCategories(req.user.id);
  res.json({ categories });
});

const create = asyncHandler(async (req, res) => {
  const category = await categoryService.createCategory(req.user.id, req.body.name);
  res.status(201).json({ category });
});

const rename = asyncHandler(async (req, res) => {
  const category = await categoryService.renameCategory(
    Number(req.params.id),
    req.user.id,
    req.body.name
  );
  res.json({ category });
});

const remove = asyncHandler(async (req, res) => {
  await categoryService.deleteCategory(Number(req.params.id), req.user.id);
  res.status(204).send();
});

const reorder = asyncHandler(async (req, res) => {
  const categories = await categoryService.reorderCategories(req.user.id, req.body.orderedIds);
  res.json({ categories });
});

module.exports = { list, create, rename, remove, reorder };
