const db = require('../utils/db')
const stripe = require('../utils/stripeClient')
const { verifyTransaction } = require('../utils/appleIAP')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { validateReferralCodeValue } = require('../utils/referralEngine')
const { getOrCreateReferralCoupon } = require('../utils/referralStripeCoupon')

// ------------------------------------------------------------------
// Shared helpers
// ------------------------------------------------------------------

// The org's currently-active subscribed_services row, if any. There is at
// most one per org — Section 14 conventions ("one owner user, one active
// plan") and the payment-path rule in Section 10 ("the two payment paths do
// not cross") both assume a single active subscription per organization.
const getActiveSubscription = async (organizationId) => {
    const { rows } = await db.query(
        `SELECT id, plan_id, payment_provider, external_subscription_id, billing_cadence,
                since, active_until, price, is_cancelled, is_active
         FROM subscribed_services
         WHERE organization_id = $1 AND is_active = TRUE
         ORDER BY created_at DESC
         LIMIT 1`,
        [organizationId]
    )
    return rows[0] || null
}

const getPlanById = async (planId) => {
    const { rows } = await db.query(
        `SELECT plan_id, name, max_workers, modules, history_months,
                stripe_price_id_monthly, stripe_price_id_yearly,
                apple_product_id_monthly, apple_product_id_yearly, is_active
         FROM plans
         WHERE plan_id = $1`,
        [planId]
    )
    return rows[0] || null
}

// ------------------------------------------------------------------
// CREATE CHECKOUT SESSION (Stripe) — web & Android per Section 10.
// Body: { planId, billingCadence: 'monthly'|'yearly' }
// ------------------------------------------------------------------
const createCheckoutSession = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { planId, billingCadence, referralCode } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!planId || !['monthly', 'yearly'].includes(billingCadence)) {
            return res.status(400).json({ message: 'planId and billingCadence (monthly|yearly) are required' })
        }

        const existing = await getActiveSubscription(organizationId)
        if (existing) {
            if (existing.payment_provider === 'apple') {
                // Section 10: "the two payment paths do not cross."
                return res.status(409).json({ message: 'this organization is subscribed via Apple IAP — manage the subscription on iOS' })
            }
            return res.status(409).json({ message: 'this organization already has an active subscription — use change-plan instead' })
        }

        const plan = await getPlanById(planId)
        if (!plan || !plan.is_active) {
            return res.status(404).json({ message: 'plan not found or inactive' })
        }
        const priceId = billingCadence === 'monthly' ? plan.stripe_price_id_monthly : plan.stripe_price_id_yearly
        if (!priceId) {
            return res.status(400).json({ message: `plan "${plan.name}" has no Stripe price configured for ${billingCadence} billing` })
        }

        let discounts
        if (referralCode) {
            const { valid, referring_organization_id, discount_pct } = await validateReferralCodeValue(referralCode)
            if (!valid) return res.status(400).json({ message: 'invalid referral code' })
            if (referring_organization_id === organizationId) {
                return res.status(400).json({ message: 'you cannot use your own referral code' })
            }
            const couponId = await getOrCreateReferralCoupon(discount_pct)
            discounts = [{ coupon: couponId }]
        }

        // Reuse the org's existing Stripe customer if one was already created
        // on a previous (e.g. abandoned) checkout attempt, instead of minting
        // a new one every time.
        const { rows: orgRows } = await db.query(
            `SELECT o.stripe_customer_id, u.email
             FROM organizations o
             JOIN users u ON u.id = o.owner_user_id
             WHERE o.id = $1 AND o.deleted_at IS NULL`,
            [organizationId]
        )
        if (orgRows.length === 0) return res.status(404).json({ message: 'organization not found' })
        const org = orgRows[0]

        let stripeCustomerId = org.stripe_customer_id
        if (!stripeCustomerId) {
            const customer = await stripe.customers.create({
                email: org.email,
                metadata: { organizationId }
            })
            stripeCustomerId = customer.id
            await db.query('UPDATE organizations SET stripe_customer_id = $1 WHERE id = $2', [stripeCustomerId, organizationId])
        }

        const session = await stripe.checkout.sessions.create({
            customer: stripeCustomerId,
            mode: 'subscription',
            line_items: [{ price: priceId, quantity: 1 }],
            ...(discounts ? { discounts } : { allow_promotion_codes: true }),
            success_url: process.env.STRIPE_CHECKOUT_SUCCESS_URL,
            cancel_url: process.env.STRIPE_CHECKOUT_CANCEL_URL,
            metadata: { organizationId, planId, billingCadence, referralCode: referralCode || '' },
            subscription_data: {
                metadata: { organizationId, planId, billingCadence }
            }
        })

        res.status(200).json({ url: session.url })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create checkout session' })
    }
}

// ------------------------------------------------------------------
// CHANGE PLAN (Stripe) — upgrade or downgrade the active subscription.
// Body: { planId, billingCadence: 'monthly'|'yearly' }
//
// Deliberately does NOT write subscribed_services/organizations itself —
// only triggers the change on Stripe's side. The customer.subscription.updated
// webhook is what persists the new plan_id/price/active_until, matching
// Section 10's rule that the entitlement table is only ever written by
// webhook/notification handlers, never by request-time controllers.
// ------------------------------------------------------------------
const changePlan = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { planId, billingCadence } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!planId || !['monthly', 'yearly'].includes(billingCadence)) {
            return res.status(400).json({ message: 'planId and billingCadence (monthly|yearly) are required' })
        }

        const existing = await getActiveSubscription(organizationId)
        if (!existing || existing.payment_provider !== 'stripe') {
            return res.status(409).json({ message: 'no active Stripe subscription to change — use checkout instead' })
        }

        const plan = await getPlanById(planId)
        if (!plan || !plan.is_active) {
            return res.status(404).json({ message: 'plan not found or inactive' })
        }
        const newPriceId = billingCadence === 'monthly' ? plan.stripe_price_id_monthly : plan.stripe_price_id_yearly
        if (!newPriceId) {
            return res.status(400).json({ message: `plan "${plan.name}" has no Stripe price configured for ${billingCadence} billing` })
        }

        const subscription = await stripe.subscriptions.retrieve(existing.external_subscription_id)
        const itemId = subscription.items.data[0].id

        await stripe.subscriptions.update(existing.external_subscription_id, {
            items: [{ id: itemId, price: newPriceId }],
            proration_behavior: 'create_prorations',
            metadata: { organizationId, planId, billingCadence }
        })

        res.status(200).json({ message: 'plan change submitted — it will reflect once Stripe confirms the update' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not change plan' })
    }
}

// ------------------------------------------------------------------
// CANCEL SUBSCRIPTION (Stripe) — toggles auto-renew, does not revoke
// access immediately. Body: { autoRenew: boolean }
// Optimistically flips is_cancelled locally for immediate UI feedback;
// the webhook reconciles the same field afterward (idempotent overwrite),
// but is_active is never touched here — only Stripe/the webhook decide that.
// ------------------------------------------------------------------
const cancelSubscription = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { autoRenew } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (typeof autoRenew !== 'boolean') {
            return res.status(400).json({ message: 'autoRenew (boolean) is required' })
        }

        const existing = await getActiveSubscription(organizationId)
        if (!existing || existing.payment_provider !== 'stripe') {
            return res.status(409).json({ message: 'no active Stripe subscription to cancel' })
        }

        await stripe.subscriptions.update(existing.external_subscription_id, {
            cancel_at_period_end: !autoRenew
        })
        await db.query('UPDATE subscribed_services SET is_cancelled = $1 WHERE id = $2', [!autoRenew, existing.id])

        res.status(200).json({ message: autoRenew ? 'auto-renew re-enabled' : 'subscription will not renew at period end' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update cancellation status' })
    }
}

// ------------------------------------------------------------------
// MANAGE BILLING (Stripe billing portal) — payment method updates,
// invoice history, etc. all handled by Stripe's hosted portal.
// ------------------------------------------------------------------
const manageBilling = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const { rows } = await db.query('SELECT stripe_customer_id FROM organizations WHERE id = $1', [organizationId])
        if (rows.length === 0) return res.status(404).json({ message: 'organization not found' })
        if (!rows[0].stripe_customer_id) return res.status(404).json({ message: 'no Stripe customer on file for this organization' })

        const session = await stripe.billingPortal.sessions.create({
            customer: rows[0].stripe_customer_id,
            return_url: process.env.STRIPE_BILLING_PORTAL_RETURN_URL
        })
        res.status(200).json({ url: session.url })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create billing portal session' })
    }
}

// ------------------------------------------------------------------
// REGISTER APPLE TRANSACTION — iOS only. Called by the app immediately
// after StoreKit 2 reports a successful purchase, handing the backend the
// signed transaction so it can grant entitlement right away rather than
// waiting on a server notification (which isn't guaranteed to be prompt).
// The subsequent App Store Server Notifications webhook (appleController.js)
// is what keeps this row in sync afterward — this endpoint only ever
// handles the FIRST activation of a given originalTransactionId.
// Body: { signedTransactionInfo }
// ------------------------------------------------------------------
const registerAppleTransaction = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { signedTransactionInfo } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!signedTransactionInfo) {
            return res.status(400).json({ message: 'signedTransactionInfo is required' })
        }

        const existing = await getActiveSubscription(organizationId)
        if (existing && existing.payment_provider === 'stripe') {
            return res.status(409).json({ message: 'this organization is subscribed via Stripe — manage the subscription on web' })
        }

        const transaction = await verifyTransaction(signedTransactionInfo)
        // transaction: { originalTransactionId, productId, expiresDate,
        //   purchaseDate, price, currency, environment, ... }

        // Derive the plan/cadence from the verified productId rather than
        // trusting anything the client claims — the signed payload is the
        // only part of this request that can't be spoofed.
        const { rows: planRows } = await db.query(
            `SELECT plan_id, name FROM plans
             WHERE (apple_product_id_monthly = $1 OR apple_product_id_yearly = $1) AND is_active = TRUE`,
            [transaction.productId]
        )
        if (planRows.length === 0) {
            return res.status(400).json({ message: `productId ${transaction.productId} does not match any active plan` })
        }
        const plan = planRows[0]
        const billingCadence = transaction.productId === plan.apple_product_id_yearly ? 'yearly' : 'monthly'

        const expiresDate = new Date(transaction.expiresDate)
        const purchaseDate = new Date(transaction.purchaseDate)
        const price = transaction.price != null ? transaction.price / 1000 : 0 // StoreKit 2 price is in milliunits

        const client = await db.connect()
        try {
            await client.query('BEGIN')
            // At most one active row per org (see getActiveSubscription comment).
            await client.query('UPDATE subscribed_services SET is_active = FALSE WHERE organization_id = $1 AND is_active = TRUE', [organizationId])
            const { rows } = await client.query(
                `INSERT INTO subscribed_services
                    (organization_id, plan_id, payment_provider, external_subscription_id,
                     billing_cadence, since, active_until, price, is_cancelled, is_active)
                 VALUES ($1, $2, 'apple', $3, $4, $5, $6, $7, FALSE, TRUE)
                 ON CONFLICT (external_subscription_id) DO UPDATE
                    SET plan_id = EXCLUDED.plan_id, active_until = EXCLUDED.active_until,
                        price = EXCLUDED.price, is_active = TRUE, is_cancelled = FALSE,
                        updated_at = NOW()
                 RETURNING id`,
                [organizationId, plan.plan_id, transaction.originalTransactionId, billingCadence, purchaseDate, expiresDate, price]
            )
            await client.query('UPDATE organizations SET plan_id = $1 WHERE id = $2', [plan.plan_id, organizationId])
            await client.query('COMMIT')
            res.status(200).json({ message: 'subscription activated', subscribedServiceId: rows[0].id })
        } catch (txErr) {
            await client.query('ROLLBACK').catch(() => {})
            throw txErr
        } finally {
            client.release()
        }
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not register Apple transaction' })
    }
}

module.exports = {
    createCheckoutSession,
    changePlan,
    cancelSubscription,
    manageBilling,
    registerAppleTransaction,
    // Exported so organizationController.deleteOrganization can look up and
    // best-effort-cancel an active subscription on org deletion, without
    // duplicating this query. See 11.files/BATCH_NOTES.md.
    getActiveSubscription
}
