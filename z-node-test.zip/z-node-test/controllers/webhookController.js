const db = require('../utils/db')
const stripe = require('../utils/stripeClient')
const { ensureReferralCodeForOrganization, recordReferralUseIfNew, recordReferralEarning } = require('../utils/referralEngine')

// Mounted with express.raw({ type: 'application/json' }) — see routes/webhookRoutes.js
// and the index.js merge notes in BATCH_NOTES.md. Signature verification needs the
// exact raw request body bytes; if express.json() has already parsed it, this fails.

// Resolves organization_id for a Stripe subscription: prefer the metadata set
// at checkout (subscription_data.metadata in paymentController.createCheckoutSession),
// fall back to matching organizations.stripe_customer_id for subscriptions that
// somehow didn't carry metadata (e.g. created manually in the Stripe dashboard).
const resolveOrganizationId = async (subscription) => {
    if (subscription.metadata?.organizationId) return subscription.metadata.organizationId
    const { rows } = await db.query('SELECT id FROM organizations WHERE stripe_customer_id = $1', [subscription.customer])
    return rows[0]?.id || null
}

const resolvePlanByStripePriceId = async (priceId) => {
    const { rows } = await db.query(
        `SELECT plan_id, stripe_price_id_monthly, stripe_price_id_yearly
         FROM plans
         WHERE stripe_price_id_monthly = $1 OR stripe_price_id_yearly = $1`,
        [priceId]
    )
    if (rows.length === 0) return null
    const billingCadence = rows[0].stripe_price_id_yearly === priceId ? 'yearly' : 'monthly'
    return { planId: rows[0].plan_id, billingCadence }
}

// Upserts the subscribed_services row for a Stripe subscription and keeps
// organizations.plan_id in sync. Shared by checkout.session.completed and
// customer.subscription.updated — both end up wanting the same fields synced
// from the current state of the Subscription object.
const syncSubscriptionRow = async (subscription) => {
    const organizationId = await resolveOrganizationId(subscription)
    if (!organizationId) {
        console.error(`Stripe webhook: could not resolve organizationId for subscription ${subscription.id}`)
        return
    }

    const item = subscription.items.data[0]
    const priceId = item.price.id
    const resolved = await resolvePlanByStripePriceId(priceId)
    if (!resolved) {
        console.error(`Stripe webhook: price ${priceId} on subscription ${subscription.id} does not match any plan`)
        return
    }

    const activeUntil = new Date(subscription.current_period_end * 1000)
    const since = new Date(subscription.start_date * 1000)
    const price = item.price.unit_amount != null ? item.price.unit_amount / 100 : 0
    const isActive = ['active', 'trialing'].includes(subscription.status)

    const client = await db.connect()
    try {
        await client.query('BEGIN')
        // At most one active row per org — deactivate any other row for this
        // org before upserting this one (covers the plan-swap-via-new-subscription
        // edge case; the common case just updates the same row via ON CONFLICT).
        await client.query(
            'UPDATE subscribed_services SET is_active = FALSE WHERE organization_id = $1 AND external_subscription_id != $2 AND is_active = TRUE',
            [organizationId, subscription.id]
        )
        await client.query(
            `INSERT INTO subscribed_services
                (organization_id, plan_id, payment_provider, external_subscription_id,
                 billing_cadence, since, active_until, price, is_cancelled, is_active)
             VALUES ($1, $2, 'stripe', $3, $4, $5, $6, $7, $8, $9)
             ON CONFLICT (external_subscription_id) DO UPDATE
                SET plan_id = EXCLUDED.plan_id, billing_cadence = EXCLUDED.billing_cadence,
                    active_until = EXCLUDED.active_until, price = EXCLUDED.price,
                    is_cancelled = EXCLUDED.is_cancelled, is_active = EXCLUDED.is_active,
                    updated_at = NOW()`,
            [organizationId, resolved.planId, subscription.id, resolved.billingCadence,
                since, activeUntil, price, subscription.cancel_at_period_end, isActive]
        )
        await client.query('UPDATE organizations SET plan_id = $1, stripe_customer_id = $2 WHERE id = $3', [resolved.planId, subscription.customer, organizationId])
        await client.query('COMMIT')
    } catch (err) {
        await client.query('ROLLBACK').catch(() => { })
        throw err
    } finally {
        client.release()
    }
}

const stripeWebhook = async (req, res) => {
    const sig = req.headers['stripe-signature']
    let event
    try {
        event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET)
    } catch (err) {
        console.error('Stripe webhook signature verification failed:', err.message)
        return res.status(400).send(`Webhook Error: ${err.message}`)
    }
    try {
        switch (event.type) {
            case 'checkout.session.completed': {
                const session = event.data.object
                if (session.mode !== 'subscription') break
                const subscription = await stripe.subscriptions.retrieve(session.subscription)
                await syncSubscriptionRow(subscription)

                const organizationId = session.metadata?.organizationId
                if (organizationId) {
                    await ensureReferralCodeForOrganization(db, organizationId)
                    if (session.metadata?.referralCode) {
                        await recordReferralUseIfNew(db, { code: session.metadata.referralCode, referredOrganizationId: organizationId })
                    }
                }
                break
            }
            case 'invoice.payment_succeeded': {
                const invoice = event.data.object
                if (!invoice.subscription) break
                const subscription = await stripe.subscriptions.retrieve(invoice.subscription)
                const organizationId = subscription.metadata?.organizationId
                if (organizationId) {
                    await recordReferralEarning(db, {
                        referredOrganizationId: organizationId,
                        stripeInvoiceId: invoice.id,
                        amountPaidCents: invoice.amount_paid
                    })
                }
                break
            }
            // Fires on plan/price changes, renewals, and status transitions
            // (active -> past_due -> unpaid etc.) — Stripe's own subscription
            // `status` field is trusted as the is_active source rather than
            // reimplementing retry/grace-period logic here.
            case 'customer.subscription.updated': {
                await syncSubscriptionRow(event.data.object)
                break
            }
            case 'customer.subscription.deleted': {
                const subscription = event.data.object
                await db.query(
                    'UPDATE subscribed_services SET is_active = FALSE, is_cancelled = TRUE, updated_at = NOW() WHERE external_subscription_id = $1',
                    [subscription.id]
                )
                break
            }
            // Not acted on directly — customer.subscription.updated already
            // covers the resulting status change (past_due/unpaid) once Stripe's
            // retry schedule concludes. Logged so failed payments are visible.
            case 'invoice.payment_failed': {
                console.warn(`Stripe invoice payment failed: invoice ${event.data.object.id}, subscription ${event.data.object.subscription}`)
                break
            }

            default:
                break
        }
        res.status(200).json({ received: true })
    } catch (err) {
        console.error('Stripe webhook processing error:', err)
        // 500 so Stripe retries delivery rather than treating this event as handled.
        res.status(500).json({ error: 'webhook processing failed' })
    }
}

module.exports = { stripeWebhook }