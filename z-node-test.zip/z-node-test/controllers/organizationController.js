const db = require('../utils/db')
const bcrypt = require('bcrypt')
const stripe = require('../utils/stripeClient')
const { getActiveSubscription } = require('./paymentController')
const { ORGANIZATION_TYPES } = require('../utils/constants')

// ------------------------------------------------------------------
// CREATE ORGANIZATION — the onboarding step right after verifyOTP,
// before payment. Sets organizationType (drives all localized labels,
// Section 6) but does NOT set a plan yet — plan_id stays null until
// checkout. Everything else in the app depends on an organization_id
// existing, so this is the first real "workspace" endpoint.
// ------------------------------------------------------------------
const createOrganization = async (req, res) => {
    const { name, organizationType } = req.body
    const ownerUserId = req.user.id
    try {
        if (!name || !organizationType) {
            return res.status(400).json({ message: 'name and organizationType are required' })
        }
        if (!ORGANIZATION_TYPES.includes(organizationType)) {
            return res.status(400).json({ message: `unknown organizationType: ${organizationType}` })
        }

        const { rows } = await db.query(
            `INSERT INTO organizations (owner_user_id, name, organization_type)
             VALUES ($1, $2, $3)
             RETURNING id, name, organization_type, plan_id, created_at`,
            [ownerUserId, name, organizationType]
        )

        res.status(201).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create organization' })
    }
}

// ------------------------------------------------------------------
// LIST MY ORGANIZATIONS — supports a user owning more than one
// workspace (e.g. runs two separate businesses).
// ------------------------------------------------------------------
const listMyOrganizations = async (req, res) => {
    const ownerUserId = req.user.id
    try {
        const { rows } = await db.query(
            `SELECT id, name, organization_type, plan_id, logo_filename, created_at
             FROM organizations
             WHERE owner_user_id = $1 AND deleted_at IS NULL
             ORDER BY created_at ASC`,
            [ownerUserId]
        )
        res.status(200).json({ organizations: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch organizations' })
    }
}

// ------------------------------------------------------------------
// GET ORGANIZATION — full profile for the Settings > Org profile
// screen and the header dropdown.
// ------------------------------------------------------------------
const getOrganization = async (req, res) => {
    const { organizationId } = req.params
    const ownerUserId = req.user.id
    try {
        const { rows } = await db.query(
            `SELECT o.id, o.name, o.organization_type, o.logo_filename, o.plan_id, o.created_at,
                    p.name AS plan_name, p.max_workers, p.modules
             FROM organizations o
             LEFT JOIN plans p ON p.plan_id = o.plan_id
             WHERE o.id = $1 AND o.owner_user_id = $2 AND o.deleted_at IS NULL`,
            [organizationId, ownerUserId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'organization not found' })
        res.status(200).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch organization' })
    }
}

// ------------------------------------------------------------------
// UPDATE ORGANIZATION — name / organizationType only. Logo goes
// through the generic asset upload flow, then updateOrganizationLogo
// below patches the filename in.
// ------------------------------------------------------------------
const updateOrganization = async (req, res) => {
    const { organizationId } = req.params
    const ownerUserId = req.user.id
    const { name, organizationType } = req.body
    try {
        if (organizationType && !ORGANIZATION_TYPES.includes(organizationType)) {
            return res.status(400).json({ message: `unknown organizationType: ${organizationType}` })
        }

        const { rows } = await db.query(
            `UPDATE organizations
             SET name = COALESCE($1, name),
                 organization_type = COALESCE($2, organization_type)
             WHERE id = $3 AND owner_user_id = $4 AND deleted_at IS NULL
             RETURNING id, name, organization_type`,
            [name, organizationType, organizationId, ownerUserId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'organization not found' })
        res.status(200).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update organization' })
    }
}

// ------------------------------------------------------------------
// UPDATE ORGANIZATION LOGO — called after POST /assets returns a
// filename for assetType 'logo', ownerType 'organization'.
// ------------------------------------------------------------------
const updateOrganizationLogo = async (req, res) => {
    const { organizationId } = req.params
    const ownerUserId = req.user.id
    const { filename } = req.body
    try {
        if (!filename) return res.status(400).json({ message: 'filename is required' })

        const { rows } = await db.query(
            `UPDATE organizations
             SET logo_filename = $1
             WHERE id = $2 AND owner_user_id = $3 AND deleted_at IS NULL
             RETURNING id, logo_filename`,
            [filename, organizationId, ownerUserId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'organization not found' })
        res.status(200).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update organization logo' })
    }
}

// selectPlan (the old dev-only "set your own plan_id, no payment" endpoint)
// has been removed — see 10.files/BATCH_NOTES.md. Now that checkout is built
// (batch 5), plan_id is set exclusively by webhookController.js after a real
// Stripe/Apple payment. Leaving this endpoint live would let any authenticated
// user grant themselves any plan for free.

// ------------------------------------------------------------------
// DELETE ORGANIZATION — the last gap flagged at the end of batch 9.
// Mirrors authController.deleteAccount's confirmation pattern (re-enter
// password) since this is just as destructive, and best-effort-cancels any
// active Stripe subscription so a deleted org doesn't keep getting billed.
// Soft delete only — same as everywhere else in the schema (deleted_at),
// so historical workers/jobs/invoices/etc. under this org aren't touched or
// cascade-deleted; they just stop showing up because every other query
// already filters through the parent org's deleted_at.
// ------------------------------------------------------------------
const deleteOrganization = async (req, res) => {
    const { organizationId } = req.params
    const ownerUserId = req.user.id
    const { password } = req.body
    try {
        if (!password) return res.status(400).json({ message: 'password is required to confirm deletion' })

        const { rows: userRows } = await db.query(
            'SELECT password_hash FROM users WHERE id = $1 AND deleted_at IS NULL',
            [ownerUserId]
        )
        if (userRows.length === 0) return res.status(404).json({ message: 'user not found' })

        const passwordMatches = await bcrypt.compare(password, userRows[0].password_hash)
        if (!passwordMatches) return res.status(401).json({ message: 'password confirmation did not match' })

        const { rows: orgRows } = await db.query(
            'SELECT id FROM organizations WHERE id = $1 AND owner_user_id = $2 AND deleted_at IS NULL',
            [organizationId, ownerUserId]
        )
        if (orgRows.length === 0) return res.status(404).json({ message: 'organization not found' })

        // Best-effort subscription cancellation. Deliberately doesn't block
        // deletion if this fails (e.g. Stripe is down) — the org gets deleted
        // either way and a stray active subscription is something to reconcile
        // manually rather than a reason to trap the user mid-deletion.
        const activeSubscription = await getActiveSubscription(organizationId)
        let subscriptionCancelWarning = null
        if (activeSubscription?.payment_provider === 'stripe') {
            try {
                await stripe.subscriptions.cancel(activeSubscription.external_subscription_id)
                // Not strictly necessary — the resulting customer.subscription.deleted
                // webhook will also flip this — but set it now so it's correct
                // immediately rather than waiting on webhook delivery.
                await db.query('UPDATE subscribed_services SET is_active = FALSE, is_cancelled = TRUE WHERE id = $1', [activeSubscription.id])
            } catch (err) {
                console.error(`Could not cancel Stripe subscription for deleted org ${organizationId}:`, err)
                subscriptionCancelWarning = 'organization deleted, but the Stripe subscription could not be cancelled automatically — cancel it manually in the Stripe dashboard'
            }
        } else if (activeSubscription?.payment_provider === 'apple') {
            // No programmatic cancellation exists for Apple IAP (see batch 5's
            // "Deliberately left out: Apple → App Store Server API" note) — the
            // subscription can only be cancelled by the user via the App Store.
            // Flip the local row so feature-gating stops treating this org as
            // subscribed, but flag it — Apple will keep charging the user's
            // Apple ID until they cancel it themselves.
            await db.query('UPDATE subscribed_services SET is_active = FALSE WHERE id = $1', [activeSubscription.id])
            subscriptionCancelWarning = 'organization deleted, but this org had an active Apple IAP subscription — Apple will keep charging until the user cancels it from their device (Settings > Apple ID > Subscriptions); this cannot be cancelled from the backend'
        }

        await db.query('UPDATE organizations SET deleted_at = NOW() WHERE id = $1', [organizationId])

        res.status(200).json({
            message: 'organization deleted',
            ...(subscriptionCancelWarning ? { warning: subscriptionCancelWarning } : {})
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not delete organization' })
    }
}

module.exports = {
    createOrganization,
    listMyOrganizations,
    getOrganization,
    updateOrganization,
    updateOrganizationLogo,
    deleteOrganization
}
