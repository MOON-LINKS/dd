const { sendBillReminders } = require('../utils/billReminders')

// Not behind requireAuth — same reasoning as invoiceCronController.js: this
// is meant to be hit by a scheduler, not a logged-in user. Gated by
// CRON_SECRET instead — see routes/billReminderCronRoutes.js.
const runSendBillReminders = async (req, res) => {
    try {
        const results = await sendBillReminders()
        const sent = results.filter((r) => r.status === 'sent').length
        const failed = results.filter((r) => r.status === 'failed' || r.status === 'error').length
        res.status(200).json({ remindersSent: sent, failed, results })
    } catch (err) {
        console.error('Bill reminder cron failed:', err)
        res.status(500).json({ message: 'bill reminder run failed' })
    }
}

module.exports = { runSendBillReminders }
