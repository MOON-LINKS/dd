-- Migration 005 — Payments
-- Run this against schema.sql's existing database before dropping in this batch's code.

-- ------------------------------------------------------------------
-- 1. organizations.stripe_customer_id
--
-- Neither `organizations` nor `users` currently persists a Stripe Customer ID.
-- Without one, every checkout would create a brand new Stripe customer, which
-- breaks "reuse the same customer across checkout + billing portal + future
-- resubscribes" and makes the customer.subscription.* webhooks harder to
-- reconcile back to an organization_id.
--
-- This lives on `organizations`, not `users`, because the organization is the
-- billing entity (one owner user, one active plan — Section 14 conventions).
-- Apple does not need an equivalent column: there is no pre-purchase "customer"
-- object on Apple's side, and the subscription itself is already identified by
-- `subscribed_services.external_subscription_id` (the originalTransactionId).
ALTER TABLE organizations
    ADD COLUMN stripe_customer_id VARCHAR(100) UNIQUE;

-- ------------------------------------------------------------------
-- 2. organizations.plan_id — DROP NOT NULL
--
-- This is a bug fix, not a new decision. Section 2's onboarding flow creates
-- the organization BEFORE payment ("On registration — before payment — the
-- user is asked what type of work/organization they run"), and
-- organizationController.createOrganization (already written, batch 2) never
-- supplies plan_id on INSERT — its own comments describe plan_id as staying
-- null "until checkout." The current NOT NULL constraint contradicts both of
-- those and would make createOrganization fail outright the moment it's run
-- against this schema. Loosening it back to nullable is required for the
-- checkout flow in this batch to have an organization to attach to in the
-- first place.
ALTER TABLE organizations
    ALTER COLUMN plan_id DROP NOT NULL;

-- ------------------------------------------------------------------
-- 3. subscribed_services.external_subscription_id — add UNIQUE constraint
--
-- Already indexed (idx_subscribed_services_ext) but not constrained unique.
-- Both the Apple registration endpoint and the Stripe/Apple webhook handlers
-- in this batch upsert on this column (ON CONFLICT ... DO UPDATE) so that
-- retried webhook deliveries and a client re-submitting the same signed
-- transaction don't create duplicate rows. That requires a real UNIQUE
-- constraint, not just an index.
ALTER TABLE subscribed_services
    ADD CONSTRAINT uq_subscribed_services_external_id UNIQUE (external_subscription_id);
