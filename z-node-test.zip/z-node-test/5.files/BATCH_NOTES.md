# This Batch — Payments (Stripe + Apple IAP)

Tap was dropped from this batch — confirmed you're going Stripe + Apple IAP
only, so `tap_plan_id` on `plans` and `'tap'` as a `payment_provider` value
stay in the schema (harmless to leave) but nothing here writes to them.

## New files, ready to drop into your project structure

| File | Goes in |
|---|---|
| `controllers/paymentController.js` | `controllers/` |
| `controllers/webhookController.js` | `controllers/` |
| `controllers/appleController.js` | `controllers/` |
| `routes/paymentRoutes.js` | `routes/` |
| `routes/webhookRoutes.js` | `routes/` |
| `utils/stripeClient.js` | `utils/` |
| `utils/appleIAP.js` | `utils/` |
| `certs/README.md` + the `.cer` files you download per its instructions | project root, new `certs/` folder |
| `migrations/005_payments.sql` | run against your DB before testing this batch |
| `index.js` | reference only — merge into your real `index.js`, don't overwrite. **The webhook-mounting-order note at the top of this file is not optional**, read it first |

## Required before this batch will run

**1. Run `migrations/005_payments.sql`.** Three changes, all blocking:
- `organizations.stripe_customer_id` — didn't exist; checkout/portal need it.
- `organizations.plan_id` → nullable — this was already a live bug independent
  of this batch. `organizationController.createOrganization` (batch 2) never
  sets `plan_id` on insert, by design (org is created pre-payment), but your
  current `schema.sql` has it `NOT NULL`. Onboarding would fail before a user
  ever reached checkout. Confirmed with you this is fine to fix now.
- `subscribed_services.external_subscription_id` → add a `UNIQUE` constraint.
  It was indexed but not constrained; the upserts in this batch (`ON CONFLICT
  ... DO UPDATE`) need the real constraint or every webhook retry / duplicate
  Apple notification creates a second row instead of updating the first.

**2. Install packages:**
```
npm install stripe @apple/app-store-server-library --save
```
(`stripe@22.x`, pinned to API version `2026-06-24.dahlia` in `utils/stripeClient.js`
— bump deliberately if you upgrade later. `@apple/app-store-server-library` is
Apple's own package for this, not a third-party wrapper — don't swap it for a
generic JWT library, correctly validating Apple's certificate chain is the
whole point of using it.)

**3. Download Apple's root certs** — instructions in `certs/README.md`.
Nothing Apple-related will work without at least one `.cer` file there.

**4. Env vars needed:**
```
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
STRIPE_CHECKOUT_SUCCESS_URL=
STRIPE_CHECKOUT_CANCEL_URL=
STRIPE_BILLING_PORTAL_RETURN_URL=
APPLE_BUNDLE_ID=
APPLE_APP_APPLE_ID=        # numeric App Store Connect app ID, production only
APPLE_ENVIRONMENT=sandbox  # or "production"
```

**5. Same blocker as every prior batch:** `middleware/auth.js` still doesn't
exist. `paymentRoutes.js` imports the same placeholder as everything else.

## What's built

- **Stripe checkout** — one plan, one billing cadence (monthly/yearly) per
  org at a time, matching "one owner user, one active plan." Reuses the org's
  Stripe customer across attempts instead of creating a new one each time.
- **Stripe plan change** — upgrade/downgrade with proration. Deliberately
  writes nothing to the DB itself; only triggers the change on Stripe's side
  and lets the webhook persist the result, per Section 10's "app's own
  database is the source of truth, updated only by webhook events" rule.
- **Stripe cancel** (toggle auto-renew) and **billing portal** (payment
  method management, Stripe-hosted).
- **Stripe webhook** — `checkout.session.completed`, `customer.subscription.updated`
  (covers plan changes AND renewals AND status transitions — trusts Stripe's
  own `status` field rather than reimplementing grace-period math),
  `customer.subscription.deleted`. `invoice.payment_failed` is logged only;
  Stripe's own retry schedule ends in a `subscription.updated` status change,
  which is already handled.
- **Apple IAP registration endpoint** — the iOS app calls this immediately
  after a StoreKit 2 purchase completes, handing over the signed transaction.
  This is the primary activation path (instant, no waiting on Apple's
  notification delivery).
- **Apple server notifications webhook** (App Store Server Notifications V2)
  — `SUBSCRIBED`/`DID_RENEW` sync the row, `EXPIRED`/`GRACE_PERIOD_EXPIRED`/
  `REVOKE`/`REFUND` deactivate it, `DID_CHANGE_RENEWAL_STATUS` tracks
  auto-renew intent.
- Payment-path separation enforced server-side per Section 10 ("the two
  payment paths do not cross") — checkout/register endpoints both reject if
  the org already has an active subscription from the *other* provider.

## Known gap — flagging rather than silently working around

**A `SUBSCRIBED` Apple notification arriving before the client's own
`/apple/register` call has no reliable way to resolve which organization it
belongs to.** The webhook's fallback is StoreKit 2's `appAccountToken` — but
that only works if the iOS app sets it to the `organizationId` at purchase
time (`purchase(options:)`). That's a frontend/iOS change outside this
backend batch. Until it's set, `/apple/register` (called synchronously by the
app right after purchase) is doing all the real work and the notification
handler is best-effort reconciliation for renewals on already-known
subscriptions. Worth confirming the iOS purchase code sets `appAccountToken`
before this goes to production — otherwise a purchase followed immediately by
an app crash (before `/apple/register` fires) has no recovery path.

## Deliberately left out of this batch
- **Apple → App Store Server API** (fetching transaction history, issuing
  refunds programmatically, look-up-by-order-ID) — only signed-data
  verification is built. Add `AppStoreServerAPIClient` from the same package
  if a "resend receipt" or refund-from-dashboard feature comes up later.
- **Grace-period policy** — Stripe's own subscription status and Apple's
  `GRACE_PERIOD_EXPIRED` notification are trusted as-is; nothing here adds a
  custom grace window on top. If you want one, it's a small addition to
  `webhookController.js`'s `customer.subscription.updated` case, but wasn't
  asked for.
- **Downgrade-timing policy** (immediate vs. end-of-period) — `changePlan`
  always uses `proration_behavior: 'create_prorations'`, which changes
  immediately with a prorated charge/credit. If you want downgrades to wait
  until the current period ends instead, that's a `stripe.subscriptions.update`
  option (`schedule` a phase change) — flagging as a choice, not building both.
- **`sendBillReminders`, invoice generation, invoice analytics, Bio Pages,
  Referrals, `deleteOrganization`** — unchanged from where the last batch
  left them.

## Suggested next session
With Payments unblocked, **Invoices** is the natural next chunk — Jobs has
real data to generate from and `subscribed_services` now has real rows to
gate history-window access (`plans.history_months`) against.
