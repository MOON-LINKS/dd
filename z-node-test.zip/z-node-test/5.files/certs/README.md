# Apple root certificates go here

`utils/appleIAP.js` reads every `.cer` file in this directory at first use and
feeds them to Apple's `SignedDataVerifier` as the trusted root chain.

1. Go to https://www.apple.com/certificateauthority/ and download the
   certificates listed under **"Apple Root Certificates"** (not the
   intermediate/WWDR ones — the actual root CAs, currently "Apple Root CA -
   G2" and "Apple Root CA - G3").
2. Save the `.cer` files in this folder.
3. Do not commit these to a public repo with anything else sensitive nearby —
   they're public certificates so it's not a secret, but keep this folder
   dedicated to just these files so it's obvious what's in it.

Without at least one `.cer` file here, every call into appleIAP.js throws
immediately with a clear error rather than silently failing signature checks.
