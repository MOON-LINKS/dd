# API Routes — Postman Reference

Base URL: `http://localhost:3000` (adjust if you run on a different port —
`.env`'s `PORT` currently defaults to 4000, so either change `PORT=3000` in
`.env` or swap the base URL in your Postman environment to match whatever
you actually run it on).

Replace any `:param` segment with a real value (e.g. `:organizationId` →
an actual org UUID). **Auth** column: `None` = no auth needed, `Auth` =
needs `requireAuth` (send the `auth_token` cookie from `/auth/login`, or
your bearer/app-header equivalent), `Admin` = needs `requireAuth` +
`requireAdmin` (your email must be in `ADMIN_EMAILS`), `Cron` = needs an
`x-cron-secret` header matching `CRON_SECRET`.

Suggested testing order: `Auth` → `Organizations` → then everything else
nested under an org (`Workers`, `Clients`, `Jobs`, etc. all need a real
`organizationId` from the org you create).

---

## Auth
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/auth/register` | Register | None |
| POST | `/auth/verify-otp` | Verify registration OTP | None |
| POST | `/auth/login` | Log in | None |
| POST | `/auth/logout` | Log out (current session) | Auth |
| POST | `/auth/logout-all` | Log out from all sessions | Auth |
| GET | `/auth/me` | Get current user info | Auth |
| POST | `/auth/reset-password/request` | Request password reset OTP | None |
| POST | `/auth/reset-password/verify` | Verify password reset OTP | None |
| POST | `/auth/reset-password/confirm` | Confirm new password | None |
| DELETE | `/auth/account` | Delete account (body: `email`, `password`) | Auth |

> Note: `changePassword` exists in the code (`authController.js`) but has
> no route wired up yet — not testable until that's added.

## Organizations
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/organizations` | Create organization | Auth |
| GET | `/organizations` | List my organizations | Auth |
| GET | `/organizations/:organizationId` | Get organization | Auth |
| PATCH | `/organizations/:organizationId` | Update organization | Auth |
| PATCH | `/organizations/:organizationId/logo` | Update organization logo | Auth |
| DELETE | `/organizations/:organizationId` | Delete organization (body: `password`) | Auth |

## Workers
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/organizations/:organizationId/workers` | Create worker | Auth |
| GET | `/organizations/:organizationId/workers` | List workers | Auth |
| GET | `/organizations/:organizationId/workers/:workerId` | Get worker | Auth |
| PATCH | `/organizations/:organizationId/workers/:workerId` | Update worker | Auth |
| PATCH | `/organizations/:organizationId/workers/:workerId/asset` | Update worker photo/asset | Auth |
| DELETE | `/organizations/:organizationId/workers/:workerId` | Delete worker | Auth |
| GET | `/organizations/:organizationId/workers/:workerId/hours-summary` | Get worker hours summary | Auth |

## Clients
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/organizations/:organizationId/clients` | Create client | Auth |
| GET | `/organizations/:organizationId/clients` | List clients | Auth |
| GET | `/organizations/:organizationId/clients/:clientId` | Get client | Auth |
| PATCH | `/organizations/:organizationId/clients/:clientId` | Update client | Auth |
| DELETE | `/organizations/:organizationId/clients/:clientId` | Delete client | Auth |
| POST | `/organizations/:organizationId/clients/:clientId/feedback` | Add client feedback | Auth |
| GET | `/organizations/:organizationId/clients/:clientId/feedback` | List client feedback | Auth |

## Job Templates
| Method | URL | Title | Auth |
|---|---|---|---|
| GET | `/organizations/:organizationId/job-templates` | List job templates | Auth |
| POST | `/admin/job-templates` | Create job template | Admin |
| PATCH | `/admin/job-templates/:templateId` | Update job template | Admin |

## Jobs
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/organizations/:organizationId/jobs` | Create job | Auth |
| GET | `/organizations/:organizationId/jobs` | List jobs | Auth |
| PATCH | `/organizations/:organizationId/jobs/:jobId` | Update job | Auth |
| PATCH | `/organizations/:organizationId/jobs/:jobId/postpone` | Postpone job | Auth |
| DELETE | `/organizations/:organizationId/jobs/:jobId` | Delete job | Auth |
| GET | `/organizations/:organizationId/jobs/:jobId/snapshot` | Get job day snapshot | Auth |
| PUT | `/organizations/:organizationId/jobs/:jobId/snapshot` | Save job day snapshot | Auth |

## Expenses
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/organizations/:organizationId/expenses` | Create expense | Auth |
| GET | `/organizations/:organizationId/expenses` | List expenses | Auth |
| GET | `/organizations/:organizationId/expenses/:expenseId` | Get expense | Auth |
| PATCH | `/organizations/:organizationId/expenses/:expenseId` | Update expense | Auth |
| DELETE | `/organizations/:organizationId/expenses/:expenseId` | Delete expense | Auth |

## Upcoming Bills
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/organizations/:organizationId/upcoming-bills` | Create upcoming bill | Auth |
| GET | `/organizations/:organizationId/upcoming-bills` | List upcoming bills | Auth |
| GET | `/organizations/:organizationId/upcoming-bills/:billId` | Get upcoming bill | Auth |
| PATCH | `/organizations/:organizationId/upcoming-bills/:billId` | Update upcoming bill | Auth |
| DELETE | `/organizations/:organizationId/upcoming-bills/:billId` | Delete upcoming bill | Auth |
| PATCH | `/organizations/:organizationId/upcoming-bills/:billId/mark-paid` | Mark bill as paid | Auth |
| POST | `/organizations/:organizationId/upcoming-bills/:billId/convert-to-expense` | Convert bill to expense | Auth |

## Billing / Payments
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/organizations/:organizationId/billing/checkout` | Create Stripe checkout session | Auth |
| POST | `/organizations/:organizationId/billing/change-plan` | Change plan (Stripe) | Auth |
| POST | `/organizations/:organizationId/billing/cancel` | Cancel subscription (Stripe) | Auth |
| POST | `/organizations/:organizationId/billing/portal` | Get Stripe billing portal link | Auth |
| POST | `/organizations/:organizationId/billing/apple/register` | Register Apple IAP transaction | Auth |

## Webhooks
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/webhooks/stripe` | Stripe webhook receiver | None* |
| POST | `/webhooks/apple` | Apple IAP webhook receiver | None* |

*\*Not for manual Postman testing in the normal sense — Stripe verifies a
signature header (`stripe-signature`) that only Stripe's servers can
produce correctly; hitting this from Postman directly will fail signature
verification unless you construct that header yourself (Stripe CLI's
`stripe listen`/`trigger` is the normal way to test this one).*

## Invoices
| Method | URL | Title | Auth |
|---|---|---|---|
| GET | `/organizations/:organizationId/invoices` | List invoices | Auth |
| POST | `/organizations/:organizationId/invoices/generate` | Generate invoices now | Auth |
| GET | `/organizations/:organizationId/invoices/analytics` | Get invoice analytics | Auth |
| GET | `/organizations/:organizationId/invoices/:invoiceId` | Get invoice | Auth |
| PATCH | `/organizations/:organizationId/invoices/:invoiceId/payment` | Record invoice payment | Auth |
| POST | `/organizations/:organizationId/invoices/:invoiceId/pdf` | Generate invoice PDF | Auth |
| POST | `/organizations/:organizationId/invoices/:invoiceId/send` | Send invoice email | Auth |
| POST | `/organizations/:organizationId/invoices/:invoiceId/resend` | Resend invoice email | Auth |
| GET | `/organizations/:organizationId/invoices/branding/design` | Get invoice branding | Auth |
| PATCH | `/organizations/:organizationId/invoices/branding/design` | Update invoice branding | Auth |
| GET | `/organizations/:organizationId/invoices/history/log` | List email send history | Auth |

## Referrals
| Method | URL | Title | Auth |
|---|---|---|---|
| GET | `/organizations/:organizationId/referrals` | Get my referral code | Auth |
| GET | `/organizations/:organizationId/referrals/earnings` | Get referral earnings | Auth |
| GET | `/organizations/:organizationId/referrals/history` | List referral history | Auth |
| GET | `/referrals/validate?code=XYZ` | Validate a referral code | None |
| POST | `/admin/referrals/payouts` | Issue a referral payout | Admin |
| GET | `/admin/referrals/payouts/pending` | List pending payout balances | Admin |

## Bio Page (editor)
| Method | URL | Title | Auth |
|---|---|---|---|
| GET | `/organizations/:organizationId/bio-page` | Get bio page editor data | Auth |
| PATCH | `/organizations/:organizationId/bio-page` | Update bio page draft | Auth |
| PATCH | `/organizations/:organizationId/bio-page/logo` | Update bio page logo | Auth |
| POST | `/organizations/:organizationId/bio-page/buttons` | Add bio page button | Auth |
| PATCH | `/organizations/:organizationId/bio-page/buttons/reorder` | Reorder bio page buttons | Auth |
| PATCH | `/organizations/:organizationId/bio-page/buttons/:buttonId` | Update bio page button | Auth |
| DELETE | `/organizations/:organizationId/bio-page/buttons/:buttonId` | Delete bio page button | Auth |
| POST | `/organizations/:organizationId/bio-page/publish` | Publish bio page | Auth |
| PATCH | `/organizations/:organizationId/bio-page/unpublish` | Unpublish bio page | Auth |
| GET | `/organizations/:organizationId/bio-page/versions` | List bio page versions | Auth |
| POST | `/organizations/:organizationId/bio-page/versions/:version/rollback` | Roll back to a version | Auth |

## Bio Page (public)
| Method | URL | Title | Auth |
|---|---|---|---|
| GET | `/bio/slug-check?slug=xyz&excludeOrganizationId=...` | Check slug availability | None |
| GET | `/bio/:slug/data` | Get public bio page data (JSON) | None |
| GET | `/bio/:slug` | Get public bio page (rendered HTML) | None |

## Assets
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/assets` | Upload asset (multipart, field name `file`) | Auth |
| DELETE | `/assets/:assetId` | Delete asset | Auth |

## Plans
| Method | URL | Title | Auth |
|---|---|---|---|
| GET | `/plans` | List active plans (pricing page) | None |

## Cron (scheduled jobs)
| Method | URL | Title | Auth |
|---|---|---|---|
| POST | `/cron/generate-monthly-invoices` | Run monthly invoice generation | Cron |
| POST | `/cron/send-bill-reminders` | Run bill reminder send | Cron |

## Health
| Method | URL | Title | Auth |
|---|---|---|---|
| GET | `/health` | Health check | None |

---
**Total: 96 routes** (93 real endpoints + 2 webhook receivers you likely
won't hit directly from Postman + 1 health check).
