const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')

// Backs Section 3's History tab: "sending history of every invoice email
// dispatched... and, separately, of upcoming-bill reminders... this is the
// 'did this actually go out' record, distinct from the invoices themselves."
// Filter by type so the frontend can show either sub-list or both merged.
const listEmailLog = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { emailType, page = '1', pageSize = '25' } = req.query
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (emailType && !['invoice', 'bill_reminder'].includes(emailType)) {
            return res.status(400).json({ message: "emailType must be 'invoice' or 'bill_reminder'" })
        }

        const conditions = ['organization_id = $1']
        const params = [organizationId]
        if (emailType) {
            params.push(emailType)
            conditions.push(`email_type = $${params.length}`)
        }

        const limit = Math.min(parseInt(pageSize, 10) || 25, 100)
        const offset = (Math.max(parseInt(page, 10) || 1, 1) - 1) * limit
        params.push(limit, offset)

        const { rows } = await db.query(
            `SELECT id, email_type, reference_id, recipient_email, subject, status, error_message, sent_at
             FROM email_log
             WHERE ${conditions.join(' AND ')}
             ORDER BY sent_at DESC
             LIMIT $${params.length - 1} OFFSET $${params.length}`,
            params
        )
        res.status(200).json({ emailLog: rows, page: parseInt(page, 10) || 1, pageSize: limit })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch email log' })
    }
}

module.exports = { listEmailLog }
