const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { resolveAssetUrl } = require('../utils/cdn')

// One row per org (invoice_branding.organization_id is UNIQUE) — "One
// configurable template in v1, not multiple selectable templates" per
// Section 3. Get auto-creates the default row on first read rather than
// requiring a separate "initialize branding" step the frontend would have
// to remember to call.
const getInvoiceBranding = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const { rows } = await db.query(
            `INSERT INTO invoice_branding (organization_id)
             VALUES ($1)
             ON CONFLICT (organization_id) DO UPDATE SET organization_id = EXCLUDED.organization_id
             RETURNING id, primary_color, secondary_color, logo_asset_id`,
            [organizationId]
        )
        const branding = rows[0]

        let logoUrl = null
        if (branding.logo_asset_id) {
            const { rows: assetRows } = await db.query('SELECT filename FROM assets WHERE id = $1', [branding.logo_asset_id])
            logoUrl = resolveAssetUrl(assetRows[0]?.filename)
        }

        res.status(200).json({
            branding: {
                primaryColor: branding.primary_color,
                secondaryColor: branding.secondary_color,
                logoAssetId: branding.logo_asset_id,
                logoUrl
            }
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch invoice branding' })
    }
}

const HEX_COLOR = /^#[0-9A-Fa-f]{6}$/

const updateInvoiceBranding = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { primaryColor, secondaryColor, logoAssetId } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (primaryColor && !HEX_COLOR.test(primaryColor)) {
            return res.status(400).json({ message: 'primaryColor must be a 6-digit hex value, e.g. #1D9E75' })
        }
        if (secondaryColor && !HEX_COLOR.test(secondaryColor)) {
            return res.status(400).json({ message: 'secondaryColor must be a 6-digit hex value, e.g. #0F6E56' })
        }

        // logoAssetId, if provided, must actually be an asset owned by this org
        // (uploaded via the normal /assets endpoint with ownerType=organization) —
        // otherwise any org could point its invoice branding at another org's logo.
        if (logoAssetId) {
            const { rows } = await db.query(
                `SELECT a.id FROM assets a
                 WHERE a.id = $1 AND a.owner_type = 'organization' AND a.owner_id = $2`,
                [logoAssetId, organizationId]
            )
            if (rows.length === 0) return res.status(400).json({ message: 'logoAssetId does not belong to this organization' })
        }

        const { rows } = await db.query(
            `INSERT INTO invoice_branding (organization_id, primary_color, secondary_color, logo_asset_id)
             VALUES ($1, COALESCE($2, '#1D9E75'), COALESCE($3, '#0F6E56'), $4)
             ON CONFLICT (organization_id) DO UPDATE
                SET primary_color = COALESCE($2, invoice_branding.primary_color),
                    secondary_color = COALESCE($3, invoice_branding.secondary_color),
                    logo_asset_id = COALESCE($4, invoice_branding.logo_asset_id),
                    updated_at = NOW()
             RETURNING primary_color, secondary_color, logo_asset_id`,
            [organizationId, primaryColor || null, secondaryColor || null, logoAssetId || null]
        )

        res.status(200).json({
            branding: {
                primaryColor: rows[0].primary_color,
                secondaryColor: rows[0].secondary_color,
                logoAssetId: rows[0].logo_asset_id
            }
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update invoice branding' })
    }
}

module.exports = { getInvoiceBranding, updateInvoiceBranding }
