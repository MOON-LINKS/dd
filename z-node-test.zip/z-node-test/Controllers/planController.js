const db = require('../utils/db')

// ------------------------------------------------------------------
// LIST PLANS — public, no auth. Powers the pricing page. Only returns
// active plans; retired plans stay in the DB (orgs already on them keep
// working) but drop out of new-signup listings.
// ------------------------------------------------------------------
const listPlans = async (req, res) => {
    try {
        const { rows } = await db.query(
            `SELECT plan_id, name, max_workers, modules, history_months
             FROM plans
             WHERE is_active = TRUE
             ORDER BY max_workers ASC`
        )
        res.status(200).json({ plans: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch plans' })
    }
}

module.exports = { listPlans }
