const db = require('./db')

// Resolves which organization a given owner record belongs to, and verifies
// the requesting user actually owns that organization. Every future controller
// that touches org-scoped data (workers, jobs, clients, expenses, bills, bio
// pages, assets...) should route its access checks through this file instead
// of re-deriving ownership ad hoc.

// v1 assumes a single owner per organization (organizations.owner_user_id).
// If team members/roles are added later, this is the one place to extend.

const ORGANIZATION_OWNER_QUERIES = {
    organization: 'SELECT id AS organization_id FROM organizations WHERE id = $1 AND deleted_at IS NULL',
    worker:       'SELECT organization_id FROM workers WHERE id = $1 AND deleted_at IS NULL',
    client:       'SELECT organization_id FROM clients WHERE id = $1 AND deleted_at IS NULL',
    job:          'SELECT organization_id FROM jobs WHERE id = $1 AND deleted_at IS NULL',
    bio_page:     'SELECT organization_id FROM bio_pages WHERE id = $1',
    upcoming_bill: 'SELECT organization_id FROM upcoming_bills WHERE id = $1',
    expense:      'SELECT organization_id FROM expenses WHERE id = $1',
    invoice:      'SELECT organization_id FROM invoices WHERE id = $1'
}

// Given an ownerType + ownerId (e.g. 'worker' + workerId), returns the
// organization_id that record belongs to, or null if not found.
const resolveOrganizationId = async (ownerType, ownerId) => {
    const query = ORGANIZATION_OWNER_QUERIES[ownerType]
    if (!query) return null
    const { rows } = await db.query(query, [ownerId])
    return rows[0]?.organization_id || null
}

// Throws-free check: returns true/false rather than throwing, so callers
// decide the HTTP response shape.
const userOwnsOrganization = async (userId, organizationId) => {
    if (!organizationId) return false
    const { rows } = await db.query(
        'SELECT 1 FROM organizations WHERE id = $1 AND owner_user_id = $2 AND deleted_at IS NULL',
        [organizationId, userId]
    )
    return rows.length > 0
}

// Convenience for controllers: resolves + checks ownership in one call.
// Returns the organization_id on success, or null if the record doesn't
// exist or doesn't belong to this user.
const assertOwnedOrganizationId = async (userId, ownerType, ownerId) => {
    const organizationId = await resolveOrganizationId(ownerType, ownerId)
    const owns = await userOwnsOrganization(userId, organizationId)
    return owns ? organizationId : null
}

module.exports = { resolveOrganizationId, userOwnsOrganization, assertOwnedOrganizationId }
