const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { checkHistoryLimit } = require('../utils/historyLimit')
const { generateInvoicesForOrganization, previousCalendarMonth } = require('../utils/invoiceGeneration')
const { buildInvoicePdfBuffer } = require('../utils/pdfBuilder')
const { storeInvoicePdf } = require('../utils/invoicePdfStorage')
const { resolveAssetUrl } = require('../utils/cdn')
const { sendMail } = require('../utils/mailer')
const { invoiceEmail } = require('../utils/emailTemplates')

// ------------------------------------------------------------------
// GENERATE INVOICES NOW — manual/backfill trigger. Body: { periodStart,
// periodEnd } both optional, default to the previous full calendar month.
// The cron entrypoint (controllers/invoiceCronController.js) calls the same
// underlying utils/invoiceGeneration.js function — this is just the
// org-scoped, on-demand version of the same operation.
// ------------------------------------------------------------------
const generateInvoicesNow = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        let { periodStart, periodEnd } = req.body
        if (!periodStart || !periodEnd) {
            const defaults = previousCalendarMonth()
            periodStart = periodStart || defaults.periodStart
            periodEnd = periodEnd || defaults.periodEnd
        }
        if (new Date(periodEnd) < new Date(periodStart)) {
            return res.status(400).json({ message: 'periodEnd must not be before periodStart' })
        }

        const client = await db.connect()
        let result
        try {
            await client.query('BEGIN')
            result = await generateInvoicesForOrganization(client, organizationId, periodStart, periodEnd)
            await client.query('COMMIT')
        } catch (txErr) {
            await client.query('ROLLBACK').catch(() => {})
            throw txErr
        } finally {
            client.release()
        }

        res.status(200).json({
            message: result.invoices.length > 0
                ? `${result.invoices.length} invoice(s) generated`
                : (result.skippedReason || 'no invoices generated'),
            invoices: result.invoices
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not generate invoices' })
    }
}

// ------------------------------------------------------------------
// LIST INVOICES — filterable by client and date range, paginated.
// Enforces plans.history_months on the requested start date.
// ------------------------------------------------------------------
const listInvoices = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { clientId, startDate, endDate, page = '1', pageSize = '25' } = req.query
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        if (startDate) {
            const historyCheck = await checkHistoryLimit(organizationId, startDate)
            if (!historyCheck.allowed) return res.status(403).json({ message: historyCheck.message })
        }

        const conditions = ['i.organization_id = $1']
        const params = [organizationId]
        if (clientId) {
            params.push(clientId)
            conditions.push(`i.client_id = $${params.length}`)
        }
        if (startDate) {
            params.push(startDate)
            conditions.push(`i.period_end >= $${params.length}`)
        }
        if (endDate) {
            params.push(endDate)
            conditions.push(`i.period_start <= $${params.length}`)
        }

        const limit = Math.min(parseInt(pageSize, 10) || 25, 100)
        const offset = (Math.max(parseInt(page, 10) || 1, 1) - 1) * limit
        params.push(limit, offset)

        const { rows } = await db.query(
            `SELECT i.id, i.client_id, c.name AS client_name, i.period_start, i.period_end,
                    i.total_hours, i.total_amount, i.amount_paid, i.amount_owed,
                    i.pdf_asset_id, i.sent_at, i.created_at
             FROM invoices i
             LEFT JOIN clients c ON c.id = i.client_id
             WHERE ${conditions.join(' AND ')}
             ORDER BY i.period_start DESC, i.created_at DESC
             LIMIT $${params.length - 1} OFFSET $${params.length}`,
            params
        )
        res.status(200).json({ invoices: rows, page: parseInt(page, 10) || 1, pageSize: limit })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch invoices' })
    }
}

// ------------------------------------------------------------------
// GET INVOICE — with line items.
// ------------------------------------------------------------------
const getInvoice = async (req, res) => {
    const { organizationId, invoiceId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const { rows: invoiceRows } = await db.query(
            `SELECT i.*, c.name AS client_name, c.email AS client_email, c.phone AS client_phone
             FROM invoices i
             LEFT JOIN clients c ON c.id = i.client_id
             WHERE i.id = $1 AND i.organization_id = $2`,
            [invoiceId, organizationId]
        )
        if (invoiceRows.length === 0) return res.status(404).json({ message: 'invoice not found' })

        const { rows: lineItems } = await db.query(
            `SELECT li.id, li.worker_id, w.name AS worker_name, li.job_id, j.title AS job_title,
                    li.description, li.hours, li.rate, li.amount
             FROM invoice_line_items li
             LEFT JOIN workers w ON w.id = li.worker_id
             LEFT JOIN jobs j ON j.id = li.job_id
             WHERE li.invoice_id = $1
             ORDER BY li.created_at ASC`,
            [invoiceId]
        )

        res.status(200).json({ invoice: invoiceRows[0], lineItems })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch invoice' })
    }
}

// ------------------------------------------------------------------
// RECORD PAYMENT — the client pays the org outside this system (this
// module has nothing to do with Batch 5's Stripe/Apple payments, which are
// the ORG paying FOR the SaaS subscription, not the client paying the org).
// The manager just logs what came in. Body: { amountPaid } — absolute value,
// not a delta, so a correction is just "send the right number again."
// ------------------------------------------------------------------
const recordPayment = async (req, res) => {
    const { organizationId, invoiceId } = req.params
    const userId = req.user.id
    const { amountPaid } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (amountPaid === undefined || Number(amountPaid) < 0) {
            return res.status(400).json({ message: 'amountPaid (a non-negative number) is required' })
        }

        const { rows } = await db.query(
            `UPDATE invoices SET amount_paid = $1, updated_at = NOW()
             WHERE id = $2 AND organization_id = $3
             RETURNING id, total_amount, amount_paid, amount_owed`,
            [amountPaid, invoiceId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'invoice not found' })

        res.status(200).json({ invoice: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not record payment' })
    }
}

// ------------------------------------------------------------------
// GENERATE / REGENERATE PDF — builds the PDF, stores it as an asset,
// updates invoices.pdf_asset_id. Safe to call more than once (e.g. after
// branding changes or a payment is recorded) — each call creates a fresh
// asset and repoints the invoice at it; the old asset row/file is left in
// place rather than deleted, so a previously-emailed PDF link never breaks.
// ------------------------------------------------------------------
const generateInvoicePdf = async (req, res) => {
    const { organizationId, invoiceId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const { rows: invoiceRows } = await db.query(
            `SELECT i.*, c.name AS client_name, c.email AS client_email, c.phone AS client_phone
             FROM invoices i LEFT JOIN clients c ON c.id = i.client_id
             WHERE i.id = $1 AND i.organization_id = $2`,
            [invoiceId, organizationId]
        )
        if (invoiceRows.length === 0) return res.status(404).json({ message: 'invoice not found' })
        const invoice = invoiceRows[0]

        const { rows: lineItems } = await db.query(
            `SELECT li.description, li.hours, li.rate, li.amount
             FROM invoice_line_items li WHERE li.invoice_id = $1 ORDER BY li.created_at ASC`,
            [invoiceId]
        )

        const { rows: orgRows } = await db.query('SELECT id, name FROM organizations WHERE id = $1', [organizationId])
        const organization = orgRows[0]

        const { rows: brandingRows } = await db.query(
            `SELECT ib.primary_color, ib.secondary_color, COALESCE(a1.filename, a2.filename) AS logo_filename
             FROM organizations o
             LEFT JOIN invoice_branding ib ON ib.organization_id = o.id
             LEFT JOIN assets a1 ON a1.id = ib.logo_asset_id
             LEFT JOIN assets a2 ON a2.owner_type = 'organization' AND a2.owner_id = o.id
             WHERE o.id = $1
             LIMIT 1`,
            [organizationId]
        )
        const brandingRow = brandingRows[0] || {}
        const branding = {
            primaryColor: brandingRow.primary_color,
            secondaryColor: brandingRow.secondary_color,
            logoUrl: resolveAssetUrl(brandingRow.logo_filename)
        }

        const pdfBuffer = await buildInvoicePdfBuffer({
            organization,
            client: { name: invoice.client_name, email: invoice.client_email, phone: invoice.client_phone },
            invoice,
            lineItems,
            branding
        })

        const asset = await storeInvoicePdf(organizationId, invoiceId, pdfBuffer)
        await db.query('UPDATE invoices SET pdf_asset_id = $1, updated_at = NOW() WHERE id = $2', [asset.id, invoiceId])

        res.status(200).json({ pdfUrl: resolveAssetUrl(asset.filename) })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not generate invoice PDF' })
    }
}

// ------------------------------------------------------------------
// SEND / RESEND EMAIL — manager-only per spec. Generates the PDF first if
// one doesn't exist yet (so "send" always works standalone, without forcing
// the caller to remember to generate the PDF first). Logs to email_log
// either way — a failed send is still worth showing in the History tab
// (status='failed'), not silently dropped.
// ------------------------------------------------------------------
const sendInvoiceEmailInternal = async (organizationId, invoiceId) => {
    const { rows: invoiceRows } = await db.query(
        `SELECT i.*, c.name AS client_name, o.name AS organization_name, o.owner_user_id
         FROM invoices i
         LEFT JOIN clients c ON c.id = i.client_id
         JOIN organizations o ON o.id = i.organization_id
         WHERE i.id = $1 AND i.organization_id = $2`,
        [invoiceId, organizationId]
    )
    if (invoiceRows.length === 0) throw { status: 404, message: 'invoice not found' }
    const invoice = invoiceRows[0]

    const { rows: ownerRows } = await db.query('SELECT email FROM users WHERE id = $1', [invoice.owner_user_id])
    const recipientEmail = ownerRows[0]?.email
    if (!recipientEmail) throw { status: 404, message: 'organization owner email not found' }

    let pdfAssetId = invoice.pdf_asset_id
    let pdfFilename = null
    if (pdfAssetId) {
        const { rows } = await db.query('SELECT filename FROM assets WHERE id = $1', [pdfAssetId])
        pdfFilename = rows[0]?.filename
    }
    if (!pdfFilename) {
        // No PDF yet — build one now rather than failing the send.
        const { rows: lineItems } = await db.query(
            `SELECT description, hours, rate, amount FROM invoice_line_items WHERE invoice_id = $1 ORDER BY created_at ASC`,
            [invoiceId]
        )
        const { rows: brandingRows } = await db.query(
            `SELECT ib.primary_color, ib.secondary_color, COALESCE(a1.filename, a2.filename) AS logo_filename
             FROM organizations o
             LEFT JOIN invoice_branding ib ON ib.organization_id = o.id
             LEFT JOIN assets a1 ON a1.id = ib.logo_asset_id
             LEFT JOIN assets a2 ON a2.owner_type = 'organization' AND a2.owner_id = o.id
             WHERE o.id = $1 LIMIT 1`,
            [organizationId]
        )
        const brandingRow = brandingRows[0] || {}
        const pdfBuffer = await buildInvoicePdfBuffer({
            organization: { name: invoice.organization_name },
            client: { name: invoice.client_name },
            invoice,
            lineItems,
            branding: {
                primaryColor: brandingRow.primary_color,
                secondaryColor: brandingRow.secondary_color,
                logoUrl: resolveAssetUrl(brandingRow.logo_filename)
            }
        })
        const asset = await storeInvoicePdf(organizationId, invoiceId, pdfBuffer)
        pdfAssetId = asset.id
        pdfFilename = asset.filename
        await db.query('UPDATE invoices SET pdf_asset_id = $1, updated_at = NOW() WHERE id = $2', [pdfAssetId, invoiceId])
    }

    const pdfUrl = resolveAssetUrl(pdfFilename)
    const { subject, text, html } = invoiceEmail({
        organizationName: invoice.organization_name,
        clientName: invoice.client_name || 'Unknown client',
        periodStart: invoice.period_start,
        periodEnd: invoice.period_end,
        totalAmount: Number(invoice.total_amount).toFixed(2),
        amountOwed: Number(invoice.amount_owed).toFixed(2),
        pdfUrl
    })

    let status = 'sent'
    let errorMessage = null
    try {
        await sendMail({ to: recipientEmail, subject, text, html })
        await db.query('UPDATE invoices SET sent_at = NOW(), updated_at = NOW() WHERE id = $1', [invoiceId])
    } catch (err) {
        status = 'failed'
        errorMessage = err.message
    }

    await db.query(
        `INSERT INTO email_log (organization_id, email_type, reference_id, recipient_email, subject, status, error_message)
         VALUES ($1, 'invoice', $2, $3, $4, $5, $6)`,
        [organizationId, invoiceId, recipientEmail, subject, status, errorMessage]
    )

    if (status === 'failed') throw { status: 502, message: `email failed to send: ${errorMessage}` }
    return { recipientEmail, pdfUrl }
}

const sendInvoiceEmail = async (req, res) => {
    const { organizationId, invoiceId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const result = await sendInvoiceEmailInternal(organizationId, invoiceId)
        res.status(200).json({ message: 'invoice email sent', ...result })
    } catch (err) {
        if (err.status) return res.status(err.status).json({ message: err.message })
        console.error(err)
        res.status(500).json({ message: 'could not send invoice email' })
    }
}

// Same handler as send — resend is just "send again," and email_log naturally
// accumulates every attempt (that's what makes it a history, not a status flag).
const resendInvoiceEmail = sendInvoiceEmail

module.exports = {
    generateInvoicesNow,
    listInvoices,
    getInvoice,
    recordPayment,
    generateInvoicePdf,
    sendInvoiceEmail,
    resendInvoiceEmail
}
