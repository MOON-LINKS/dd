const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')

// All routes here are nested under /organizations/:organizationId/clients —
// same ownership-check pattern as workerController.

// ------------------------------------------------------------------
// CREATE CLIENT
// ------------------------------------------------------------------
const createClient = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { name, email, phone, notes } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!name) return res.status(400).json({ message: 'name is required' })

        const { rows } = await db.query(
            `INSERT INTO clients (organization_id, name, email, phone, notes)
             VALUES ($1, $2, $3, $4, $5)
             RETURNING id, name, email, phone, notes, created_at`,
            [organizationId, name, email || null, phone || null, notes || null]
        )
        res.status(201).json({ client: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create client' })
    }
}

// ------------------------------------------------------------------
// LIST CLIENTS
// ------------------------------------------------------------------
const listClients = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `SELECT c.id, c.name, c.email, c.phone, c.notes, c.created_at,
                    COALESCE(AVG(cf.rating), NULL) AS average_rating,
                    COUNT(cf.id) AS feedback_count
             FROM clients c
             LEFT JOIN client_feedback cf ON cf.client_id = c.id
             WHERE c.organization_id = $1 AND c.deleted_at IS NULL
             GROUP BY c.id
             ORDER BY c.created_at DESC`,
            [organizationId]
        )
        res.status(200).json({
            clients: rows.map(r => ({
                ...r,
                average_rating: r.average_rating !== null ? parseFloat(r.average_rating) : null,
                feedback_count: parseInt(r.feedback_count, 10)
            }))
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch clients' })
    }
}

// ------------------------------------------------------------------
// GET CLIENT
// ------------------------------------------------------------------
const getClient = async (req, res) => {
    const { organizationId, clientId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `SELECT * FROM clients WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL`,
            [clientId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'client not found' })
        res.status(200).json({ client: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch client' })
    }
}

// ------------------------------------------------------------------
// UPDATE CLIENT
// ------------------------------------------------------------------
const updateClient = async (req, res) => {
    const { organizationId, clientId } = req.params
    const userId = req.user.id
    const { name, email, phone, notes } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `UPDATE clients
             SET name = COALESCE($1, name),
                 email = COALESCE($2, email),
                 phone = COALESCE($3, phone),
                 notes = COALESCE($4, notes),
                 updated_at = NOW()
             WHERE id = $5 AND organization_id = $6 AND deleted_at IS NULL
             RETURNING id, name, email, phone, notes, updated_at`,
            [name, email, phone, notes, clientId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'client not found' })
        res.status(200).json({ client: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update client' })
    }
}

// ------------------------------------------------------------------
// DELETE CLIENT (soft delete)
// ------------------------------------------------------------------
const deleteClient = async (req, res) => {
    const { organizationId, clientId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `UPDATE clients SET deleted_at = NOW()
             WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL
             RETURNING id`,
            [clientId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'client not found' })
        res.status(200).json({ message: 'client deleted' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not delete client' })
    }
}

// ------------------------------------------------------------------
// ADD CLIENT FEEDBACK — post-job rating. job_id's FK exists (added
// after jobs table in schema.sql) even though Jobs endpoints aren't
// built yet, so this is safe to ship now; a job_id just won't exist
// until a real job is created via that module later.
// ------------------------------------------------------------------
const addClientFeedback = async (req, res) => {
    const { organizationId, clientId } = req.params
    const userId = req.user.id
    const { jobId, rating, comment } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!jobId) return res.status(400).json({ message: 'jobId is required' })
        if (rating === undefined || rating < 1 || rating > 5) {
            return res.status(400).json({ message: 'rating must be between 1 and 5' })
        }

        // Confirm the client actually belongs to this org before attaching feedback
        const { rows: clientRows } = await db.query(
            'SELECT id FROM clients WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL',
            [clientId, organizationId]
        )
        if (clientRows.length === 0) return res.status(404).json({ message: 'client not found' })

        const { rows } = await db.query(
            `INSERT INTO client_feedback (client_id, job_id, rating, comment)
             VALUES ($1, $2, $3, $4)
             RETURNING id, client_id, job_id, rating, comment, submitted_at`,
            [clientId, jobId, rating, comment || null]
        )
        res.status(201).json({ feedback: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not add client feedback' })
    }
}

// ------------------------------------------------------------------
// LIST CLIENT FEEDBACK
// ------------------------------------------------------------------
const listClientFeedback = async (req, res) => {
    const { organizationId, clientId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `SELECT cf.id, cf.job_id, cf.rating, cf.comment, cf.submitted_at
             FROM client_feedback cf
             JOIN clients c ON c.id = cf.client_id
             WHERE cf.client_id = $1 AND c.organization_id = $2
             ORDER BY cf.submitted_at DESC`,
            [clientId, organizationId]
        )
        res.status(200).json({ feedback: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch client feedback' })
    }
}

module.exports = {
    createClient,
    listClients,
    getClient,
    updateClient,
    deleteClient,
    addClientFeedback,
    listClientFeedback
}
