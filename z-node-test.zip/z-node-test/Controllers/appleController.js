const db = require('../utils/db')
const { verifyNotification, verifyTransaction } = require('../utils/appleIAP')

// App Store Server Notifications V2 posts a single field: { signedPayload }.
// Unlike Stripe, Apple signs the payload itself (a JWS), not the raw HTTP
// body — so this route does NOT need express.raw() / can sit behind the
// normal express.json() middleware. See routes/webhookRoutes.js.

// Resolves organization_id for an incoming notification. Preferred path: an
// existing subscribed_services row already created by
// paymentController.registerAppleTransaction (the common case — the iOS app
// calls that endpoint immediately after purchase, well before Apple's
// notification typically arrives). Fallback: appAccountToken on the
// transaction, IF the iOS app sets it to the organizationId at purchase time
// via StoreKit 2's `purchase(options:)`. Without one of these two, a
// first-ever SUBSCRIBED notification arriving before the client's own
// register-transaction call has no way to be attributed to an organization —
// this is a known gap, see BATCH_NOTES.md.
const resolveOrganizationId = async (originalTransactionId, appAccountToken) => {
    const { rows } = await db.query(
        'SELECT organization_id FROM subscribed_services WHERE external_subscription_id = $1',
        [originalTransactionId]
    )
    if (rows.length > 0) return rows[0].organization_id
    if (!appAccountToken) return null

    const { rows: orgRows } = await db.query('SELECT id FROM organizations WHERE id = $1', [appAccountToken])
    return orgRows[0]?.id || null
}

const resolvePlanByAppleProductId = async (productId) => {
    const { rows } = await db.query(
        `SELECT plan_id, apple_product_id_yearly FROM plans
         WHERE apple_product_id_monthly = $1 OR apple_product_id_yearly = $1`,
        [productId]
    )
    if (rows.length === 0) return null
    const billingCadence = rows[0].apple_product_id_yearly === productId ? 'yearly' : 'monthly'
    return { planId: rows[0].plan_id, billingCadence }
}

// Upserts based on the verified transaction — shared shape between SUBSCRIBED
// and DID_RENEW, which both carry a full transaction to sync from.
const upsertFromTransaction = async (transaction) => {
    const organizationId = await resolveOrganizationId(transaction.originalTransactionId, transaction.appAccountToken)
    if (!organizationId) {
        console.error(`Apple notification: could not resolve organizationId for originalTransactionId ${transaction.originalTransactionId}`)
        return
    }
    const resolved = await resolvePlanByAppleProductId(transaction.productId)
    if (!resolved) {
        console.error(`Apple notification: productId ${transaction.productId} does not match any plan`)
        return
    }

    const purchaseDate = new Date(transaction.purchaseDate)
    const expiresDate = new Date(transaction.expiresDate)
    const price = transaction.price != null ? transaction.price / 1000 : 0

    const client = await db.connect()
    try {
        await client.query('BEGIN')
        await client.query(
            'UPDATE subscribed_services SET is_active = FALSE WHERE organization_id = $1 AND external_subscription_id != $2 AND is_active = TRUE',
            [organizationId, transaction.originalTransactionId]
        )
        await client.query(
            `INSERT INTO subscribed_services
                (organization_id, plan_id, payment_provider, external_subscription_id,
                 billing_cadence, since, active_until, price, is_cancelled, is_active)
             VALUES ($1, $2, 'apple', $3, $4, $5, $6, $7, FALSE, TRUE)
             ON CONFLICT (external_subscription_id) DO UPDATE
                SET plan_id = EXCLUDED.plan_id, active_until = EXCLUDED.active_until,
                    price = EXCLUDED.price, is_active = TRUE, updated_at = NOW()`,
            [organizationId, resolved.planId, transaction.originalTransactionId, resolved.billingCadence, purchaseDate, expiresDate, price]
        )
        await client.query('UPDATE organizations SET plan_id = $1 WHERE id = $2', [resolved.planId, organizationId])
        await client.query('COMMIT')
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {})
        throw err
    } finally {
        client.release()
    }
}

const deactivate = async (originalTransactionId) => {
    await db.query(
        'UPDATE subscribed_services SET is_active = FALSE, updated_at = NOW() WHERE external_subscription_id = $1',
        [originalTransactionId]
    )
}

const setCancelled = async (originalTransactionId, isCancelled) => {
    await db.query(
        'UPDATE subscribed_services SET is_cancelled = $1, updated_at = NOW() WHERE external_subscription_id = $2',
        [isCancelled, originalTransactionId]
    )
}

const appleNotificationWebhook = async (req, res) => {
    const { signedPayload } = req.body
    if (!signedPayload) return res.status(400).json({ message: 'signedPayload is required' })

    let notification
    try {
        notification = await verifyNotification(signedPayload)
    } catch (err) {
        console.error('Apple notification signature verification failed:', err.message)
        return res.status(400).json({ message: 'invalid signature' })
    }

    try {
        const signedTransactionInfo = notification.data?.signedTransactionInfo
        const transaction = signedTransactionInfo ? await verifyTransaction(signedTransactionInfo) : null

        switch (notification.notificationType) {
            case 'SUBSCRIBED':
            case 'DID_RENEW':
                if (transaction) await upsertFromTransaction(transaction)
                break

            case 'EXPIRED':
            case 'GRACE_PERIOD_EXPIRED':
            case 'REVOKE':
            case 'REFUND':
                if (transaction) await deactivate(transaction.originalTransactionId)
                break

            case 'DID_CHANGE_RENEWAL_STATUS':
                if (transaction) await setCancelled(transaction.originalTransactionId, notification.subtype === 'AUTO_RENEW_DISABLED')
                break

            // DID_FAIL_TO_RENEW, DID_CHANGE_RENEWAL_PREF, PRICE_INCREASE, OFFER_REDEEMED,
            // RENEWAL_EXTENDED, TEST, etc. — not acted on. DID_FAIL_TO_RENEW in particular:
            // Apple keeps retrying billing on its own during the grace period, so no
            // immediate deactivation here — GRACE_PERIOD_EXPIRED (or EXPIRED, if the plan
            // has no grace period configured) is what actually ends access.
            default:
                break
        }
        res.status(200).json({ received: true })
    } catch (err) {
        console.error('Apple notification processing error:', err)
        res.status(500).json({ error: 'notification processing failed' })
    }
}

module.exports = { appleNotificationWebhook }
