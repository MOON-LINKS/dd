const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { validateReferralCodeValue } = require('../utils/referralEngine')

// ------------------------------------------------------------------
// GET MY REFERRAL CODE — code is created lazily on first payment (see
// referralEngine.ensureReferralCodeForOrganization, called from the
// webhook patch), so a pre-payment org legitimately has none yet.
// ------------------------------------------------------------------
const getMyReferralCode = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            'SELECT code, discount_pct, created_at FROM referral_codes WHERE organization_id = $1',
            [organizationId]
        )
        if (rows.length === 0) {
            return res.status(200).json({ code: null, message: 'referral code is generated after your first successful payment' })
        }
        res.status(200).json(rows[0])
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch referral code' })
    }
}

// ------------------------------------------------------------------
// VALIDATE — public, no auth. Live-checked by the new-org signup/
// checkout UI as the person types a code in, same pattern as bio page
// slug-check.
// ------------------------------------------------------------------
const validateReferralCode = async (req, res) => {
    const { code } = req.query
    try {
        const { valid, discount_pct } = await validateReferralCodeValue(code)
        res.status(200).json({ valid, discountPct: valid ? discount_pct : null })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not validate referral code' })
    }
}

// ------------------------------------------------------------------
// GET EARNINGS — accumulated ledger summary: lifetime earned, already
// paid out, and current payable balance.
// ------------------------------------------------------------------
const getReferralEarnings = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `SELECT
                COALESCE(SUM(commission_cents), 0) AS total_earned_cents,
                COALESCE(SUM(commission_cents) FILTER (WHERE payout_id IS NOT NULL), 0) AS total_paid_cents,
                COALESCE(SUM(commission_cents) FILTER (WHERE payout_id IS NULL), 0) AS pending_balance_cents,
                COUNT(DISTINCT referred_organization_id) AS referred_organizations_count
             FROM referral_earnings
             WHERE referring_organization_id = $1`,
            [organizationId]
        )
        res.status(200).json({
            totalEarnedCents: parseInt(rows[0].total_earned_cents, 10),
            totalPaidCents: parseInt(rows[0].total_paid_cents, 10),
            pendingBalanceCents: parseInt(rows[0].pending_balance_cents, 10),
            referredOrganizationsCount: parseInt(rows[0].referred_organizations_count, 10)
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch referral earnings' })
    }
}

// ------------------------------------------------------------------
// LIST HISTORY — who's used your code, and every earning entry from
// their ongoing payments.
// ------------------------------------------------------------------
const listReferralHistory = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const { rows: uses } = await db.query(
            `SELECT ru.id, ru.referred_organization_id, o.name AS referred_organization_name,
                    ru.discount_applied_pct, ru.used_at
             FROM referral_uses ru
             JOIN referral_codes rc ON rc.id = ru.referral_code_id
             JOIN organizations o ON o.id = ru.referred_organization_id
             WHERE rc.organization_id = $1
             ORDER BY ru.used_at DESC`,
            [organizationId]
        )

        const { rows: earnings } = await db.query(
            `SELECT id, referred_organization_id, source_amount_cents, commission_cents, payout_id, created_at
             FROM referral_earnings
             WHERE referring_organization_id = $1
             ORDER BY created_at DESC`,
            [organizationId]
        )

        res.status(200).json({ referredOrganizations: uses, earnings })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch referral history' })
    }
}

module.exports = { getMyReferralCode, validateReferralCode, getReferralEarnings, listReferralHistory }
