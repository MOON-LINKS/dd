const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { checkHistoryLimit } = require('../utils/historyLimit')

// Section 3: "Not just a flat list — a full analytics/charts view... revenue
// over the period, hours logged vs. hours billed, amount paid vs. amount
// owed, breakdown by client and by job, trends over time." This endpoint
// returns all of it in one call so the frontend can render the whole tab
// from a single request rather than five round trips.
//
// "Hours logged" vs "hours billed" is a real distinction in this data model,
// not just a rename: logged = every hour recorded on a day_assignment in the
// period regardless of worker pay_type; billed = only the hours that
// actually produced a dollar amount on an invoice (hourly workers only —
// monthly-salaried workers' hours are logged but never billed to a client,
// see utils/invoiceGeneration.js's money-model note).
const getInvoiceAnalytics = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { startDate, endDate } = req.query
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!startDate || !endDate) {
            return res.status(400).json({ message: 'startDate and endDate are required' })
        }
        if (new Date(endDate) < new Date(startDate)) {
            return res.status(400).json({ message: 'endDate must not be before startDate' })
        }

        const historyCheck = await checkHistoryLimit(organizationId, startDate)
        if (!historyCheck.allowed) return res.status(403).json({ message: historyCheck.message })

        const [
            revenueTrendResult,
            paidVsOwedResult,
            byClientResult,
            byJobResult,
            hoursLoggedResult,
            hoursBilledResult
        ] = await Promise.all([
            // Revenue trend — one bucket per calendar month touched by the range.
            db.query(
                `SELECT DATE_TRUNC('month', period_start)::date AS month,
                        SUM(total_amount) AS revenue,
                        SUM(total_hours) AS hours
                 FROM invoices
                 WHERE organization_id = $1 AND period_start >= $2 AND period_end <= $3
                 GROUP BY 1
                 ORDER BY 1 ASC`,
                [organizationId, startDate, endDate]
            ),
            db.query(
                `SELECT COALESCE(SUM(amount_paid), 0) AS total_paid, COALESCE(SUM(amount_owed), 0) AS total_owed
                 FROM invoices
                 WHERE organization_id = $1 AND period_start >= $2 AND period_end <= $3`,
                [organizationId, startDate, endDate]
            ),
            db.query(
                `SELECT i.client_id, c.name AS client_name,
                        SUM(i.total_hours) AS total_hours, SUM(i.total_amount) AS total_amount,
                        SUM(i.amount_paid) AS amount_paid, SUM(i.amount_owed) AS amount_owed
                 FROM invoices i
                 LEFT JOIN clients c ON c.id = i.client_id
                 WHERE i.organization_id = $1 AND i.period_start >= $2 AND i.period_end <= $3
                 GROUP BY i.client_id, c.name
                 ORDER BY total_amount DESC`,
                [organizationId, startDate, endDate]
            ),
            db.query(
                `SELECT li.job_id, j.title AS job_title,
                        SUM(li.hours) AS total_hours,
                        SUM(li.amount) FILTER (WHERE li.amount IS NOT NULL) AS total_amount
                 FROM invoice_line_items li
                 JOIN invoices i ON i.id = li.invoice_id
                 LEFT JOIN jobs j ON j.id = li.job_id
                 WHERE i.organization_id = $1 AND i.period_start >= $2 AND i.period_end <= $3
                 GROUP BY li.job_id, j.title
                 ORDER BY total_amount DESC NULLS LAST`,
                [organizationId, startDate, endDate]
            ),
            db.query(
                `SELECT COALESCE(SUM(da.hours), 0) AS hours_logged
                 FROM day_assignments da
                 JOIN job_days jd ON jd.id = da.job_day_id
                 JOIN jobs j ON j.id = jd.job_id AND j.deleted_at IS NULL
                 WHERE j.organization_id = $1 AND jd.date BETWEEN $2 AND $3`,
                [organizationId, startDate, endDate]
            ),
            db.query(
                `SELECT COALESCE(SUM(li.hours), 0) AS hours_billed
                 FROM invoice_line_items li
                 JOIN invoices i ON i.id = li.invoice_id
                 WHERE i.organization_id = $1 AND i.period_start >= $2 AND i.period_end <= $3
                   AND li.amount IS NOT NULL`,
                [organizationId, startDate, endDate]
            )
        ])

        res.status(200).json({
            range: { startDate, endDate },
            revenueTrend: revenueTrendResult.rows.map((r) => ({
                month: r.month,
                revenue: parseFloat(r.revenue),
                hours: parseFloat(r.hours)
            })),
            paidVsOwed: {
                totalPaid: parseFloat(paidVsOwedResult.rows[0].total_paid),
                totalOwed: parseFloat(paidVsOwedResult.rows[0].total_owed)
            },
            hoursLoggedVsBilled: {
                hoursLogged: parseFloat(hoursLoggedResult.rows[0].hours_logged),
                hoursBilled: parseFloat(hoursBilledResult.rows[0].hours_billed)
            },
            byClient: byClientResult.rows.map((r) => ({
                clientId: r.client_id,
                clientName: r.client_name,
                totalHours: parseFloat(r.total_hours),
                totalAmount: parseFloat(r.total_amount),
                amountPaid: parseFloat(r.amount_paid),
                amountOwed: parseFloat(r.amount_owed)
            })),
            byJob: byJobResult.rows.map((r) => ({
                jobId: r.job_id,
                jobTitle: r.job_title,
                totalHours: parseFloat(r.total_hours),
                totalAmount: r.total_amount != null ? parseFloat(r.total_amount) : 0
            }))
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not compute invoice analytics' })
    }
}

module.exports = { getInvoiceAnalytics }
