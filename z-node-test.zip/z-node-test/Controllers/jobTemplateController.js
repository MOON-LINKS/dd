const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')

// Job templates are global (not org-scoped) but filtered by the requesting
// org's organization_type on read. Only admins create/update them — v1 has
// no manager-facing template builder, per spec Section 3.

// ------------------------------------------------------------------
// LIST JOB TEMPLATES — manager-facing. Returns templates matching the
// org's industry, plus universal ones (industry IS NULL).
// ------------------------------------------------------------------
const listJobTemplates = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const { rows: orgRows } = await db.query(
            'SELECT organization_type FROM organizations WHERE id = $1 AND deleted_at IS NULL',
            [organizationId]
        )
        if (orgRows.length === 0) return res.status(404).json({ message: 'organization not found' })
        const { organization_type } = orgRows[0]

        const { rows } = await db.query(
            `SELECT id, name, description, industry, created_at
             FROM job_templates
             WHERE is_active = TRUE
               AND (industry IS NULL OR industry = $1)
             ORDER BY industry NULLS LAST, name ASC`,
            [organization_type]
        )
        res.status(200).json({ templates: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch job templates' })
    }
}

// ------------------------------------------------------------------
// CREATE JOB TEMPLATE — internal/admin tool only. Not exposed to
// managers in v1; gate this route behind a requireAdmin middleware
// once that exists, not requireAuth alone.
// ------------------------------------------------------------------
const createJobTemplate = async (req, res) => {
    const { name, description, industry } = req.body
    try {
        if (!name) return res.status(400).json({ message: 'name is required' })

        const { rows } = await db.query(
            `INSERT INTO job_templates (name, description, industry)
             VALUES ($1, $2, $3)
             RETURNING id, name, description, industry, is_active, created_at`,
            [name, description || null, industry || null]
        )
        res.status(201).json({ template: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create job template' })
    }
}

// ------------------------------------------------------------------
// UPDATE JOB TEMPLATE — admin tool. Includes is_active so templates
// can be retired without deleting (jobs already using them keep the FK).
// ------------------------------------------------------------------
const updateJobTemplate = async (req, res) => {
    const { templateId } = req.params
    const { name, description, industry, isActive } = req.body
    try {
        const { rows } = await db.query(
            `UPDATE job_templates
             SET name = COALESCE($1, name),
                 description = COALESCE($2, description),
                 industry = COALESCE($3, industry),
                 is_active = COALESCE($4, is_active)
             WHERE id = $5
             RETURNING id, name, description, industry, is_active`,
            [name, description, industry, isActive, templateId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'template not found' })
        res.status(200).json({ template: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update job template' })
    }
}

module.exports = { listJobTemplates, createJobTemplate, updateJobTemplate }
