const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')

// All routes nested under /organizations/:organizationId/jobs.
// getJobSnapshot / saveJobSnapshot implement the hydration pattern from
// spec Section 14: one request loads the full job + days + assignments,
// the frontend edits it locally (Riverpod), and one Save button sends the
// whole changed snapshot back in a single request.

// ------------------------------------------------------------------
// CREATE JOB — original_due_date is set once here and never changes
// again (postponeJob only ever touches due_date).
// ------------------------------------------------------------------
const createJob = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { title, clientId, templateId, dueDate } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!title) return res.status(400).json({ message: 'title is required' })
        if (!dueDate) return res.status(400).json({ message: 'dueDate is required' })

        // clientId/templateId are optional but must belong to this org if provided
        if (clientId) {
            const { rows } = await db.query(
                'SELECT id FROM clients WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL',
                [clientId, organizationId]
            )
            if (rows.length === 0) return res.status(400).json({ message: 'clientId does not belong to this organization' })
        }

        const { rows } = await db.query(
            `INSERT INTO jobs (organization_id, client_id, template_id, title, original_due_date, due_date)
             VALUES ($1, $2, $3, $4, $5, $5)
             RETURNING id, title, status, client_id, template_id, original_due_date, due_date, created_at`,
            [organizationId, clientId || null, templateId || null, title, dueDate]
        )
        res.status(201).json({ job: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create job' })
    }
}

// ------------------------------------------------------------------
// LIST JOBS — filter by status / clientId / due date range
// ------------------------------------------------------------------
const listJobs = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { status, clientId, dueFrom, dueTo } = req.query
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const { rows } = await db.query(
            `SELECT j.id, j.title, j.status, j.client_id, c.name AS client_name,
                    j.template_id, j.original_due_date, j.due_date, j.postponed_at, j.created_at
             FROM jobs j
             LEFT JOIN clients c ON c.id = j.client_id
             WHERE j.organization_id = $1 AND j.deleted_at IS NULL
               AND ($2::varchar IS NULL OR j.status = $2)
               AND ($3::uuid IS NULL OR j.client_id = $3)
               AND ($4::date IS NULL OR j.due_date >= $4)
               AND ($5::date IS NULL OR j.due_date <= $5)
             ORDER BY j.due_date ASC`,
            [organizationId, status || null, clientId || null, dueFrom || null, dueTo || null]
        )
        res.status(200).json({ jobs: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch jobs' })
    }
}

// ------------------------------------------------------------------
// UPDATE JOB — title / clientId / templateId / status. due_date is
// deliberately NOT editable here — postponeJob is the only path that
// changes it, so the postponed_at/postponed_by audit trail can't be bypassed.
// ------------------------------------------------------------------
const updateJob = async (req, res) => {
    const { organizationId, jobId } = req.params
    const userId = req.user.id
    const { title, clientId, templateId, status } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (status && !['pending', 'in_progress', 'done'].includes(status)) {
            return res.status(400).json({ message: 'invalid status' })
        }

        const { rows } = await db.query(
            `UPDATE jobs
             SET title = COALESCE($1, title),
                 client_id = COALESCE($2, client_id),
                 template_id = COALESCE($3, template_id),
                 status = COALESCE($4, status),
                 updated_at = NOW()
             WHERE id = $5 AND organization_id = $6 AND deleted_at IS NULL
             RETURNING id, title, status, client_id, template_id, original_due_date, due_date`,
            [title, clientId, templateId, status, jobId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'job not found' })
        res.status(200).json({ job: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update job' })
    }
}

// ------------------------------------------------------------------
// POSTPONE JOB — the only path that changes due_date. original_due_date
// is untouched, preserving what was originally committed to (spec Section 3/14).
// ------------------------------------------------------------------
const postponeJob = async (req, res) => {
    const { organizationId, jobId } = req.params
    const userId = req.user.id
    const { newDueDate } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!newDueDate) return res.status(400).json({ message: 'newDueDate is required' })

        const { rows } = await db.query(
            `UPDATE jobs
             SET due_date = $1, postponed_at = NOW(), postponed_by = $2, updated_at = NOW()
             WHERE id = $3 AND organization_id = $4 AND deleted_at IS NULL
             RETURNING id, title, original_due_date, due_date, postponed_at, postponed_by`,
            [newDueDate, userId, jobId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'job not found' })
        res.status(200).json({ job: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not postpone job' })
    }
}

// ------------------------------------------------------------------
// DELETE JOB (soft delete)
// ------------------------------------------------------------------
const deleteJob = async (req, res) => {
    const { organizationId, jobId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `UPDATE jobs SET deleted_at = NOW()
             WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL
             RETURNING id`,
            [jobId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'job not found' })
        res.status(200).json({ message: 'job deleted' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not delete job' })
    }
}

// ------------------------------------------------------------------
// Shared data fetcher — used by getJobSnapshot directly, and by
// saveJobSnapshot to return the fresh state after a save, without a
// fake-response hack. Assumes ownership was already checked by the caller.
// ------------------------------------------------------------------
const fetchJobSnapshotData = async (organizationId, jobId) => {
    const { rows: jobRows } = await db.query(
        `SELECT id, title, status, client_id, template_id, original_due_date, due_date, postponed_at
         FROM jobs WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL`,
        [jobId, organizationId]
    )
    if (jobRows.length === 0) return null

    const { rows: dayRows } = await db.query(
        `SELECT jd.id, jd.date, jd.invoiced,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', da.id,
                            'workerId', da.worker_id,
                            'workerName', w.name,
                            'hours', da.hours,
                            'editedAt', da.edited_at
                        ) ORDER BY w.name
                    ) FILTER (WHERE da.id IS NOT NULL), '[]'
                ) AS assignments
         FROM job_days jd
         LEFT JOIN day_assignments da ON da.job_day_id = jd.id
         LEFT JOIN workers w ON w.id = da.worker_id
         WHERE jd.job_id = $1
         GROUP BY jd.id
         ORDER BY jd.date ASC`,
        [jobId]
    )

    return { job: jobRows[0], days: dayRows }
}

// ------------------------------------------------------------------
// GET JOB SNAPSHOT — hydrates the job + all its days + all assignments
// (with worker name so the UI doesn't need extra calls) in one response.
// This is what the frontend loads into Riverpod state on open.
// ------------------------------------------------------------------
const getJobSnapshot = async (req, res) => {
    const { organizationId, jobId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const snapshot = await fetchJobSnapshotData(organizationId, jobId)
        if (!snapshot) return res.status(404).json({ message: 'job not found' })
        res.status(200).json(snapshot)
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch job snapshot' })
    }
}

// ------------------------------------------------------------------
// SAVE JOB SNAPSHOT — the single Save button. Upserts changed days +
// assignments in one request/transaction. Any day already marked
// `invoiced` is skipped (not silently overwritten) and reported back
// so the frontend can flag it, per spec Section 4's safeguard.
//
// Expected body shape:
// { days: [ { id?, date, assignments: [ { id?, workerId, hours } ] } ] }
// - Omit `id` on a day/assignment to create it; include it to update.
// ------------------------------------------------------------------
const saveJobSnapshot = async (req, res) => {
    const { organizationId, jobId } = req.params
    const userId = req.user.id
    const { days } = req.body
    if (!Array.isArray(days)) return res.status(400).json({ message: 'days must be an array' })

    const client = await db.connect()
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            client.release()
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows: jobRows } = await db.query(
            'SELECT id FROM jobs WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL',
            [jobId, organizationId]
        )
        if (jobRows.length === 0) {
            client.release()
            return res.status(404).json({ message: 'job not found' })
        }

        const skippedDays = [] // dates that were already invoiced — not touched

        await client.query('BEGIN')

        for (const day of days) {
            if (!day.date) continue

            // Does this day already exist, and is it invoiced?
            const { rows: existingDayRows } = await client.query(
                'SELECT id, invoiced FROM job_days WHERE job_id = $1 AND date = $2',
                [jobId, day.date]
            )
            const existingDay = existingDayRows[0]

            if (existingDay?.invoiced) {
                skippedDays.push(day.date)
                continue // never silently edit an already-invoiced day
            }

            // Upsert the job_day row
            const { rows: dayUpsertRows } = await client.query(
                `INSERT INTO job_days (job_id, date)
                 VALUES ($1, $2)
                 ON CONFLICT (job_id, date) DO UPDATE SET date = EXCLUDED.date
                 RETURNING id`,
                [jobId, day.date]
            )
            const jobDayId = dayUpsertRows[0].id

            for (const assignment of (day.assignments || [])) {
                if (!assignment.workerId || assignment.hours === undefined) continue

                // Confirm the worker belongs to this org before attaching hours to it
                const { rows: workerRows } = await client.query(
                    'SELECT id FROM workers WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL',
                    [assignment.workerId, organizationId]
                )
                if (workerRows.length === 0) continue // silently skip a worker that doesn't belong here

                const { rows: existingAssignmentRows } = await client.query(
                    'SELECT id FROM day_assignments WHERE job_day_id = $1 AND worker_id = $2',
                    [jobDayId, assignment.workerId]
                )
                const isUpdate = existingAssignmentRows.length > 0

                await client.query(
                    `INSERT INTO day_assignments (job_day_id, worker_id, hours, edited_at, edited_by)
                     VALUES ($1, $2, $3, $4, $5)
                     ON CONFLICT (job_day_id, worker_id) DO UPDATE
                         SET hours = EXCLUDED.hours, edited_at = EXCLUDED.edited_at, edited_by = EXCLUDED.edited_by`,
                    [jobDayId, assignment.workerId, assignment.hours, isUpdate ? new Date() : null, isUpdate ? userId : null]
                )
            }
        }

        await client.query('COMMIT')
        client.release()

        // Return the fresh snapshot so the frontend can resync state after save
        const snapshot = await fetchJobSnapshotData(organizationId, jobId)
        return res.status(200).json({ ...snapshot, skippedDays })
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {})
        client.release()
        console.error(err)
        res.status(500).json({ message: 'could not save job snapshot' })
    }
}

module.exports = {
    createJob,
    listJobs,
    updateJob,
    postponeJob,
    deleteJob,
    getJobSnapshot,
    saveJobSnapshot
}
