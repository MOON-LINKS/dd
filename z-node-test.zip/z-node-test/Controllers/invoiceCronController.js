const db = require('../utils/db')
const { generateInvoicesForOrganization, previousCalendarMonth } = require('../utils/invoiceGeneration')

// Not behind requireAuth — there's no logged-in user calling this, it's a
// scheduler (cron / a serverless scheduled function / whatever you point at
// this route). Gated by a shared secret instead — see routes/invoiceCronRoutes.js.
//
// Only generates for organizations with an active subscription
// (subscribed_services.is_active = TRUE), matching Batch 5's payment-gating
// intent — an org that let its subscription lapse shouldn't have invoices
// silently piling up (and PDFs/emails going out) for a product it's no
// longer paying for. An org's job/hours data is untouched either way; it's
// only NEW invoice generation that's gated, not read access to past invoices.
const runMonthlyInvoiceGeneration = async (req, res) => {
    const { periodStart, periodEnd } = previousCalendarMonth()

    try {
        const { rows: activeOrgs } = await db.query(
            `SELECT DISTINCT organization_id
             FROM subscribed_services
             WHERE is_active = TRUE`
        )

        const results = []
        for (const { organization_id: organizationId } of activeOrgs) {
            const client = await db.connect()
            try {
                await client.query('BEGIN')
                const result = await generateInvoicesForOrganization(client, organizationId, periodStart, periodEnd)
                await client.query('COMMIT')
                results.push({ organizationId, invoicesCreated: result.invoices.length })
            } catch (err) {
                await client.query('ROLLBACK').catch(() => {})
                // One org's failure (e.g. a data anomaly) shouldn't block every
                // other org's invoices from generating — log and continue.
                console.error(`Invoice generation failed for org ${organizationId}:`, err)
                results.push({ organizationId, error: err.message })
            } finally {
                client.release()
            }
        }

        res.status(200).json({ periodStart, periodEnd, organizationsProcessed: results.length, results })
    } catch (err) {
        console.error('Monthly invoice generation cron failed:', err)
        res.status(500).json({ message: 'monthly invoice generation failed' })
    }
}

module.exports = { runMonthlyInvoiceGeneration }
