const db = require('../utils/db')
const { MIN_PAYOUT_CENTS } = require('../utils/referralConstants')

// ------------------------------------------------------------------
// ISSUE PAYOUT — admin-only. No payout processor is wired (flagged
// earlier as its own open question — bank transfer, gift card, etc. are
// all still manual). This endpoint records that a payout happened and
// atomically marks the earnings it covers as paid; it does not move any
// money itself.
//
// Body: { organizationId, amountCents, notes, allowBelowThreshold? }
// Pays out the OLDEST unpaid earnings first, up to amountCents.
// ------------------------------------------------------------------
const issuePayout = async (req, res) => {
    const { organizationId, amountCents, notes, allowBelowThreshold } = req.body
    const adminUserId = req.user.id
    try {
        if (!organizationId || !amountCents || amountCents <= 0) {
            return res.status(400).json({ message: 'organizationId and a positive amountCents are required' })
        }
        if (amountCents < MIN_PAYOUT_CENTS && !allowBelowThreshold) {
            return res.status(400).json({
                message: `payout is below the ${MIN_PAYOUT_CENTS / 100} minimum — pass allowBelowThreshold: true to override`
            })
        }

        const client = await db.connect()
        try {
            await client.query('BEGIN')

            const { rows: balanceRows } = await client.query(
                `SELECT COALESCE(SUM(commission_cents), 0) AS pending_balance_cents
                 FROM referral_earnings
                 WHERE referring_organization_id = $1 AND payout_id IS NULL`,
                [organizationId]
            )
            const pendingBalanceCents = parseInt(balanceRows[0].pending_balance_cents, 10)
            if (amountCents > pendingBalanceCents) {
                await client.query('ROLLBACK')
                return res.status(400).json({
                    message: `requested amount exceeds pending balance ($${(pendingBalanceCents / 100).toFixed(2)} available)`
                })
            }

            const { rows: payoutRows } = await client.query(
                `INSERT INTO referral_payouts (organization_id, amount_cents, status, notes, paid_at, created_by_admin_user_id)
                 VALUES ($1, $2, 'paid', $3, NOW(), $4)
                 RETURNING id`,
                [organizationId, amountCents, notes || null, adminUserId]
            )
            const payoutId = payoutRows[0].id

            // Mark the oldest unpaid earnings as covered by this payout, up to
            // amountCents. Simple oldest-first allocation — not a partial-row
            // split, so the sum covered may slightly exceed amountCents if the
            // last earning row straddles the requested amount; acceptable for
            // a manually-reconciled payout process.
            const { rows: unpaidEarnings } = await client.query(
                `SELECT id, commission_cents FROM referral_earnings
                 WHERE referring_organization_id = $1 AND payout_id IS NULL
                 ORDER BY created_at ASC`,
                [organizationId]
            )
            let covered = 0
            const coveredIds = []
            for (const earning of unpaidEarnings) {
                if (covered >= amountCents) break
                coveredIds.push(earning.id)
                covered += earning.commission_cents
            }
            await client.query(
                'UPDATE referral_earnings SET payout_id = $1 WHERE id = ANY($2::uuid[])',
                [payoutId, coveredIds]
            )

            await client.query('COMMIT')
            res.status(201).json({ message: 'payout recorded', payoutId, coveredEarningsCount: coveredIds.length })
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {})
            throw err
        } finally {
            client.release()
        }
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not issue payout' })
    }
}

const listPendingPayoutBalances = async (req, res) => {
    try {
        const { rows } = await db.query(
            `SELECT re.referring_organization_id, o.name AS organization_name,
                    SUM(re.commission_cents) AS pending_balance_cents
             FROM referral_earnings re
             JOIN organizations o ON o.id = re.referring_organization_id
             WHERE re.payout_id IS NULL
             GROUP BY re.referring_organization_id, o.name
             HAVING SUM(re.commission_cents) > 0
             ORDER BY pending_balance_cents DESC`
        )
        res.status(200).json({ balances: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch pending payout balances' })
    }
}

module.exports = { issuePayout, listPendingPayoutBalances }
