const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')

// All routes nested under /organizations/:organizationId/upcoming-bills.
//
// NOTE: sendBillReminders (the scheduled reminder job) is intentionally NOT
// included here — still blocked on formalizing the recurring-interval
// fields, per the open item in the spec. reminder_days_before already
// exists on the table and is accepted below so the data is captured now;
// the actual cron/worker that reads it and fires notifications is separate
// follow-up work once that's unblocked.

// ------------------------------------------------------------------
// CREATE UPCOMING BILL
// ------------------------------------------------------------------
const createUpcomingBill = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { title, amount, dueDate, reminderDaysBefore, proofAssetId, linkedWorkerId, linkedJobId } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!title) return res.status(400).json({ message: 'title is required' })
        if (amount === undefined || amount < 0) return res.status(400).json({ message: 'a valid amount is required' })
        if (!dueDate) return res.status(400).json({ message: 'dueDate is required' })

        if (linkedWorkerId) {
            const { rows } = await db.query(
                'SELECT id FROM workers WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL',
                [linkedWorkerId, organizationId]
            )
            if (rows.length === 0) return res.status(400).json({ message: 'linkedWorkerId does not belong to this organization' })
        }
        if (linkedJobId) {
            const { rows } = await db.query(
                'SELECT id FROM jobs WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL',
                [linkedJobId, organizationId]
            )
            if (rows.length === 0) return res.status(400).json({ message: 'linkedJobId does not belong to this organization' })
        }

        const { rows } = await db.query(
            `INSERT INTO upcoming_bills
                (organization_id, title, amount, due_date, reminder_days_before, proof_asset_id, linked_worker_id, linked_job_id)
             VALUES ($1, $2, $3, $4, COALESCE($5, 7), $6, $7, $8)
             RETURNING id, title, amount, due_date, reminder_days_before, is_paid, proof_asset_id,
                       linked_worker_id, linked_job_id, created_at`,
            [organizationId, title, amount, dueDate, reminderDaysBefore || null, proofAssetId || null, linkedWorkerId || null, linkedJobId || null]
        )
        res.status(201).json({ bill: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create upcoming bill' })
    }
}

// ------------------------------------------------------------------
// LIST UPCOMING BILLS — filter by paid/unpaid, due date range
// ------------------------------------------------------------------
const listUpcomingBills = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { isPaid, dueFrom, dueTo } = req.query
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `SELECT id, title, amount, due_date, reminder_days_before, is_paid, proof_asset_id,
                    linked_worker_id, linked_job_id, converted_expense_id, created_at
             FROM upcoming_bills
             WHERE organization_id = $1
               AND ($2::boolean IS NULL OR is_paid = $2)
               AND ($3::date IS NULL OR due_date >= $3)
               AND ($4::date IS NULL OR due_date <= $4)
             ORDER BY due_date ASC`,
            [organizationId, isPaid === undefined ? null : isPaid === 'true', dueFrom || null, dueTo || null]
        )
        res.status(200).json({ bills: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch upcoming bills' })
    }
}

// ------------------------------------------------------------------
// GET UPCOMING BILL
// ------------------------------------------------------------------
const getUpcomingBill = async (req, res) => {
    const { organizationId, billId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            'SELECT * FROM upcoming_bills WHERE id = $1 AND organization_id = $2',
            [billId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'bill not found' })
        res.status(200).json({ bill: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch upcoming bill' })
    }
}

// ------------------------------------------------------------------
// UPDATE UPCOMING BILL
// ------------------------------------------------------------------
const updateUpcomingBill = async (req, res) => {
    const { organizationId, billId } = req.params
    const userId = req.user.id
    const { title, amount, dueDate, reminderDaysBefore, proofAssetId, linkedWorkerId, linkedJobId } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `UPDATE upcoming_bills
             SET title = COALESCE($1, title),
                 amount = COALESCE($2, amount),
                 due_date = COALESCE($3, due_date),
                 reminder_days_before = COALESCE($4, reminder_days_before),
                 proof_asset_id = COALESCE($5, proof_asset_id),
                 linked_worker_id = COALESCE($6, linked_worker_id),
                 linked_job_id = COALESCE($7, linked_job_id),
                 updated_at = NOW()
             WHERE id = $8 AND organization_id = $9
             RETURNING id, title, amount, due_date, reminder_days_before, is_paid, proof_asset_id,
                       linked_worker_id, linked_job_id`,
            [title, amount, dueDate, reminderDaysBefore, proofAssetId, linkedWorkerId, linkedJobId, billId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'bill not found' })
        res.status(200).json({ bill: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update upcoming bill' })
    }
}

// ------------------------------------------------------------------
// DELETE UPCOMING BILL — hard delete, same rationale as expenses
// ------------------------------------------------------------------
const deleteUpcomingBill = async (req, res) => {
    const { organizationId, billId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            'DELETE FROM upcoming_bills WHERE id = $1 AND organization_id = $2 RETURNING id',
            [billId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'bill not found' })
        res.status(200).json({ message: 'bill deleted' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not delete upcoming bill' })
    }
}

// ------------------------------------------------------------------
// MARK BILL PAID
// ------------------------------------------------------------------
const markBillPaid = async (req, res) => {
    const { organizationId, billId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `UPDATE upcoming_bills SET is_paid = TRUE, updated_at = NOW()
             WHERE id = $1 AND organization_id = $2
             RETURNING id, title, amount, is_paid`,
            [billId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'bill not found' })
        res.status(200).json({ bill: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not mark bill paid' })
    }
}

// ------------------------------------------------------------------
// CONVERT BILL TO EXPENSE — creates an expense record from a paid bill
// and links them via converted_expense_id. Category defaults to 'other'
// since bills don't carry the same category enum as expenses; the
// manager can recategorize the resulting expense afterward.
// ------------------------------------------------------------------
const convertBillToExpense = async (req, res) => {
    const { organizationId, billId } = req.params
    const userId = req.user.id
    const { category } = req.body // optional override, defaults to 'other'
    const client = await db.connect()
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            client.release()
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows: billRows } = await db.query(
            'SELECT * FROM upcoming_bills WHERE id = $1 AND organization_id = $2',
            [billId, organizationId]
        )
        if (billRows.length === 0) {
            client.release()
            return res.status(404).json({ message: 'bill not found' })
        }
        const bill = billRows[0]
        if (bill.converted_expense_id) {
            client.release()
            return res.status(400).json({ message: 'bill has already been converted to an expense' })
        }

        await client.query('BEGIN')

        const { rows: expenseRows } = await client.query(
            `INSERT INTO expenses (organization_id, category, amount, date, recurring, notes, linked_worker_id, linked_job_id)
             VALUES ($1, $2, $3, CURRENT_DATE, FALSE, $4, $5, $6)
             RETURNING id`,
            [organizationId, category || 'other', bill.amount, `Converted from bill: ${bill.title}`, bill.linked_worker_id, bill.linked_job_id]
        )
        const expenseId = expenseRows[0].id

        const { rows: updatedBillRows } = await client.query(
            `UPDATE upcoming_bills SET is_paid = TRUE, converted_expense_id = $1, updated_at = NOW()
             WHERE id = $2
             RETURNING id, title, amount, is_paid, converted_expense_id`,
            [expenseId, billId]
        )

        await client.query('COMMIT')
        client.release()
        res.status(200).json({ bill: updatedBillRows[0], expenseId })
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {})
        client.release()
        console.error(err)
        res.status(500).json({ message: 'could not convert bill to expense' })
    }
}

module.exports = {
    createUpcomingBill,
    listUpcomingBills,
    getUpcomingBill,
    updateUpcomingBill,
    deleteUpcomingBill,
    markBillPaid,
    convertBillToExpense
}
