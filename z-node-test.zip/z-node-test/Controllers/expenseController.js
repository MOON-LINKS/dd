const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')

const EXPENSE_CATEGORIES = ['hospital', 'tax', 'electricity', 'rent', 'fuel', 'transportation', 'other']

// All routes nested under /organizations/:organizationId/expenses

// ------------------------------------------------------------------
// CREATE EXPENSE
// ------------------------------------------------------------------
const createExpense = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { category, amount, date, recurring, notes, linkedWorkerId, linkedJobId } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!EXPENSE_CATEGORIES.includes(category)) {
            return res.status(400).json({ message: `category must be one of: ${EXPENSE_CATEGORIES.join(', ')}` })
        }
        if (amount === undefined || amount < 0) return res.status(400).json({ message: 'a valid amount is required' })
        if (!date) return res.status(400).json({ message: 'date is required' })

        // Optional links must belong to this org if provided
        if (linkedWorkerId) {
            const { rows } = await db.query(
                'SELECT id FROM workers WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL',
                [linkedWorkerId, organizationId]
            )
            if (rows.length === 0) return res.status(400).json({ message: 'linkedWorkerId does not belong to this organization' })
        }
        if (linkedJobId) {
            const { rows } = await db.query(
                'SELECT id FROM jobs WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL',
                [linkedJobId, organizationId]
            )
            if (rows.length === 0) return res.status(400).json({ message: 'linkedJobId does not belong to this organization' })
        }

        const { rows } = await db.query(
            `INSERT INTO expenses (organization_id, category, amount, date, recurring, notes, linked_worker_id, linked_job_id)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
             RETURNING id, category, amount, date, recurring, notes, linked_worker_id, linked_job_id, created_at`,
            [organizationId, category, amount, date, !!recurring, notes || null, linkedWorkerId || null, linkedJobId || null]
        )
        res.status(201).json({ expense: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create expense' })
    }
}

// ------------------------------------------------------------------
// LIST EXPENSES — filter by category / date range / linked worker or job
// ------------------------------------------------------------------
const listExpenses = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { category, dateFrom, dateTo, linkedWorkerId, linkedJobId } = req.query
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `SELECT id, category, amount, date, recurring, notes, linked_worker_id, linked_job_id, created_at
             FROM expenses
             WHERE organization_id = $1
               AND ($2::varchar IS NULL OR category = $2)
               AND ($3::date IS NULL OR date >= $3)
               AND ($4::date IS NULL OR date <= $4)
               AND ($5::uuid IS NULL OR linked_worker_id = $5)
               AND ($6::uuid IS NULL OR linked_job_id = $6)
             ORDER BY date DESC`,
            [organizationId, category || null, dateFrom || null, dateTo || null, linkedWorkerId || null, linkedJobId || null]
        )
        res.status(200).json({ expenses: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch expenses' })
    }
}

// ------------------------------------------------------------------
// GET EXPENSE
// ------------------------------------------------------------------
const getExpense = async (req, res) => {
    const { organizationId, expenseId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            'SELECT * FROM expenses WHERE id = $1 AND organization_id = $2',
            [expenseId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'expense not found' })
        res.status(200).json({ expense: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch expense' })
    }
}

// ------------------------------------------------------------------
// UPDATE EXPENSE
// ------------------------------------------------------------------
const updateExpense = async (req, res) => {
    const { organizationId, expenseId } = req.params
    const userId = req.user.id
    const { category, amount, date, recurring, notes, linkedWorkerId, linkedJobId } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (category && !EXPENSE_CATEGORIES.includes(category)) {
            return res.status(400).json({ message: `category must be one of: ${EXPENSE_CATEGORIES.join(', ')}` })
        }

        const { rows } = await db.query(
            `UPDATE expenses
             SET category = COALESCE($1, category),
                 amount = COALESCE($2, amount),
                 date = COALESCE($3, date),
                 recurring = COALESCE($4, recurring),
                 notes = COALESCE($5, notes),
                 linked_worker_id = COALESCE($6, linked_worker_id),
                 linked_job_id = COALESCE($7, linked_job_id),
                 updated_at = NOW()
             WHERE id = $8 AND organization_id = $9
             RETURNING id, category, amount, date, recurring, notes, linked_worker_id, linked_job_id`,
            [category, amount, date, recurring, notes, linkedWorkerId, linkedJobId, expenseId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'expense not found' })
        res.status(200).json({ expense: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update expense' })
    }
}

// ------------------------------------------------------------------
// DELETE EXPENSE — hard delete (expenses table has no deleted_at column
// in schema.sql; unlike workers/clients/jobs, there's no soft-delete need
// since expenses aren't referenced by other records the way workers are)
// ------------------------------------------------------------------
const deleteExpense = async (req, res) => {
    const { organizationId, expenseId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            'DELETE FROM expenses WHERE id = $1 AND organization_id = $2 RETURNING id',
            [expenseId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'expense not found' })
        res.status(200).json({ message: 'expense deleted' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not delete expense' })
    }
}

module.exports = { createExpense, listExpenses, getExpense, updateExpense, deleteExpense }
