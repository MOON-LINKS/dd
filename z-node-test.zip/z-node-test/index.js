/*
 * This is now the real index.js, not a reference/delta file — 10.files
 * merges in everything batches 5-9 left unmounted. See BATCH_NOTES.md for
 * what changed and why.
 */

require('dotenv').config()
const express = require('express')
const cookieParser = require('cookie-parser')

const authRoutes = require('./routes/authRoutes')
const organizationRoutes = require('./routes/organizationRoutes')
const workerRoutes = require('./routes/workerRoutes')
const assetRoutes = require('./routes/assetRoutes')
const clientRoutes = require('./routes/clientRoutes')
const { router: jobTemplateRoutes, adminRouter: jobTemplateAdminRoutes } = require('./routes/jobTemplateRoutes')
const jobRoutes = require('./routes/jobRoutes')
const expenseRoutes = require('./routes/expenseRoutes')
const upcomingBillRoutes = require('./routes/upcomingBillRoutes')
const planRoutes = require('./routes/planRoutes')
const paymentRoutes = require('./routes/paymentRoutes')
const webhookRoutes = require('./routes/webhookRoutes')
const invoiceRoutes = require('./routes/invoiceRoutes')
const invoiceCronRoutes = require('./routes/invoiceCronRoutes')
const billReminderCronRoutes = require('./routes/billReminderCronRoutes')
const referralRoutes = require('./routes/referralRoutes')
const bioPageRoutes = require('./routes/bioPageRoutes')
const publicBioPageRoutes = require('./routes/publicBioPageRoutes')

const app = express()

// IMPORTANT — webhookRoutes must be mounted BEFORE express.json(). Stripe's
// signature check needs the exact raw request bytes; webhookRoutes.js applies
// express.raw() itself per-route, but that only works if the global json()
// parser hasn't already consumed the body first. This was previously required
// but never mounted at all — see BATCH_NOTES.md.
app.use('/webhooks', webhookRoutes)

app.use(express.json())
app.use(cookieParser())

app.use('/auth', authRoutes)
app.use('/organizations', organizationRoutes)

// Nested resources: /organizations/:organizationId/...
// mergeParams on each router lets it read :organizationId from this mount.
app.use('/organizations/:organizationId/workers', workerRoutes)
app.use('/organizations/:organizationId/clients', clientRoutes)
app.use('/organizations/:organizationId/job-templates', jobTemplateRoutes)
app.use('/organizations/:organizationId/jobs', jobRoutes)
app.use('/organizations/:organizationId/expenses', expenseRoutes)
app.use('/organizations/:organizationId/upcoming-bills', upcomingBillRoutes)
app.use('/organizations/:organizationId/billing', paymentRoutes)
app.use('/organizations/:organizationId/invoices', invoiceRoutes)
app.use('/organizations/:organizationId/referrals', referralRoutes)
app.use('/referrals', referralRoutes.publicRouter)
app.use('/admin/referrals', referralRoutes.adminRouter)
app.use('/organizations/:organizationId/bio-page', bioPageRoutes)

// Public bio page serving — not org-scoped, not requireAuth, by design
// (spec Section 3's zero-per-visit-cost path). Batch 8 built this but it was
// never mounted — see BATCH_NOTES.md.
app.use('/bio', publicBioPageRoutes)

// NOT org-scoped, NOT requireAuth — see routes/invoiceCronRoutes.js for the
// shared-secret gate. Point your scheduler at POST /cron/generate-monthly-invoices.
app.use('/cron', invoiceCronRoutes)
app.use('/cron', billReminderCronRoutes)
// Not org-scoped — global resources
app.use('/assets', assetRoutes)
app.use('/admin/job-templates', jobTemplateAdminRoutes) // requireAdmin is now applied inside this router's routes
app.use('/plans', planRoutes) // public, no auth — pricing page

app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }))

const PORT = process.env.PORT || 4000
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`))

module.exports = app
