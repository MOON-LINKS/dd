const express = require('express')
const router = express.Router({ mergeParams: true })
const { createExpense, listExpenses, getExpense, updateExpense, deleteExpense } = require('../controllers/expenseController')
const requireAuth = require('../middleware/auth')

router.post('/', requireAuth, createExpense)
router.get('/', requireAuth, listExpenses)
router.get('/:expenseId', requireAuth, getExpense)
router.patch('/:expenseId', requireAuth, updateExpense)
router.delete('/:expenseId', requireAuth, deleteExpense)

module.exports = router
