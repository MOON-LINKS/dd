const express = require('express')
const router = express.Router()
const { stripeWebhook } = require('../controllers/webhookController')
const { appleNotificationWebhook } = require('../controllers/appleController')

// IMPORTANT: this router must be mounted in index.js BEFORE app.use(express.json()).
// Stripe's signature check needs the exact raw request bytes, so express.raw() is
// applied per-route here instead of relying on the global json() parser (by the time
// json() has run, the raw bytes are gone). Apple's payload isn't signed at the
// HTTP-body level (the JWS lives inside the JSON, not the request body itself), so
// its route parses JSON normally — applied locally since this whole router sits
// ahead of the app-wide json() middleware and can't rely on it.
router.post('/stripe', express.raw({ type: 'application/json' }), stripeWebhook)
router.post('/apple', express.json(), appleNotificationWebhook)

module.exports = router
