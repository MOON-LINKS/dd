const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId from parent mount
const {
    createCheckoutSession,
    changePlan,
    cancelSubscription,
    manageBilling,
    registerAppleTransaction
} = require('../controllers/paymentController')
const requireAuth = require('../middleware/auth') // TODO: shared once you provide the real middleware

// Web / Android — Stripe
router.post('/checkout', requireAuth, createCheckoutSession)
router.post('/change-plan', requireAuth, changePlan)
router.post('/cancel', requireAuth, cancelSubscription)
router.post('/portal', requireAuth, manageBilling)

// iOS — Apple IAP
router.post('/apple/register', requireAuth, registerAppleTransaction)

module.exports = router
