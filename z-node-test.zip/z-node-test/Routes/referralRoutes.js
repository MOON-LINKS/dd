const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId
const requireAuth = require('../middleware/auth')
const { requireAdmin } = require('../middleware/auth')

const {
    getMyReferralCode,
    validateReferralCode,
    getReferralEarnings,
    listReferralHistory
} = require('../controllers/referralController')
const { issuePayout, listPendingPayoutBalances } = require('../controllers/referralAdminController')

// Org-scoped, authenticated
router.get('/', requireAuth, getMyReferralCode)
router.get('/earnings', requireAuth, getReferralEarnings)
router.get('/history', requireAuth, listReferralHistory)

module.exports = router

// ------------------------------------------------------------------
// Two more routers below, exported separately — mount both in index.js
// (see index.js delta in this batch). They're NOT nested under
// /organizations/:organizationId, unlike the router above.
// ------------------------------------------------------------------

const publicRouter = express.Router()
publicRouter.get('/validate', validateReferralCode) // GET /referrals/validate?code=XYZ — public, no auth
module.exports.publicRouter = publicRouter

const adminRouter = express.Router()
adminRouter.post('/payouts', requireAuth, requireAdmin, issuePayout)              // POST /admin/referrals/payouts
adminRouter.get('/payouts/pending', requireAuth, requireAdmin, listPendingPayoutBalances)
module.exports.adminRouter = adminRouter
