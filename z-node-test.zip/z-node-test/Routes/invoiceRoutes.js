const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId
const requireAuth = require('../middleware/auth')

const {
    generateInvoicesNow,
    listInvoices,
    getInvoice,
    recordPayment,
    generateInvoicePdf,
    sendInvoiceEmail,
    resendInvoiceEmail
} = require('../controllers/invoiceController')
const { getInvoiceAnalytics } = require('../controllers/invoiceAnalyticsController')
const { getInvoiceBranding, updateInvoiceBranding } = require('../controllers/invoiceBrandingController')
const { listEmailLog } = require('../controllers/emailLogController')

// Invoices (analytics) tab — the flat list + individual invoices
router.get('/', requireAuth, listInvoices)
router.post('/generate', requireAuth, generateInvoicesNow)
router.get('/analytics', requireAuth, getInvoiceAnalytics)
router.get('/:invoiceId', requireAuth, getInvoice)
router.patch('/:invoiceId/payment', requireAuth, recordPayment)
router.post('/:invoiceId/pdf', requireAuth, generateInvoicePdf)
router.post('/:invoiceId/send', requireAuth, sendInvoiceEmail)
router.post('/:invoiceId/resend', requireAuth, resendInvoiceEmail)

// Design tab
router.get('/branding/design', requireAuth, getInvoiceBranding)
router.patch('/branding/design', requireAuth, updateInvoiceBranding)

// History tab
router.get('/history/log', requireAuth, listEmailLog)

module.exports = router
