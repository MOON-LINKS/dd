const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId from parent mount
const {
    createClient,
    listClients,
    getClient,
    updateClient,
    deleteClient,
    addClientFeedback,
    listClientFeedback
} = require('../controllers/clientController')
const requireAuth = require('../middleware/auth') // TODO: shared once you provide the real middleware

router.post('/', requireAuth, createClient)
router.get('/', requireAuth, listClients)
router.get('/:clientId', requireAuth, getClient)
router.patch('/:clientId', requireAuth, updateClient)
router.delete('/:clientId', requireAuth, deleteClient)
router.post('/:clientId/feedback', requireAuth, addClientFeedback)
router.get('/:clientId/feedback', requireAuth, listClientFeedback)

module.exports = router
