const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId from parent mount
const {
    createJob,
    listJobs,
    updateJob,
    postponeJob,
    deleteJob,
    getJobSnapshot,
    saveJobSnapshot
} = require('../controllers/jobController')
const requireAuth = require('../middleware/auth') // TODO: shared once you provide the real middleware

router.post('/', requireAuth, createJob)
router.get('/', requireAuth, listJobs)
router.patch('/:jobId', requireAuth, updateJob)
router.patch('/:jobId/postpone', requireAuth, postponeJob)
router.delete('/:jobId', requireAuth, deleteJob)
router.get('/:jobId/snapshot', requireAuth, getJobSnapshot)
router.put('/:jobId/snapshot', requireAuth, saveJobSnapshot)

module.exports = router
