const express = require('express')
const router = express.Router()
const { listPlans } = require('../controllers/planController')

// Public — no requireAuth. This is what a pricing page calls before signup.
router.get('/', listPlans)

module.exports = router
