const express = require('express')
const router = express.Router()
const { runMonthlyInvoiceGeneration } = require('../controllers/invoiceCronController')

// No logged-in user calls this — it's meant to be hit by your scheduler
// (cron, a hosting provider's "scheduled function," GitHub Actions on a
// schedule, whatever you're using). Gated by a shared secret instead of
// requireAuth since there's no user session to check.
const requireCronSecret = (req, res, next) => {
    const provided = req.headers['x-cron-secret']
    if (!process.env.CRON_SECRET) {
        console.error('CRON_SECRET is not set — refusing all cron requests until it is.')
        return res.status(503).json({ message: 'cron endpoint not configured' })
    }
    if (provided !== process.env.CRON_SECRET) {
        return res.status(401).json({ message: 'invalid cron secret' })
    }
    next()
}

router.post('/generate-monthly-invoices', requireCronSecret, runMonthlyInvoiceGeneration)

module.exports = router
