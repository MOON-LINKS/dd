const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId
const { listJobTemplates, createJobTemplate, updateJobTemplate } = require('../controllers/jobTemplateController')
const requireAuth = require('../middleware/auth')
const { requireAdmin } = require('../middleware/auth')

// Manager-facing — filtered by the org's industry inside the controller
router.get('/', requireAuth, listJobTemplates)

// Internal/admin only in v1 — spec Section 3 says not exposed to managers.
// requireAdmin exists as of batch 6 — applied below. These two are mounted
// separately (not nested under :organizationId) since templates aren't org-scoped.
const adminRouter = express.Router()
adminRouter.post('/', requireAuth, requireAdmin, createJobTemplate)
adminRouter.patch('/:templateId', requireAuth, requireAdmin, updateJobTemplate)

module.exports = { router, adminRouter }
