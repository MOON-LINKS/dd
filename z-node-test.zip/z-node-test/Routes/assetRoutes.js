const express = require('express')
const router = express.Router()
const upload = require('../middleware/upload')
const { uploadAsset, deleteAsset } = require('../controllers/assetController')
const requireAuth = require('../middleware/auth') // TODO: shared once you provide the real middleware

router.post('/', requireAuth, upload.single('file'), uploadAsset)
router.delete('/:assetId', requireAuth, deleteAsset)

module.exports = router
