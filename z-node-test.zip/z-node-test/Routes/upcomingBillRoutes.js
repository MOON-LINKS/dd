const express = require('express')
const router = express.Router({ mergeParams: true })
const {
    createUpcomingBill,
    listUpcomingBills,
    getUpcomingBill,
    updateUpcomingBill,
    deleteUpcomingBill,
    markBillPaid,
    convertBillToExpense
} = require('../controllers/upcomingBillController')
const requireAuth = require('../middleware/auth')

router.post('/', requireAuth, createUpcomingBill)
router.get('/', requireAuth, listUpcomingBills)
router.get('/:billId', requireAuth, getUpcomingBill)
router.patch('/:billId', requireAuth, updateUpcomingBill)
router.delete('/:billId', requireAuth, deleteUpcomingBill)
router.patch('/:billId/mark-paid', requireAuth, markBillPaid)
router.post('/:billId/convert-to-expense', requireAuth, convertBillToExpense)

module.exports = router
