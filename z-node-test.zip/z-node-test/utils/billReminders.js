const db = require('../utils/db')
const { sendMail } = require('./mailer')
const { billReminderEmail } = require('./emailTemplates')

// ------------------------------------------------------------------
// This was the one open item left at the end of batch 9 — "blocked on
// formalizing the recurring-interval fields." That field already existed
// (upcoming_bills.reminder_days_before, per-bill, default 7) since the base
// schema — the actual blocker was never the interval itself, just that
// nobody had written the cron/worker that reads it. This is that worker.
//
// Fires a reminder exactly once, on the day `due_date - reminder_days_before`
// equals today — not "every day until paid" and not "on due_date itself"
// (that's what reminder_days_before is *for*: it's the lead time the manager
// chose per bill). Unpaid bills only; a bill marked paid or converted to an
// expense stops generating reminders same-day since is_paid flips to TRUE.
//
// Idempotent the same way invoiceGeneration.js is idempotent, just against
// email_log instead of job_days: a bill is skipped if a 'bill_reminder' row
// already exists in email_log for it with today's date, so re-running this
// same day (a retried cron trigger, a scheduler double-fire) never sends the
// same reminder twice. There is no separate "already reminded" flag on
// upcoming_bills — email_log is the source of truth for that, matching how
// batch 7 designed it to also back "the upcoming-bill-reminder history
// mentioned in the same paragraph, once sendBillReminders is built."
// ------------------------------------------------------------------
const sendBillReminders = async () => {
    const { rows: dueBills } = await db.query(
        `SELECT b.id, b.title, b.amount, b.due_date,
                o.id AS organization_id, o.name AS organization_name, o.owner_user_id
         FROM upcoming_bills b
         JOIN organizations o ON o.id = b.organization_id AND o.deleted_at IS NULL
         WHERE b.is_paid = FALSE
           AND b.due_date - b.reminder_days_before = CURRENT_DATE
           AND NOT EXISTS (
               SELECT 1 FROM email_log e
               WHERE e.email_type = 'bill_reminder'
                 AND e.reference_id = b.id
                 AND e.sent_at::date = CURRENT_DATE
           )`
    )

    const results = []
    for (const bill of dueBills) {
        try {
            const { rows: ownerRows } = await db.query('SELECT email FROM users WHERE id = $1', [bill.owner_user_id])
            const recipientEmail = ownerRows[0]?.email
            if (!recipientEmail) {
                results.push({ billId: bill.id, status: 'skipped', reason: 'organization owner email not found' })
                continue
            }

            const { subject, text, html } = billReminderEmail({
                organizationName: bill.organization_name,
                title: bill.title,
                amount: Number(bill.amount).toFixed(2),
                dueDate: bill.due_date
            })

            let status = 'sent'
            let errorMessage = null
            try {
                await sendMail({ to: recipientEmail, subject, text, html })
            } catch (err) {
                status = 'failed'
                errorMessage = err.message
            }

            await db.query(
                `INSERT INTO email_log (organization_id, email_type, reference_id, recipient_email, subject, status, error_message)
                 VALUES ($1, 'bill_reminder', $2, $3, $4, $5, $6)`,
                [bill.organization_id, bill.id, recipientEmail, subject, status, errorMessage]
            )

            results.push({ billId: bill.id, organizationId: bill.organization_id, status })
        } catch (err) {
            // One bill's failure (bad data, a transient DB error) shouldn't
            // block every other org's reminder from going out — same pattern
            // invoiceCronController.js uses per-organization.
            console.error(`Bill reminder failed for bill ${bill.id}:`, err)
            results.push({ billId: bill.id, status: 'error', error: err.message })
        }
    }

    return results
}

module.exports = { sendBillReminders }
