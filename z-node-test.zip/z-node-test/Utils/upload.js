const multer = require('multer')

// Memory storage: sharp reads directly from the buffer, nothing touches
// disk until after resize/compress. 8MB cap covers the largest expected
// upload (bill/invoice photos); presets below downsize well under that.
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 8 * 1024 * 1024 }
})

module.exports = upload
