const { createClient } = require('redis')

const redisClient = createClient({
    url: process.env.REDIS_URL
})

redisClient.on('error', (err) => console.error('Redis client error', err))

;(async () => {
    if (!redisClient.isOpen) await redisClient.connect()
})()

module.exports = { redisClient }
