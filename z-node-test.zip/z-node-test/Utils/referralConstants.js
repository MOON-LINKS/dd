// Business parameters for the referral program — isolated here since
// these are the numbers most likely to change as the model gets tuned
// (spec Section 3/13: reward mechanism was explicitly "decided later").

// What a NEW user gets on their first checkout when they enter a valid
// referral code. Matches referral_codes.discount_pct's default (10) — kept
// as a constant here too since it's what gets requested from Stripe as a
// coupon percent_off at checkout time, independent of the DB default.
const REFERRAL_SIGNUP_DISCOUNT_PCT = 10

// What the REFERRING org earns, as a fraction of every payment the
// referred org makes — this is the "$200 referred -> $50 earned" rate you
// described (50/200 = 0.25), applied to every invoice, not just the first.
const REFERRAL_COMMISSION_RATE = 0.25

// Admin payout endpoint blocks issuing a payout below this by default
// (can be overridden per-request) — avoids trivial $1 payout admin actions.
const MIN_PAYOUT_CENTS = 5000 // $50.00

module.exports = { REFERRAL_SIGNUP_DISCOUNT_PCT, REFERRAL_COMMISSION_RATE, MIN_PAYOUT_CENTS }
