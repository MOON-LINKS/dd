// Wraps Apple's own @apple/app-store-server-library instead of hand-rolling
// JWS/X.509 chain verification. Don't verify Apple's signed payloads
// yourself with a generic JWT library — this library is what Apple publishes
// specifically to do that correctly (chain validation against their root CAs,
// revocation checks, environment matching), and it's what the notification
// and transaction payload shapes below assume.
//
// Setup required before this file works:
//   npm install @apple/app-store-server-library --save
//
//   1. Download the Apple Root CA certificates (.cer files) from
//      https://www.apple.com/certificateauthority/ ("Apple Root Certificates"
//      section) and place them in ./certs/ next to this file.
//   2. Set these env vars:
//        APPLE_BUNDLE_ID        — e.g. com.yourcompany.yourapp
//        APPLE_APP_APPLE_ID     — numeric App Store Connect app ID (production only)
//        APPLE_ENVIRONMENT      — "sandbox" | "production"
//
// This file only covers verifying signed data Apple sends you (transactions
// and server notifications). It does NOT cover the App Store Server API
// (fetching transaction history, issuing refunds, etc.) — add
// AppStoreServerAPIClient from the same package if/when that's needed.

const fs = require('fs')
const path = require('path')
const { SignedDataVerifier, Environment } = require('@apple/app-store-server-library')

const CERTS_DIR = path.join(__dirname, '..', 'certs')

const loadRootCAs = () => {
    if (!fs.existsSync(CERTS_DIR)) {
        throw new Error(`Apple root CA cert directory not found at ${CERTS_DIR} — see setup notes at the top of appleIAP.js`)
    }
    const files = fs.readdirSync(CERTS_DIR).filter((f) => f.endsWith('.cer'))
    if (files.length === 0) {
        throw new Error(`No .cer files found in ${CERTS_DIR} — download Apple's root certificates first, see setup notes at the top of appleIAP.js`)
    }
    return files.map((f) => fs.readFileSync(path.join(CERTS_DIR, f)))
}

const environment = process.env.APPLE_ENVIRONMENT === 'production'
    ? Environment.PRODUCTION
    : Environment.SANDBOX

// Lazily constructed so a missing cert directory doesn't crash the whole
// server on boot — only requests that actually touch Apple IAP fail, with a
// clear error, until the certs are in place.
let verifier = null
const getVerifier = () => {
    if (!verifier) {
        verifier = new SignedDataVerifier(
            loadRootCAs(),
            true, // enableOnlineChecks — lets the library hit Apple's OCSP endpoint for revocation checks
            environment,
            process.env.APPLE_BUNDLE_ID,
            process.env.APPLE_APP_APPLE_ID ? parseInt(process.env.APPLE_APP_APPLE_ID, 10) : undefined
        )
    }
    return verifier
}

// signedTransactionInfo — the JWS string the iOS client hands the backend
// right after a StoreKit 2 purchase completes. Returns the decoded
// JWSTransactionDecodedPayload (originalTransactionId, productId,
// expiresDate, purchaseDate, price, currency, environment, etc.)
const verifyTransaction = async (signedTransactionInfo) => {
    return getVerifier().verifyAndDecodeTransaction(signedTransactionInfo)
}

// signedPayload — the top-level body Apple posts to the App Store Server
// Notifications V2 webhook. Returns the decoded ResponseBodyV2DecodedPayload
// (notificationType, subtype, and nested signed data still needing decode —
// see notificationController for how the nested transaction/renewal info is
// unwrapped separately).
const verifyNotification = async (signedPayload) => {
    return getVerifier().verifyAndDecodeNotification(signedPayload)
}

// signedRenewalInfo — nested inside a decoded notification's `data` object,
// separate JWS string from signedTransactionInfo. Carries autoRenewStatus,
// autoRenewProductId, etc.
const verifyRenewalInfo = async (signedRenewalInfo) => {
    return getVerifier().verifyAndDecodeRenewalInfo(signedRenewalInfo)
}

module.exports = { verifyTransaction, verifyNotification, verifyRenewalInfo }
