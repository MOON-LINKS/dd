// Section 9: "Store only the relative filename/path in the database... Serve
// via CDN... the CDN base URL is prefixed at render time in code, not stored
// in the database." No shared helper existed for this yet — every consumer
// (invoice emails, invoice PDFs, and eventually worker photos / bio pages /
// bill proofs once those responses need full URLs too) can use this one
// instead of re-hardcoding the prefix.
const resolveAssetUrl = (filename) => {
    if (!filename) return null
    const base = process.env.CDN_BASE_URL || 'https://cdn.mydomain.com/imgs'
    return `${base.replace(/\/$/, '')}/${filename}`
}

module.exports = { resolveAssetUrl }
