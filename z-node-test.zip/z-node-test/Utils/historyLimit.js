const db = require('../utils/db')

// Section 9: "the frontend reading plan features is for UX only — every
// backend endpoint that touches a plan-limited action must independently
// verify the org's plan server-side." history_months is exactly this kind
// of limit (Section 9 / plans table) and wasn't enforced anywhere yet — this
// is the first place it's wired in.
//
// Returns { allowed: true } or { allowed: false, earliestAllowedDate, message }.
// Caller passes the earliest date the request is asking for (e.g. a
// `startDate` query param); this only checks how far BACK the request
// reaches, not the end of the range.
const checkHistoryLimit = async (organizationId, requestedStartDate) => {
    const { rows } = await db.query(
        `SELECT p.history_months
         FROM organizations o
         LEFT JOIN plans p ON p.plan_id = o.plan_id
         WHERE o.id = $1`,
        [organizationId]
    )
    if (rows.length === 0) {
        return { allowed: false, message: 'organization not found' }
    }

    // No plan set yet (pre-payment, or between cancellation and resubscribe):
    // default to "current month only" rather than fully blocking or fully
    // allowing — neither is specified for this edge case, this is the
    // conservative middle ground. Revisit if pre-payment invoice access
    // needs its own defined behavior.
    const historyMonths = rows[0].history_months != null ? rows[0].history_months : 1

    const earliestAllowedDate = new Date()
    earliestAllowedDate.setMonth(earliestAllowedDate.getMonth() - historyMonths)
    earliestAllowedDate.setHours(0, 0, 0, 0)

    const requested = new Date(requestedStartDate)
    if (requested < earliestAllowedDate) {
        return {
            allowed: false,
            earliestAllowedDate,
            message: `your plan only allows viewing the last ${historyMonths} month(s) of history`
        }
    }
    return { allowed: true }
}

module.exports = { checkHistoryLimit }
