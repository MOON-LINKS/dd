const PDFDocument = require('pdfkit')

// Builds the invoice PDF in memory and resolves with a Buffer — caller
// decides where it ends up (disk, S3, straight into an email attachment).
// No network/font-loading dependency beyond pdfkit's bundled Helvetica, so
// this works the same in any environment without extra setup.
//
// branding: { primaryColor, secondaryColor, logoUrl } — logoUrl is expected
// to already be a fully-resolved URL (CDN base + assets.filename), not a
// bare filename; resolving that prefix is the caller's job per Section 9's
// "CDN base URL is prefixed at render time in code, not stored in the DB."
const buildInvoicePdfBuffer = async ({ organization, client, invoice, lineItems, branding }) => {
    // Fetched outside the pdfkit Promise on purpose: a failed/slow logo fetch
    // should degrade to "no logo" rather than fail the whole PDF or leave the
    // pdfkit stream half-written. Uses the platform's built-in fetch (Node 18+).
    let logoBuffer = null
    if (branding?.logoUrl) {
        try {
            const response = await fetch(branding.logoUrl)
            if (response.ok) logoBuffer = Buffer.from(await response.arrayBuffer())
        } catch (err) {
            console.error('Invoice PDF: logo fetch failed, continuing without it:', err.message)
        }
    }

    return new Promise((resolve, reject) => {
        const doc = new PDFDocument({ size: 'A4', margin: 50 })
        const chunks = []
        doc.on('data', (chunk) => chunks.push(chunk))
        doc.on('end', () => resolve(Buffer.concat(chunks)))
        doc.on('error', reject)

        const primary = branding?.primaryColor || '#1D9E75'
        const secondary = branding?.secondaryColor || '#0F6E56'

        // ---- Header band ----
        doc.rect(0, 0, doc.page.width, 90).fill(primary)
        doc.fillColor('#FFFFFF').fontSize(22).font('Helvetica-Bold')
            .text(organization.name || 'Invoice', 50, 30)
        doc.fontSize(10).font('Helvetica')
            .text(`Invoice period: ${invoice.period_start} to ${invoice.period_end}`, 50, 60)
        doc.fillColor('#000000')

        if (logoBuffer) {
            try {
                doc.image(logoBuffer, doc.page.width - 120, 20, { fit: [70, 50] })
            } catch (err) {
                // Malformed/unsupported image format — same degrade-gracefully
                // rule as the fetch failure above, just caught later since
                // pdfkit only validates the buffer once it tries to decode it.
                console.error('Invoice PDF: logo embed failed, continuing without it:', err.message)
            }
        }

        doc.moveDown(4)

        // ---- Bill-to / meta ----
        const metaTop = 120
        doc.fontSize(11).font('Helvetica-Bold').text('Billed to', 50, metaTop)
        doc.font('Helvetica').fontSize(10)
            .text(client?.name || 'Unknown client', 50, metaTop + 16)
        if (client?.email) doc.text(client.email, 50, metaTop + 30)
        if (client?.phone) doc.text(client.phone, 50, metaTop + 44)

        doc.font('Helvetica-Bold').fontSize(11).text('Invoice', 350, metaTop)
        doc.font('Helvetica').fontSize(10)
            .text(`ID: ${invoice.id}`, 350, metaTop + 16)
            .text(`Generated: ${new Date(invoice.created_at).toISOString().slice(0, 10)}`, 350, metaTop + 30)
            .text(invoice.sent_at ? `Sent: ${new Date(invoice.sent_at).toISOString().slice(0, 10)}` : 'Not yet sent', 350, metaTop + 44)

        // ---- Line items table ----
        let y = metaTop + 90
        doc.rect(50, y, 495, 22).fill(secondary)
        doc.fillColor('#FFFFFF').fontSize(9).font('Helvetica-Bold')
        doc.text('Description', 56, y + 6, { width: 260 })
        doc.text('Hours', 320, y + 6, { width: 50, align: 'right' })
        doc.text('Rate', 375, y + 6, { width: 60, align: 'right' })
        doc.text('Amount', 445, y + 6, { width: 90, align: 'right' })
        doc.fillColor('#000000')
        y += 22

        doc.font('Helvetica').fontSize(9)
        for (const item of lineItems) {
            if (y > doc.page.height - 120) {
                doc.addPage()
                y = 50
            }
            doc.text(item.description, 56, y + 6, { width: 260 })
            doc.text(item.hours != null ? String(item.hours) : '—', 320, y + 6, { width: 50, align: 'right' })
            doc.text(item.rate != null ? `$${Number(item.rate).toFixed(2)}` : '—', 375, y + 6, { width: 60, align: 'right' })
            doc.text(item.amount != null ? `$${Number(item.amount).toFixed(2)}` : '—', 445, y + 6, { width: 90, align: 'right' })
            doc.moveTo(50, y + 24).lineTo(545, y + 24).strokeColor('#E5E5E5').stroke()
            y += 26
        }

        // ---- Totals ----
        y += 20
        if (y > doc.page.height - 140) {
            doc.addPage()
            y = 50
        }
        const totalsX = 350
        doc.font('Helvetica').fontSize(10)
        doc.text('Total hours', totalsX, y, { width: 100 })
        doc.text(String(invoice.total_hours), totalsX + 100, y, { width: 95, align: 'right' })
        y += 18
        doc.text('Total amount', totalsX, y, { width: 100 })
        doc.text(`$${Number(invoice.total_amount).toFixed(2)}`, totalsX + 100, y, { width: 95, align: 'right' })
        y += 18
        doc.text('Amount paid', totalsX, y, { width: 100 })
        doc.text(`$${Number(invoice.amount_paid).toFixed(2)}`, totalsX + 100, y, { width: 95, align: 'right' })
        y += 18
        doc.font('Helvetica-Bold')
        doc.text('Amount owed', totalsX, y, { width: 100 })
        doc.text(`$${Number(invoice.amount_owed).toFixed(2)}`, totalsX + 100, y, { width: 95, align: 'right' })

        doc.end()
    })
}

module.exports = { buildInvoicePdfBuffer }
