// ------------------------------------------------------------------
// Money-model note (flagged, not hidden): schema.sql has no client-facing
// billing rate anywhere — only workers.hourly_rate (what the ORG pays the
// WORKER) and workers.monthly_amount (a fixed salary, not tied to any job).
// There is no markup/margin field. So "amount owed" on a client invoice is
// built the only way the schema unambiguously supports: hourly workers'
// hours × hourly_rate, summed per client. This is effectively cost-plus-zero
// billing (the client is charged exactly what the org pays the worker) —
// worth confirming that's actually the intended business model before this
// goes live, since Section 13's open question ("define exact invoice PDF
// layout/fields") never nailed this down. See BATCH_NOTES.md.
//
// monthly_amount workers contribute hours to the invoice (spec: "hours are
// ALWAYS logged, regardless of pay type") but contribute $0 to total_amount,
// since their pay isn't tied to any specific job/client — their line item is
// hours-for-reference only. rate/amount are NULL on that line rather than 0,
// so a report can distinguish "billed at $0" from "not billable."
// ------------------------------------------------------------------

const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100

// Generates (at most) one invoice per client for the given organization and
// date range, from every not-yet-invoiced job_day in range. Idempotent by
// construction: job_days.invoiced=TRUE excludes a day from every future run,
// so re-running with an overlapping range never double-bills a day — no
// separate "does an invoice already exist for this period" check is needed.
//
// Must run inside a transaction the caller owns (pass a checked-out client),
// so a partial failure across multiple clients-of-the-org can't leave some
// job_days marked invoiced without a matching invoice row.
const generateInvoicesForOrganization = async (dbClient, organizationId, periodStart, periodEnd) => {
    const { rows } = await dbClient.query(
        `SELECT jd.id AS job_day_id, j.id AS job_id, j.title AS job_title, j.client_id,
                da.worker_id, da.hours, w.name AS worker_name, w.pay_type, w.hourly_rate
         FROM job_days jd
         JOIN jobs j ON j.id = jd.job_id AND j.deleted_at IS NULL
         JOIN day_assignments da ON da.job_day_id = jd.id
         JOIN workers w ON w.id = da.worker_id
         WHERE j.organization_id = $1
           AND jd.date BETWEEN $2 AND $3
           AND jd.invoiced = FALSE
           AND j.client_id IS NOT NULL
         ORDER BY j.client_id, j.id, w.id`,
        [organizationId, periodStart, periodEnd]
    )

    if (rows.length === 0) {
        return { invoices: [], skippedReason: 'no un-invoiced job days with a client in this period' }
    }

    // Group by client -> (job_id, worker_id) -> summed hours/amount
    const byClient = new Map()
    for (const row of rows) {
        if (!byClient.has(row.client_id)) byClient.set(row.client_id, { lines: new Map(), jobDayIds: new Set() })
        const clientGroup = byClient.get(row.client_id)
        clientGroup.jobDayIds.add(row.job_day_id)

        const lineKey = `${row.job_id}:${row.worker_id}`
        if (!clientGroup.lines.has(lineKey)) {
            clientGroup.lines.set(lineKey, {
                jobId: row.job_id,
                jobTitle: row.job_title,
                workerId: row.worker_id,
                workerName: row.worker_name,
                payType: row.pay_type,
                hourlyRate: row.hourly_rate != null ? parseFloat(row.hourly_rate) : null,
                hours: 0
            })
        }
        clientGroup.lines.get(lineKey).hours += parseFloat(row.hours)
    }

    const createdInvoices = []

    for (const [clientId, group] of byClient.entries()) {
        let totalHours = 0
        let totalAmount = 0
        const lineItemsToInsert = []

        for (const line of group.lines.values()) {
            const hours = round2(line.hours)
            totalHours += hours

            const isHourly = line.payType === 'hourly' && line.hourlyRate != null
            const amount = isHourly ? round2(hours * line.hourlyRate) : 0
            if (isHourly) totalAmount += amount

            lineItemsToInsert.push({
                workerId: line.workerId,
                jobId: line.jobId,
                description: isHourly
                    ? `${line.jobTitle} — ${line.workerName}`
                    : `${line.jobTitle} — ${line.workerName} (salaried; hours for reference only)`,
                hours,
                rate: isHourly ? line.hourlyRate : null,
                amount: isHourly ? amount : null
            })
        }

        totalHours = round2(totalHours)
        totalAmount = round2(totalAmount)

        const { rows: invoiceRows } = await dbClient.query(
            `INSERT INTO invoices (organization_id, client_id, period_start, period_end, total_hours, total_amount, amount_paid)
             VALUES ($1, $2, $3, $4, $5, $6, 0)
             RETURNING id, organization_id, client_id, period_start, period_end, total_hours, total_amount, amount_paid, amount_owed, created_at`,
            [organizationId, clientId, periodStart, periodEnd, totalHours, totalAmount]
        )
        const invoice = invoiceRows[0]

        for (const item of lineItemsToInsert) {
            await dbClient.query(
                `INSERT INTO invoice_line_items (invoice_id, worker_id, job_id, description, hours, rate, amount)
                 VALUES ($1, $2, $3, $4, $5, $6, $7)`,
                [invoice.id, item.workerId, item.jobId, item.description, item.hours, item.rate, item.amount]
            )
        }

        const jobDayIds = [...group.jobDayIds]
        await dbClient.query(
            `UPDATE job_days SET invoiced = TRUE WHERE id = ANY($1::uuid[])`,
            [jobDayIds]
        )

        createdInvoices.push(invoice)
    }

    return { invoices: createdInvoices }
}

// Previous full calendar month, in UTC — the default period for both the
// manual-trigger and cron entrypoints when no explicit range is given.
const previousCalendarMonth = () => {
    const now = new Date()
    const firstOfThisMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1))
    const periodEnd = new Date(firstOfThisMonth.getTime() - 1) // last millisecond of previous month
    const periodStart = new Date(Date.UTC(periodEnd.getUTCFullYear(), periodEnd.getUTCMonth(), 1))
    const toDateString = (d) => d.toISOString().slice(0, 10)
    return { periodStart: toDateString(periodStart), periodEnd: toDateString(periodEnd) }
}

module.exports = { generateInvoicesForOrganization, previousCalendarMonth, round2 }
