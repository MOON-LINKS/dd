const { Pool } = require('pg')

const db = new Pool({
    connectionString: process.env.DATABASE_URL,
    // SSL required by most managed Postgres providers (RDS, Supabase, etc.) in production
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
})

db.on('error', (err) => {
    console.error('Unexpected Postgres pool error', err)
})

module.exports = db
