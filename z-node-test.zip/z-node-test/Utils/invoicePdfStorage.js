const fs = require('fs')
const path = require('path')
const db = require('../utils/db')

// Mirrors assetController.js's storage convention exactly (same ASSETS_ROOT,
// same {organizationId}/{ownerType}/{file} layout, same "store relative
// filename only" rule from Section 9) so invoice PDFs show up alongside
// every other asset type rather than living in a separate storage scheme.
const ASSETS_ROOT = path.join(__dirname, '..', 'assets_storage')

// Requires 'invoice' to be added to ASSET_OWNER_TYPES in utils/constants.js —
// see BATCH_NOTES.md for the one-line patch. Not editing that file directly
// here since it's shared across every other module's asset uploads too.
const storeInvoicePdf = async (organizationId, invoiceId, pdfBuffer) => {
    const orgFolder = path.join(ASSETS_ROOT, organizationId, 'invoice')
    if (!fs.existsSync(orgFolder)) fs.mkdirSync(orgFolder, { recursive: true })

    const fileName = `invoice-${invoiceId}-${Date.now()}.pdf`
    const filePath = path.join(orgFolder, fileName)
    fs.writeFileSync(filePath, pdfBuffer)

    const relativeFilename = `${organizationId}/invoice/${fileName}`

    const { rows } = await db.query(
        `INSERT INTO assets (owner_type, owner_id, filename, mime_type)
         VALUES ('invoice', $1, $2, 'application/pdf')
         RETURNING id, filename`,
        [invoiceId, relativeFilename]
    )
    return rows[0]
}

module.exports = { storeInvoicePdf }
