const Stripe = require('stripe')

// Pin the API version explicitly rather than relying on the account default,
// so a dashboard-side default bump can't silently change response shapes
// under this code. Bump this deliberately when you're ready to test against
// a newer version.
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: '2026-06-24.dahlia'
})

module.exports = stripe
