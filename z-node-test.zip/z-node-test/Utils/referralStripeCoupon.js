const stripe = require('./stripeClient')

// One reusable Stripe Coupon for the referral signup discount, rather than
// minting a new Coupon object on every checkout. A deterministic custom ID
// means "already exists" from a previous call is the expected/safe outcome,
// not an error path to work around.
const REFERRAL_COUPON_ID = 'referral-signup-discount'

const getOrCreateReferralCoupon = async (percentOff) => {
    try {
        return (await stripe.coupons.retrieve(REFERRAL_COUPON_ID)).id
    } catch (err) {
        if (err.code !== 'resource_missing') throw err
    }
    const coupon = await stripe.coupons.create({
        id: REFERRAL_COUPON_ID,
        percent_off: percentOff,
        duration: 'once' // applies to the first invoice only, per spec ("first payment / year or /month")
    })
    return coupon.id
}

module.exports = { getOrCreateReferralCoupon }
