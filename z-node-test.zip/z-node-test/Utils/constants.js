// Target verticals from spec Section 1. Extensible — see the localization
// fallback pattern in Section 6 (default_{fieldKey}) for how new types launch
// safely before their custom wording is written.
const ORGANIZATION_TYPES = [
    'construction',
    'tutoring',
    'gym',
    'contractor',
    'sales',
    'cleaning'
]

// Polymorphic owner_type values used by the assets table and asset uploads.
// 'invoice' added per batch 7 — generated invoice PDFs are stored as ordinary
// assets rows (owner_type='invoice'); without this, invoicePdfStorage.js's
// inserts would be the only 'invoice' rows the app itself never validates.
const ASSET_OWNER_TYPES = ['organization', 'worker', 'bio_page', 'upcoming_bill', 'invoice']

// Curated color presets for the Bio Page builder (spec Section 3: "curated/
// gathered color pattern presets user can pick from" — deliberately not a
// raw hex picker). Add new presets here anytime; bioPageRenderer.js reads
// whichever key is stored in bio_pages.color_preset and falls back to
// 'default' if the stored key is ever missing/renamed. Merged in from batch 8.
const BIO_PAGE_COLOR_PRESETS = {
    default:  { primary: '#1D9E75', secondary: '#0F6E56', background: '#FFFFFF', text: '#1A1A1A' },
    midnight: { primary: '#4F46E5', secondary: '#312E81', background: '#0B1020', text: '#F5F5F5' },
    sunset:   { primary: '#F97316', secondary: '#EA580C', background: '#FFF7ED', text: '#1A1A1A' },
    rose:     { primary: '#DB2777', secondary: '#9D174D', background: '#FFF1F5', text: '#1A1A1A' },
    ocean:    { primary: '#0891B2', secondary: '#075985', background: '#F0FDFF', text: '#1A1A1A' }
}

module.exports = { ORGANIZATION_TYPES, ASSET_OWNER_TYPES, BIO_PAGE_COLOR_PRESETS }
