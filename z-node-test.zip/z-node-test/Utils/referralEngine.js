const db = require('../utils/db')
const { REFERRAL_SIGNUP_DISCOUNT_PCT, REFERRAL_COMMISSION_RATE } = require('./referralConstants')

const sanitizeNamePrefix = (name) => {
    const letters = (name || '').replace(/[^a-zA-Z]/g, '').toUpperCase()
    return letters.slice(0, 10) || 'USER'
}

const randomSuffix = () => String(Math.floor(1000 + Math.random() * 9000)) // 4 digits

// ------------------------------------------------------------------
// ENSURE REFERRAL CODE — creates the org's code lazily, on their FIRST
// successful payment (called from the checkout.session.completed webhook
// patch below), not at registration. If a code already exists (every
// payment after the first), this is a no-op. Retries on the rare unique
// collision instead of trusting randomness alone.
// ------------------------------------------------------------------
const ensureReferralCodeForOrganization = async (dbClient, organizationId) => {
    const { rows: existing } = await dbClient.query(
        'SELECT code FROM referral_codes WHERE organization_id = $1',
        [organizationId]
    )
    if (existing.length > 0) return existing[0].code

    const { rows: ownerRows } = await dbClient.query(
        `SELECT u.full_name FROM organizations o JOIN users u ON u.id = o.owner_user_id WHERE o.id = $1`,
        [organizationId]
    )
    const prefix = sanitizeNamePrefix(ownerRows[0]?.full_name)

    for (let attempt = 0; attempt < 5; attempt++) {
        const code = `${prefix}${randomSuffix()}`
        try {
            await dbClient.query(
                'INSERT INTO referral_codes (organization_id, code, discount_pct) VALUES ($1, $2, $3)',
                [organizationId, code, REFERRAL_SIGNUP_DISCOUNT_PCT]
            )
            return code
        } catch (err) {
            if (err.code === '23505') continue // unique_violation on `code` — retry with a new suffix
            throw err
        }
    }
    throw new Error('could not generate a unique referral code after 5 attempts')
}

// ------------------------------------------------------------------
// VALIDATE — used both by the public validate endpoint (live-check in
// the new-signup UI) and internally at checkout time.
// ------------------------------------------------------------------
const validateReferralCodeValue = async (code) => {
    if (!code) return { valid: false }
    const { rows } = await db.query(
        `SELECT rc.id AS referral_code_id, rc.organization_id AS referring_organization_id, rc.discount_pct
         FROM referral_codes rc
         JOIN organizations o ON o.id = rc.organization_id AND o.deleted_at IS NULL
         WHERE rc.code = $1`,
        [code]
    )
    if (rows.length === 0) return { valid: false }
    return { valid: true, ...rows[0] }
}

// ------------------------------------------------------------------
// RECORD USE — called from the checkout.session.completed webhook patch
// when the completed session's metadata carried a referralCode. Idempotent
// against webhook retries via referral_uses.referred_organization_id's
// existing UNIQUE constraint (schema.sql Section 14).
// ------------------------------------------------------------------
const recordReferralUseIfNew = async (dbClient, { code, referredOrganizationId }) => {
    const { valid, referral_code_id, referring_organization_id, discount_pct } = await validateReferralCodeValue(code)
    if (!valid) return { recorded: false, reason: 'invalid code' }
    if (referring_organization_id === referredOrganizationId) {
        return { recorded: false, reason: 'self-referral not allowed' }
    }

    const { rows } = await dbClient.query(
        `INSERT INTO referral_uses (referral_code_id, referred_organization_id, discount_applied_pct)
         VALUES ($1, $2, $3)
         ON CONFLICT (referred_organization_id) DO NOTHING
         RETURNING id`,
        [referral_code_id, referredOrganizationId, discount_pct]
    )
    return { recorded: rows.length > 0 }
}

// ------------------------------------------------------------------
// RECORD EARNING — called from the new invoice.payment_succeeded webhook
// case (patch below) on every payment the referred org makes, not just
// the first. No-op if this org was never referred. Idempotent against
// Stripe's own webhook retries via referral_earnings.stripe_invoice_id's
// UNIQUE constraint.
// ------------------------------------------------------------------
const recordReferralEarning = async (dbClientOrPool, { referredOrganizationId, stripeInvoiceId, amountPaidCents }) => {
    const { rows: useRows } = await dbClientOrPool.query(
        `SELECT ru.id AS referral_use_id, rc.organization_id AS referring_organization_id
         FROM referral_uses ru
         JOIN referral_codes rc ON rc.id = ru.referral_code_id
         WHERE ru.referred_organization_id = $1`,
        [referredOrganizationId]
    )
    if (useRows.length === 0) return { recorded: false, reason: 'organization was not referred' }

    const commissionCents = Math.round(amountPaidCents * REFERRAL_COMMISSION_RATE)

    const { rows } = await dbClientOrPool.query(
        `INSERT INTO referral_earnings
            (referral_use_id, referring_organization_id, referred_organization_id,
             stripe_invoice_id, source_amount_cents, commission_cents)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (stripe_invoice_id) DO NOTHING
         RETURNING id`,
        [useRows[0].referral_use_id, useRows[0].referring_organization_id, referredOrganizationId,
            stripeInvoiceId, amountPaidCents, commissionCents]
    )
    return { recorded: rows.length > 0, commissionCents }
}

module.exports = {
    ensureReferralCodeForOrganization,
    validateReferralCodeValue,
    recordReferralUseIfNew,
    recordReferralEarning
}
