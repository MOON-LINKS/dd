// Matches the token scheme already issued by controllers/authController.js:
//   - JWT payload: { userId, sessionId }, signed with process.env.JWT_SECRET,
//     no `exp` claim — revocation is entirely Redis-driven, not JWT-expiry-driven.
//   - Token arrives either as the `auth_token` httpOnly cookie (web) or as
//     `Authorization: Bearer <token>` (mobile, x-client-type: app).
//   - `session:{sessionId}` in Redis holds the owning userId as its value.
//     logout / logoutFromAll / resetPass3 / deleteAccount all delete this key
//     (see authController.js's invalidateAllSessions and logout), so a JWT
//     that's structurally still valid but whose session was revoked correctly
//     fails here.
//
// Downstream code consistently expects `req.user.id` (see authController.js's
// logout, resetPass1, getUserInfo, deleteAccount) — NOT `req.user.userId` —
// so the JWT's `userId` claim is remapped to `req.user.id` below.

const jwt = require('jsonwebtoken')
const db = require('../utils/db')
const { redisClient } = require('../utils/redis')

const extractToken = (req) => {
    if (req.cookies?.auth_token) return req.cookies.auth_token
    const header = req.headers['authorization']
    if (header?.startsWith('Bearer ')) return header.slice(7)
    return null
}

const requireAuth = async (req, res, next) => {
    const token = extractToken(req)
    if (!token) return res.status(401).json({ message: 'authentication required' })

    let decoded
    try {
        decoded = jwt.verify(token, process.env.JWT_SECRET)
    } catch (err) {
        return res.status(401).json({ message: 'invalid or expired token' })
    }

    const { userId, sessionId } = decoded
    if (!userId || !sessionId) {
        return res.status(401).json({ message: 'malformed token' })
    }

    let sessionOwnerId
    try {
        sessionOwnerId = await redisClient.get(`session:${sessionId}`)
    } catch (err) {
        console.error('Redis session lookup failed:', err)
        // Fail closed: if Redis is down we can't confirm the session is still
        // valid, and letting requests through on a JWT alone would silently
        // bypass every logout/logoutFromAll/password-reset revocation.
        return res.status(503).json({ message: 'authentication temporarily unavailable' })
    }
    if (!sessionOwnerId || sessionOwnerId !== String(userId)) {
        return res.status(401).json({ message: 'session expired or logged out' })
    }

    req.user = { id: userId, sessionId }
    next()
}

// ------------------------------------------------------------------
// ADMIN GATE — see BATCH_NOTES.md. There is no role/is_admin column
// anywhere in schema.sql, so this is a pragmatic placeholder: an
// ADMIN_EMAILS env var (comma-separated) checked against the authenticated
// user's email. Swap this for a real `users.is_admin` column (or a
// separate admins table) whenever that decision gets made — flagged as a
// decision, not silently invented as permanent.
//
// Must run AFTER requireAuth (needs req.user already set):
//   router.post('/', requireAuth, requireAdmin, createJobTemplate)
// ------------------------------------------------------------------
const requireAdmin = async (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'authentication required' })
    try {
        const { rows } = await db.query('SELECT email FROM users WHERE id = $1 AND deleted_at IS NULL', [req.user.id])
        if (rows.length === 0) return res.status(401).json({ message: 'user not found' })

        const adminEmails = (process.env.ADMIN_EMAILS || '')
            .split(',')
            .map((e) => e.trim().toLowerCase())
            .filter(Boolean)

        if (!adminEmails.includes(rows[0].email.toLowerCase())) {
            return res.status(403).json({ message: 'admin access required' })
        }
        next()
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'error checking admin access' })
    }
}

// Every existing route file does `const requireAuth = require('../middleware/auth')`
// — a default single-function import, written before this file existed. Keeping
// that working (rather than going back and editing every route file) by exporting
// requireAuth as the module itself, with requireAdmin attached as a property.
// Both of these work:
//   const requireAuth = require('../middleware/auth')
//   const { requireAdmin } = require('../middleware/auth')
module.exports = requireAuth
module.exports.requireAuth = requireAuth
module.exports.requireAdmin = requireAdmin
