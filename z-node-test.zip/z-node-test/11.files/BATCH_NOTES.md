# This Batch — Apple IAP decision, .env/.gitignore, deleteOrganization, sendBillReminders

Also (re-created after the session that built this got cut off): found one
more thing while working on this batch that's more urgent than anything on
the actual list — see the first section below.

## 0. CRITICAL, found incidentally — folder casing will break this in production

Every `require()` in the codebase — 25+ call sites, checked all of them —
imports from lowercase paths: `require('../controllers/...')`,
`require('../routes/...')`, `require('../utils/...')`. But the actual
folders on disk are `Controllers/`, `Routes/`, `Utils/` (capitalized).

This works today because you're almost certainly developing on macOS or
Windows, where the filesystem is case-insensitive by default. It will **not**
work on Linux — which is what essentially every production Node.js host and
every Docker container uses. Deploy this as-is and the process crashes
immediately on boot with `MODULE_NOT_FOUND`, before it ever binds to a port.

Fix (run once, from the project root, before merging this batch's files in):
```
git mv Controllers controllers
git mv Routes routes
git mv Utils utils
```
(drop `git` if this isn't a git repo yet — plain `mv` works the same). Every
file in this batch already uses lowercase folder names, so it's consistent
with the rename, not with the current capitalized layout.

## 1. Apple IAP — kept

You confirmed you want it kept, not stripped. No code changes needed there —
`Controllers/appleController.js`, `Utils/appleIAP.js`, and the `/webhooks/apple`
route (mounted since 10.files) are already complete and wired in from batch 5.
What was actually still missing is now handled by items 2 and 3 below:
the `APPLE_*` env vars (in `.env`) and the root-level `certs/` folder (with
its setup instructions) that batch 5 only ever left inside `5.files/certs/`.

One thing I still can't do for you: the actual Apple root `.cer` files
themselves. `certs/README.md` (below) has the exact steps — it's a two-minute
manual download from Apple, not something that can be generated.

## 2. `.env` — created

`.env` in this batch has every environment variable the codebase actually
reads — cross-checked by grepping every `process.env.X` across
`Controllers/`, `Routes/`, `Utils/`, `middleware/`, and `index.js`, not
copied from memory. Placeholders are marked; fill in real values before
running. One thing worth knowing while you do: `Utils/emailTemplates.js`
has its own hardcoded `APP_NAME = 'YOUR_APP_NAME'` constant that's separate
from the `APP_NAME` env var (that one only feeds the bio-page footer) — the
`.env` file has a comment on this, and it's still a manual edit in that file
if you want your product name in emails.

## 3. `.gitignore` — created

Didn't exist anywhere in the repo before. Excludes `.env`, `certs/*.cer`
(public certs but keep the folder to just what's documented), `node_modules/`,
and a local `assets_storage/` in case that's how you're serving uploads
(remove that line if you're on S3/equivalent instead).

## 4. `deleteOrganization` — finalized

`DELETE /organizations/:organizationId`, body `{ password }`. Mirrors
`authController.deleteAccount`'s confirmation pattern (re-enter password,
checked against the logged-in user's `password_hash`) since this is just as
destructive and there was already an established pattern for it in the
codebase.

Soft delete only (`deleted_at = NOW()` on the organization row) — same as
everywhere else in the schema. Workers, clients, jobs, invoices, etc. under
the org are untouched, not cascade-deleted; they simply stop appearing
because every existing query already filters through the parent org's
`deleted_at`.

Before soft-deleting, it best-effort-cancels any active subscription so a
deleted org doesn't keep getting billed:
- **Stripe**: calls `stripe.subscriptions.cancel(...)` directly (immediate
  cancellation, not `cancel_at_period_end`) and flips `subscribed_services`
  locally right away rather than waiting on the webhook. If the Stripe call
  fails, deletion still proceeds — the response includes a `warning` field
  telling you to cancel it manually, rather than trapping the user mid-delete
  over a Stripe outage.
- **Apple IAP**: there is no API to cancel an Apple subscription from the
  backend (same "deliberately left out" boundary batch 5 documented for
  Apple → App Store Server API). `subscribed_services.is_active` gets flipped
  locally so feature-gating stops treating the org as subscribed, but the
  response's `warning` field says plainly that Apple will keep charging the
  user until they cancel it themselves from their device. This is a real
  limitation of IAP, not something this endpoint can fix — worth surfacing
  in your app's UI copy wherever org deletion is offered to iOS users.

`paymentController.js`'s `getActiveSubscription` helper is now exported so
this reuses it instead of duplicating the query.

## 5. `sendBillReminders` — finalized

The blocker noted at the end of batch 9 ("blocked on formalizing the
recurring-interval fields") turned out to already be resolved by the schema —
`upcoming_bills.reminder_days_before` has existed per-bill since the base
schema, defaulting to 7. Nobody had written the worker that reads it; that's
all this batch adds.

`POST /cron/send-bill-reminders`, gated by the same `x-cron-secret` header
pattern as the existing invoice cron (separate route file,
`billReminderCronRoutes.js`, but same `/cron` prefix — mounted as a second
router on that path in `index.js`). Point your scheduler at it once a day;
it doesn't matter what time, since it checks `due_date - reminder_days_before
= CURRENT_DATE`, not a time window.

Fires a reminder exactly once per bill, on the day that equality holds.
Idempotency is via `email_log`, not a new flag on `upcoming_bills`: a bill
is skipped if a `bill_reminder` row already exists for it in `email_log`
dated today, so a retried scheduler trigger can't double-send. This mirrors
how batch 7 already designed `email_log` to also back "the upcoming-bill-
reminder history... once `sendBillReminders` is built" — so the History tab
UI (already reading `email_log` via `emailLogController.listEmailLog`) picks
up bill reminders automatically, no separate endpoint needed.

Added `billReminderEmail` to `Utils/emailTemplates.js`, following the exact
shape of the existing `invoiceEmail` (same wrapper, same table-row layout).

One thing intentionally left alone: a bill marked paid, or converted to an
expense, just stops matching the query (`is_paid = FALSE`) — no separate
cancel-pending-reminder logic needed, since the reminder only fires on
that one specific day anyway.

## Still open
- Those five stale `// TODO: shared once you provide the real middleware`
  comments (flagged after 10.files) — still there, still harmless, still
  cosmetic.
- Helmet, rate limiting — you're still saving these for last.
- `Utils/emailTemplates.js`'s hardcoded `APP_NAME` — see item 2.
