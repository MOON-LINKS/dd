# This Batch — Billing & Invoices

Section 3's "biggest section in the app," all three tabs, plus generation,
PDF, and email.

## New files

| File | Goes in |
|---|---|
| `controllers/invoiceController.js` | `controllers/` |
| `controllers/invoiceAnalyticsController.js` | `controllers/` |
| `controllers/invoiceBrandingController.js` | `controllers/` |
| `controllers/emailLogController.js` | `controllers/` |
| `controllers/invoiceCronController.js` | `controllers/` |
| `routes/invoiceRoutes.js` | `routes/` |
| `routes/invoiceCronRoutes.js` | `routes/` |
| `utils/invoiceGeneration.js` | `utils/` |
| `utils/pdfBuilder.js` | `utils/` |
| `utils/invoicePdfStorage.js` | `utils/` |
| `utils/historyLimit.js` | `utils/` |
| `utils/cdn.js` | `utils/` |
| `utils/emailTemplates.js` | `utils/` — **replaces** your existing file (see below) |
| `migrations/007_invoices.sql` | run against your DB first |
| `index.js` | reference delta only — two `app.use` lines to add |

## Required before this batch will run

**1. Run `migrations/007_invoices.sql`.** Adds `email_log` — the only new
table this batch needs. `invoices`, `invoice_line_items`, and
`invoice_branding` were already in `schema.sql`, untouched.

**2. Install `pdfkit`:**
```
npm install pdfkit --save
```
Chosen over a Puppeteer/headless-Chrome approach deliberately — no Chromium
binary to ship or crash in whatever environment this deploys to, and the
branding requirements (two colors + a logo) don't need HTML/CSS to express.

**3. Node 18+ required.** `pdfBuilder.js` uses the platform's built-in
`fetch` to pull the org's logo into the PDF. If you're on an older Node,
either upgrade or swap that one `fetch` call for `node-fetch` — everything
else is unaffected either way.

**4. One-line patch to `utils/constants.js`** — not replaced wholesale since
every other module's asset uploads share that file:
```diff
- const ASSET_OWNER_TYPES = ['organization', 'worker', 'bio_page', 'upcoming_bill']
+ const ASSET_OWNER_TYPES = ['organization', 'worker', 'bio_page', 'upcoming_bill', 'invoice']
```
Generated invoice PDFs are stored as ordinary `assets` rows
(`owner_type='invoice'`) so they show up through the same storage/CDN path
as everything else — this addition is what makes that valid.

**5. `utils/emailTemplates.js` is a full replacement, not a new file** — the
only change is one new function, `invoiceEmail`, added at the bottom.
Everything above it (`wrapper`, `otpCodeBlock`, `APP_NAME`,
`registrationOtpEmail`, `passwordResetOtpEmail`, `welcomeEmail`) is
byte-for-byte what you already have. Diff it against your copy before
overwriting if you want to confirm that yourself.

**6. New env var:**
```
CRON_SECRET=<any long random string>
CDN_BASE_URL=https://cdn.yourdomain.com/imgs   # optional — defaults to the placeholder from Section 9's example
```
Point your scheduler (cron / hosting provider's scheduled functions / etc.)
at `POST /cron/generate-monthly-invoices` with header `x-cron-secret:
<CRON_SECRET>`, once a month.

## What's built

- **Monthly auto-generation** — `utils/invoiceGeneration.js` is the shared
  core, called by both the manual endpoint and the cron job. One invoice per
  client per period, built from every not-yet-invoiced `job_day` in range.
  **Idempotent by construction**: `job_days.invoiced` gates inclusion, so
  re-running with an overlapping period never double-bills a day — no
  separate "does this invoice already exist" check was needed.
- **Manual/backfill trigger** — `POST /invoices/generate`, same engine,
  explicit or default-to-previous-month period.
- **List + get** — filterable by client/date range, paginated.
- **Record payment** — manager logs what a client actually paid; this has
  nothing to do with Batch 5's Stripe/Apple payments (that's the org paying
  for the SaaS; this is the org's client paying the org).
- **PDF generation** (pdfkit) — branded with the org's `invoice_branding`
  colors and logo (falls back to the org's general logo if no
  invoice-specific one is set, then to default colors if neither exists).
  Stored as a normal asset. Regenerating is safe — old PDFs aren't deleted,
  so a previously emailed link never breaks.
- **Send / resend email** — manager-only per spec. Builds the PDF on the fly
  if one doesn't exist yet rather than requiring a separate "generate PDF
  first" step. Every attempt — success or failure — is logged.
- **History tab** (`email_log` + `GET /invoices/history/log`) — the
  dispatch record Section 3 describes as distinct from the invoices
  themselves. Built generically (`email_type` + `reference_id`) so it's
  ready for `sendBillReminders` to log into as well once that's built —
  not invoice-only.
- **Design tab** (`invoice_branding` get/update) — hex color validation,
  and confirms a submitted `logoAssetId` actually belongs to the requesting
  org before accepting it (otherwise any org could point its branding at
  another org's uploaded logo).
- **Invoices (analytics) tab** — one endpoint, `GET /invoices/analytics`,
  returns revenue trend by month, hours logged vs. hours billed (a real
  distinction here — see below), paid vs. owed, and breakdowns by client and
  by job, in a single response.
- **`plans.history_months` enforcement** — `utils/historyLimit.js`, applied
  to both `listInvoices` and `getInvoiceAnalytics`. First place this
  plan-limit (flagged as ungated in the last requirements pass) is actually
  checked server-side.

## Flagging, not hiding — two things worth your direct attention

**1. The money model has no client billing rate anywhere in `schema.sql`.**
Only `workers.hourly_rate` exists (what the org pays the *worker*), no
markup/margin field. So `invoice.total_amount` is built the only way the
schema unambiguously supports: hourly workers' `hours × hourly_rate`,
summed per client — the client is charged exactly what the org pays the
worker, zero markup. `monthly_amount` (salaried) workers' hours are tracked
on the invoice for reference (matches "hours are ALWAYS logged, regardless
of pay type") but contribute `$0` — their pay isn't tied to any one job or
client, so there's no defensible way to attribute a dollar figure to a
specific invoice for them. If the real business model needs a markup or a
separate client billing rate, that's a schema addition (e.g.
`jobs.client_rate` or a per-job/per-client rate table) and a change to
`utils/invoiceGeneration.js`'s calculation — flagging now rather than
guessing at a number that might not match what you actually charge clients.

**2. "Hours logged vs. hours billed" in the analytics tab is a real,
non-trivial distinction, not a rename** — worth understanding before reading
that chart: *logged* = every hour on a `day_assignment` in the period,
any pay type. *Billed* = only the hours that produced a dollar amount on an
invoice line (hourly workers only). A org with a lot of salaried workers
will always show a gap between the two — that's correct, not a bug.

## Deliberately left out of this batch
- **Bio Pages, Referrals, `deleteOrganization`, `sendBillReminders`** —
  unchanged from where the last batch left them. `email_log`'s generic
  design means `sendBillReminders` can log into it directly once built,
  rather than needing its own table later.
- **Module gating on invoices** — treated as a core, always-on feature
  (not in `plans.modules`'s example list in Section 9), so no gate was
  added. Flag if that's wrong and it should be plan-limited too.
- **Multi-currency** — everything assumes a single currency throughout
  (no currency field anywhere in the invoice tables); not something the
  current schema supports, not invented here.

## Suggested next
Bio Page Builder is next per the priority list — but it has one open design
question (the static-snapshot caching mechanism) that's worth deciding
before that batch starts, unlike Invoices, which had none blocking it.
