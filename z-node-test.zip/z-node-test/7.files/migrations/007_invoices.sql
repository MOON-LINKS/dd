-- Migration 007 — Invoices support
--
-- invoices / invoice_line_items / invoice_branding already exist in schema.sql
-- (Section 14) — nothing to add for those. This migration only adds what was
-- missing: a log of dispatched emails to back the History tab, which Section 3
-- describes as explicitly distinct from the invoices table itself ("this is
-- the 'did this actually go out' record, distinct from the invoices
-- themselves"). Designed generically (email_type + reference_id) so it can
-- also back the upcoming-bill-reminder history mentioned in the same
-- paragraph, once sendBillReminders is built — not just invoices.

CREATE TABLE email_log (
    id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  UUID          NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    email_type       VARCHAR(30)   NOT NULL CHECK (email_type IN ('invoice', 'bill_reminder')),
    reference_id     UUID          NOT NULL,  -- invoices.id or upcoming_bills.id, depending on email_type
    recipient_email  CITEXT        NOT NULL,
    subject          VARCHAR(300),
    status           VARCHAR(20)   NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'failed')),
    error_message    TEXT,
    sent_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_email_log_org ON email_log(organization_id, sent_at DESC);
CREATE INDEX idx_email_log_reference ON email_log(email_type, reference_id);

COMMENT ON COLUMN email_log.reference_id IS 'Points at invoices.id when email_type=invoice, or upcoming_bills.id when email_type=bill_reminder. No FK constraint since it targets two different tables.';
