const express = require('express')
const router = express.Router()
const { runSendBillReminders } = require('../controllers/billReminderCronController')

// Same shared-secret gate as invoiceCronRoutes.js — duplicated rather than
// imported since it's four lines and both files are meant to stay
// independently readable/deletable. If a third cron job shows up, worth
// pulling this into its own middleware/cronAuth.js instead.
const requireCronSecret = (req, res, next) => {
    const provided = req.headers['x-cron-secret']
    if (!process.env.CRON_SECRET) {
        console.error('CRON_SECRET is not set — refusing all cron requests until it is.')
        return res.status(503).json({ message: 'cron endpoint not configured' })
    }
    if (provided !== process.env.CRON_SECRET) {
        return res.status(401).json({ message: 'invalid cron secret' })
    }
    next()
}

// Point your scheduler at this once a day (any time of day works — it
// checks due_date - reminder_days_before = CURRENT_DATE, not a time window).
router.post('/send-bill-reminders', requireCronSecret, runSendBillReminders)

module.exports = router
