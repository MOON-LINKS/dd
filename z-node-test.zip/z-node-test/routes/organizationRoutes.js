const express = require('express')
const router = express.Router()
const {
    createOrganization,
    listMyOrganizations,
    getOrganization,
    updateOrganization,
    updateOrganizationLogo,
    deleteOrganization
} = require('../controllers/organizationController')
const requireAuth = require('../middleware/auth')

router.post('/', requireAuth, createOrganization)
router.get('/', requireAuth, listMyOrganizations)
router.get('/:organizationId', requireAuth, getOrganization)
router.patch('/:organizationId', requireAuth, updateOrganization)
router.patch('/:organizationId/logo', requireAuth, updateOrganizationLogo)
// Body: { password } — re-confirmation required, same pattern as
// authController.deleteAccount. See 11.files/BATCH_NOTES.md.
router.delete('/:organizationId', requireAuth, deleteOrganization)
// plan_id is set exclusively by webhookController.js after a real payment —
// see 10.files/BATCH_NOTES.md for why the old PATCH /:organizationId/plan
// dev-testing route was removed.

module.exports = router
