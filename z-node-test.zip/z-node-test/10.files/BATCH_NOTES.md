# This Batch — Fixes from the full-backend review

Not a new feature batch. This closes out everything flagged in the review of
batches 0–9: two integration gaps (webhooks and Bio Pages never actually
mounted), three documented-but-unapplied patches, and one real bug — a
payment-bypass endpoint that should have been removed once Stripe checkout
went live.

## Files — all drop-in replacements for what you already have

| File | Goes in | What changed |
|---|---|---|
| `index.js` | project root — **full replacement**, not a delta this time | webhook routes now actually mounted, and mounted *before* `express.json()`; bio page routes mounted |
| `controllers/organizationController.js` | `controllers/` | removed `selectPlan` |
| `controllers/authController.js` | `controllers/` | fixed `getUserInfo`'s `stripe_customer_id` bug |
| `routes/organizationRoutes.js` | `routes/` | removed the `selectPlan` route |
| `routes/jobTemplateRoutes.js` | `routes/` | admin routes now use `requireAdmin` |
| `utils/constants.js` | `utils/` | added `'invoice'` to `ASSET_OWNER_TYPES`; merged in `BIO_PAGE_COLOR_PRESETS` |
| `package.json` | project root | added `stripe`, `@apple/app-store-server-library`, `pdfkit` |
| `controllers/bioPage*.js`, `controllers/publicBioPageController.js` | `controllers/` | unchanged from batch 8 — just actually copying them in this time |
| `routes/bioPageRoutes.js`, `routes/publicBioPageRoutes.js` | `routes/` | unchanged from batch 8 — same |
| `utils/bioPageFeatures.js`, `utils/bioPageRenderer.js` | `utils/` | unchanged from batch 8 — same |

All files syntax-checked with `node --check`.

## What was actually wrong, and what changed

**1. Webhooks were never reachable at all.** `index.js` required
`webhookRoutes` but had no `app.use(...)` for it. Added `app.use('/webhooks',
webhookRoutes)` — Stripe hits `/webhooks/stripe`, Apple hits
`/webhooks/apple`. It's placed **before** `express.json()`, matching the
comment already in `webhookRoutes.js`: Stripe's signature check needs the raw
request body, and once the global `json()` parser has consumed it, it's
gone. Update your Stripe dashboard / Apple App Store Connect webhook URLs to
point at `https://yourdomain.com/webhooks/stripe` and
`https://yourdomain.com/webhooks/apple` once deployed.

**2. Bio Pages (batch 8) was fully built but never merged in.** Its
controllers/routes/utils were still sitting only in `8.files/`, and
`index.js` never required or mounted them. Copied the files into place and
added:
```
app.use('/organizations/:organizationId/bio-page', bioPageRoutes)
app.use('/bio', publicBioPageRoutes)
```
Also merged `BIO_PAGE_COLOR_PRESETS` into `utils/constants.js` (was
documented as a required manual step in batch 8's notes, never done).

**3. `organizationController.selectPlan` — a real payment bypass, removed.**
This was explicitly commented as a temporary dev-only endpoint ("goes away"
once checkout was built) that lets an authenticated user set their own
`plan_id` via `PATCH /organizations/:organizationId/plan` with no payment.
Batch 5 (Stripe checkout) has been live for a while and this was never taken
out — any user could grant themselves any plan for free. Deleted the
function and its route. `plan_id` is now set exclusively by
`webhookController.js` after a real Stripe/Apple event, as originally
intended.

**4. `authController.getUserInfo`'s `stripe_customer_id` bug — fixed.** It
was selecting `u.stripe_customer_id` (never existed on `users`) instead of
`o.stripe_customer_id`. Every call was throwing a "column does not exist"
error. Fixed the query, and — since a user can own more than one
organization — moved `stripeCustomerId` off the top-level `user` object and
into each entry of `user.organizations[]` instead, where it actually makes
sense per-org.

**5. `jobTemplateRoutes.js` admin routes — `requireAdmin` now applied.**
`POST /admin/job-templates` and `PATCH /admin/job-templates/:templateId`
were still gated by `requireAuth` alone (any logged-in user), with a
leftover `// TODO: swap for requireAdmin` comment. Both now run
`requireAuth, requireAdmin`.

**6. `ASSET_OWNER_TYPES` missing `'invoice'` — fixed.** Batch 7's
`invoicePdfStorage.js` was inserting `assets` rows with `owner_type =
'invoice'` directly (bypassing the app-level check), but nothing had added
`'invoice'` to the list `assetController.js` validates against. Any
route that lists/validates assets generically by owner type would have
rejected invoice PDFs. Added.

**7. `package.json` — missing dependencies added.** `stripe`,
`@apple/app-store-server-library`, and `pdfkit` were imported by code
that's been live since batches 5 and 7 but were never added to
`package.json`. `npm install` after this batch.

## Flagging — you said Stripe is the payment gateway

You confirmed Stripe, and the code does already use it as the primary path
(`utils/stripeClient.js`, `paymentController.js`). But the backend also has
a fully-built **Apple IAP** path from batch 5 (`controllers/appleController.js`,
`utils/appleIAP.js`, the `/webhooks/apple` route) — batch 5's notes describe
this as a confirmed "Stripe + Apple IAP, no Tap" decision at the time. I've
kept `@apple/app-store-server-library` in `package.json` because
`webhookController.js`'s file (required by the now-mounted `webhookRoutes.js`)
imports `appleController.js` at the top level — without the package installed,
the app won't even boot, regardless of whether you use the Apple endpoints.

If Apple IAP is actually out of scope now and you only want Stripe: that's a
real removal (delete `appleController.js`, `utils/appleIAP.js`, the
`/apple` route and its `certs/` requirement, the `payment_provider = 'apple'`
paths in `webhookController.js`, and the package from `package.json`) —
worth confirming explicitly before I do that, since it touches several files
across two batches rather than being a one-line fix.

## Not in this batch
Helmet, rate limiting, and `.env` setup — you said to save those for last,
so nothing here touches them. `deleteOrganization` and `sendBillReminders`
are also still the two open gaps from batch 9, unchanged.

## Suggested next
A real end-to-end pass now that both webhooks and Bio Pages are actually
reachable — register → org → Stripe checkout → confirm the webhook fires and
`plan_id`/`subscribed_services` update → publish a bio page → hit the public
`/bio/:slug` URL. This is the first point the whole backend, as actually
wired together, can be exercised.
