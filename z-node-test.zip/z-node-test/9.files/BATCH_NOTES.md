# This Batch — Referrals (backend feature list now complete)

Last unblocked module from the original list. This one touches two files
you already have from Batch 5 (`paymentController.js`, `webhookController.js`)
— patched, not replaced, exact before/after snippets in `index.js`.

## New files, ready to drop into your project structure

| File | Goes in |
|---|---|
| `controllers/referralController.js` | `controllers/` |
| `controllers/referralAdminController.js` | `controllers/` |
| `routes/referralRoutes.js` | `routes/` |
| `utils/referralEngine.js` | `utils/` |
| `utils/referralStripeCoupon.js` | `utils/` |
| `utils/referralConstants.js` | `utils/` |
| `migrations/009_referral_earnings.sql` | run against your DB before testing |
| `index.js` | **not a drop-in this time** — it's the two-route-mount delta AND the exact patch instructions for `paymentController.js` and `webhookController.js`. Read it, don't run it. |

## Required before this batch will run

**1. Run `migrations/009_referral_earnings.sql`.** Adds `referral_earnings`
and `referral_payouts`. `referral_codes` and `referral_uses` already existed
in `schema.sql` — untouched, except three columns on `referral_uses`
(`reward_type`, `reward_value`, `reward_issued_at`) are now commented as
deprecated rather than dropped (see "flagging" note below).

**2. Apply Patch 1 to `controllers/paymentController.js`** — adds an
optional `referralCode` to `createCheckoutSession`'s request body, validates
it, and applies a 10%-off Stripe coupon. Exact before/after in `index.js`.

**3. Apply Patch 2 to `controllers/webhookController.js`** — two changes:
extends the existing `checkout.session.completed` case to (a) generate the
paying org's own referral code on their first successful payment, and (b)
record that they used someone else's code, if they did; and adds a brand
new `invoice.payment_succeeded` case, which is what actually credits the
referring org on every payment the referred org makes afterward. Exact
before/after in `index.js`.

**4. Add the two new route mounts** — also in `index.js`'s top section.
Note the module export shape: `referralRoutes.js` exports three things off
one object (`module.exports = router` plus `.publicRouter` and
`.adminRouter` attached to it) — same pattern Batch 6's `middleware/auth.js`
already uses for `requireAuth`/`requireAdmin`, so nothing new to learn here,
just applying the same trick again.

**5. `middleware/auth.js`'s `requireAdmin` must exist** (Batch 6) — the
payout endpoints are admin-only.

## What's built

- **Code generation** (`referralEngine.ensureReferralCodeForOrganization`)
  — exactly matching what you described: created on an org's **first
  successful payment**, not at registration. Every payment after the first
  is a no-op (checks for an existing row first). First-name-based, retries
  on collision, no manual "generate my code" button needed anywhere.
- **10% first-payment discount** (`referralStripeCoupon.js` +
  `paymentController` patch) — one reusable Stripe Coupon
  (`duration: 'once'`), applied via the `discounts` checkout param. Rejects
  self-referral (an org using its own code) server-side.
- **Accumulating cashback ledger** (`referral_earnings` +
  `recordReferralEarning`) — this is the part that's genuinely different
  from a one-time signup reward: every payment the referred org makes,
  forever (not just their first), credits the referring org 25% of that
  payment. That's the "$200 referred → $50 earned" rate you gave as an
  example (50/200 = 0.25), applied continuously rather than as a single
  flat bonus. Idempotent against Stripe's webhook retries via
  `stripe_invoice_id`'s `UNIQUE` constraint.
- **Payout** (`referralAdminController.issuePayout`) — admin-triggered,
  records that a transfer happened (oldest-unpaid-earnings-first
  allocation) without moving any money itself — no payout processor is
  wired, matching the open question flagged back when this was first
  designed. `listPendingPayoutBalances` gives an admin a queue to work from.
- **Referrer-facing endpoints** (`referralController.js`) — `getMyReferralCode`
  (returns `null` gracefully pre-first-payment, not an error),
  `getReferralEarnings` (lifetime/paid/pending summary),
  `listReferralHistory` (who used your code + every earning entry).
- **Public validate** (`GET /referrals/validate?code=`) — no auth, same
  live-check-while-typing pattern as the bio page slug-check.

## Flagging, not deciding for you

**`referral_uses.reward_type`/`reward_value`/`reward_issued_at` are now
dead columns**, superseded by `referral_earnings`/`referral_payouts`. Not
dropped — they might hold data from before this design existed if you ever
manually tested the earlier one-shot version — but nothing in this batch
writes to them. Clean them up in a later migration once you've confirmed
nothing else reads them.

**No payout processor is wired, still.** `issuePayout` is bookkeeping —
"this org is now marked as paid $X" — with a free-text `notes` field for
however you actually moved the money (bank transfer, manual PayPal, etc.).
If this becomes frequent enough to automate, that's a real integration
decision (Stripe Connect payouts, PayPal Payouts API, etc.) — not guessed
at here.

**The 25% commission rate and $50 minimum payout are both constants in
`referralConstants.js`**, not hardcoded inline — change the numbers there
if the model gets tuned, no controller edits needed.

## Backend feature list — now complete

Per the running list from earlier in this project: Auth, Organizations,
Assets, Workers, Clients, Job Templates, Jobs, Expenses, Upcoming Bills
(minus `sendBillReminders`, still blocked on the reminder-interval decision
flagged early on), Invoices, Payments, Bio Pages, and now Referrals are all
built. `deleteOrganization` was never picked up (low priority, flagging it
still exists) and the `sendBillReminders` cron is the one remaining gap tied
to an actual open decision rather than just not-yet-built.

Given you said you want the full backend finished before starting Flutter:
worth a real end-to-end pass (register → org → checkout → referral →
publish bio page) before calling it done, same as Batch 6 suggested after
auth became testable — this is the first point the *entire* backend can run
together.
