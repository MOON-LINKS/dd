-- ============================================================
-- Batch 9 — Referrals: earnings ledger + payouts
-- ============================================================
-- referral_codes and referral_uses already exist in schema.sql (Section 14
-- design). This migration adds what wasn't in the original design: an
-- accumulating cashback ledger tied to the REFERRED org's ongoing payments
-- (not a one-time reward captured at signup), per the "$200 referred -> $50
-- to the referrer" model you described — that's a running 25% commission
-- on the referred org's payments, paid out once, not a flat one-time bonus.

CREATE TABLE referral_earnings (
    id                        UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    referral_use_id           UUID          NOT NULL REFERENCES referral_uses(id) ON DELETE CASCADE,
    referring_organization_id UUID          NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    referred_organization_id  UUID          NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    stripe_invoice_id         VARCHAR(255)  NOT NULL, -- idempotency key: one earning row per Stripe invoice, ever
    source_amount_cents       INT           NOT NULL, -- what the referred org paid on that invoice
    commission_cents          INT           NOT NULL, -- source_amount_cents * commission rate, at time of earning
    payout_id                 UUID,                   -- set once included in a payout (FK added below, after referral_payouts exists)
    created_at                TIMESTAMPTZ   NOT NULL DEFAULT NOW(),

    UNIQUE (stripe_invoice_id)
);

CREATE TABLE referral_payouts (
    id                        UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id           UUID          NOT NULL REFERENCES organizations(id) ON DELETE CASCADE, -- the referring org being paid
    amount_cents              INT           NOT NULL,
    status                    VARCHAR(20)   NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'failed')),
    notes                     TEXT,                   -- e.g. "manual bank transfer, ref #1234" — no payout processor wired yet
    requested_at              TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    paid_at                   TIMESTAMPTZ,
    created_by_admin_user_id  UUID          REFERENCES users(id) ON DELETE SET NULL
);

ALTER TABLE referral_earnings ADD CONSTRAINT fk_referral_earnings_payout
    FOREIGN KEY (payout_id) REFERENCES referral_payouts(id) ON DELETE SET NULL;

CREATE INDEX idx_referral_earnings_referring_org ON referral_earnings(referring_organization_id, payout_id);
CREATE INDEX idx_referral_earnings_use ON referral_earnings(referral_use_id);
CREATE INDEX idx_referral_payouts_org ON referral_payouts(organization_id);

COMMENT ON TABLE referral_earnings IS 'One row per Stripe invoice paid by a referred org, while that org has an unexpired referral relationship. commission_cents is credited to referring_organization_id. payout_id groups earnings into a payout once issued (see referral_payouts).';
COMMENT ON COLUMN referral_earnings.stripe_invoice_id IS 'Idempotency key — invoice.payment_succeeded can fire more than once for the same invoice; UNIQUE here prevents double-crediting.';
COMMENT ON TABLE referral_payouts IS 'Manual/admin-issued payout record. No payout processor is wired (flagged as an open question earlier) — notes field is a free-text record of however the transfer actually happened.';

-- referral_uses.reward_type / reward_value / reward_issued_at (original
-- schema.sql columns) are now SUPERSEDED by referral_earnings + referral_payouts
-- for the referring-org reward. Not dropped — no destructive migration for
-- columns that might still hold historical data — but new code should not
-- write to them going forward. discount_applied_pct on the same table stays
-- the source of truth for what the REFERRED org got, which this batch does
-- not change.
COMMENT ON COLUMN referral_uses.reward_type IS 'DEPRECATED as of Batch 9 — superseded by referral_earnings/referral_payouts. Left in place, not written to by new code.';
COMMENT ON COLUMN referral_uses.reward_value IS 'DEPRECATED as of Batch 9 — see referral_earnings.commission_cents instead.';
COMMENT ON COLUMN referral_uses.reward_issued_at IS 'DEPRECATED as of Batch 9 — see referral_payouts.paid_at instead.';
