# This Batch — Auth Middleware

The one file every other batch has been waiting on.

## New files

| File | Goes in |
|---|---|
| `middleware/auth.js` | `middleware/` |
| `migrations/006_user_sessions.sql` | run against your DB before testing |

That's it — this batch is deliberately small. No new env vars beyond what
auth already needs (`JWT_SECRET`, `REDIS_URL`), plus one new optional one:

```
ADMIN_EMAILS=you@yourcompany.com,other-admin@yourcompany.com
```

## What it does

- **`requireAuth`** — reads the token from the `auth_token` cookie (web) or
  `Authorization: Bearer` header (mobile), verifies the JWT, then checks
  `session:{sessionId}` in Redis actually still holds that user's ID. That
  second check is what makes logout/logoutFromAll/password-reset real —
  authController's JWTs carry no `exp` claim, so without the Redis check a
  "logged out" token would keep working forever.
- Sets `req.user = { id, sessionId }` — matches what every controller
  already destructures (`const { id } = req.user`, `req.user?.id`, etc.) in
  authController.js, orgAccess.js, and every org-scoped controller since.
- **`requireAdmin`** — see "Open decision" below before you rely on this one.
- Exported so every existing `const requireAuth = require('../middleware/auth')`
  line — already sitting in every route file from batches 1–5 — works
  unchanged. `const { requireAdmin } = require('../middleware/auth')` also
  works, for the one place that needs it.

## Required before this batch will run

**Run `migrations/006_user_sessions.sql`.** `authController.js` already reads
and writes a `user_sessions` table (login creates a row, logout deletes one,
logoutFromAll sweeps them all, getUserInfo lists them for the device-management
UI) — but that table isn't in `schema.sql`. Login has effectively never been
testable end-to-end against the current schema until this migration runs.
This is a separate gap from the OTP-columns mismatch you said you'd handle
yourself — that one was extra columns to remove later; this one is a missing
table auth needs to work at all.

## Two small existing-file bugs surfaced while wiring this up

Not fixed automatically — these are in files you already have from earlier
batches, so here's the exact patch for each rather than me re-shipping whole
files you didn't ask me to touch:

**1. `authController.js` → `getUserInfo`** selects `u.stripe_customer_id` off
`users`, but that column was never on `users` — Batch 5's Payments work put
`stripe_customer_id` on `organizations` instead (the org is the billing
entity, not the user; see Batch 5's migration notes). As written, every call
to `getUserInfo` throws a "column does not exist" error. Fix:
```diff
- u.stripe_customer_id,
+ o.stripe_customer_id,
```
(the query already joins `organizations o`, so this is a one-word swap — just
also move the corresponding line in the JS object-mapping below the query
from `stripeCustomerId: rows[0].stripe_customer_id` to read off the org row
instead, since a user can own more than one org).

**2. `jobTemplateRoutes.js` → `adminRouter`** — both routes still use
`requireAuth`, with a `// TODO: swap for requireAdmin once that exists`
comment sitting right above them. That middleware exists now:
```diff
- adminRouter.post('/', requireAuth, createJobTemplate)
- adminRouter.patch('/:templateId', requireAuth, updateJobTemplate)
+ adminRouter.post('/', requireAuth, requireAdmin, createJobTemplate)
+ adminRouter.patch('/:templateId', requireAuth, requireAdmin, updateJobTemplate)
```
(add `const { requireAdmin } = require('../middleware/auth')` alongside the
existing `requireAuth` import.)

## Open decision — `requireAdmin` is a placeholder, flagging it as one

There's no `is_admin` column, no roles table, nothing in `schema.sql` that
distinguishes an admin from a regular manager. `requireAdmin` as shipped here
checks the authenticated user's email against a comma-separated `ADMIN_EMAILS`
env var — works, but doesn't scale past "it's just you/a few people running
this" and isn't manageable from any UI. Two real options whenever this
matters enough to fix properly:
- `ALTER TABLE users ADD COLUMN is_admin BOOLEAN NOT NULL DEFAULT FALSE` —
  simplest, fine if admin access is rare and internal-only
- A separate `admins` table if you ever want scoped admin roles (e.g.
  "can edit job templates" vs. "can see billing across all orgs") rather
  than one all-or-nothing flag

Not building either speculatively — the env-var version unblocks the one
route that needs it (`/admin/job-templates`) today without guessing at a
shape you haven't decided on.

## Now genuinely unblocked
Every route in batches 1–5 can be wired to real auth and tested end-to-end
for the first time. Worth an actual pass through login → create org →
add workers/jobs/clients → checkout → webhook before starting Batch 7, since
this is the first point all of it can run together.
