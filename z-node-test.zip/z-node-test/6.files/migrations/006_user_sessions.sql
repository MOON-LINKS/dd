-- Migration 006 — user_sessions
--
-- Not a new decision — authController.js (batch 1) already reads/writes a
-- `user_sessions` table (login, logout, logoutFromAll, deleteAccount,
-- getUserInfo's device list), but it does not exist anywhere in schema.sql.
-- This was the same class of gap flagged for the OTP columns earlier, except
-- you said the OTP mismatch was already handled on your end — this table is
-- a separate, still-open gap: it's not a stale extra column to remove, it's
-- a whole table that needs to be added for login to work past this point.
--
-- Columns match exactly what authController.js already queries:
--   INSERT INTO user_sessions (user_id, device_name, jwt_token) VALUES (...)
--   SELECT jwt_token FROM user_sessions WHERE user_id = $1
--   DELETE FROM user_sessions WHERE user_id = $1 [AND jwt_token = $2]
--   SELECT s.id, s.device_name, s.last_active FROM user_sessions s ...

CREATE TABLE user_sessions (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_name   VARCHAR(200),
    jwt_token     TEXT        NOT NULL,
    last_active   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_user_sessions_user ON user_sessions(user_id);

-- Middleware/auth.js itself does NOT query this table (Redis's session:{id}
-- key is the actual authority requireAuth checks, and is cheaper to hit on
-- every request) — this table backs the *device management UI* (getUserInfo's
-- session list) and the *logoutFromAll sweep* (which needs every stored
-- jwt_token to decode its sessionId and delete the matching Redis key), not
-- per-request auth itself.
