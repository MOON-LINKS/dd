const express = require('express')
const router = express.Router()

const { getPublicBioPageHtml, getPublicBioPageData } = require('../controllers/publicBioPageController')
const { checkSlugAvailability } = require('../controllers/bioPageController')

// No requireAuth on any of these — public-facing by design.
router.get('/slug-check', checkSlugAvailability)   // GET /bio/slug-check?slug=xyz&excludeOrganizationId=...
router.get('/:slug/data', getPublicBioPageData)    // GET /bio/:slug/data  (JSON, for native rendering)
router.get('/:slug', getPublicBioPageHtml)         // GET /bio/:slug       (raw cached HTML)

module.exports = router
