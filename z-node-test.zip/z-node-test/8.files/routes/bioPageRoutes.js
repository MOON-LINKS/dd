const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId
const requireAuth = require('../middleware/auth')

const {
    getBioPageEditorData,
    updateBioPageDraft,
    updateBioPageLogo
} = require('../controllers/bioPageController')
const {
    addBioPageButton,
    updateBioPageButton,
    deleteBioPageButton,
    reorderBioPageButtons
} = require('../controllers/bioPageButtonController')
const {
    publishBioPage,
    unpublishBioPage,
    listBioPageVersions,
    rollbackBioPageToVersion
} = require('../controllers/bioPageSnapshotController')

router.get('/', requireAuth, getBioPageEditorData)
router.patch('/', requireAuth, updateBioPageDraft)
router.patch('/logo', requireAuth, updateBioPageLogo)

router.post('/buttons', requireAuth, addBioPageButton)
router.patch('/buttons/reorder', requireAuth, reorderBioPageButtons) // must precede :buttonId below
router.patch('/buttons/:buttonId', requireAuth, updateBioPageButton)
router.delete('/buttons/:buttonId', requireAuth, deleteBioPageButton)

router.post('/publish', requireAuth, publishBioPage)
router.patch('/unpublish', requireAuth, unpublishBioPage)
router.get('/versions', requireAuth, listBioPageVersions)
router.post('/versions/:version/rollback', requireAuth, rollbackBioPageToVersion)

module.exports = router
