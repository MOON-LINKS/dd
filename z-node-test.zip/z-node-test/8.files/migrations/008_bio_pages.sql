-- ============================================================
-- Batch 8 — Bio Pages: versioned snapshots + scalable feature flags
-- ============================================================

-- Generic, scalable per-plan feature limits — separate from `plans.modules`
-- (which stays a simple on/off array). This is for flags with a VALUE, not
-- just a toggle: counts, numbers, nested config. Deliberately not bio-page-
-- specific in shape, even though bio pages are the first consumer — any
-- future feature-gated number/toggle (e.g. max clients on a plan, max PDF
-- exports/month) can live here without another migration.
--
-- Example value once populated:
-- {
--   "bio_page_max_buttons": 8,
--   "bio_page_max_social_icons": 5,
--   "bio_page_animations_enabled": false,
--   "bio_page_banner_enabled": true
-- }
-- Keys are read with safe defaults in utils/bioPageFeatures.js — an org on
-- a plan with no matching key falls back to that default, not an error.
ALTER TABLE plans ADD COLUMN feature_limits JSONB NOT NULL DEFAULT '{}';

COMMENT ON COLUMN plans.feature_limits IS 'Scalable per-plan feature flags/limits (counts, toggles). Keys are feature-specific and read with defaults — see utils/bioPageFeatures.js for the bio page consumer.';


-- Versioned publish history for bio pages, mirroring the Moon Links
-- menu_snapshots pattern: each publish writes one row here, bio_pages itself
-- only ever holds the CURRENT draft + the current cached rendered_html.
-- Enables a "History"/rollback view without needing it to be asked for twice.
CREATE TABLE bio_page_snapshots (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    bio_page_id  UUID        NOT NULL REFERENCES bio_pages(id) ON DELETE CASCADE,
    version      INT         NOT NULL,
    payload      JSONB       NOT NULL,  -- { title, shortBio, colorPreset, logoAssetId, buttons: [...] }
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    UNIQUE (bio_page_id, version)
);

CREATE INDEX idx_bio_page_snapshots_page ON bio_page_snapshots(bio_page_id, version DESC);

COMMENT ON TABLE bio_page_snapshots IS 'One row per publish. Cleanup keeps only the latest 2 versions per bio_page_id (see bioPageSnapshotController.publishBioPage) — this is publish history for rollback, not a full audit log.';
