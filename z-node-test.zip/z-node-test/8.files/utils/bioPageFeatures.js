const db = require('../utils/db')

// The scalable piece: bio page feature flags aren't hardcoded per plan tier
// anywhere in code — they're read from plans.feature_limits (JSONB, added in
// migration 008) with defaults here. Adding a new gated feature later (an
// animation toggle, a banner block, more social icon slots, whatever gets
// decided) means adding one key to DEFAULTS + reading it below — no schema
// change, no new migration, no controller changes.
//
// Naming convention: prefix every key with "bio_page_" in the DB/JSON so
// this file's keys never collide with some other feature's flags sharing
// the same feature_limits column later.
const DEFAULTS = {
    bio_page_max_buttons: 6,
    bio_page_max_social_icons: 4,
    bio_page_animations_enabled: false,
    bio_page_banner_enabled: false
}

// Returns the resolved flags for an org — every key in DEFAULTS is
// guaranteed present in the result, using the plan's override if set.
const getBioPageFeatureFlags = async (organizationId) => {
    const { rows } = await db.query(
        `SELECT p.feature_limits
         FROM organizations o
         LEFT JOIN plans p ON p.plan_id = o.plan_id
         WHERE o.id = $1`,
        [organizationId]
    )
    const overrides = rows[0]?.feature_limits || {}
    return { ...DEFAULTS, ...overrides }
}

// Enforcement — called both at button-add time (immediate feedback in the
// builder) and again inside the publish transaction (defends against a plan
// downgrade happening between "added the 5th icon" and "hit publish").
// Mirrors the Moon Links checkFeatureAccess-inside-transaction pattern.
//
// draftPayload shape: { buttons: [{ buttonType, ... }, ...], ... }
const assertBioPageFeatureAccess = async (organizationId, draftPayload) => {
    const flags = await getBioPageFeatureFlags(organizationId)
    const buttons = draftPayload.buttons || []

    if (buttons.length > flags.bio_page_max_buttons) {
        return {
            allowed: false,
            reason: `your plan allows up to ${flags.bio_page_max_buttons} buttons (currently ${buttons.length})`
        }
    }

    const socialCount = buttons.filter((b) => b.buttonType === 'social').length
    if (socialCount > flags.bio_page_max_social_icons) {
        return {
            allowed: false,
            reason: `your plan allows up to ${flags.bio_page_max_social_icons} social icons (currently ${socialCount})`
        }
    }

    // Placeholder checks for not-yet-decided features — wired to the flag
    // now so turning them on later is a data change, not a code change.
    if (draftPayload.bannerAssetId && !flags.bio_page_banner_enabled) {
        return { allowed: false, reason: 'banner images are not available on your current plan' }
    }
    if (draftPayload.animationsEnabled && !flags.bio_page_animations_enabled) {
        return { allowed: false, reason: 'animations are not available on your current plan' }
    }

    return { allowed: true }
}

module.exports = { getBioPageFeatureFlags, assertBioPageFeatureAccess, DEFAULTS }
