// ------------------------------------------------------------------
// ADDITIVE PATCH to your existing utils/constants.js — not a full replace.
// Add this export alongside ORGANIZATION_TYPES and ASSET_OWNER_TYPES;
// everything else in your current constants.js is untouched.
// ------------------------------------------------------------------

// Curated color presets for the Bio Page builder (spec Section 3: "curated/
// gathered color pattern presets user can pick from" — deliberately not a
// raw hex picker). Add new presets here anytime; bioPageRenderer.js reads
// whichever key is stored in bio_pages.color_preset and falls back to
// 'default' if the stored key is ever missing/renamed.
const BIO_PAGE_COLOR_PRESETS = {
    default:  { primary: '#1D9E75', secondary: '#0F6E56', background: '#FFFFFF', text: '#1A1A1A' },
    midnight: { primary: '#4F46E5', secondary: '#312E81', background: '#0B1020', text: '#F5F5F5' },
    sunset:   { primary: '#F97316', secondary: '#EA580C', background: '#FFF7ED', text: '#1A1A1A' },
    rose:     { primary: '#DB2777', secondary: '#9D174D', background: '#FFF1F5', text: '#1A1A1A' },
    ocean:    { primary: '#0891B2', secondary: '#075985', background: '#F0FDFF', text: '#1A1A1A' }
}

module.exports.BIO_PAGE_COLOR_PRESETS = BIO_PAGE_COLOR_PRESETS
