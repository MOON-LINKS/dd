const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { getOrCreateDraftRow } = require('./bioPageController')
const { assertBioPageFeatureAccess } = require('../utils/bioPageFeatures')

const loadDraftPayloadForFeatureCheck = async (bioPageId) => {
    const { rows } = await db.query(
        'SELECT button_type FROM bio_page_buttons WHERE bio_page_id = $1',
        [bioPageId]
    )
    return { buttons: rows.map((r) => ({ buttonType: r.button_type })) }
}

// ------------------------------------------------------------------
// ADD BUTTON — checked against plan feature flags immediately, so the
// manager gets feedback in the builder rather than only at publish time.
// ------------------------------------------------------------------
const addBioPageButton = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { label, url, buttonType } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!label || !url || !['call', 'link', 'social'].includes(buttonType)) {
            return res.status(400).json({ message: 'label, url, and a valid buttonType are required' })
        }

        const bioPage = await getOrCreateDraftRow(organizationId)
        const existingPayload = await loadDraftPayloadForFeatureCheck(bioPage.id)
        const hypotheticalPayload = { buttons: [...existingPayload.buttons, { buttonType }] }

        const { allowed, reason } = await assertBioPageFeatureAccess(organizationId, hypotheticalPayload)
        if (!allowed) return res.status(402).json({ message: reason })

        const { rows: maxOrderRows } = await db.query(
            'SELECT COALESCE(MAX(sort_order), -1) + 1 AS next_order FROM bio_page_buttons WHERE bio_page_id = $1',
            [bioPage.id]
        )

        const { rows } = await db.query(
            `INSERT INTO bio_page_buttons (bio_page_id, label, url, button_type, sort_order)
             VALUES ($1, $2, $3, $4, $5)
             RETURNING id, label, url, button_type, sort_order`,
            [bioPage.id, label, url, buttonType, maxOrderRows[0].next_order]
        )
        res.status(201).json({ button: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not add button' })
    }
}

// ------------------------------------------------------------------
// UPDATE BUTTON
// ------------------------------------------------------------------
const updateBioPageButton = async (req, res) => {
    const { organizationId, buttonId } = req.params
    const userId = req.user.id
    const { label, url, buttonType } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (buttonType && !['call', 'link', 'social'].includes(buttonType)) {
            return res.status(400).json({ message: 'invalid buttonType' })
        }

        const { rows } = await db.query(
            `UPDATE bio_page_buttons b
             SET label = COALESCE($1, b.label),
                 url = COALESCE($2, b.url),
                 button_type = COALESCE($3, b.button_type)
             FROM bio_pages p
             WHERE b.id = $4 AND b.bio_page_id = p.id AND p.organization_id = $5
             RETURNING b.id, b.label, b.url, b.button_type, b.sort_order`,
            [label, url, buttonType, buttonId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'button not found' })
        res.status(200).json({ button: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update button' })
    }
}

// ------------------------------------------------------------------
// DELETE BUTTON
// ------------------------------------------------------------------
const deleteBioPageButton = async (req, res) => {
    const { organizationId, buttonId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `DELETE FROM bio_page_buttons b
             USING bio_pages p
             WHERE b.id = $1 AND b.bio_page_id = p.id AND p.organization_id = $2
             RETURNING b.id`,
            [buttonId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'button not found' })
        res.status(200).json({ message: 'button deleted' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not delete button' })
    }
}

// ------------------------------------------------------------------
// REORDER BUTTONS — body: { orderedButtonIds: [uuid, uuid, ...] }
// ------------------------------------------------------------------
const reorderBioPageButtons = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { orderedButtonIds } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!Array.isArray(orderedButtonIds) || orderedButtonIds.length === 0) {
            return res.status(400).json({ message: 'orderedButtonIds must be a non-empty array' })
        }

        const bioPage = await getOrCreateDraftRow(organizationId)
        await Promise.all(
            orderedButtonIds.map((buttonId, index) =>
                db.query(
                    'UPDATE bio_page_buttons SET sort_order = $1 WHERE id = $2 AND bio_page_id = $3',
                    [index, buttonId, bioPage.id]
                )
            )
        )
        res.status(200).json({ message: 'buttons reordered' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not reorder buttons' })
    }
}

module.exports = { addBioPageButton, updateBioPageButton, deleteBioPageButton, reorderBioPageButtons }
