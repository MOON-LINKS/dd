const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { getBioPageFeatureFlags } = require('../utils/bioPageFeatures')

const SLUG_PATTERN = /^[a-z0-9](?:[a-z0-9-]{1,98}[a-z0-9])?$/ // lowercase, dashes, 2-100 chars

// One bio page per org (schema: organization_id UNIQUE). This upserts an
// empty draft row on first access so the builder always has a row to PATCH
// against — the manager never has to explicitly "create" a bio page first.
const getOrCreateDraftRow = async (organizationId) => {
    const { rows } = await db.query(
        'SELECT * FROM bio_pages WHERE organization_id = $1',
        [organizationId]
    )
    if (rows.length > 0) return rows[0]

    const { rows: created } = await db.query(
        `INSERT INTO bio_pages (organization_id, slug)
         VALUES ($1, $2)
         RETURNING *`,
        [organizationId, `org-${organizationId.slice(0, 8)}`] // placeholder slug, manager renames before publishing
    )
    return created[0]
}

// ------------------------------------------------------------------
// GET EDITOR DATA — hydrates the builder: draft fields + buttons +
// this org's resolved feature flags (so the UI can show/hide/lock
// controls, e.g. disable "add banner" if the plan doesn't include it).
// ------------------------------------------------------------------
const getBioPageEditorData = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const bioPage = await getOrCreateDraftRow(organizationId)
        const { rows: buttons } = await db.query(
            'SELECT id, label, url, button_type, sort_order FROM bio_page_buttons WHERE bio_page_id = $1 ORDER BY sort_order ASC',
            [bioPage.id]
        )
        const featureFlags = await getBioPageFeatureFlags(organizationId)

        res.status(200).json({ bioPage, buttons, featureFlags })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch bio page' })
    }
}

// ------------------------------------------------------------------
// UPDATE DRAFT — title / shortBio / colorPreset / slug. Does NOT touch
// rendered_html or is_published — publishing is a separate explicit step.
// ------------------------------------------------------------------
const updateBioPageDraft = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { title, shortBio, colorPreset, slug } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        if (slug !== undefined) {
            if (!SLUG_PATTERN.test(slug)) {
                return res.status(400).json({ message: 'slug must be lowercase letters, numbers, and dashes only (2-100 chars)' })
            }
            const { rows: clash } = await db.query(
                'SELECT organization_id FROM bio_pages WHERE slug = $1 AND organization_id != $2',
                [slug, organizationId]
            )
            if (clash.length > 0) return res.status(409).json({ message: 'this slug is already taken' })
        }

        const bioPage = await getOrCreateDraftRow(organizationId)
        const { rows } = await db.query(
            `UPDATE bio_pages
             SET title = COALESCE($1, title),
                 short_bio = COALESCE($2, short_bio),
                 color_preset = COALESCE($3, color_preset),
                 slug = COALESCE($4, slug)
             WHERE id = $5
             RETURNING *`,
            [title, shortBio, colorPreset, slug, bioPage.id]
        )
        res.status(200).json({ bioPage: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update bio page' })
    }
}

// ------------------------------------------------------------------
// UPDATE LOGO — same two-step pattern as every other asset in the app:
// POST /assets first (assetType: 'bio_page', ownerType: 'bio_page'), then
// attach the returned assetId here.
// ------------------------------------------------------------------
const updateBioPageLogo = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { assetId } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const bioPage = await getOrCreateDraftRow(organizationId)
        const { rows } = await db.query(
            'UPDATE bio_pages SET logo_asset_id = $1 WHERE id = $2 RETURNING id, logo_asset_id',
            [assetId, bioPage.id]
        )
        res.status(200).json({ bioPage: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update bio page logo' })
    }
}

// ------------------------------------------------------------------
// SLUG AVAILABILITY — public, no auth required. Lets the builder
// live-check as the manager types without needing their own session.
// excludeOrganizationId lets a manager re-check their own current slug
// without it falsely showing as taken.
// ------------------------------------------------------------------
const checkSlugAvailability = async (req, res) => {
    const { slug, excludeOrganizationId } = req.query
    try {
        if (!slug || !SLUG_PATTERN.test(slug)) {
            return res.status(200).json({ available: false, reason: 'invalid format' })
        }
        const { rows } = await db.query(
            'SELECT organization_id FROM bio_pages WHERE slug = $1 AND organization_id != COALESCE($2, \'00000000-0000-0000-0000-000000000000\'::uuid)',
            [slug, excludeOrganizationId || null]
        )
        res.status(200).json({ available: rows.length === 0 })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not check slug availability' })
    }
}

module.exports = {
    getBioPageEditorData,
    updateBioPageDraft,
    updateBioPageLogo,
    checkSlugAvailability,
    getOrCreateDraftRow
}
