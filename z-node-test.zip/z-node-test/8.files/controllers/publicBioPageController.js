const db = require('../utils/db')
const { resolveAssetUrl } = require('../utils/cdn')

// ------------------------------------------------------------------
// GET PUBLIC HTML — the actual "HTML part" requested. No auth, no
// live query-and-render: this serves the cached rendered_html string
// exactly as it was written at the last publishBioPage call. Zero
// per-visit render cost, per spec Section 3.
// ------------------------------------------------------------------
const getPublicBioPageHtml = async (req, res) => {
    const { slug } = req.params
    try {
        const { rows } = await db.query(
            'SELECT rendered_html FROM bio_pages WHERE slug = $1 AND is_published = TRUE',
            [slug]
        )
        if (rows.length === 0 || !rows[0].rendered_html) {
            return res.status(404).type('html').send('<!DOCTYPE html><html><body><h1>Page not found</h1></body></html>')
        }
        res.status(200).type('html').send(rows[0].rendered_html)
    } catch (err) {
        console.error(err)
        res.status(500).type('html').send('<!DOCTYPE html><html><body><h1>Something went wrong</h1></body></html>')
    }
}

// ------------------------------------------------------------------
// GET PUBLIC DATA — JSON variant of the same published snapshot, for
// a Flutter client (or anything else) that wants to render the page
// natively instead of loading it as raw HTML/webview.
// ------------------------------------------------------------------
const getPublicBioPageData = async (req, res) => {
    const { slug } = req.params
    try {
        const { rows: pageRows } = await db.query(
            'SELECT id, title, short_bio, color_preset, is_published FROM bio_pages WHERE slug = $1',
            [slug]
        )
        if (pageRows.length === 0 || !pageRows[0].is_published) {
            return res.status(404).json({ message: 'page not found' })
        }
        const bioPageId = pageRows[0].id

        const { rows: snapshotRows } = await db.query(
            'SELECT payload FROM bio_page_snapshots WHERE bio_page_id = $1 ORDER BY version DESC LIMIT 1',
            [bioPageId]
        )
        const payload = snapshotRows[0]?.payload || null

        res.status(200).json({
            title: pageRows[0].title,
            shortBio: pageRows[0].short_bio,
            colorPreset: pageRows[0].color_preset,
            logoUrl: payload?.logoFilename ? resolveAssetUrl(payload.logoFilename) : null,
            buttons: payload?.buttons || []
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch bio page data' })
    }
}

module.exports = { getPublicBioPageHtml, getPublicBioPageData }
