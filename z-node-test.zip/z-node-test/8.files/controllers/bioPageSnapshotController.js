const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { getOrCreateDraftRow } = require('./bioPageController')
const { assertBioPageFeatureAccess } = require('../utils/bioPageFeatures')
const { renderBioPageHtml } = require('../utils/bioPageRenderer')

// Loads the draft row + its buttons and assembles the JSON payload shape
// that gets snapshotted (and handed to the renderer). Shared by publish
// and rollback so the two never drift on what "the payload" contains.
const buildDraftPayload = async (dbClient, bioPage) => {
    const { rows: buttons } = await dbClient.query(
        'SELECT id, label, url, button_type AS "buttonType", sort_order AS "sortOrder" FROM bio_page_buttons WHERE bio_page_id = $1 ORDER BY sort_order ASC',
        [bioPage.id]
    )
    let logoFilename = null
    if (bioPage.logo_asset_id) {
        const { rows: logoRows } = await dbClient.query('SELECT filename FROM assets WHERE id = $1', [bioPage.logo_asset_id])
        logoFilename = logoRows[0]?.filename || null
    }
    return {
        title: bioPage.title,
        shortBio: bioPage.short_bio,
        colorPreset: bioPage.color_preset,
        logoAssetId: bioPage.logo_asset_id,
        logoFilename,
        buttons
    }
}

// ------------------------------------------------------------------
// PUBLISH — the batch's centerpiece. Directly adapted from the Moon
// Links publishMenu pattern: versioned snapshot insert, old-version
// cleanup, then the "live" row update, all in one transaction, plus a
// feature-access check run inside the transaction (their
// checkFeatureAccess call, here assertBioPageFeatureAccess) so a plan
// downgrade that happens mid-edit can't slip an over-limit page live.
// ------------------------------------------------------------------
const publishBioPage = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const bioPage = await getOrCreateDraftRow(organizationId)
        if (!bioPage.title || !bioPage.slug) {
            return res.status(400).json({ message: 'title and slug are required before publishing' })
        }

        const client = await db.connect()
        try {
            await client.query('BEGIN')

            const payload = await buildDraftPayload(client, bioPage)

            // Feature-access re-check, inside the transaction — mirrors
            // publishMenu's checkFeatureAccess call happening after the
            // snapshot write but before commit.
            const { allowed, reason } = await assertBioPageFeatureAccess(organizationId, payload)
            if (!allowed) {
                await client.query('ROLLBACK')
                return res.status(402).json({ message: reason })
            }

            const { rows: versionRows } = await client.query(
                'SELECT MAX(version) AS last_version FROM bio_page_snapshots WHERE bio_page_id = $1',
                [bioPage.id]
            )
            const newVersion = (versionRows[0].last_version || 0) + 1

            await client.query(
                'INSERT INTO bio_page_snapshots (bio_page_id, version, payload) VALUES ($1, $2, $3)',
                [bioPage.id, newVersion, JSON.stringify(payload)]
            )

            // Cleanup: keep only the latest 2 versions. Postgres equivalent
            // of the MySQL DELETE...JOIN in publishMenu (Postgres uses
            // DELETE...USING instead of DELETE...JOIN).
            await client.query(
                `DELETE FROM bio_page_snapshots s
                 USING (SELECT MAX(version) AS max_version FROM bio_page_snapshots WHERE bio_page_id = $1) t
                 WHERE s.bio_page_id = $1 AND s.version < t.max_version - 1`,
                [bioPage.id]
            )

            const renderedHtml = renderBioPageHtml(payload)

            await client.query(
                `UPDATE bio_pages
                 SET rendered_html = $1, last_rendered_at = NOW(), is_published = TRUE
                 WHERE id = $2`,
                [renderedHtml, bioPage.id]
            )

            await client.query('COMMIT')
            res.status(200).json({ message: 'bio page published', version: newVersion })
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {})
            throw err
        } finally {
            client.release()
        }
    } catch (err) {
        console.error('PUBLISH FAILED:', err)
        res.status(500).json({ message: 'publish failed', error: err.message })
    }
}

// ------------------------------------------------------------------
// UNPUBLISH — takes the page offline (public route stops serving it)
// without touching the draft or snapshot history. Re-publishing later
// creates a new version rather than resurrecting the old rendered_html
// as-is, in case the draft changed while unpublished.
// ------------------------------------------------------------------
const unpublishBioPage = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const bioPage = await getOrCreateDraftRow(organizationId)
        await db.query('UPDATE bio_pages SET is_published = FALSE WHERE id = $1', [bioPage.id])
        res.status(200).json({ message: 'bio page unpublished' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not unpublish bio page' })
    }
}

// ------------------------------------------------------------------
// LIST VERSIONS — publish history, enabled directly by the snapshot
// table. Only version + created_at, not the full payload (keeps the
// list light; rollback below fetches the full payload for one version).
// ------------------------------------------------------------------
const listBioPageVersions = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const bioPage = await getOrCreateDraftRow(organizationId)
        const { rows } = await db.query(
            'SELECT version, created_at FROM bio_page_snapshots WHERE bio_page_id = $1 ORDER BY version DESC',
            [bioPage.id]
        )
        res.status(200).json({ versions: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch version history' })
    }
}

// ------------------------------------------------------------------
// ROLLBACK TO VERSION — loads a past snapshot's payload back into the
// DRAFT (bio_pages fields + bio_page_buttons rows). Does NOT auto-
// republish — manager reviews the restored draft, then hits Publish
// again, which creates a new version rather than reusing the old one.
// ------------------------------------------------------------------
const rollbackBioPageToVersion = async (req, res) => {
    const { organizationId, version } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const bioPage = await getOrCreateDraftRow(organizationId)

        const { rows: snapshotRows } = await db.query(
            'SELECT payload FROM bio_page_snapshots WHERE bio_page_id = $1 AND version = $2',
            [bioPage.id, version]
        )
        if (snapshotRows.length === 0) return res.status(404).json({ message: 'version not found' })
        const payload = snapshotRows[0].payload

        const client = await db.connect()
        try {
            await client.query('BEGIN')
            await client.query(
                `UPDATE bio_pages
                 SET title = $1, short_bio = $2, color_preset = $3, logo_asset_id = $4
                 WHERE id = $5`,
                [payload.title, payload.shortBio, payload.colorPreset, payload.logoAssetId, bioPage.id]
            )
            await client.query('DELETE FROM bio_page_buttons WHERE bio_page_id = $1', [bioPage.id])
            for (const button of payload.buttons || []) {
                await client.query(
                    `INSERT INTO bio_page_buttons (bio_page_id, label, url, button_type, sort_order)
                     VALUES ($1, $2, $3, $4, $5)`,
                    [bioPage.id, button.label, button.url, button.buttonType, button.sortOrder || 0]
                )
            }
            await client.query('COMMIT')
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {})
            throw err
        } finally {
            client.release()
        }

        res.status(200).json({ message: `draft restored from version ${version} — review and publish to go live` })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not roll back to this version' })
    }
}

module.exports = { publishBioPage, unpublishBioPage, listBioPageVersions, rollbackBioPageToVersion }
