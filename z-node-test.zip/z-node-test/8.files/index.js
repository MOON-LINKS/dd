// Reference only — merge these lines into your real index.js, don't overwrite it.

const bioPageRoutes = require('./routes/bioPageRoutes')
const publicBioPageRoutes = require('./routes/publicBioPageRoutes')

// Nested resource, same mergeParams pattern as workers/jobs/etc.
app.use('/organizations/:organizationId/bio-page', bioPageRoutes)

// Top-level, public, no auth — this is the actual link-in-bio URL surface.
// e.g. https://yourdomain.com/bio/some-org-slug
app.use('/bio', publicBioPageRoutes)
