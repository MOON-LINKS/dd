# This Batch — Bio Page Builder (+ scalable feature-flag foundation)

Section 3's Bio Page Builder, built on the versioned-snapshot pattern from
your `publishMenu` reference — adapted from MySQL/callback style to
Postgres/async-await, matching every other batch.

## New files, ready to drop into your project structure

| File | Goes in |
|---|---|
| `controllers/bioPageController.js` | `controllers/` |
| `controllers/bioPageButtonController.js` | `controllers/` |
| `controllers/bioPageSnapshotController.js` | `controllers/` |
| `controllers/publicBioPageController.js` | `controllers/` |
| `routes/bioPageRoutes.js` | `routes/` |
| `routes/publicBioPageRoutes.js` | `routes/` |
| `utils/bioPageFeatures.js` | `utils/` |
| `utils/bioPageRenderer.js` | `utils/` |
| `utils/constants.additions.js` | **not a drop-in** — copy the `BIO_PAGE_COLOR_PRESETS` export into your existing `utils/constants.js`, don't overwrite the file |
| `migrations/008_bio_pages.sql` | run against your DB before testing this batch |
| `index.js` | reference delta only — two `app.use` lines to add |

## Required before this batch will run

**1. Run `migrations/008_bio_pages.sql`.** Two changes:
- `plans.feature_limits` — new JSONB column, default `'{}'`. This is the
  scalable piece you asked for: not bio-page-specific in the schema, so any
  future feature-gated count/toggle (not just bio page ones) can add a key
  here without another migration.
- `bio_page_snapshots` — new table. Versioned publish history, mirroring
  your `menu_snapshots` pattern.

**2. Patch `utils/constants.js`** — add the `BIO_PAGE_COLOR_PRESETS` export
from `constants.additions.js`. Everything else in your constants file is
untouched. (`ASSET_OWNER_TYPES` already includes `'bio_page'` from Batch 2 —
no change needed there.)

**3. `utils/cdn.js` and `middleware/auth.js` must already exist** — this
batch imports both (`resolveAssetUrl`, `requireAuth`) rather than
reimplementing them. If you're applying batches out of order, Batches 6 and
7 need to land first.

**4. Optional env var:**
```
APP_NAME=YourAppName   # shown in the public bio page's footer; defaults to "YOUR_APP_NAME" if unset
```

## What's built

- **Editor/draft** (`bioPageController.js`) — `getBioPageEditorData` upserts
  an empty draft row on first access (one bio page per org, matching the
  schema's `UNIQUE(organization_id)`), so there's no separate "create bio
  page" step. `updateBioPageDraft` handles title/bio/color preset/slug, with
  slug format validation and a uniqueness check. `checkSlugAvailability` is
  public/unauthenticated so the builder can live-check as the manager types.
- **Buttons** (`bioPageButtonController.js`) — full CRUD + reorder. Every
  add is checked against `assertBioPageFeatureAccess` *before* insert — the
  manager gets immediate feedback in the builder, not just a rejection at
  publish time.
- **Publish** (`bioPageSnapshotController.js`) — this is the direct
  adaptation of `publishMenu`:
  - Runs in a transaction (`BEGIN`/`COMMIT`/`ROLLBACK`, `pool.connect()` +
    `client.release()` — same shape as `invoiceController.js` from Batch 7).
  - Writes a new row to `bio_page_snapshots` with the next `version`.
  - Cleans up old versions, keeping the latest 2 — same intent as your
    `cleanupQuery`, translated to Postgres (`DELETE ... USING` instead of
    MySQL's `DELETE ... JOIN`).
  - Re-runs the feature-access check **inside** the transaction (your
    `checkFeatureAccess` call, here `assertBioPageFeatureAccess`) — catches
    the edge case where a plan downgrade happens between adding a 5th social
    icon and hitting Publish.
  - Renders and caches `rendered_html` via `bioPageRenderer.js`, sets
    `is_published = TRUE`.
  - `unpublishBioPage` — just flips the flag, keeps history intact.
  - `listBioPageVersions` / `rollbackBioPageToVersion` — a bonus enabled
    directly by having versioned snapshots: restores a past version's
    payload back into the *draft* (not live) so the manager reviews before
    re-publishing.
- **Public serving** (`publicBioPageController.js`) — the "HTML part" you
  asked for directly: `getPublicBioPageHtml` serves the cached
  `rendered_html` string byte-for-byte, no auth, no live render, no DB joins
  beyond the one lookup — this is the zero-per-visit-cost path from spec
  Section 3. `getPublicBioPageData` is the JSON counterpart for a Flutter
  client that wants to render the page natively instead of loading raw HTML
  — reads the latest snapshot's payload directly rather than re-deriving it
  from the live draft tables (a rolled-back-but-not-yet-republished draft
  should never leak into what's publicly visible).
- **Scalable feature flags** (`utils/bioPageFeatures.js`) — the actual thing
  you asked for beyond just "build bio pages." `DEFAULTS` + one
  `feature_limits` JSONB column means adding a real feature later (an
  animation toggle, a banner block, more icon slots — whatever you land on)
  is a data change, not a schema change, not a controller change. Two
  placeholder checks (`bannerAssetId`, `animationsEnabled`) are wired into
  `assertBioPageFeatureAccess` already, reading flags that don't do anything
  yet on the frontend — they're there so the enforcement path exists before
  you've decided the exact feature, matching what you described wanting.

## Deliberately left out of this batch

- **Actually deciding what the gated features are** — `bio_page_banner_enabled`
  and `bio_page_animations_enabled` are read and enforced, but nothing in
  this batch adds a banner or animation *feature* to the renderer or the
  builder payload. They're plumbing, not product decisions — you said you
  haven't chosen yet, so nothing was invented here.
- **Module-level gating on Bio Pages itself** (i.e. is Bio Pages a
  `plans.modules` entry that some tier doesn't get at all) — only per-feature
  limits *within* bio pages are gated. If the whole feature should be
  lockable per plan too, that's a `hasModule(organizationId, 'bio_page')`
  check added to `getBioPageEditorData` — small addition, not built because
  it wasn't asked for and Section 9's `modules` example list already
  includes `"bio_page"` as if it's assumed available on some tier, which
  conflicts with gating the whole thing off entirely on others. Flagging the
  ambiguity rather than guessing.
- **Referrals, `deleteOrganization`, `sendBillReminders`** — unchanged from
  where earlier batches left them.

## Suggested next

Referrals is the last fully-scoped, fully-unblocked module left on the
original list — small, and closes out the backend's feature surface before
you move to Flutter as planned.
