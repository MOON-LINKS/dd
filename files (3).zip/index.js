require('dotenv').config()
const express = require('express')
const cookieParser = require('cookie-parser')

const authRoutes = require('./routes/authRoutes')
const organizationRoutes = require('./routes/organizationRoutes')
const workerRoutes = require('./routes/workerRoutes')
const assetRoutes = require('./routes/assetRoutes')

const app = express()

app.use(express.json())
app.use(cookieParser())

app.use('/auth', authRoutes)
app.use('/organizations', organizationRoutes)
// Nested resource: /organizations/:organizationId/workers/...
// mergeParams on workerRoutes lets it read :organizationId from this mount.
app.use('/organizations/:organizationId/workers', workerRoutes)
app.use('/assets', assetRoutes)

app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }))

const PORT = process.env.PORT || 4000
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`))

module.exports = app
