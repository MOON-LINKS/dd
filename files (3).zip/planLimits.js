const db = require('./db')

// Reads the org's current plan limits. Returns null if the org has no
// plan yet (pre-payment) — callers decide what "no plan" should block.
const getOrgPlanLimits = async (organizationId) => {
    const { rows } = await db.query(
        `SELECT p.max_workers, p.modules, p.history_months
         FROM organizations o
         JOIN plans p ON p.plan_id = o.plan_id
         WHERE o.id = $1`,
        [organizationId]
    )
    return rows[0] || null
}

// Server-side enforcement per spec Section 9: frontend hiding/showing UI
// based on plan is UX only — every limited action must be re-checked here,
// never trusted from the client.
const canAddWorker = async (organizationId) => {
    const limits = await getOrgPlanLimits(organizationId)
    if (!limits) return { allowed: false, reason: 'organization has no active plan' }
    if (limits.max_workers === -1) return { allowed: true }

    const { rows } = await db.query(
        'SELECT COUNT(*) FROM workers WHERE organization_id = $1 AND deleted_at IS NULL',
        [organizationId]
    )
    const currentCount = parseInt(rows[0].count, 10)
    if (currentCount >= limits.max_workers) {
        return { allowed: false, reason: `plan limit reached (${limits.max_workers} workers)` }
    }
    return { allowed: true }
}

const hasModule = async (organizationId, moduleKey) => {
    const limits = await getOrgPlanLimits(organizationId)
    if (!limits) return false
    return (limits.modules || []).includes(moduleKey)
}

module.exports = { getOrgPlanLimits, canAddWorker, hasModule }
