const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId from parent mount
const {
    createWorker,
    listWorkers,
    getWorker,
    updateWorker,
    updateWorkerAsset,
    deleteWorker,
    getWorkerHoursSummary
} = require('../controllers/workerController')
const requireAuth = require('../middleware/auth') // TODO: shared once you provide the real middleware

router.post('/', requireAuth, createWorker)
router.get('/', requireAuth, listWorkers)
router.get('/:workerId', requireAuth, getWorker)
router.patch('/:workerId', requireAuth, updateWorker)
router.patch('/:workerId/asset', requireAuth, updateWorkerAsset)
router.delete('/:workerId', requireAuth, deleteWorker)
router.get('/:workerId/hours-summary', requireAuth, getWorkerHoursSummary)

module.exports = router
