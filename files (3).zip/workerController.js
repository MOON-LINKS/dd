const db = require('../utils/db')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { canAddWorker } = require('../utils/planLimits')

// All routes here are nested under /organizations/:organizationId/workers —
// organizationId comes from the URL, ownership is checked once per request
// via userOwnsOrganization rather than re-resolving it (that resolver is for
// cases like asset upload where only a worker/job/etc id is known up front).

const validatePayTypeFields = ({ payType, monthlyAmount, hourlyRate }) => {
    if (payType === 'monthly' && (monthlyAmount === undefined || monthlyAmount === null)) {
        return 'monthlyAmount is required when payType is monthly'
    }
    if (payType === 'hourly' && (hourlyRate === undefined || hourlyRate === null)) {
        return 'hourlyRate is required when payType is hourly'
    }
    if (!['monthly', 'hourly'].includes(payType)) {
        return 'payType must be monthly or hourly'
    }
    return null
}

// ------------------------------------------------------------------
// CREATE WORKER
// ------------------------------------------------------------------
const createWorker = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    const { name, payType, monthlyAmount, hourlyRate } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!name) return res.status(400).json({ message: 'name is required' })

        const validationError = validatePayTypeFields({ payType, monthlyAmount, hourlyRate })
        if (validationError) return res.status(400).json({ message: validationError })

        const { allowed, reason } = await canAddWorker(organizationId)
        if (!allowed) return res.status(402).json({ message: reason }) // 402 Payment Required — plan limit

        const { rows } = await db.query(
            `INSERT INTO workers (organization_id, name, pay_type, monthly_amount, hourly_rate)
             VALUES ($1, $2, $3, $4, $5)
             RETURNING id, name, pay_type, monthly_amount, hourly_rate, created_at`,
            [organizationId, name, payType, monthlyAmount || null, hourlyRate || null]
        )
        res.status(201).json({ worker: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create worker' })
    }
}

// ------------------------------------------------------------------
// LIST WORKERS
// ------------------------------------------------------------------
const listWorkers = async (req, res) => {
    const { organizationId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `SELECT w.id, w.name, w.pay_type, w.monthly_amount, w.hourly_rate, w.created_at,
                    pa.filename AS profile_image_filename
             FROM workers w
             LEFT JOIN assets pa ON pa.id = w.profile_image_id
             WHERE w.organization_id = $1 AND w.deleted_at IS NULL
             ORDER BY w.created_at DESC`,
            [organizationId]
        )
        res.status(200).json({ workers: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch workers' })
    }
}

// ------------------------------------------------------------------
// GET WORKER
// ------------------------------------------------------------------
const getWorker = async (req, res) => {
    const { organizationId, workerId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `SELECT w.*, pa.filename AS profile_image_filename, ida.filename AS id_document_filename
             FROM workers w
             LEFT JOIN assets pa ON pa.id = w.profile_image_id
             LEFT JOIN assets ida ON ida.id = w.id_document_id
             WHERE w.id = $1 AND w.organization_id = $2 AND w.deleted_at IS NULL`,
            [workerId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'worker not found' })
        res.status(200).json({ worker: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch worker' })
    }
}

// ------------------------------------------------------------------
// UPDATE WORKER
// ------------------------------------------------------------------
const updateWorker = async (req, res) => {
    const { organizationId, workerId } = req.params
    const userId = req.user.id
    const { name, payType, monthlyAmount, hourlyRate } = req.body
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (payType) {
            const validationError = validatePayTypeFields({ payType, monthlyAmount, hourlyRate })
            if (validationError) return res.status(400).json({ message: validationError })
        }

        const { rows } = await db.query(
            `UPDATE workers
             SET name = COALESCE($1, name),
                 pay_type = COALESCE($2, pay_type),
                 monthly_amount = CASE WHEN $2 = 'monthly' THEN $3 ELSE monthly_amount END,
                 hourly_rate = CASE WHEN $2 = 'hourly' THEN $4 ELSE hourly_rate END
             WHERE id = $5 AND organization_id = $6 AND deleted_at IS NULL
             RETURNING id, name, pay_type, monthly_amount, hourly_rate`,
            [name, payType, monthlyAmount, hourlyRate, workerId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'worker not found' })
        res.status(200).json({ worker: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update worker' })
    }
}

// ------------------------------------------------------------------
// UPDATE WORKER PROFILE IMAGE / ID DOCUMENT — same two-step pattern as
// organization logo: upload via /assets first, then attach the filename.
// ------------------------------------------------------------------
const updateWorkerAsset = async (req, res) => {
    const { organizationId, workerId } = req.params
    const userId = req.user.id
    const { assetId, field } = req.body // field: 'profile_image_id' | 'id_document_id'
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        if (!['profile_image_id', 'id_document_id'].includes(field)) {
            return res.status(400).json({ message: 'field must be profile_image_id or id_document_id' })
        }

        const { rows } = await db.query(
            `UPDATE workers SET ${field} = $1
             WHERE id = $2 AND organization_id = $3 AND deleted_at IS NULL
             RETURNING id, ${field}`,
            [assetId, workerId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'worker not found' })
        res.status(200).json({ worker: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update worker asset' })
    }
}

// ------------------------------------------------------------------
// DELETE WORKER (soft delete)
// ------------------------------------------------------------------
const deleteWorker = async (req, res) => {
    const { organizationId, workerId } = req.params
    const userId = req.user.id
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }
        const { rows } = await db.query(
            `UPDATE workers SET deleted_at = NOW()
             WHERE id = $1 AND organization_id = $2 AND deleted_at IS NULL
             RETURNING id`,
            [workerId, organizationId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'worker not found' })
        res.status(200).json({ message: 'worker deleted' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not delete worker' })
    }
}

// ------------------------------------------------------------------
// GET WORKER HOURS SUMMARY — read-only aggregate, feeds the worker
// detail page. Optional ?from=&to= date range (defaults to all-time).
// ------------------------------------------------------------------
const getWorkerHoursSummary = async (req, res) => {
    const { organizationId, workerId } = req.params
    const userId = req.user.id
    const { from, to } = req.query
    try {
        if (!(await userOwnsOrganization(userId, organizationId))) {
            return res.status(403).json({ message: 'you do not have access to this organization' })
        }

        const { rows: workerRows } = await db.query(
            'SELECT pay_type, monthly_amount, hourly_rate FROM workers WHERE id = $1 AND organization_id = $2',
            [workerId, organizationId]
        )
        if (workerRows.length === 0) return res.status(404).json({ message: 'worker not found' })
        const worker = workerRows[0]

        const { rows } = await db.query(
            `SELECT COALESCE(SUM(da.hours), 0) AS total_hours, COUNT(DISTINCT jd.job_id) AS jobs_worked
             FROM day_assignments da
             JOIN job_days jd ON jd.id = da.job_day_id
             WHERE da.worker_id = $1
               AND ($2::date IS NULL OR jd.date >= $2)
               AND ($3::date IS NULL OR jd.date <= $3)`,
            [workerId, from || null, to || null]
        )

        const totalHours = parseFloat(rows[0].total_hours)
        const amountOwed = worker.pay_type === 'hourly' ? totalHours * parseFloat(worker.hourly_rate) : null

        res.status(200).json({
            totalHours,
            jobsWorked: parseInt(rows[0].jobs_worked, 10),
            payType: worker.pay_type,
            amountOwed // null for monthly workers — hours tracked for analytics only, not owed calc
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch worker hours summary' })
    }
}

module.exports = {
    createWorker,
    listWorkers,
    getWorker,
    updateWorker,
    updateWorkerAsset,
    deleteWorker,
    getWorkerHoursSummary
}
