const db = require('../utils/db')
const { ORGANIZATION_TYPES } = require('../utils/constants')

// ------------------------------------------------------------------
// CREATE ORGANIZATION — the onboarding step right after verifyOTP,
// before payment. Sets organizationType (drives all localized labels,
// Section 6) but does NOT set a plan yet — plan_id stays null until
// checkout. Everything else in the app depends on an organization_id
// existing, so this is the first real "workspace" endpoint.
// ------------------------------------------------------------------
const createOrganization = async (req, res) => {
    const { name, organizationType } = req.body
    const ownerUserId = req.user.id
    try {
        if (!name || !organizationType) {
            return res.status(400).json({ message: 'name and organizationType are required' })
        }
        if (!ORGANIZATION_TYPES.includes(organizationType)) {
            return res.status(400).json({ message: `unknown organizationType: ${organizationType}` })
        }

        const { rows } = await db.query(
            `INSERT INTO organizations (owner_user_id, name, organization_type)
             VALUES ($1, $2, $3)
             RETURNING id, name, organization_type, plan_id, created_at`,
            [ownerUserId, name, organizationType]
        )

        res.status(201).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not create organization' })
    }
}

// ------------------------------------------------------------------
// LIST MY ORGANIZATIONS — supports a user owning more than one
// workspace (e.g. runs two separate businesses).
// ------------------------------------------------------------------
const listMyOrganizations = async (req, res) => {
    const ownerUserId = req.user.id
    try {
        const { rows } = await db.query(
            `SELECT id, name, organization_type, plan_id, logo_filename, created_at
             FROM organizations
             WHERE owner_user_id = $1 AND deleted_at IS NULL
             ORDER BY created_at ASC`,
            [ownerUserId]
        )
        res.status(200).json({ organizations: rows })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch organizations' })
    }
}

// ------------------------------------------------------------------
// GET ORGANIZATION — full profile for the Settings > Org profile
// screen and the header dropdown.
// ------------------------------------------------------------------
const getOrganization = async (req, res) => {
    const { organizationId } = req.params
    const ownerUserId = req.user.id
    try {
        const { rows } = await db.query(
            `SELECT o.id, o.name, o.organization_type, o.logo_filename, o.plan_id, o.created_at,
                    p.name AS plan_name, p.max_workers, p.modules
             FROM organizations o
             LEFT JOIN plans p ON p.plan_id = o.plan_id
             WHERE o.id = $1 AND o.owner_user_id = $2 AND o.deleted_at IS NULL`,
            [organizationId, ownerUserId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'organization not found' })
        res.status(200).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not fetch organization' })
    }
}

// ------------------------------------------------------------------
// UPDATE ORGANIZATION — name / organizationType only. Logo goes
// through the generic asset upload flow, then updateOrganizationLogo
// below patches the filename in.
// ------------------------------------------------------------------
const updateOrganization = async (req, res) => {
    const { organizationId } = req.params
    const ownerUserId = req.user.id
    const { name, organizationType } = req.body
    try {
        if (organizationType && !ORGANIZATION_TYPES.includes(organizationType)) {
            return res.status(400).json({ message: `unknown organizationType: ${organizationType}` })
        }

        const { rows } = await db.query(
            `UPDATE organizations
             SET name = COALESCE($1, name),
                 organization_type = COALESCE($2, organization_type)
             WHERE id = $3 AND owner_user_id = $4 AND deleted_at IS NULL
             RETURNING id, name, organization_type`,
            [name, organizationType, organizationId, ownerUserId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'organization not found' })
        res.status(200).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update organization' })
    }
}

// ------------------------------------------------------------------
// UPDATE ORGANIZATION LOGO — called after POST /assets returns a
// filename for assetType 'logo', ownerType 'organization'.
// ------------------------------------------------------------------
const updateOrganizationLogo = async (req, res) => {
    const { organizationId } = req.params
    const ownerUserId = req.user.id
    const { filename } = req.body
    try {
        if (!filename) return res.status(400).json({ message: 'filename is required' })

        const { rows } = await db.query(
            `UPDATE organizations
             SET logo_filename = $1
             WHERE id = $2 AND owner_user_id = $3 AND deleted_at IS NULL
             RETURNING id, logo_filename`,
            [filename, organizationId, ownerUserId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'organization not found' })
        res.status(200).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not update organization logo' })
    }
}

// ------------------------------------------------------------------
// SELECT PLAN — TEMPORARY placeholder. Once Stripe/Tap is chosen and
// checkout + webhooks are built, this goes away: plan_id will only be
// set by the webhook handler after a successful payment (alongside
// creating the subscribed_services row). This exists now purely so
// organizations aren't stuck plan-less during local/manual testing.
// ------------------------------------------------------------------
const selectPlan = async (req, res) => {
    const { organizationId } = req.params
    const ownerUserId = req.user.id
    const { planId } = req.body
    try {
        const { rows: planRows } = await db.query(
            'SELECT plan_id FROM plans WHERE plan_id = $1 AND is_active = TRUE',
            [planId]
        )
        if (planRows.length === 0) return res.status(404).json({ message: 'plan not found or inactive' })

        const { rows } = await db.query(
            `UPDATE organizations
             SET plan_id = $1
             WHERE id = $2 AND owner_user_id = $3 AND deleted_at IS NULL
             RETURNING id, plan_id`,
            [planId, organizationId, ownerUserId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'organization not found' })
        res.status(200).json({ organization: rows[0] })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not select plan' })
    }
}

module.exports = {
    createOrganization,
    listMyOrganizations,
    getOrganization,
    updateOrganization,
    updateOrganizationLogo,
    selectPlan
}
