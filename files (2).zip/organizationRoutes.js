const express = require('express')
const router = express.Router()
const {
    createOrganization,
    listMyOrganizations,
    getOrganization,
    updateOrganization,
    updateOrganizationLogo,
    selectPlan
} = require('../controllers/organizationController')
const requireAuth = require('../middleware/auth') // TODO: shared once you provide the real middleware

router.post('/', requireAuth, createOrganization)
router.get('/', requireAuth, listMyOrganizations)
router.get('/:organizationId', requireAuth, getOrganization)
router.patch('/:organizationId', requireAuth, updateOrganization)
router.patch('/:organizationId/logo', requireAuth, updateOrganizationLogo)
router.patch('/:organizationId/plan', requireAuth, selectPlan) // TEMP — see controller comment

module.exports = router
