// Target verticals from spec Section 1. Extensible — see the localization
// fallback pattern in Section 6 (default_{fieldKey}) for how new types launch
// safely before their custom wording is written.
const ORGANIZATION_TYPES = [
    'construction',
    'tutoring',
    'gym',
    'contractor',
    'sales',
    'cleaning'
]

// Polymorphic owner_type values used by the assets table and asset uploads.
const ASSET_OWNER_TYPES = ['organization', 'worker', 'bio_page', 'upcoming_bill']

module.exports = { ORGANIZATION_TYPES, ASSET_OWNER_TYPES }
