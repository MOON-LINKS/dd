/*
 * REFERENCE FILE — delta only. Add these lines to your real index.js
 * (the one already updated per Batch 5's reference file) rather than
 * replacing it. Two additions, no ordering constraints this time — unlike
 * Batch 5's webhook routes, neither of these needs to sit before
 * express.json().
 */

const invoiceRoutes = require('./routes/invoiceRoutes')
const invoiceCronRoutes = require('./routes/invoiceCronRoutes')

// Nested under organizations, alongside workers/clients/jobs/expenses/etc.
app.use('/organizations/:organizationId/invoices', invoiceRoutes)

// NOT org-scoped, NOT requireAuth — see routes/invoiceCronRoutes.js for the
// shared-secret gate. Point your scheduler at POST /cron/generate-monthly-invoices.
app.use('/cron', invoiceCronRoutes)
