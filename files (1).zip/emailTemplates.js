// One function per email event type (spec Section 9: "each task/event type has its own template").
// TODO: wire these into the Section 6 localization system (en/ar/fr) once locale JSON files exist —
// each function should accept a `locale` param and pull subject/body strings from the JSON keys
// instead of the hardcoded English below.

const APP_NAME = 'YOUR_APP_NAME' // TODO: replace once product name is finalized

const wrapper = (title, bodyHtml) => `
<div style="font-family: Arial, sans-serif; background:#f6f6f6; padding:20px;">
    <div style="max-width:500px; margin:auto; background:white; padding:20px; border-radius:10px;">
        <img
            src="https://cdn.mydomain.com/imgs/logo.png"
            alt="${APP_NAME}"
            style="width:140px; margin-bottom:20px;"
        />
        <h2 style="color:#111;">${title}</h2>
        ${bodyHtml}
        <hr>
        <p style="font-size:12px; color:#8d209b;">
            If you did not request this, you can ignore this email.
        </p>
    </div>
</div>`

const otpCodeBlock = (otp) => `
<div style="
    font-size:24px;
    font-weight:bold;
    letter-spacing:4px;
    background:#f0f0f0;
    padding:10px;
    text-align:center;
    border-radius:6px;
">
    ${otp}
</div>`

const registrationOtpEmail = ({ name, otp }) => ({
    subject: `Verify your ${APP_NAME} account`,
    text: `Hello ${name}, your verification code is ${otp}`,
    html: wrapper(
        `${APP_NAME} Verification`,
        `<p>Hello ${name},</p><p>Your verification code is:</p>${otpCodeBlock(otp)}`
    )
})

const passwordResetOtpEmail = ({ otp }) => ({
    subject: `Reset your ${APP_NAME} password`,
    text: `Your password reset code is ${otp}`,
    html: wrapper(
        'Password Reset',
        `<p>Your password reset code is:</p>${otpCodeBlock(otp)}`
    )
})

const welcomeEmail = ({ name }) => ({
    subject: `Welcome to ${APP_NAME}`,
    text: `Hi ${name}, your account is verified and ready to go.`,
    html: wrapper('Welcome!', `<p>Hi ${name}, your account is verified and ready to go.</p>`)
})

module.exports = { registrationOtpEmail, passwordResetOtpEmail, welcomeEmail }
