package com.example.z_dart_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
