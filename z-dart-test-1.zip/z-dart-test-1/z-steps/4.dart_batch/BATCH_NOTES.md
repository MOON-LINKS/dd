# Dart Batch 4 — Worker models + list/create/edit form

Implements both decisions from last time: hand-written classes (no codegen),
and the smallest useful slice (list + create/edit form, not a full detail
page yet).

## New files

| File | Goes in |
|---|---|
| `lib/api/models/worker.dart` | new |
| `lib/api/models/worker_hours_summary.dart` | new |
| `lib/features/shell/providers/current_organization_provider.dart` | new |
| `lib/features/workers/providers/workers_provider.dart` | new |
| `lib/features/workers/screens/workers_list_screen.dart` | new |
| `lib/features/workers/screens/worker_form_screen.dart` | new |
| `lib/features/workers/widgets/worker_list_tile.dart` | new |

## Replaces existing files — diff before overwriting if you want to confirm

| File | What changed |
|---|---|
| `lib/api/services/worker_api.dart` | Every method now returns `Worker`/`WorkerHoursSummary` instead of raw `Map<String, dynamic>`. Request/response shapes on the wire are unchanged — this is a typing change, not an API contract change. |
| `lib/app/router.dart` | Two-line diff: one new import, and `_screenForPath('/workers', ...)` now returns `WorkersListScreen()` instead of falling through to `PlaceholderScreen`. Nothing else touched. |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | Ten new keys appended to each (see below) — everything already in these files is untouched. Run `flutter gen-l10n` (or just `flutter pub get`, since `generate: true` is already set in your pubspec) after replacing these so the new `AppLocalizations.of(context)!.xxx` getters exist. |

## Why `Worker.fromJson` reads snake_case

Worth knowing before you extend this pattern to the next entity: the
backend's create/list/get/update worker endpoints all return raw Postgres
rows (`pay_type`, `monthly_amount`, `created_at`), not hand-built response
objects — so `fromJson` reads snake_case. But the *request* bodies those
same endpoints expect are camelCase (`payType`, `monthlyAmount`) — that's
how `workerController.js` destructures `req.body`. `Worker.toJson()` and the
raw maps `WorkerApi.create`/`update` send are camelCase; `Worker.fromJson`
is snake_case. Both are correct — they're reading different shapes going
different directions, not an inconsistency. `WorkerHoursSummary.fromJson` is
the one exception: that endpoint builds its response object by hand
(`workerController.js`'s `getWorkerHoursSummary`) instead of returning raw
rows, so it's already camelCase both ways — noted in that file's doc comment
so it isn't mistaken for a copy-paste mismatch later.

## `currentOrganizationIdProvider` — small piece of shared infra, not scope creep

`app_shell_screen.dart` already computes "the current org id" inline
(`orgs.first as Map<String, dynamic>`) to gate rendering the shell. Workers
needed the same value, so rather than copy that line into
`workers_list_screen.dart` too, it's pulled into its own provider that both
can eventually share. **`app_shell_screen.dart` itself is untouched** — its
inline version still works exactly as before, this doesn't require touching
that file. If you want to de-duplicate later, replacing its inline
computation with `ref.watch(currentOrganizationIdProvider)` is a one-line
change, but it wasn't necessary for this batch to work, so it's left alone.

## New ARB keys — deliberately generic, not worker-specific

```
payTypeLabel, payTypeMonthly, payTypeHourly, monthlyAmountLabel, hourlyRateLabel,
nameRequiredError, amountRequiredError, confirmDeleteGeneric, emptyListTitleGeneric,
planLimitReachedTitle
```
`confirmDeleteGeneric` and `emptyListTitleGeneric` in particular are named
generically on purpose — Clients, Jobs, and everything else on the priority
list will need the exact same "delete this?" dialog and "nothing here yet"
empty state. Reusing these two keys means Clients' batch doesn't need to add
`confirmDeleteClientGeneric` next to this one.

The worker-specific label ("Worker" vs. "Coach" vs. "Tutor" depending on
organization type) is deliberately NOT a new ARB key — it already exists via
`verticalLabelProvider('worker_title')` (Section 6's per-vertical label
system, not the static ARB layer), which is what both new screens actually
use for every worker-facing string ("Add Worker" / "Add Coach" / etc.).

## Form validation

Client-side validation (name required, rate required and non-negative)
mirrors the backend's `validatePayTypeFields` closely but isn't a substitute
for it — the backend still rejects invalid input independently. The one
error case handled specially rather than falling into the generic
`ApiException.message` line: `isPlanLimitError` (HTTP 402 from
`planLimits.js`'s `canAddWorker`) gets its own message
(`planLimitReachedTitle`) — "add worker" failing because you're out of seats
vs. failing because of a network blip need to read differently to the
person hitting them, even though both currently show as a plain line of red
text under the form rather than a distinct dialog/banner treatment (that's
a fair follow-up if you want the plan-limit case to stand out more).

## Deliberately out of scope for this batch

- **Profile photo / ID document upload** (`WorkerApi.updateAsset` exists,
  untouched, unused by these screens) — the recommendation this batch
  followed was list + create/edit form specifically so it wouldn't also
  need to solve image picking/upload UI in the same pass. `AssetApi.upload`
  is already built and ready whenever the worker detail/profile page picks
  this up.
- **Hours summary display** (`WorkerHoursSummary` model + `WorkerApi.hoursSummary`
  are built and ready, but nothing calls it yet) — same reasoning, it's a
  detail-page concern.
- **Worker detail/profile screen** — the list tile currently opens the edit
  form directly on tap rather than a separate read-only detail view, per the
  "list + form is the smallest useful slice" call. A detail page (with
  photo, hours summary, assigned jobs) is the natural next Workers-related
  batch once this is confirmed working end-to-end.

## Suggested next
Either a Worker detail page (photo + hours summary, building on the two
pieces flagged above as already-built-but-unused), or move on to Clients
using the exact same pattern this batch established (model + typed service +
list/form screens) — Clients' backend shape is simpler (no pay-type
branching), so it should be a faster repeat of this batch's structure.
