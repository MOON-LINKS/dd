# Dart Batch 11 — Referrals (code, earnings, history)

Batch 10's "suggested next" offered Bio Page or Referrals; picked
Referrals as the smaller, self-contained one. `referral_api.dart` already
existed from Step 1's route-coverage pass.

## Review pass: no bugs found this time

Checked every method in the existing `ReferralApi` stub against
`referralController.js` — `getMyCode`, `getEarnings`, `getHistory`,
`validateCode` all already read the correct keys with the correct shapes.
Unlike batches 7–10, nothing was silently broken. Still rewrote the three
org-facing methods to return typed models (`ReferralCode`,
`ReferralEarningsSummary`, `ReferralHistory`) rather than raw
`Map`/`List<dynamic>`, since this batch's screen is their first real
caller and every other service in the app already returns typed models —
consistency, not a fix.

## New files

| File | Goes in |
|---|---|
| `lib/api/models/referral.dart` | new — `ReferralCode`, `ReferralEarningsSummary`, `ReferralUse`, `ReferralEarningEntry`, `ReferralHistory` |
| `lib/features/referrals/providers/referral_providers.dart` | new |
| `lib/features/referrals/screens/referrals_screen.dart` | new |

## Replaces existing files

| File | What changed |
|---|---|
| `lib/api/services/referral_api.dart` | `getMyCode`/`getEarnings`/`getHistory` now typed. `validateCode` and the two admin methods untouched. |
| `lib/app/router.dart` | One new import, `_screenForPath('/referrals', ...)` now returns `ReferralsScreen()`. Every other line untouched. |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | 13 new keys. Reuses `copiedToClipboardMessage`/`copyAssignmentAction`/`paidStatusLabel`/`errorGeneric`/`emptyListTitleGeneric` from earlier batches. |

## Notes

- **No mutation actions on this screen** — a referral code is generated
  server-side on first payment, not user-editable, so unlike most
  providers in this app the three here are never `ref.invalidate()`d by a
  button; only pull-to-refresh re-fetches them.
- **`ReferralCode.hasCode == false` is a real, expected state** — orgs
  before their first payment legitimately have no code yet
  (`referralEngine.ensureReferralCodeForOrganization` only runs from the
  payment webhook). Shown as an explanatory message, not an error or a
  loading stall.
- **Cents → currency**: earnings/history amounts are cents (`int`) from
  the backend; divided by 100 before `NumberFormat.simpleCurrency`, same
  convention Batch 9's invoice screens already established.
- **Admin payout UI, validateCode's consuming screen** — out of scope,
  unchanged from before this batch (admin tooling isn't part of the
  manager-facing app per spec; `validateCode` is already consumed by the
  existing checkout screen from earlier batches).
- No Flutter environment available to run `flutter analyze` — checked by
  hand, all new files brace/paren-balanced, ARB parity verified across
  all three locales.

## Suggested next

Bio Page is the last placeholder destination — and the natural place to
finally build the image-picker + asset-display pattern Batch 10
deliberately deferred (needed for logo upload too).
