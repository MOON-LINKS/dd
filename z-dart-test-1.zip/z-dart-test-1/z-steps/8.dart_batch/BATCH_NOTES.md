# Dart Batch 8 — Jobs (day-grid: model + list/create/edit + snapshot workspace)

Batch 7's notes flagged this one explicitly: Jobs doesn't reduce to a flat
list+form the way Workers/Clients/Expenses/Upcoming Bills did, because of
the day_days + day_assignments structure, postpone vs. original_due_date,
and the snapshot get/save hydration pattern from spec Section 14. This
batch is that dedicated scoping pass, not "batch 8, same pattern again."

## Before this batch: found and fixed two real bugs in the existing stubs

Same "review pass before building on top of it" approach Batch 7 took.

**1. `JobApi.postpone()` sent the wrong request key.** The old stub sent
`{'dueDate': ...}`, but `postponeJob` in `jobController.js` reads
`req.body.newDueDate` — every postpone call would have hit
`if (!newDueDate) return res.status(400)...` and failed with a 400. Never
caught before now because nothing called this method until this batch's
screens did.

**2. `JobTemplateApi.list()` read the wrong response key.** The old stub
read `res.data['jobTemplates']`, but `listJobTemplates` in
`jobTemplateController.js` wraps its response as `{ templates: rows }` —
this would have thrown a null-cast exception the first time it was called.
Same class of bug as Batch 7's `upcomingBillApi` fix. Fixed as part of
rewriting this file to the typed pattern, since the job-creation form (this
batch) is the first real caller.

Everything else checked out on this pass — `createJob`/`listJobs`/
`updateJob`/`getJobSnapshot`/`saveJobSnapshot` all match their controllers,
and the `NavItem` for `/jobs` in `nav_item.dart` (added back in Step 3) was
already correctly wired to fall through to `PlaceholderScreen`.

## Requires Batches 4–7 already applied

Imports `current_organization_provider.dart` and `workers_provider.dart`
(Batch 4, for the day-grid's worker picker), and `clients_provider.dart`
(Batch 5, for the job-creation form's client dropdown). None duplicated
here.

## New files

| File | Goes in |
|---|---|
| `lib/api/models/job.dart` | new |
| `lib/api/models/job_day.dart` | new — `JobDay` + `DayAssignment` |
| `lib/api/models/job_template.dart` | new |
| `lib/features/jobs/providers/jobs_provider.dart` | new |
| `lib/features/jobs/providers/job_templates_provider.dart` | new |
| `lib/features/jobs/providers/job_snapshot_provider.dart` | new — local edit state for the day-grid |
| `lib/features/jobs/providers/job_clipboard_provider.dart` | new — spec Section 4's copy/paste clipboard |
| `lib/features/jobs/utils/job_status_labels.dart` | new |
| `lib/features/jobs/screens/jobs_list_screen.dart` | new |
| `lib/features/jobs/screens/job_form_screen.dart` | new — create + edit metadata only, NOT the day-grid |
| `lib/features/jobs/screens/job_day_grid_screen.dart` | new — the actual day-based workspace |
| `lib/features/jobs/widgets/job_list_tile.dart` | new |
| `lib/features/jobs/widgets/day_card.dart` | new — one day's card + its assignment rows |

## Replaces existing files

| File | What changed |
|---|---|
| `lib/api/services/job_api.dart` | Full rewrite — typed (`Job`/`JobDay`/`JobSnapshot` instead of raw `Map`/`List<dynamic>`), fixes bug #1 above. |
| `lib/api/services/job_template_api.dart` | Full rewrite — typed (`JobTemplate`), fixes bug #2 above. |
| `lib/app/router.dart` | Same shape of diff as batches 4–7: one new import, `_screenForPath('/jobs', ...)` now returns `JobsListScreen()` instead of falling through to `PlaceholderScreen`. Workers/Clients/Expenses/Upcoming Bills lines untouched. |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | 23 new keys (status labels, day-grid actions, clipboard/paste messages, invoiced-lock label). Everything from batches 4–7 is untouched. `titleLabel` and `dueDateLabel` (already added in earlier batches) are reused rather than duplicated. |

## Why the job-creation form and the day-grid are two separate screens

Every other entity's list tile opens straight into an edit form on tap.
Jobs deliberately doesn't follow that: `JobFormScreen` only ever touches
title/client/template/due-date(create)/status(edit) — the metadata — and
tapping a job in the list opens `JobDayGridScreen` instead, which is where
the actual work happens (assigning workers/hours per day). Folding day-grid
editing into a "form" would misrepresent what it is: Section 14's snapshot
pattern is explicitly load-once/edit-locally/save-once across a whole tree
of days and assignments, not a set of form fields. `JobFormScreen` is
reachable from the list's overflow menu ("Edit job details") for the cases
that are genuinely just metadata edits.

## Why `dueDate` isn't a field in edit mode

Mirrors `jobController.js`'s own separation exactly: `updateJob`'s SQL
never touches `due_date`, only `postponeJob` does (so the
`postponed_at`/`postponed_by` audit trail can't be bypassed by a plain
edit). `JobFormScreen` reflects that split — due date is only settable at
creation; postponing afterward is its own action (date picker + confirm)
from the list's overflow menu, calling `JobApi.postpone` directly rather
than going through the form at all.

## `Job`'s four inconsistent response shapes — read this before extending the model

Same category of problem Client/UpcomingBill already documented, but one
step further this time:

```
createJob   -> id, title, status, client_id, template_id,
               original_due_date, due_date, created_at
listJobs    -> id, title, status, client_id, client_name, template_id,
               original_due_date, due_date, postponed_at, created_at
updateJob   -> id, title, status, client_id, template_id,
               original_due_date, due_date
postponeJob -> id, title, original_due_date, due_date, postponed_at,
               postponed_by   (NO status, NO client_id, NO template_id)
```

`postponeJob`'s response isn't just missing a couple of optional fields
the way `updateJob`'s is (no `created_at`/`client_name`) — it's missing
`status`, which this model treats as required. Rather than make `status`
nullable everywhere to accommodate one sparse endpoint, `JobApi.postpone`
doesn't attempt to parse its response into a `Job` at all — it returns
`void`, and the call site invalidates `jobsProvider` afterward. This is
the exact precedent Batch 7 set for `markPaid`/`convertToExpense`, applied
here for the same reason.

## The day-grid's own response shape — a fifth shape, kept separate on purpose

`getJobSnapshot`/`saveJobSnapshot` return `{ job, days, skippedDays? }`
where `job` is `fetchJobSnapshotData`'s own sparse select (no
`client_name`, no `created_at` — different again from all four shapes
above). Rather than stretch `Job.fromJson` to tolerate a fifth shape, this
batch introduces `JobSnapshot` (in `job_api.dart`) as its own small
wrapper — `job` stays a raw `Map` there, since `JobDayGridScreen` only
ever reads `title`/`status` off it and building a whole model for two
fields nothing else uses felt like the wrong kind of thoroughness.

## `JobDay`/`DayAssignment` read camelCase, not snake_case — different from every other model so far

Worth flagging since every model up to this point (`Worker`, `Client`,
`Expense`, `UpcomingBill`) reads snake_case because their controllers
return raw Postgres rows. `fetchJobSnapshotData` in `jobController.js`
builds the assignments array by hand with
`json_build_object('workerId', da.worker_id, 'workerName', w.name, ...)`
— already camelCase on the wire, the same reason
`WorkerHoursSummary.fromJson` is camelCase-both-ways while `Worker.fromJson`
is snake_case (Batch 4's note). Not an inconsistency to work around, just
a genuinely different situation — flagging so it isn't "corrected" to
snake_case by habit if this pattern gets copied for a future entity.

## Copy/paste clipboard — implemented exactly as spec Section 4 describes

`jobClipboardProvider` is a plain `StateProvider<List<DayAssignment>?>`,
scoped globally rather than per-job (nothing in the spec restricts
copying between different jobs, and a global provider is simpler than
threading a job-scoped one through every `JobDayGridScreen` instance for a
restriction nobody asked for). "Copy day" copies every assignment on that
day; "copy" on a single row copies just that one — both land in the same
clipboard, so pasting is always "upsert everything currently on the
clipboard into the target day," no separate code path for the two cases.
Pasted hours stay editable afterward, per spec. Pasting onto a day that
already has an assignment for one of the copied workers overwrites that
worker's hours (upsert by `workerId`, matching the backend's own
`(job_day_id, worker_id)` uniqueness constraint) rather than duplicating a
row — this felt like the only sane behavior, but flagging the choice
since the spec doesn't say explicitly what should happen on a collision.

## Invoiced days are locked in the UI, not just server-enforced

Spec Section 4: once a day is part of an already-sent invoice, editing
should be "blocked or clearly flagged." This app takes the blocking
option — `DayCard` disables every control (hours field, copy, paste, add
worker, remove) on an invoiced day and shows a chip explaining why. The
backend already silently skips invoiced days server-side regardless of
what the client sends (`saveJobSnapshot`'s `existingDay?.invoiced` check),
so the UI lock is about the manager understanding why nothing happened,
not a substitute for the backend guard — both are real, doing the same
job at two different layers.

`saveSnapshot`'s response can still list a day in `skippedDays` even with
the UI lock in place — that's the race case (someone else invoiced the
day between this screen loading and this save completing), surfaced via a
snackbar rather than silently discarded.

## Removing an assignment is local-only — flagged, not fudged

`saveJobSnapshot` only ever upserts (see its own doc comment on the
expected body shape in `jobController.js`) — there's no backend path to
delete a `day_assignments` row. `JobSnapshotNotifier.removeUnsavedAssignment`
removes it from local state only; if that assignment was already saved on
a previous visit, the next load brings it right back, since nothing told
the backend to delete anything. This is intentionally NOT hidden behind a
misleading "delete" button that looks like it works — same "flag, don't
fake it" call Batch 2 made for OTP resend and Batch 3 made for the
account/profile screen. **A real delete needs a small backend addition**
(a `DELETE /organizations/:organizationId/jobs/:jobId/snapshot/assignments/:assignmentId`
route, or similar) before this can be a real feature rather than a
same-session undo.

## Worker picker in "add assignment" degrades quietly, same as Expense's dropdown

`JobDayGridScreen` reads `workersProvider(orgId).valueOrNull ?? []` rather
than blocking the whole day-grid on that fetch — same reasoning Batch 6
used for Expense's linked-worker dropdown. A slow/failed worker-list fetch
shouldn't stop someone from adding days or editing hours for workers
already on the snapshot; it just means "add worker" briefly has nothing to
offer until the list arrives.

## Status filter on the Jobs list is client-side only

`JobApi.list` already accepts `status`/`clientId`/`dueFrom`/`dueTo` (the
backend supports all four), but `JobsListScreen` fetches the full
unfiltered list once and filters status client-side via `ChoiceChip`s.
Same scope call Expenses/Upcoming Bills made for their own unused filter
params — cheap to wire the server-side version later if the list ever
gets large enough for client-side filtering to matter.

## Deliberately out of scope for this batch

- **Filtering by client or date range** — same reasoning as the status
  filter above; `JobApi.list` supports both, unused by this screen.
- **Assignment delete on the backend** — flagged above as a real gap, not
  silently worked around.
- **A day-of-week / calendar-grid visual layout** — `JobDayGridScreen` is
  a scrollable list of day cards in date order, not a literal calendar
  grid. Spec Section 4 describes the *data* as day-based, not a specific
  calendar UI; a list of cards is the simplest thing that's provably
  correct end to end. A true calendar view is a reasonable follow-up if
  you want one, but it's a visual layer on top of the same state/API this
  batch already built, not a different data model.
- **Job template admin UI** — `JobTemplateApi.adminCreate`/`adminUpdate`
  exist (typed, working), unused by any screen — per spec Section 3,
  template management isn't manager-facing in v1.
- **No Flutter environment available in this session to run
  `flutter analyze`/`flutter test`** — every file was checked by hand
  against the exact patterns Batches 4–7 already established (response
  shapes, PATCH/COALESCE-safety, provider style, ARB usage), and every
  file's braces/parens were verified balanced, but you should still run
  `flutter analyze` after merging before treating this as final. Flagging
  rather than claiming a confidence this session couldn't actually verify.

## Suggested next

Jobs was the last of the 9 sidebar destinations without a real screen —
Billing & Invoices, Bio page, Referrals, and Settings are still
`PlaceholderScreen`. Of those, Billing & Invoices is probably the most
natural next batch: `invoice_api.dart` already exists (Step 1's API layer
pass covered all 96 routes), and job_days' `invoiced` flag — which this
batch's UI now visibly respects — is exactly what invoice generation would
flip.
