# Dart Batch 12 — Bio Page: editor, buttons, logo (part 1 of 2)

Bio Page was the last placeholder destination. Scoped as two batches per
the earlier plan: this one is editor + buttons + logo (and the first
image-picker/asset-display pattern in the app). Publish/unpublish,
version history + rollback, and the public-facing page renderer are the
separate next batch.

## Found: `checkSlugAvailability` was missing entirely from the stub

`Endpoints.bioSlugCheck` was already defined, but no `BioPageApi` method
ever called it — the slug field had no live-availability check. Added
`BioPageApi.checkSlugAvailability()`, wired into the editor with a 500ms
debounce as the manager types.

## Found: no way to preview a logo set in a previous session

`getBioPageEditorData` returns `logo_asset_id` as a bare UUID and never
resolves it to a filename/URL — unlike `getInvoiceBranding`, which does
exactly this (joins `assets`, returns `logoUrl`) for the *same kind* of
field. There's also no `GET /assets/:id`. A freshly-picked logo still
previews correctly this session (the upload response already includes
the filename), but a logo from an earlier session falls back to a "logo
saved, no preview" placeholder rather than a broken `Image.network`.
Worth fixing backend-side (mirror `getInvoiceBranding`'s join) before
Worker profile pictures need the same pattern.

## New files

| File | Purpose |
|---|---|
| `lib/core/constants/bio_page_color_presets.dart` | 5 presets, mirrors backend `BIO_PAGE_COLOR_PRESETS` exactly |
| `lib/core/utils/cdn.dart` | client mirror of backend's `resolveAssetUrl` |
| `lib/api/models/bio_page.dart` | `BioPage`, `BioPageButton`, `BioPageFeatureFlags`, `BioPageEditorData` |
| `lib/features/bio_page/providers/bio_page_provider.dart` | single editor-data provider |
| `lib/features/bio_page/screens/bio_page_screen.dart` | title/slug/bio, color presets, logo upload |
| `lib/features/bio_page/widgets/bio_page_buttons_section.dart` | CRUD + drag-reorder, plan-limit enforcement |

## Replaced

| File | What changed |
|---|---|
| `lib/api/services/bio_page_api.dart` | Full rewrite — typed responses, adds `checkSlugAvailability`, fixes `updateLogo` to always send an explicit `assetId` key (including `null` to clear) since the backend has no COALESCE fallback there. Publish/version methods left untouched — next batch's job. |
| `pubspec.yaml` | +`image_picker: ^1.1.2` |
| `lib/app/router.dart` | `/bio-page` → `BioPageScreen`, same one-line-per-batch diff shape as every batch since 4 |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | 25 new keys, reused `save`/`cancel`/`delete`/`retry`/`errorGeneric`/`emptyListTitleGeneric`/`nameRequiredError`/`amountRequiredError`/`confirmDeleteGeneric`/`copiedToClipboardMessage`/`copyAssignmentAction`/`savedMessage` |

## Deliberately out of scope (next batch)

- Publish / unpublish / version history / rollback — `BioPageApi` methods
  exist (carried over from the old stub, unverified against controllers
  this batch — will be checked when that batch builds a screen against
  them).
- Public-facing page renderer / preview.
- No Flutter environment available to run `flutter analyze` — checked by
  hand: all new files brace/paren-balanced, all relative imports resolve,
  ARB key parity verified across all three locales.

## Suggested next

Batch 13: Publish/Unpublish + version history/rollback + public bio page
preview — the second half of Bio Page, and the last piece needed for
every sidebar destination to be fully complete end to end.
