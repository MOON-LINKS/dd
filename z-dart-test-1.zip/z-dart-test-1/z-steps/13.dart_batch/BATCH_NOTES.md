# Dart Batch 13 — Bio Page: publish/unpublish, version history, rollback (part 2 of 2)

Second half of Bio Page, closing out the last placeholder destination.
Batch 12 built the editor (title/slug/bio, appearance, logo, buttons);
this batch adds the publish lifecycle on top of it, using the
`BioPageApi.publish/unpublish/listVersions/rollbackToVersion` methods
that were carried over unverified from the old stub.

## Changed: `listVersions` typed instead of raw `List<dynamic>`

Added `BioPageVersion` (`version: int`, `createdAt: DateTime`) to
`bio_page.dart` and updated `BioPageApi.listVersions` to parse into it.
`version` (not a UUID `id`) is the identifier — matches `publish`
already returning `version` as `int` and `rollbackToVersion` already
taking `version` as `int` in the URL, so this isn't a new assumption,
just finishing the type the other two methods already committed to.

## Changed: `BioPage.lastRenderedAt` now modeled

Batch 12's model doc comment said this batch would be the one that
cares about it. Nullable — a page that's never been published has no
render to report. Shown next to the publish actions as "Last published
{date}".

## New files

| File | Purpose |
|---|---|
| `lib/features/bio_page/widgets/bio_page_publish_section.dart` | Publish/Republish, Unpublish (with confirm), "View live page" (external launch via `url_launcher`, same convention as `InvoiceDetailScreen`'s PDF link), and a version-history dialog with per-version rollback (with confirm) |

## Changed files

| File | What changed |
|---|---|
| `lib/api/models/bio_page.dart` | +`BioPageVersion`, +`BioPage.lastRenderedAt` |
| `lib/api/services/bio_page_api.dart` | `listVersions` now returns `List<BioPageVersion>` instead of `List<dynamic>` |
| `lib/features/bio_page/screens/bio_page_screen.dart` | Mounts `BioPagePublishSection` below the buttons section; updated the file-level doc comment (was pointing at this batch as "separate follow-up", now describes it as done) |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | +16 keys: publish/unpublish/republish actions, confirm messages, version list label, rollback action/message, "view live page" + its open-link error, last-published label |

## No public-page-renderer screen built

"Public bio page preview" is the server-rendered `/bio/:slug` HTML
route, not a Flutter screen — there's no `webview_flutter` dependency
in this project, and adding one for a single external page isn't
justified. "View live page" opens it in the external browser instead,
the same pattern `InvoiceDetailScreen` already uses for generated PDFs.
If an in-app preview is wanted later, that's a deliberate follow-up
(new dependency), not something to fold in silently here.

## Deliberately unverified

Same caveat as every batch before it: no Flutter environment available
to run `flutter analyze`. Checked by hand — all new/changed files
brace/paren-balanced, all relative imports resolve, ARB key parity
verified across all three locales (194/188/188 — the 6-key gap is
pre-existing `@`-metadata-only entries, not from this batch). The
`BioPageVersion` field names (`version`, `created_at`) are inferred
from the two methods that already committed to that shape
(`publish`'s return, `rollbackToVersion`'s param) — worth a quick
diff against the actual controller/migration the next time this route
is touched.

## Suggested next

Every sidebar destination now has a real screen end to end. Worth a
pass over the "Deliberately out of scope" and "Found" notes left
across Batches 4–13 (the `getInvoiceBranding`/bio-page logo-resolution
asymmetry from Batch 12 is the most concrete one) before starting any
new feature area.
