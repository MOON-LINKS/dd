# Dart Batch 16 — Invoice Analytics tab (the last unbuilt Billing & Invoices piece)

Batch 15's "suggested next" called this one: the last of the three Billing
& Invoices tabs, and per Section 3 the "main tab" of the three. Same "own
pushed screen, not a real `TabBar` tab" shape Design (Batch 14) and
History (Batch 15) already established — see Batch 14's "Not a tab bar"
note for why `InvoicesListScreen` still has no local tab bar of its own.

## Found: the existing `analytics()` stub's own doc comment was wrong

Before writing the screen, checked the method this batch would build
against — its comment claimed "already reads the response correctly,
verified against `invoiceAnalyticsController.js`." That claim doesn't
hold up:

- **Wrong query params.** The stub sent optional `from`/`to` plus a
  `groupBy`. The actual endpoint (`getInvoiceAnalytics`) reads
  `req.query.startDate`/`req.query.endDate` — **required**, not optional —
  and 400s immediately with `"startDate and endDate are required"` if
  either is missing. There's no `groupBy` param anywhere in the handler.
  Under the old signature, **every call to this method would have 400'd**,
  every time — the exact "silently guaranteed to fail" bug class Batches
  7–9 kept finding elsewhere in this project.
- **Untyped.** Returned the raw response body as `Map<String, dynamic>`,
  so even a successful call would have needed hand-written key lookups
  (`res.data['paidVsOwed']['totalPaid']`, etc.) at every call site.

Unlike `InvoiceBranding`/`InvoiceEmailLogEntry` (Batches 14/15, both
built with "no backend present in this project" and defensive
snake_case/camelCase fallbacks as a result), this fix isn't inferred —
`invoiceAnalyticsController.js` was actually available and read earlier
in this project's session history, and is quoted in full in this batch's
working notes. The response is camelCase top-to-bottom
(`range.startDate`, `paidVsOwed.totalPaid`, `byClient[].clientName`,
etc.) with no casing ambiguity anywhere, so `InvoiceAnalytics.fromJson`
below doesn't need the `??` fallback chains those two models do.

Rewrote `InvoiceApi.analytics()` to require `startDate`/`endDate`, drop
`groupBy`, and return a typed `InvoiceAnalytics`.

## New model: `InvoiceAnalytics` (+3 supporting classes), in `invoice.dart`

Kept in the same file as `Invoice`/`InvoiceBranding`/`InvoiceEmailLogEntry`
rather than a new file — matches this project's own established
convention of one `invoice.dart` for every invoice-domain model, not a
model-per-file split.

- `InvoiceRevenueTrendPoint` — `month`, `revenue`, `hours`. One per
  calendar month touched by the range.
- `InvoiceAnalyticsByClient` — `totalAmount` is a plain (non-nullable)
  `double` here; every invoice has a client-or-null row, never a "not
  billable" gap the way a job's line items can.
- `InvoiceAnalyticsByJob` — `totalAmount` is genuinely **nullable**. The
  backend's SQL uses `SUM(...) FILTER (WHERE amount IS NOT NULL)` with no
  `COALESCE`, so a job whose every logged hour belongs to a salaried
  (non-hourly) worker comes back as JSON `null`, not `0` — same
  "not billable" vs. "billed at $0" distinction `InvoiceLineItem.amount`
  already draws. The screen renders that case as `noneOptionLabel`
  ("None"), dimmed, rather than a misleading `$0.00`.
- `InvoiceAnalytics` — the whole tab's data in one object: the two totals
  (`totalPaid`/`totalOwed`), the two hour figures (`hoursLogged`/
  `hoursBilled` — a real distinction per the controller's own comment:
  logged = every hour recorded regardless of pay type, billed = only
  hours that produced a dollar amount), the trend list, and both
  breakdown lists.

## Scoping decision: no charting package added

`pubspec.yaml` has never had `fl_chart` or any charting dependency.
Adding one for a single trend chart is a real decision (new package, new
transitive deps, a version to pin) — not something to fold into this
batch as a side effect of one screen, same call `InvoiceDesignScreen`
already made choosing a plain hex `TextFormField` over a color-picker
package for two fields (Batch 14). `RevenueTrendBars` is a hand-rolled
`Row` of proportionally-sized `Container`s instead — correct output
today, and swapping in a real charting package later only touches that
one widget file, nothing else in this batch depends on how the bars are
drawn.

## New files

| File | Purpose |
|---|---|
| `lib/features/invoices/providers/invoice_analytics_provider.dart` | `invoiceAnalyticsRangeProvider` (selected date range, per org, defaults to current calendar month) + `invoiceAnalyticsProvider` (the fetch, keyed by a `(organizationId, start, end)` record) |
| `lib/features/invoices/widgets/revenue_trend_bars.dart` | hand-rolled bar row, see above |
| `lib/features/invoices/screens/invoice_analytics_screen.dart` | date range picker (From/To + This month/Last month presets), paid/owed + hours-logged/hours-billed stat cards, revenue trend, by-client and by-job breakdown lists |

## Changed files

| File | What changed |
|---|---|
| `lib/api/models/invoice.dart` | +`InvoiceRevenueTrendPoint`, `InvoiceAnalyticsByClient`, `InvoiceAnalyticsByJob`, `InvoiceAnalytics` |
| `lib/api/services/invoice_api.dart` | `analytics()` rewritten — see bug above |
| `lib/features/invoices/screens/invoices_list_screen.dart` | +third header button ("Analytics") pushing `InvoiceAnalyticsScreen`; the header row was a plain `Row`, which already fit its 2 buttons tightly on a narrow phone — adding a third pushed it into real overflow risk, so it's now a `Wrap` (see below) |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | +12 new keys. Reuses `amountPaidLabel`/`amountOwedLabel`/`hoursUnitSuffix`/`retry`/`errorGeneric`/`noneOptionLabel` from earlier batches — deliberately did **not** add a `notBilledLabel` key for the by-job null-amount case; `noneOptionLabel` ("None") already exists and reads fine there, and one more single-purpose key felt like it wasn't earning its keep. |

## Also fixed while touching the header row: real (if minor) overflow risk

Not something this batch introduced on its own, but adding the third
button is what exposed it: `InvoicesListScreen`'s header (Design +
History, now + Analytics) was a plain `Row` with `MainAxisAlignment.end`.
Two `OutlinedButton.icon`s with English-length labels already ran close
to a narrow phone's width; three pushes it into genuine overflow
territory on some devices/locales (French's slightly longer labels make
this worse). Changed to `Wrap` — same visual result on any screen wide
enough to fit all three, drops the overflow button to its own line
instead of erroring on ones that aren't. Left the analogous date-range
row inside the new Analytics screen as a `Wrap` from the start for the
same reason, rather than writing it as a `Row` and having to fix it later.

## Deliberately out of scope

- **A real charting package** — see above; `RevenueTrendBars` is the
  placeholder, swap-in-later piece.
- **Pagination / "load more" on the breakdown lists** — `byClient`/
  `byJob` aren't paginated server-side either (the controller returns
  every group for the range, no `LIMIT`), so there's nothing to page
  through client-side; a very wide date range with many distinct
  clients/jobs will render a correspondingly long list. Worth a
  server-side cap if that becomes a real problem, not a client-only fix.
- **A shared date-range picker widget** — this batch's From/To/preset
  row is specific to `InvoiceAnalyticsScreen`; nothing else in the app
  has a comparable date-range UI to factor a shared widget out of yet.
  Worth revisiting if a second screen ever needs the same pattern.
- **No Flutter environment available in this session to run
  `flutter analyze`/`flutter test`** — same disclosure every batch since
  8 has made. Checked by hand: all new/changed files brace/paren-balanced
  (verified with a grep-based count, not just eyeballed), all relative
  imports resolve, ARB key parity verified across all three locales
  (207/207/207 — full parity, no `@`-metadata gap this time since none of
  the 12 new keys needed one). `InvoiceAnalytics` and its three
  supporting classes are the one part of this batch verified against a
  real controller read rather than inferred — please still run
  `flutter analyze` after merging, same as every prior batch.

## Suggested next

Every sidebar destination and every Billing & Invoices tab now has a
real, built screen — this was the last one. Per Batch 15's own "suggested
next," the honest gaps left in the whole project are backend-side, not
frontend: no `changePassword` route (Batch 10), no per-device session
revoke (Batch 10), no `GET /assets/:id` (Batch 12), and the
`getBioPageEditorData`/`getInvoiceBranding` logo-resolution asymmetry
(Batch 12) — worth a pass whenever backend work is back in scope. On the
frontend side specifically, this batch's own "deliberately out of scope"
list (a real charting package, breakdown-list pagination) is the
shortest, most self-contained remaining list of any batch so far.
