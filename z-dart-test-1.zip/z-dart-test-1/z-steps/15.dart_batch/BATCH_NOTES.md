# Dart Batch 15 — Invoice History tab (email log)

The other item from Batch 9's "kept correct, not yet consumed" list —
smaller than Design (Batch 14) since it's read-only, no upload/color
input, per Batch 14's own "suggested next."

## Changed: `InvoiceEmailLogEntry` model, typed `historyLog`

Added `InvoiceEmailLogEntry` (`id`, `emailType`, `createdAt` required;
`referenceId`, `recipientEmail`, `status` nullable) to `invoice.dart`.
`historyLog` now returns `List<InvoiceEmailLogEntry>` instead of the
raw `List<dynamic>` Batch 9 left it as after fixing the response-key
bug. Same casing-uncertainty caveat as Batch 14's `InvoiceBranding` —
no backend in this project to verify column names against, so
`fromJson` falls back across the plausible snake_case/camelCase/
alternate spellings per field (`recipientEmail` in particular checks
four candidate keys) rather than committing to one guess.

## New files

| File | Purpose |
|---|---|
| `lib/features/invoices/providers/invoice_history_log_provider.dart` | plain `FutureProvider.family`, same style as `invoiceBrandingProvider` |
| `lib/features/invoices/screens/invoice_history_screen.dart` | read-only list — email type, recipient, timestamp, status — same `Card`+`ListTile` shape `ReferralsScreen._HistorySection` already uses for its own ledger list |

## Changed files

| File | What changed |
|---|---|
| `lib/api/models/invoice.dart` | +`InvoiceEmailLogEntry` |
| `lib/api/services/invoice_api.dart` | `historyLog` now typed |
| `lib/features/invoices/screens/invoices_list_screen.dart` | +a second header button ("History") next to Design, same pushed-screen pattern |

## Not paginated

`listEmailLog` wraps its response as `{ emailLog, page, pageSize }` per
Batch 9's fix — `page`/`pageSize` are read off the response but not
acted on here, same "fetch one page, no pager UI yet" scope call every
other list screen in this app has made for its own unused list params
(Invoices' own `clientId`/date filters, Expenses' category filter,
etc.).

## Deliberately unverified

No Flutter environment available. Checked by hand — all new/changed
files brace/paren-balanced, all relative imports resolve, ARB key
parity verified across all three locales (203/197/197).

## Suggested next

Analytics is the last unbuilt Billing & Invoices tab — genuinely
chart-heavy (`InvoiceApi.analytics()` takes `from`/`to`/`groupBy` and
returns a shape meant for a real chart, not a list), so it's worth its
own scoping pass rather than assuming it's a quick repeat of Design/
History's pattern. Past that, every "found but out of scope" item
flagged across Batches 4–15 is frontend-complete; the honest gaps left
are backend-side (no `changePassword` route, no per-device session
revoke, no `GET /assets/:id`, the `getBioPageEditorData`/
`getInvoiceBranding` logo-resolution asymmetry) — worth a pass whenever
backend work is back in scope.
