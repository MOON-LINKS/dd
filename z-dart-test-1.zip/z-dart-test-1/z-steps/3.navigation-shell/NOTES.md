# Step 3 — Theme toggle + navigation shell (Stripe-style sidebar)

Builds on Step 1 (environment) and Step 2 (auth/onboarding). Two things,
per your message: a visible dark/light toggle, and the real navigation
shell Step 2's notes flagged as "suggested next."

## Merge instructions

Copy `lib/features/shell/`, `lib/features/home/screens/dashboard_screen.dart`
into your project's `lib/` — new folders/files, nothing to merge line-by-line.

**`lib/app/router.dart` — full replace.** Restructured around
`StatefulShellRoute.indexedStack`; every sidebar destination is now its
own branch instead of a single `/home` route.

**`lib/features/home/screens/home_shell_screen.dart` — delete.** Replaced
by `AppShellScreen` (the shell itself) + `DashboardScreen` (its first tab).
The org-existence gate that used to live in `HomeShellScreen` moved into
`AppShellScreen` unchanged — same check, same redirect, just one level up
so it gates the whole shell once instead of only the dashboard.

**`lib/features/onboarding/screens/create_organization_screen.dart` —
one line changed:** `context.go('/home', ...)` → `context.go('/dashboard', ...)`.

**`pubspec.yaml` — one line added:** `go_router: ^14.2.7`. This was
already imported throughout Step 2's code and referenced in that step's
notes as added, but never actually landed in `pubspec.yaml` — worth
flagging since it would have failed `flutter pub get` silently otherwise.
Run `flutter pub get` after merging.

**`lib/l10n/app_{en,ar,fr}.arb` — merge in the new keys**, not a full
replace (your existing keys — `dashboard`, `workers`, `jobs`, `clients`,
etc. — are untouched and already correct, they're what the sidebar uses).
New keys added, all three locales kept in sync: `myAccount`, `comingSoon`,
`comingSoonBody`, `toggleTheme`, `navGroupOperations`, `navGroupMoney`,
`navGroupGrowth`. Run `flutter gen-l10n` (or `flutter run`) after merging.

## On the theme ask specifically

`themeModeProvider` (Hive + Riverpod, light/dark/system) already existed
from Step 1 — nothing changed there. What didn't exist was any UI to
flip it. `ThemeToggleButton` (`shell/widgets/theme_toggle_button.dart`)
is that missing piece, placed in the shell's top app bar per your
message. It reads `MediaQuery.platformBrightnessOf` so the icon is
correct even while state is still `ThemeMode.system` (before the user
has touched the toggle at all).

## The sidebar

`shell/widgets/app_sidebar.dart`, Stripe-dashboard style, matches your
spec:
- **Top:** account icon (`SidebarAccountMenu`) — circular avatar button,
  opens a popup with Logout wired to the same
  `SecureStorage.deleteToken()` + `authStateProvider.markLoggedOut()`
  sequence the old `HomeShellScreen` used. No account/profile screen
  exists yet, so this is the one working action for now — same
  "flag, don't fake it" approach Step 2 took with OTP resend. Swap the
  popup for a real `/account` push once that screen exists.
- **Middle:** the 9 categories, grouped Overview / Operations / Money /
  Growth — the exact grouping Step 2's "suggested next" section proposed.
  Icon + label per row, rounded tinted background on the selected item,
  built from a single `allNavItems` list (`shell/models/nav_item.dart`)
  so the sidebar and the router's branch list can never drift out of
  sync with each other.
- **Bottom:** Settings, pinned outside the scrollable group list.

**RTL:** nothing special-cased. `Row`/`Column` already respect ambient
`Directionality`, so under the Arabic locale the sidebar mirrors to the
right edge on its own — Section 6/7's RTL requirement, satisfied for
free rather than with manual left/right branching.

**Localization:** every label — nav items, group headers, account menu,
theme toggle tooltip — resolves through `AppLocalizations`, same static
app-chrome system as Steps 1–2. None of this touches
`VerticalLabelsService`; nav chrome is fixed UI text ("Workers",
"Clients"), not a per-organization-type dynamic field label, so ARB is
the correct system here, not the runtime JSON one.

## Routing architecture

`StatefulShellRoute.indexedStack` with one `StatefulShellBranch` per nav
item, generated from `allNavItems` — not hand-listed — so adding a new
sidebar item is a one-line change in `nav_item.dart`, nothing to touch
in `router.dart`. Indexed stack (rather than a plain nested route) means
each tab keeps its own navigation history when you switch away and back,
which matters once these tabs have real list→detail flows.

Only `/dashboard` has a real screen right now
(`features/home/screens/dashboard_screen.dart` — same content the old
`HomeShellScreen` showed, minus the org-check, which moved up to the
shell). The other 8 branches (`/workers`, `/jobs`, `/clients`,
`/billing`, `/expenses`, `/upcoming-bills`, `/bio-page`, `/referrals`,
`/settings`) render `PlaceholderScreen` — a shared "coming soon" body —
so the whole shell/router/sidebar wiring is provably correct end to end
before any real screen work starts on them.

## What's NOT in this batch

- **No real content for the other 9 destinations** — by design, this
  batch is the shell/nav mechanism, not the screens themselves.
- **No real account/profile screen** — flagged above, popup-menu logout
  is the stand-in.
- **No mobile-collapsed sidebar (drawer/rail breakpoint).** Built as a
  fixed always-visible sidebar per your description ("vertical left side
  bar"). Worth deciding before Workers/Jobs/Clients screens get built:
  a permanent sidebar works fine on tablet/desktop/web, but on a phone
  width it'll eat a lot of the screen. Flagging rather than guessing at
  a breakpoint you didn't ask for.
- **No locale switcher UI** — `localeProvider` already exists (Step 1)
  same as theme did, but nothing exposes it yet either. Likely lands on
  the real Settings screen once that's built, alongside the theme toggle
  if you'd rather consolidate both there instead of the top bar.

## Suggested next

Real Workers screen — first of the 9 placeholders, and the one that
forces the model/DTO decision Step 1 flagged (hand-written classes vs.
codegen) to actually get made rather than deferred again.
