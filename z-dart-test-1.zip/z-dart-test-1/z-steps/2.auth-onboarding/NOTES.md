# Step 2 — Auth & Onboarding

Builds directly on Step 1 (Hive/Riverpod/API/theme/localization). First real
screens: login, register, OTP verification, forgot password, and the
create-organization onboarding step from Section 2.

## Merge instructions

Copy `lib/app/`, `lib/shared/`, `lib/features/` into your project's `lib/`
— all new folders, nothing to merge line-by-line there.

**`lib/main.dart` — full replace.** Swapped `MaterialApp` for
`MaterialApp.router`, wired to the new `routerProvider`. The placeholder
`_EnvironmentCheckScreen` from Step 1 is gone — no longer needed now that
real screens exist.

**`pubspec.yaml` — one line added:** `go_router: ^14.2.7`. Run
`flutter pub get` after merging.

## Design decision — followed the brief, didn't invent one

Section 8 already specifies the visual direction (Stripe Dashboard-style,
clean). Per that, this batch deliberately does NOT introduce a bold new
aesthetic — the one signature touch is a quiet radial glow behind the
auth screens' titles (`shared/widgets/auth_scaffold.dart`), color-only
rather than an icon/illustration, since the product's name and logo are
still open (`APP_NAME` placeholder, same one referenced in the backend's
email templates and bio page renderer). A literal mark would need
replacing the moment that's decided; a color treatment doesn't.

**Flagged, not decided:** custom display/body webfonts (e.g. via
`google_fonts`) were deliberately left out this pass to avoid adding a
dependency + an offline-bundling decision (construction-site connectivity
matters for this product) inside an already-large batch. Current type
scale uses the system font stack with deliberate weight/spacing choices
(see `auth_scaffold.dart`'s `letterSpacing: -0.5` on headlines). Revisit
once the app has a real name/identity to design a type system around.

## Architecture decisions worth knowing about

**Routing split: auth state vs. business state.** `app/router.dart`'s
`redirect` only knows about `AuthStatus` (authenticated / unauthenticated /
unknown) — that's a routing concern. Whether the logged-in user has
actually finished onboarding (created an organization) is a business-logic
check, handled inside `HomeShellScreen` itself, which queries
`OrganizationApi.listMine()` and redirects to `/onboarding/organization`
if the list is empty. Kept these separate deliberately — folding
"has-an-org" into the router's redirect would mean an extra async
dependency fetch on every route change, not just once.

**`_RouterRefreshNotifier`** bridges `authStateProvider` into something
`GoRouter`'s `refreshListenable` understands. This is what makes login/
logout redirect instantly without an app restart — Riverpod state changes,
the notifier fires, GoRouter re-runs `redirect()`.

**Splash route, not just a loading flag.** `AuthStateNotifier` starts as
`AuthStatus.unknown` while `SecureStorage.readToken()` resolves. Without a
dedicated `/splash` route, an already-logged-in user would see a flash of
the login screen before redirecting to `/home`. Small thing, easy to miss,
worth doing right from the start.

**Forgot password is one screen, not three routes.** Mirrors
`resetPass1/2/3` step-for-step, but there's no reason to deep-link into
"step 2 of password reset" or let the user navigate back mid-flow, so it's
a local step enum inside one `StatefulWidget` rather than three separate
`GoRoute`s.

**OTP resend is intentionally NOT built.** The backend's `register` upserts
and resends an OTP if the account isn't verified yet — but that requires
re-submitting the password, which `VerifyOtpScreen` doesn't have (only
`email` + `verificationId` are passed to it). Building a fake "resend"
button that can't actually call anything useful felt worse than being
upfront: the screen offers "Code expired? Register again" instead, which
goes through the real, working path. If resend-without-password matters
enough to prioritize, that's a small backend addition (an endpoint that
re-issues an OTP given a `verificationId` alone) — flagging rather than
guessing at it.

## What's NOT in this batch

- **No plan/checkout screen.** `CreateOrganizationScreen` finishes with the
  org existing and `plan_id = null` — exactly what the backend already
  supports (Section 14: nullable `plan_id`). Plan selection is Payments UI
  work, not onboarding.
- **No "manage devices" screen** — `getDeviceName()` is deliberately minimal
  (just the platform name, no `device_info_plus`) until that screen exists
  and actually needs a real device model string.
- **No password-strength meter, no rate-limit/lockout UI** for repeated
  failed logins — not blocking, just not built yet.
- **`HomeShellScreen` is a placeholder** — confirms the whole auth →
  onboarding → "authenticated app" loop actually works end to end. The real
  dashboard/sidebar (Section 3/8) is the next real design task.

## Suggested next

Real navigation shell — the Stripe-dashboard-style sidebar we designed
early on (Dashboard / Workers / Jobs / Clients / Billing & Invoices /
Expenses / Upcoming bills / Bio page / Referrals / Settings, grouped into
Overview/Operations/Money/Growth) — replacing `HomeShellScreen`'s
placeholder body. That's also where the model/DTO decision flagged in
Step 1 stops being deferrable — the dashboard needs real typed data from
several endpoints at once.
