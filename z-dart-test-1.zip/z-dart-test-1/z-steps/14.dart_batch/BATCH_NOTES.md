# Dart Batch 14 — Invoice Design tab (branding: colors + logo)

Picked up the one item from Batch 9's "kept correct, not yet consumed"
list that was already fully ready: `InvoiceApi.getBranding`/
`updateBranding` existed, typed loosely as `Map<String, dynamic>`, bug-fixed
back in Batch 9, just never rendered by a screen.

## Changed: `InvoiceBranding` model, typed API methods

Added `InvoiceBranding` (`primaryColor`, `secondaryColor`, `logoAssetId`,
`logoUrl` — all nullable) to `invoice.dart`. `getBranding`/`updateBranding`
now return it instead of a raw `Map`. Field casing (snake_case vs
camelCase) is inferred, not verified — no backend present in this
project to check against — so `fromJson` falls back across both
spellings per field, same defensive pattern Batch 13's `BioPageVersion`
used for `created_at`/`createdAt`.

`updateBranding`'s `logoAssetId` param changed from optional to
required-but-nullable: a color-only save now always passes the
*current* logo asset id back through, rather than omitting the key —
same "no server-side COALESCE, omission binds `undefined`" reasoning
`BioPageApi.updateLogo` already documented for the structurally
identical bio-page endpoint. `InvoiceDesignScreen._save` passes
`branding.logoAssetId` through on every save for exactly this reason.

## New files

| File | Purpose |
|---|---|
| `lib/features/invoices/providers/invoice_branding_provider.dart` | plain `FutureProvider.family`, same style as `referralCodeProvider`/`bioPageEditorDataProvider` |
| `lib/features/invoices/screens/invoice_design_screen.dart` | color fields (hex text input + live swatch — no color-picker package in `pubspec.yaml`, not adding one for two fields) + logo upload, reusing Batch 12's `AssetApi.upload`/`delete` image-picker convention |

## Changed files

| File | What changed |
|---|---|
| `lib/api/models/invoice.dart` | +`InvoiceBranding` |
| `lib/api/services/invoice_api.dart` | `getBranding`/`updateBranding` now typed; `logoAssetId` param made required-but-nullable (see above) |
| `lib/features/invoices/screens/invoices_list_screen.dart` | +a header row above the list with an "Invoice design" button that pushes `InvoiceDesignScreen` |

## Not a tab bar

Spec Section 3 describes Design as one of several Billing & Invoices
tabs, but `InvoicesListScreen` is mounted directly as a shell branch
with no local `AppBar` (the shared one lives in `AppShellScreen`, one
per sidebar destination, not per-screen actions). Restructuring that
for a second tab wasn't this batch's job — pushed as its own screen
instead, same "smallest useful slice" call Batch 4 made choosing a
plain list+form over a Worker detail page. If a real tab bar is wanted
across Invoices/Design/History/Analytics later, that's a shell-level
change, not a Design-screen one.

## Logo owner/asset type

Branding is organization-scoped, not per-invoice, so the upload call
uses `assetType: 'logo'`, `ownerType: 'organization'`, `ownerId: orgId`
— the values `AssetApi.upload`'s own doc comment lists for exactly
this case. No prior batch actually built this call (Batch 10 flagged
organization logo upload as deliberately out of scope), so there's no
existing call site to match against; this is the first one.

## Deliberately out of scope

- **History tab (email log)** and **Analytics tab** — same "kept
  correct, not yet consumed" status Batch 9 left them in; still true.
- **A real color picker** (swatches/wheel) — hex input only, see above.

## Deliberately unverified

No Flutter environment available. Checked by hand — all new/changed
files brace/paren-balanced, all relative imports resolve, ARB key
parity verified across all three locales (201/195/195).

## Suggested next

History (email log) is the smaller of the two remaining Billing &
Invoices items — `InvoiceApi.historyLog` is already fixed and typed as
`List<dynamic>`, just needs a model + list screen, no new interaction
patterns (no upload, no color input) the way Design needed. Analytics
is the bigger one — genuinely chart-heavy, probably wants its own
scoping pass rather than assuming it's a quick follow-up.
