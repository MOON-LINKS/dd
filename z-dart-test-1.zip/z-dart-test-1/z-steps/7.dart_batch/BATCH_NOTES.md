# Dart Batch 7 — Upcoming Bills (model + list/create/edit + mark-paid + convert-to-expense)

Same structure as Workers/Clients/Expenses, plus the two extra actions
Batch 6 flagged this entity would need: mark-paid and convert-to-expense.

## Before this batch: a full review pass, per your request

You asked me to check everything for issues before starting Batch 7. Found
two real bugs, both fixed as part of this batch (not scope creep — the
first one is in the exact file this batch rewrites anyway):

**1. `lib/api/services/upcoming_bill_api.dart` had a response-key bug.**
The old stub read `res.data['upcomingBill']` (create/get/update) and
`res.data['upcomingBills']` (list) — but `upcomingBillController.js`
actually wraps every response as `{ bill: ... }` / `{ bills: ... }`. Every
one of those calls would have thrown a null-cast exception the first time
a real screen used them. Never caught before now because nothing did —
this batch is the first time these methods are actually exercised.

**2. `lib/shared/widgets/app_text_field.dart` hardcoded English.**
`isOptional` appended the literal string `' (optional)'` instead of using
`AppLocalizations.of(context)!.optionalFieldSuffix`, which already existed
for exactly this. Affected every optional field across Workers, Clients,
and Expenses forms — an Arabic or French user saw English "(optional)"
appended to an otherwise-translated label. Unrelated to Upcoming Bills,
but small and worth fixing immediately rather than filing away.

Everything else checked out: all other API services' response-key parsing
matches their controllers exactly, ARB files are in sync across all three
locales, router wiring is clean, and the Client/Expense models' handling
of the backend's inconsistent response shapes and COALESCE/undefined-vs-
null issues is correct.

## Requires Batches 4–6 already applied

Imports `current_organization_provider.dart` (Batch 4) and
`workers_provider.dart` (Batch 4, for the linked-worker dropdown, same as
Batch 6's Expense form). Neither is duplicated here.

## New files

| File | Goes in |
|---|---|
| `lib/api/models/upcoming_bill.dart` | new |
| `lib/features/upcoming_bills/providers/upcoming_bills_provider.dart` | new |
| `lib/features/upcoming_bills/screens/upcoming_bills_list_screen.dart` | new |
| `lib/features/upcoming_bills/screens/upcoming_bill_form_screen.dart` | new |
| `lib/features/upcoming_bills/widgets/upcoming_bill_list_tile.dart` | new |

## Replaces existing files

| File | What changed |
|---|---|
| `lib/api/services/upcoming_bill_api.dart` | Full rewrite — fixes bug #1 above, moves to the typed-model pattern (returns `UpcomingBill` instead of raw `Map`). |
| `lib/shared/widgets/app_text_field.dart` | One-line fix for bug #2 — now reads `optionalFieldSuffix` from `AppLocalizations` instead of a hardcoded string. |
| `lib/app/router.dart` | Same shape of diff as batches 4–6: one new import, `_screenForPath('/upcoming-bills', ...)` now returns `UpcomingBillsListScreen()`. Workers/Clients/Expenses lines untouched. |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | 11 new keys (title/due-date/reminder labels, paid/unpaid/converted status labels, mark-paid and convert-to-expense action labels + confirm dialog copy). Everything from batches 4–6 is untouched. |

## Why `markPaid`/`convertToExpense` don't return a parsed `UpcomingBill`

Worth reading before extending this pattern — this is a different problem
than Client's/Expense's inconsistent-shape issue. `markBillPaid`'s response
is `{ bill: { id, title, amount, is_paid } }` — genuinely too sparse to
build a full `UpcomingBill` from (missing `due_date`, which this model
treats as required, along with everything else). `convertBillToExpense`'s
bill payload is similarly sparse. Rather than make half the model's fields
nullable just to accommodate two endpoints, `UpcomingBillApi.markPaid`
returns `void` and `convertToExpense` returns just the new `expenseId`
(the one genuinely new piece of information worth surfacing). Both call
sites invalidate `upcomingBillsProvider` afterward instead — this is
already how every mutation in this codebase behaves (see `workers_provider
.dart`'s doc comment), so nothing here is a special case, it's just the
first time an endpoint's response was too sparse to parse into anything
at all rather than merely inconsistent field-to-field.

## The `linkedJobId`/`proofAssetId` pass-through — a real risk, not caution for its own sake

`updateUpcomingBill`'s SQL uses `COALESCE` for every field including
`linked_job_id` and `proof_asset_id`. This form has no UI for either (Jobs
is still a placeholder; proof-document upload is out of scope the same way
Worker's photo upload was in Batch 4). The tempting shortcut — just don't
send those keys from this form — would actually be a live bug: omitting a
key makes it `undefined` in Express, and pg's driver rejects an undefined
bind parameter outright (this is the exact class of bug Batch 6's
`linkedWorkerId` fix addressed for Expense). So editing *any* bill that
already has a linked job would crash, purely because this form has nowhere
to display that field. The fix: `UpcomingBillFormScreen` always passes
`widget.bill!.proofAssetId` / `widget.bill!.linkedJobId` straight through
unchanged on every edit — never omitted, never a fresh value the form
invented. `UpcomingBill.toJson()`'s doc comment has the full reasoning.

## Convert-to-expense doesn't require paid-first

`convertBillToExpense`'s backend check is only `bill.converted_expense_id
IS NULL` — it never checks `is_paid`. So the UI doesn't invent that
ordering constraint either: "Convert to expense" is available on any
not-yet-converted bill regardless of paid status, both actions can appear
in the overflow menu at once. Confirmed via dialog first, since converting
creates a new expense record that isn't something to undo from this
screen.

## Overflow menu instead of a second/third icon button

Worker/Client/Expense tiles all had exactly one action (delete) alongside
the row, so a single trailing `IconButton` was enough. Upcoming Bills can
have up to three (mark-paid, convert, delete) depending on state — rather
than crowd three icons into the trailing area, `UpcomingBillListTile` uses
a `PopupMenuButton` that only shows the actions that currently apply
(mark-paid hidden once paid, convert hidden once converted).

## Deliberately out of scope for this batch

- **Filtering by paid/unpaid** — `UpcomingBillApi.list` already accepts
  `isPaid`, unused by this batch's screen (paid/unpaid is shown visually
  per-row instead). Same scope call as every other batch's list screen.
- **The reminder cron/notification itself** — `reminder_days_before` is
  captured and editable in the form, same as the backend already accepts
  it, but nothing sends a reminder yet. `upcomingBillController.js`'s own
  top-of-file comment says the scheduled job is separate follow-up work
  blocked on formalizing recurring-interval fields — this batch doesn't
  change that, just captures the data cleanly on the Flutter side.
- **Proof-document upload** — same reasoning as Worker's photo upload;
  `proofAssetId` is preserved on edit but never settable from this form.

## Suggested next
Jobs is now the only entity left without a real screen, and it's the one
Batch 5's notes already flagged as meaningfully bigger than a flat
model+form (day_days + day_assignments, postpone vs. original_due_date,
snapshot get/save). Worth a dedicated scoping pass rather than assuming
it's "batch 8, same pattern again" — the other five entities all reduced
to the same shape, Jobs genuinely doesn't.
