# Dart Batch 10 — Settings (appearance, organization profile, account, danger zone)

Batch 9's "suggested next" called this one: the theme toggle has lived as
a bare icon in the app bar since Step 3 with no permanent home, and
`SidebarAccountMenu` has stood in for a real account screen with just a
logout button since it was first built. This batch is that screen.

## Before this batch: found and fixed two real bugs

**1. `OrganizationApi.updateLogo()` sent the wrong request key.** The old
stub sent `{'assetId': ...}`, but `updateOrganizationLogo` in
`organizationController.js` reads `req.body.filename` — every call would
have 400'd. Fixed, and renamed the parameter to `filename` to match (it's
the `filename` field `AssetApi.upload()` returns, not its `assetId`
field — two different values, easy to conflate).

**2. `changePassword` is unreachable — not a shape bug, a routing gap.**
`authController.js` defines and exports a full `changePassword` handler
(current/new password, re-hash, `invalidateAllSessions`), but
`authRoutes.js` never mounts it on any route. This isn't something a
frontend fix can paper over — there's no endpoint to call. Rather than add
a client method against a route that doesn't exist (the same "silently
broken" mistake batches 7–9 already fixed elsewhere), Settings' Account
section simply doesn't have a "Change password" action this batch.
Documented in both `auth_api.dart` and inline in `settings_screen.dart`
with exactly what the backend fix would look like (mirror
`logoutAll`/`resetPass3`'s shape) so it's a fast follow-up, not a
rediscovery.

## Also fixed while touching these files: one duplicated constant

`create_organization_screen.dart` had a private `_organizationTypes` list
(the six verticals from spec Section 1) that nothing else could import.
Settings' organization-type editor needs the identical list — rather than
paste a second copy (which is exactly the kind of drift the list's own
comment warns against), it's now `core/constants/organization_types.dart`,
and onboarding imports it too. Behavior there is unchanged, just the
source of the list moved.

## New files

| File | Goes in |
|---|---|
| `lib/api/models/organization_profile.dart` | new |
| `lib/api/models/user_info.dart` | new — `UserInfo`, `UserOrganizationSummary`, `UserSession` |
| `lib/core/constants/organization_types.dart` | new — see above |
| `lib/features/settings/providers/organization_profile_provider.dart` | new |
| `lib/features/settings/providers/user_info_provider.dart` | new |
| `lib/features/settings/screens/settings_screen.dart` | new |
| `lib/features/settings/widgets/settings_section.dart` | new |
| `lib/features/settings/widgets/password_confirm_dialog.dart` | new — shared by logout-all/delete-account/delete-org |

## Replaces existing files

| File | What changed |
|---|---|
| `lib/api/services/auth_api.dart` | `getMe()` now returns typed `UserInfo` instead of a raw `Map` — the one API service still doing that; not a bug fix, just consistency now that this batch is its first real caller. `changePassword` intentionally absent — see above. |
| `lib/api/services/organization_api.dart` | Fixes bug #1. `get`/`update` now return typed `OrganizationProfile`. `delete` now returns the optional `warning` string (was silently discarded before — see `deleteOrganization`'s own comments on why it can still succeed with a warning if Stripe cancellation fails). `listMine` deliberately left as raw `List<dynamic>` — see the file's own comment on why widening that would touch working, unrelated gating code in `app_shell_screen.dart`. |
| `lib/features/onboarding/screens/create_organization_screen.dart` | Uses the shared `organizationTypes` list instead of its own private copy. No behavior change. |
| `lib/app/router.dart` | Same shape of diff as every batch since 4: one new import, `_screenForPath('/settings', ...)` now returns `SettingsScreen()`. |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | 27 new keys. Reuses `save`/`cancel`/`email`/`password`/`savedMessage`/`errorGeneric`/`couldNotOpenPdfError` from earlier batches. |

## Why the Organization section's controllers only seed once

`_OrganizationSectionState` tracks `_initializedForOrgId` and only copies
`profile.name`/`profile.organizationType` into the editable
controllers the first time that org's data loads — not on every rebuild.
Saving triggers `ref.invalidate(organizationProfileProvider(orgId))`,
which refetches and would otherwise stomp the text field with the
server's echo on every save (harmless today since it's the same value,
but the kind of bug that only shows up once a field has any real latency
or a second editor). Same defensive instinct as the day-grid's local-edit
pattern in Batch 8, applied to a single form instead of a whole tree.

## Why there's no logo uploader in this batch

`AssetApi.upload()` already exists and is correct, and this batch fixed
`OrganizationApi.updateLogo()` so the two would actually work together —
but no screen in the entire project has ever consumed `AssetApi` or
displayed an uploaded asset yet (checked before starting: zero
`image_picker` usage, zero `Image.network`/CDN-URL-building anywhere).
Building the first image-picker flow *and* the first "turn a stored
filename into a displayable image" convention, from scratch, as a side
detail of a Settings screen, felt like the wrong place to introduce both
patterns for the first time — they deserve their own small pass (probably
alongside Worker profile pics and Bio Page images, which need the exact
same two things) rather than being invented once here and copied
inconsistently later. `updateLogo` is fixed and ready for whenever that
pass happens.

## Why "Manage subscription" opens an external browser tab

`PaymentApi.getBillingPortalUrl()` already existed, typed, correct —
returns a Stripe-hosted URL (payment method, invoice history, all
Stripe's UI per spec Section 10). This batch's only job was wiring it to
a button via `url_launcher` (already a dependency since Batch 9's PDF
viewer), same `launchUrl(..., mode: LaunchMode.externalApplication)` call
`InvoiceDetailScreen` already makes for PDFs — reused the pattern rather
than inventing a second way to open a URL.

## Danger zone: both actions are genuinely destructive and both work

`deleteOrganization` and `deleteAccount` are real, tested-by-reading
endpoints (password re-confirmation, `deleteAccount` also requires
re-typing the email per spec Section 9) — not stubbed. After a successful
org delete, no manual navigation is needed: invalidating
`myOrganizationsProvider` is enough, `app_shell_screen.dart`'s existing
gate redirects to onboarding on its own the moment the list comes back
empty. After account delete, `authStateProvider.markLoggedOut()` mirrors
what `SidebarAccountMenu`'s logout button already does.

## Deliberately out of scope for this batch

- **Change password** — flagged above; needs a backend route, not a
  frontend workaround.
- **Organization logo upload/display** — flagged above; needs the app's
  first image-picker + asset-display convention, shared with Worker/Bio
  Page, not a one-off built here.
- **Editing full name** — no backend endpoint updates a user's
  `full_name` (checked `authController.js`: register sets it once,
  nothing else touches it). Shown read-only for that reason.
- **Per-device logout** (revoking a single session from the list) —
  `authController.js` only exposes `logout` (current device) and
  `logoutAll` (every device); there's no
  `DELETE /auth/sessions/:sessionId`-style endpoint to revoke just one
  listed session. The sessions list is shown for visibility; only the
  all-devices action is wired to a button.
- **No Flutter environment available in this session to run
  `flutter analyze`/`flutter test`** — same disclosure every batch since
  8 has made. Checked by hand against established patterns, all relative
  imports verified to resolve, all files brace/paren-balanced. Please run
  `flutter analyze` after merging.

## Suggested next

Bio Page and Referrals are the two sidebar destinations still on
`PlaceholderScreen`. Bio Page is probably next — and it's the natural
place to finally build the image-picker + asset-display pattern this
batch deliberately deferred, since a public bio page is meaningless
without images. Referrals (`referral_api.dart` already exists, per Step
1's route-coverage pass) is the smaller, more self-contained one if you'd
rather bank an easy win first.
