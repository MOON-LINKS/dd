# Dart Batch 9 — Billing & Invoices (invoices tab: list/generate/detail/payment/PDF/email)

Batch 8's "suggested next" called this one: `invoice_api.dart` already
existed (Step 1's API layer pass covered all 96 routes) and Jobs' newly
UI-visible `invoiced` flag is exactly what generating an invoice flips.
This batch is the "Invoices" tab specifically — the flat list + individual
invoice per spec Section 3's own split. Design (branding) and History
(email log) tabs are separate, out of scope here, see below.

## Before this batch: found and fixed three real bugs in the existing stub

Same review-first approach every batch since 7 has taken.

**1. `InvoiceApi.get()` silently dropped `lineItems`.** The old stub read
only `res.data['invoice']` and discarded the rest — but `getInvoice` in
`invoiceController.js` returns `{ invoice, lineItems }`, and `lineItems`
(the per-worker/per-job breakdown) is the actual point of an invoice
detail screen, not an optional extra. Not a crash — worse, a silent data
loss that would only be noticed by someone staring at an empty invoice
detail wondering where the breakdown went. Fixed by parsing both into a
new `InvoiceDetail` wrapper.

**2. `InvoiceApi.historyLog()` read the wrong key.** The old stub read
`res.data['history']`, but `listEmailLog` in `emailLogController.js`
wraps its response as `{ emailLog: rows, page, pageSize }` — this would
have thrown a null-cast exception the first time anything called it. Same
class of bug as Batch 7's `upcomingBillApi` and Batch 8's
`jobTemplateApi` fixes. Fixed in passing while rewriting the file, even
though nothing calls `historyLog` yet (History tab is out of scope this
batch) — leaving a known-broken method sitting in a file this batch was
already rewriting felt worse than the two extra lines to fix it.

**3. `getBranding()`/`updateBranding()` returned the whole envelope
instead of unwrapping it.** Not a crash, but `getInvoiceBranding` returns
`{ branding: {...} }` and the old stub returned that entire object rather
than the `branding` value itself — misleading for whoever eventually
calls it. Fixed alongside #2 for the same "already in the file" reason.

Everything else checked out: `list`/`generateNow`/`recordPayment`/
`generatePdf`/`sendEmail`/`resendEmail`/`analytics` all matched their
controllers' actual response shapes on the first pass.

Also removed `lib/features/home/screens/home_shell_screen.dart` — dead
code left over from Step 3 (superseded by `AppShellScreen` +
`DashboardScreen` at the time, per that step's own notes, but the file
itself was never actually deleted from the project). Confirmed nothing
imports it before removing.

## Requires Batches 3–8 already applied

Nothing new beyond what Batch 8 already required — no invoice screen
needs Workers/Clients/Jobs providers directly (client name and worker/job
names for line items already arrive pre-joined from the backend).

## New files

| File | Goes in |
|---|---|
| `lib/api/models/invoice.dart` | new — `Invoice`, `InvoiceLineItem`, `InvoiceDetail`, `GenerateInvoicesResult` |
| `lib/features/invoices/providers/invoices_provider.dart` | new |
| `lib/features/invoices/providers/invoice_detail_provider.dart` | new — family keyed by a `(orgId, invoiceId)` record |
| `lib/features/invoices/screens/invoices_list_screen.dart` | new |
| `lib/features/invoices/screens/invoice_detail_screen.dart` | new |
| `lib/features/invoices/widgets/invoice_list_tile.dart` | new |

## Replaces existing files / removes one

| File | What changed |
|---|---|
| `lib/api/services/invoice_api.dart` | Full rewrite — typed (`Invoice`/`InvoiceDetail`/`GenerateInvoicesResult` instead of raw `Map`/`List<dynamic>`), fixes bugs #1–#3 above. |
| `lib/app/router.dart` | Same shape of diff as batches 4–8: one new import, `_screenForPath('/billing', ...)` now returns `InvoicesListScreen()`. Every other line untouched. |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | 15 new keys (generate-invoices dialog copy, payment/PDF/email action labels, sent/not-sent status, line-item labels). Reuses `paidStatusLabel`/`emptyListTitleGeneric`/`noneOptionLabel`/`save`/`cancel`/`hoursUnitSuffix` from earlier batches rather than duplicating. Everything else untouched. |
| `pubspec.yaml` | One line added: `url_launcher: ^6.3.1` — needed to actually open the generated PDF link; nothing in the project could open an external URL before this. |
| `lib/features/home/screens/home_shell_screen.dart` | **Deleted.** Dead code since Step 3, confirmed unimported before removing. |

## Why `recordPayment` doesn't return a parsed `Invoice`

Same precedent Batch 8 set for `JobApi.postpone`, applied here for the
identical reason: `recordPayment`'s response
(`{ invoice: { id, total_amount, amount_paid, amount_owed } }`) is
missing `period_start`, which this model treats as required. Rather than
make half the model nullable to accommodate one sparse endpoint,
`InvoiceApi.recordPayment` returns `void`, and `InvoiceDetailScreen`
invalidates both `invoiceDetailProvider` and `invoicesProvider` afterward.

## `Invoice`'s five inconsistent response shapes — one more than `Job` had

Worth reading in `invoice.dart`'s doc comment before extending this
further — `listInvoices`, `getInvoice`/`generatePdf`, `generateInvoicesNow`,
and `recordPayment` each return a genuinely different subset of fields
(no `client_name` from generate, no `updated_at` from list, etc.). Same
category of problem as `Job`/`Client`/`UpcomingBill`, just with one extra
variant. Nullable fields throughout are why, not an oversight.

## Why "View PDF" always regenerates rather than checking `pdfAssetId` first

`generatePdf` unconditionally rebuilds the PDF from current invoice data
every time it's called — there's no cheaper "just fetch the existing one"
path, and building one is the correct behavior anyway if a payment was
recorded since the last PDF was generated (the backend doesn't
auto-regenerate on payment). Rather than add client-side staleness
tracking to decide when to regenerate, `InvoiceDetailScreen` always calls
`generatePdf` and opens whatever URL comes back — simpler, always correct,
and matches what `sendInvoiceEmailInternal` already does server-side
(builds a PDF on demand if the invoice doesn't have a current one).

## Generate-invoices period picker sends nothing, not null, when left blank

`GenerateInvoicesResult`'s dialog lets `periodStart`/`periodEnd` stay
unset. `InvoiceApi.generateNow` omits those keys entirely from the request
body in that case (`if (periodStart != null) 'periodStart': ...`) rather
than sending `null` — `generateInvoicesNow`'s own logic
(`if (!periodStart || !periodEnd) { ...use previousCalendarMonth() }`)
only falls back to its default when the key is actually absent from
`req.body`, and Express would still see an explicit JSON `null` as
"provided." Sending nothing is what makes "leave both blank to generate
last month" actually work rather than silently trying to insert with a
null period.

## Deliberately out of scope for this batch

- **The Design tab (branding: colors, logo).** `InvoiceApi.getBranding`/
  `updateBranding` exist, typed, fixed (bug #3 above), unused by any
  screen — same "kept correct, not yet consumed" precedent Batch 8 left
  `JobTemplateApi.adminCreate`/`adminUpdate` in.
- **The History tab (email log).** Same situation — `historyLog()` exists,
  fixed (bug #2), unused. `email_log` is designed generically enough
  (`email_type` + `reference_id`) to eventually also back upcoming-bill
  reminder history per its own migration comment, once that's built —
  worth remembering when someone does pick up this tab.
- **The Analytics dashboard.** `InvoiceApi.analytics()` already existed
  and reads correctly (verified against `invoiceAnalyticsController.js`
  on this pass) — a genuinely separate, chart-heavy screen, not a small
  add-on to the list/detail screens this batch built.
- **Pagination UI.** `listInvoices` supports `page`/`pageSize` server-side;
  this batch fetches one page of 100 and doesn't build page controls —
  same scope call Jobs/Clients/Expenses made for their own unused list
  params.
- **Filtering by client or date range on the list screen.** `InvoiceApi
  .list` already accepts `clientId`/`startDate`/`endDate`, unused by
  `InvoicesListScreen`'s UI this batch.
- **No Flutter environment available in this session to run
  `flutter analyze`/`flutter test`** — same disclosure Batch 8 made.
  Every file was checked by hand against the exact patterns Batches
  4–8 established (response shapes, provider style, ARB usage, COALESCE/
  undefined-safety where relevant), and one real bug I introduced myself
  mid-build (a use-after-dispose on a dialog's `TextEditingController`)
  was caught and fixed during this same session's own review — which is
  exactly the kind of thing `flutter analyze` would also catch instantly.
  Please run it after merging before treating this as final.

## Suggested next

Every one of the 9 sidebar destinations now has either a real screen or a
clearly-scoped reason it doesn't yet (Bio page, Referrals, and Settings
remain `PlaceholderScreen`). Of those three, Settings is probably next —
it's the natural home for the theme toggle and locale switcher Step 3's
notes flagged as not having a permanent UI home yet, plus the account/
profile screen Step 3's `SidebarAccountMenu` has been standing in for with
just a logout button since it was first built.
