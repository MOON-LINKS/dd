# Flutter Environment Setup — Hive, Riverpod, API layer, theme, localization

This is the environment/foundation pass, per your request — before any
design, navigation, or screens. Everything here is scaffolding other code
will sit on top of; nothing renders a real screen yet except a one-line
placeholder confirming the wiring works.

## Folder structure

```
lib/
  main.dart                          — wires Hive + Riverpod + theme + locale
  core/
    storage/secure_storage.dart      — readToken / addToken / deleteToken
    hive/hive_service.dart           — non-sensitive local prefs
    theme/app_theme.dart             — light + dark ThemeData
    localization/
      vertical_labels_service.dart   — Section 6 fallback logic
    providers/
      theme_provider.dart
      locale_provider.dart
      organization_type_provider.dart
      vertical_labels_provider.dart
      auth_state_provider.dart
  api/
    api_client.dart                  — single Dio instance + auth interceptor
    api_exception.dart
    endpoints.dart                   — every path from routes.md, as constants
    services/                        — one file per backend module, 96 routes covered
  l10n/
    app_en.arb / app_ar.arb / app_fr.arb   — static UI chrome strings
assets/
  lang/
    en.json / ar.json / fr.json      — vertical-aware field labels
```

## Required setup steps (in order)

1. **`flutter create .`** in this folder if you haven't already scaffolded
   the native iOS/Android/web shells — everything above assumes a normal
   Flutter project layout, this delivery is just the `lib/`, `assets/`,
   `pubspec.yaml`, and `l10n.yaml` on top of it.
2. **`flutter pub get`** — pulls in `flutter_riverpod`, `hive`,
   `hive_flutter`, `flutter_secure_storage`, `dio`, `intl`, `path_provider`.
3. **`flutter gen-l10n`** (or just `flutter run`, which triggers it
   automatically since `generate: true` is set in `pubspec.yaml`) —
   generates `lib/l10n/app_localizations.dart` from the three ARB files.
   `main.dart` already imports it; it will not exist until this step runs.
4. **Android only:** `flutter_secure_storage` needs
   `minSdkVersion 18+` in `android/app/build.gradle` (default template is
   already 21+ in recent Flutter versions — usually a non-issue, worth
   a quick check).
5. **Point the API client at your backend** — defaults to
   `http://localhost:4000` (matches your `.env`'s `PORT=4000`). Override at
   run time without touching code:
   ```
   flutter run --dart-define=API_BASE_URL=http://192.168.1.x:4000
   ```
   (Use your machine's LAN IP, not `localhost`, when testing on a physical
   device — `localhost` on-device points at the device itself.)

## Two separate localization systems — don't conflate them

**`AppLocalizations` (ARB, generated)** — static app-chrome strings: "Save",
"Log in", "Dashboard", etc. Fixed key set, compiled at build time, normal
Flutter `flutter gen-l10n` pattern. Use `AppLocalizations.of(context)!.save`.

**`VerticalLabelsService` (JSON, runtime)** — Section 6's actual requirement:
`{organizationType}_{fieldKey}` with a `default_{fieldKey}` fallback, chosen
per the manager's organization type, not knowable at compile time. This is
NOT something ARB can express — ARB has no per-user dynamic key selection.
Use `ref.watch(verticalLabelProvider('worker_title'))` — returns "Coach" for
a gym org, "Tutor" for a tutoring center, "Worker" as the default, and the
raw key itself as a last-resort fallback if even the default is missing
(never a crash or a visible "MISSING_KEY" string to the manager).

Only three example field keys are seeded in `assets/lang/*.json`
(`worker_title`, `client_title`, `job_title`) — enough to prove the pattern
end to end. More keys get added here as each screen needs its own
vertical-aware label; this is intentionally not the full copywriting pass
(Section 13's open item), just the mechanism.

## API layer notes

- **Every one of the 96 routes in `routes.md`** has a corresponding method
  across the 14 files in `api/services/` — `auth_api.dart`,
  `organization_api.dart`, `worker_api.dart`, `client_api.dart`,
  `job_template_api.dart`, `job_api.dart`, `expense_api.dart`,
  `upcoming_bill_api.dart`, `payment_api.dart`, `invoice_api.dart`,
  `referral_api.dart`, `bio_page_api.dart`, `public_bio_page_api.dart`,
  `asset_api.dart`, `plan_api.dart`. `cron/*` and `/webhooks/*` are
  deliberately NOT wrapped — those aren't meant to be called from the app.
- **`x-client-type: app`** is set once, globally, in `api_client.dart`'s
  `BaseOptions` — this is what makes the backend return the token in the
  JSON body instead of an httpOnly cookie (see `authController.js`'s
  `sendAuthResponse`). Every request already carries it; nothing in the
  service files needs to think about this again.
- **Token attach is automatic** — the Dio interceptor reads
  `SecureStorage.readToken()` on every outgoing request and sets the
  `Authorization` header. Login/register/verifyOtp write the token via
  `SecureStorage.addToken()` themselves (inside `auth_api.dart`) — nothing
  else in the app should call `addToken`/`deleteToken` directly except
  logout/account-deletion flows, which already do.
- **Errors are normalized** — every service method is wrapped in
  `ApiClient.guard`, so callers always catch `ApiException` (with the
  backend's actual `message` string) rather than a raw `DioException`.
  `ApiException.isPlanLimitError` (checks for HTTP 402) is there
  specifically for the plan-gating responses used throughout
  (`workerController.js`, `bioPageButtonController.js`, etc.) — UI can
  special-case that into an upgrade prompt rather than a generic error toast.
- **Job snapshot save/get is intentionally loose-typed** (`List<dynamic>` /
  `Map<String, dynamic>`) for now — the exact local day-grid model (with
  the copy-paste clipboard state mentioned in Section 4) belongs to the
  Jobs UI work, not this environment pass.

## What's NOT in this batch (by design — you asked for environment only)

- No screens, no navigation/routing, no widgets beyond the one placeholder
  in `main.dart` confirming the wiring compiles.
- No local models/DTOs for API responses — services currently return raw
  `Map<String, dynamic>`/`List<dynamic>`. Worth deciding before screens are
  built: hand-written model classes, or a codegen approach (freezed/
  json_serializable)? Flagging now since it's a real fork in how the
  `services/` layer gets consumed, not something to default silently.
- No asset picker/crop UI (the `crop_your_image` + `flutter_image_compress`
  pattern you showed earlier) — `AssetApi.upload()` exists and is ready to
  be called from that kind of picker function once it's built.
- No push notification / FCM setup for the upcoming-bill reminders or
  invoice-sent notifications.

Ready for your steps whenever you send them.
