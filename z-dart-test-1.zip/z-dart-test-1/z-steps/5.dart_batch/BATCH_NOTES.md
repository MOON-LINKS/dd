# Dart Batch 5 — Client models + list/create/edit form

Same structure as Batch 4 (Workers), applied to Clients — model, typed
service, list screen, form screen. This one's simpler: no pay-type
branching, and the plan-limit gating that Workers had doesn't apply to
Clients on the backend.

## Requires Batch 4 already applied

This batch imports `lib/features/shell/providers/current_organization_provider.dart`,
which Batch 4 created. If that file isn't in your project yet, add it first —
it's not duplicated here.

## New files

| File | Goes in |
|---|---|
| `lib/api/models/client.dart` | new |
| `lib/features/clients/providers/clients_provider.dart` | new |
| `lib/features/clients/screens/clients_list_screen.dart` | new |
| `lib/features/clients/screens/client_form_screen.dart` | new |
| `lib/features/clients/widgets/client_list_tile.dart` | new |

## Replaces existing files — diff before overwriting if you want to confirm

| File | What changed |
|---|---|
| `lib/api/services/client_api.dart` | CRUD methods now return `Client` instead of raw `Map`. `addFeedback`/`listFeedback` are untouched — still raw, still unused by this batch, same reasoning as Batch 4 leaving `updateAsset`/`hoursSummary` alone (belongs to a detail page, not this slice). |
| `lib/app/router.dart` | Same shape of diff as Batch 4: one new import, `_screenForPath('/clients', ...)` now returns `ClientsListScreen()`. The Workers line from Batch 4 is untouched. |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | Two new keys this time (`phoneLabel`, `notesLabel`) — everything Batch 4 added is still there, untouched. Existing `email` key is reused for the email field rather than adding a duplicate. |

## Two things worth knowing before extending this to the next entity

**1. `Client` deliberately has no `createdAt`/`updatedAt` field — this is a
real backend inconsistency, not a simplification.** `clientController.js`'s
four endpoints return different shapes:

```
createClient  -> ...created_at
listClients   -> ...created_at, average_rating, feedback_count
getClient     -> SELECT *  (created_at AND updated_at)
updateClient  -> ...updated_at   (NO created_at at all)
```

A naive `Client.fromJson` parsing `created_at` would work fine in testing
(create/list/get all have it) and then throw the first time it's called on
an `updateClient` response. Rather than make the field nullable and quietly
carry that inconsistency into every future screen, it's left out of the
model entirely — this batch's screens never needed to display it anyway.
**If a client detail page later wants a "client since" date, the actual fix
is a one-line backend change** (add `created_at` to `updateClient`'s
`RETURNING` list, matching what `getClient` already returns) rather than
working around it in Dart. Flagging now since it's cheap to fix before
anything depends on it, expensive after.

**2. `ClientApi.create`/`update` always send `email`/`phone`/`notes` as real
strings (`''` when blank), never omit the key.** This isn't just a style
choice — `clientController.js`'s `update` query uses
`COALESCE($n, column)`, and Postgres's driver (`pg`) rejects `undefined`
bind parameters outright. If the JSON body omitted a key, `req.body.field`
would be `undefined` in Express, not `null` — and that throws rather than
being treated as "leave unchanged." Sending `''` sidesteps that risk
entirely, and also happens to be the right UX for a full-form resubmit
anyway (a field the user cleared should actually clear, not silently keep
its old value). **Worth knowing this pattern exists** if a future batch
ever builds a true partial-patch call (only sending the one field that
changed) instead of a full form resubmit — that's the case where the
`undefined` risk would actually bite, and it's a backend fix
(`workerController.js`'s `updateWorker` has the same `COALESCE` pattern, so
the same risk technically exists there too, currently only avoided because
`worker_form_screen.dart` also always sends every field).

## Rating display

`ClientListTile` shows the average rating (⭐ + one decimal) next to the
delete button when `listClients` returns one — this comes for free since
the backend already computes it via a join, no extra request needed. Only
shown when non-null (a client with zero feedback shows nothing, not "0.0").

## Deliberately out of scope for this batch

- **Client feedback** (`ClientApi.addFeedback`/`listFeedback` exist, typed
  loosely, unused) — same call as Workers' hours summary: this belongs on a
  client detail page, and feedback is tied to `jobId`, which doesn't have a
  real screen yet either (Jobs is still a placeholder).
- **Client detail page** — tapping a list row opens the edit form directly,
  same as Workers.

## Suggested next
Jobs is the natural next entity, but it's a meaningfully bigger slice than
Workers/Clients — the day-based structure (job_days + day_assignments,
postpone vs. original_due_date, snapshot get/save) doesn't reduce to a
single flat form the way these two did. Worth scoping that one specifically
before diving in, rather than assuming it's "batch 6, same pattern again."
