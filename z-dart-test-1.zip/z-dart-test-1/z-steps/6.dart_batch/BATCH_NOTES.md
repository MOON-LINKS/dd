# Dart Batch 6 — Expense models + list/create/edit form

Same structure as Workers/Clients — model, typed service, list screen, form
screen. One new thing this batch introduces: the form links to Workers data
(batch 4) for the optional "link to worker" dropdown, the first real
cross-entity reuse so far.

## Requires Batches 4 and 5 already applied

Imports `current_organization_provider.dart` (Batch 4) and
`workers_provider.dart` (Batch 4, for the linked-worker dropdown). Neither
is duplicated here.

## New files

| File | Goes in |
|---|---|
| `lib/api/models/expense.dart` | new |
| `lib/features/expenses/providers/expenses_provider.dart` | new |
| `lib/features/expenses/screens/expenses_list_screen.dart` | new |
| `lib/features/expenses/screens/expense_form_screen.dart` | new |
| `lib/features/expenses/widgets/expense_list_tile.dart` | new |
| `lib/features/expenses/utils/expense_category_labels.dart` | new — small shared helper, not a full model, so it doesn't live in `api/models/` |

## Replaces existing files

| File | What changed |
|---|---|
| `lib/api/services/expense_api.dart` | CRUD now returns `Expense` instead of raw `Map`. `create`/`update` both route through `Expense.toJson()` now (previously the stub built each request body by hand) — see the model file's doc comment for why that matters specifically for `linkedWorkerId`. |
| `lib/app/router.dart` | Same shape of diff as batches 4/5: one import, `_screenForPath('/expenses', ...)` now returns `ExpensesListScreen()`. Workers/Clients lines untouched. |
| `lib/l10n/app_en.arb`, `app_ar.arb`, `app_fr.arb` | 15 new keys (category labels for all 7 categories, plus `amountLabel`/`dateLabel`/`categoryLabel`/`recurringLabel`/`linkedWorkerOptionalLabel`/`noneOptionLabel`). Everything from batches 4/5 is untouched. |

## The `linkedWorkerId` null-vs-omitted issue — different from Client's, worth reading

Client's fix (batch 5) was "always send `''` instead of omitting a blank
field" — safe there because email/phone/notes are text columns, and an
empty string is a perfectly valid value for "cleared." **That fix does NOT
work for `linkedWorkerId`** — it's a UUID column
(`linked_worker_id = COALESCE($6, linked_worker_id)` in
`expenseController.js`'s `updateExpense`), and Postgres will reject `''` as
an invalid UUID outright. The actual fix here: always send the key, but
with a real JSON `null` (not an empty string) when no worker is linked.
`Expense.toJson()` does this unconditionally
(`'linkedWorkerId': linkedWorkerId` — no `if != null` guard), which is what
makes both `ExpenseApi.create` and `update` safe to route through the same
method, unlike Client where create/update needed slightly different
handling. Two different bugs, two different correct fixes — worth keeping
straight if a future entity has another optional foreign-key field.

One more asymmetry, lower-stakes: `expenseController.js`'s `createExpense`
*does* safely coalesce `undefined -> null` in JS before the query
(`linkedWorkerId || null`), so create was never actually at risk here — only
`update` was. `Expense.toJson()` doesn't special-case that; it just always
sends the key everywhere, which is correct for both and simpler than
tracking which of the two endpoints needed the workaround.

## `linkedJobId` is left out entirely — not a form field, not sent at all

`expenseController.js` supports linking an expense to a job, but Jobs has no
real screen yet (still a placeholder). Rather than add a field the form
can't meaningfully populate, `linkedJobId` isn't part of this batch's
`Expense` model or form at all. When Jobs exists, this is a small addition
to both — a second optional dropdown next to the worker one, same pattern.

## Worker link dropdown degrades quietly, not blockingly

`ExpenseFormScreen` reads `ref.watch(workersProvider(orgId)).valueOrNull ?? []`
rather than gating the whole form on that fetch finishing. Linking a worker
is optional, so a slow network or a failed worker-list fetch shouldn't stop
someone from logging an expense — worst case, the dropdown briefly only
shows "None" until the data arrives.

## One API worth double-checking against your actual Flutter version

`DropdownButtonFormField` uses `initialValue:` here rather than the older
`value:` parameter name — recent Flutter versions deprecated `value` in
favor of `initialValue` (matching `TextFormField`'s convention, since this
widget is uncontrolled, not a controlled `value`). If your installed Flutter
predates that rename, this is a one-word swap in both dropdowns in
`expense_form_screen.dart`, nothing structural.

## Deliberately out of scope for this batch

- **Filtering** (by category / date range) — `ExpenseApi.list` already
  accepts `category`/`from`/`to`, unused by this batch's screen. Same scope
  call as Workers/Clients showing an unfiltered list; a filter bar is a
  clean, small follow-up whenever it's wanted, not a structural change.
- **Recurring-expense automation** (auto-creating next month's instance) —
  `recurring` is stored as a flag on the backend, nothing generates future
  expenses from it automatically on either side. Purely descriptive for now.

## Suggested next
Upcoming Bills is the closest remaining entity to this same pattern
(CRUD + a couple of extra actions — mark-paid, convert-to-expense — rather
than a fundamentally different shape), so it's a reasonable batch 7 before
tackling Jobs' dedicated scoping conversation.
