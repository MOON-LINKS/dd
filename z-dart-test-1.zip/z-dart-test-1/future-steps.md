# Future Steps — Known Code Gaps

Not environment/config items (those get fixed automatically once local testing starts). These are actual bugs and unfinished pieces of code found while reviewing the batch history.

## Backend (Node)

### 1. `changePassword` is dead code
`authController.js` has a full working handler — validates current password, re-hashes the new one, invalidates all sessions — but `authRoutes.js` never mounts it on a route. There's no endpoint to call it.

**Fix:** add a route in `authRoutes.js`, e.g.:
```js
router.post('/change-password', requireAuth, changePassword)
```

### 2. No `GET /assets/:id`
Nothing in `assetController.js` / `assetRoutes.js` lets you resolve a bare asset ID back to a filename/URL after the fact.

### 3. Bio page logo doesn't resolve to a URL — inconsistent with invoice branding
`getBioPageEditorData` (`bioPageController.js`) returns `logo_asset_id` as a bare UUID and never joins it to a filename/URL. `getInvoiceBranding` does exactly this join for the same kind of field (`logoUrl`) elsewhere in the same codebase.

**Fix:** mirror the invoice-branding join into the bio page controller.

### 4. No per-device session revoke
`authController.js` only exposes `logout` (current device) and `logoutAll` (every device). There's no `DELETE /auth/sessions/:sessionId`-style endpoint to revoke a single listed session, even though the sessions list is already returned by `/auth/me`.

---

## Frontend (Flutter)

### 1. Nothing has been run through `flutter analyze` / `flutter test`
Every batch from #8 onward was built without a Flutter toolchain available — all verification was manual (brace-matching, import resolution, ARB key parity by hand). This is the single most likely place a real bug is hiding. **Run `flutter analyze` and `flutter test` before treating anything as final.**

### 2. `BioPageVersion` field names are inferred, not confirmed
`version` / `created_at` on the version-history model were inferred from what `publish` and `rollbackToVersion` already committed to — never checked directly against the `bio_page_snapshots` table or controller response. Worth a quick diff next time that route is touched.

### 3. Org logo preview degrades to a placeholder for logos from a prior session
Direct consequence of backend gap #3 above. A freshly-picked logo previews correctly this session (the upload response includes the filename), but a logo saved earlier has no way to resolve to a displayable image. Nothing more to fix client-side once the backend join is added.

### 4. Settings has no "Change password" action, and sessions list has no per-device revoke button
Both are the frontend correctly reflecting that the backend endpoints don't exist yet (backend gaps #1 and #4) — not bugs in the Flutter code itself. Will need wiring once those routes exist.

---

## Already found and fixed (no action needed)
For reference — these were flagged during batch reviews and confirmed fixed in the current code:
- `authController.getUserInfo` selecting `stripe_customer_id` off the wrong table
- `jobTemplateRoutes.js` admin routes using `requireAuth` instead of `requireAdmin`
- `organizationController.selectPlan` — a payment-bypass endpoint, removed
- Several Flutter API service methods reading the wrong response key (`upcomingBillApi`, `JobApi.postpone`, `JobTemplateApi.list`, `InvoiceApi.get`, `InvoiceApi.historyLog`, `OrganizationApi.updateLogo`)
- A use-after-dispose bug on a dialog's `TextEditingController`
