import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/providers/auth_state_provider.dart';
import '../features/shell/models/nav_item.dart';
import '../features/shell/screens/app_shell_screen.dart';
import '../features/shell/screens/placeholder_screen.dart';
import '../features/home/screens/dashboard_screen.dart';
import 'splash_screen.dart';
import '../features/auth/screens/login_screen.dart';
import '../features/auth/screens/register_screen.dart';
import '../features/auth/screens/verify_otp_screen.dart';
import '../features/auth/screens/forgot_password_screen.dart';
import '../features/onboarding/screens/create_organization_screen.dart';
import '../features/workers/screens/workers_list_screen.dart';
import '../features/clients/screens/clients_list_screen.dart';
import '../features/expenses/screens/expenses_list_screen.dart';
import '../features/upcoming_bills/screens/upcoming_bills_list_screen.dart';
import '../features/jobs/screens/jobs_list_screen.dart';
import '../features/invoices/screens/invoices_list_screen.dart';
import '../features/settings/screens/settings_screen.dart';
import '../features/referrals/screens/referrals_screen.dart';
import '../features/bio_page/screens/bio_page_screen.dart';

/// Bridges Riverpod state changes into something GoRouter's
/// `refreshListenable` understands (a plain Listenable), so `redirect`
/// re-runs automatically on login/logout without restarting the app or
/// manually calling router.refresh() from inside screens.
class _RouterRefreshNotifier extends ChangeNotifier {
  _RouterRefreshNotifier(Ref ref) {
    ref.listen(authStateProvider, (_, __) => notifyListeners());
  }
}

/// Real screens so far: Dashboard, Workers, Clients, Expenses, Upcoming
/// Bills, Jobs, Billing & Invoices, Settings, Referrals, Bio Page. Every
/// other branch renders the shared `PlaceholderScreen` until its real
/// screen is built. Keyed by path so this stays correct even if
/// `allNavItems`' order changes.
Widget _screenForPath(String path, BuildContext context) {
  if (path == '/dashboard') return const DashboardScreen();
  if (path == '/workers') return const WorkersListScreen();
  if (path == '/clients') return const ClientsListScreen();
  if (path == '/expenses') return const ExpensesListScreen();
  if (path == '/upcoming-bills') return const UpcomingBillsListScreen();
  if (path == '/jobs') return const JobsListScreen();
  if (path == '/billing') return const InvoicesListScreen();
  if (path == '/settings') return const SettingsScreen();
  if (path == '/referrals') return const ReferralsScreen();
  if (path == '/bio-page') return const BioPageScreen();
  final item = allNavItems.firstWhere((i) => i.path == path);
  return PlaceholderScreen(title: item.label(context));
}

final routerProvider = Provider<GoRouter>((ref) {
  final refreshNotifier = _RouterRefreshNotifier(ref);
  ref.onDispose(refreshNotifier.dispose);

  const authRoutePaths = {'/login', '/register', '/verify-otp', '/forgot-password'};

  return GoRouter(
    initialLocation: '/splash',
    refreshListenable: refreshNotifier,
    redirect: (context, state) {
      final authStatus = ref.read(authStateProvider);
      final onAuthRoute = authRoutePaths.contains(state.matchedLocation);
      final onSplash = state.matchedLocation == '/splash';

      // Still resolving SecureStorage on first launch — stay on splash.
      if (authStatus == AuthStatus.unknown) {
        return onSplash ? null : '/splash';
      }
      // Resolved — splash is never a valid destination past this point.
      if (onSplash) {
        return authStatus == AuthStatus.authenticated ? '/dashboard' : '/login';
      }
      if (authStatus == AuthStatus.unauthenticated && !onAuthRoute) {
        return '/login';
      }
      if (authStatus == AuthStatus.authenticated && onAuthRoute) {
        return '/dashboard';
      }
      return null;
    },
    routes: [
      GoRoute(path: '/splash', builder: (context, state) => const SplashScreen()),
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(path: '/register', builder: (context, state) => const RegisterScreen()),
      GoRoute(
        path: '/verify-otp',
        builder: (context, state) {
          final extra = state.extra as Map<String, dynamic>?;
          return VerifyOtpScreen(
            email: extra?['email'] as String? ?? '',
            verificationId: extra?['verificationId'] as String? ?? '',
          );
        },
      ),
      GoRoute(path: '/forgot-password', builder: (context, state) => const ForgotPasswordScreen()),
      GoRoute(
        path: '/onboarding/organization',
        builder: (context, state) => const CreateOrganizationScreen(),
      ),
      // Every sidebar destination gets its own branch (own nav stack,
      // preserved when switching tabs -- that's what indexedStack buys
      // over a plain nested GoRoute list). Built from `allNavItems`
      // rather than hand-listed here, so the sidebar and the router
      // structure can never drift apart.
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) =>
            AppShellScreen(navigationShell: navigationShell),
        branches: [
          for (final item in allNavItems)
            StatefulShellBranch(
              routes: [
                GoRoute(
                  path: item.path,
                  builder: (context, state) => _screenForPath(item.path, context),
                ),
              ],
            ),
        ],
      ),
    ],
  );
});
