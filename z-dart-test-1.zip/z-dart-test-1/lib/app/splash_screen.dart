import 'package:flutter/material.dart';

/// Shown only for the brief moment authStateProvider is `AuthStatus.unknown`
/// — i.e. while SecureStorage.readToken() is being awaited on app start.
/// Prevents a flash of the login screen for users who are already logged in.
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
