/// Uniform exception shape for every API call — every service method should
/// throw this rather than letting a raw DioException leak into UI code.
class ApiException implements Exception {
  final int? statusCode;
  final String message;

  ApiException({required this.message, this.statusCode});

  /// True for the plan-limit-reached responses used throughout the backend
  /// (workerController, bioPageButtonController, etc. all use 402 for this).
  bool get isPlanLimitError => statusCode == 402;

  bool get isUnauthorized => statusCode == 401 || statusCode == 403;
  bool get isNotFound => statusCode == 404;
  bool get isConflict => statusCode == 409;

  @override
  String toString() => message;
}
