import '../api_client.dart';
import '../endpoints.dart';
import '../models/client.dart';

class ClientApi {
  ClientApi._();
  static final _dio = ApiClient.instance;

  /// email/phone/notes are always sent as real strings ('' when the field is
  /// left blank), never omitted — clientController.js's create/update use
  /// `COALESCE($n, column)`, which treats SQL NULL as "leave unchanged." An
  /// omitted JSON key becomes `undefined` in req.body, and pg's driver
  /// rejects undefined bind parameters outright rather than treating it as
  /// NULL. Since this is a full-form resubmit (not a sparse patch), sending
  /// '' for a field the user cleared is also the correct UX anyway — a blank
  /// field on save should clear it, not silently leave the old value.
  static Future<Client> create(
    String orgId, {
    required String name,
    String email = '',
    String phone = '',
    String notes = '',
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.clients(orgId), data: {
        'name': name,
        'email': email,
        'phone': phone,
        'notes': notes,
      });
      return Client.fromJson(res.data['client'] as Map<String, dynamic>);
    });
  }

  static Future<List<Client>> list(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.clients(orgId));
      final rows = res.data['clients'] as List<dynamic>;
      return rows.map((row) => Client.fromJson(row as Map<String, dynamic>)).toList();
    });
  }

  static Future<Client> get(String orgId, String clientId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.client(orgId, clientId));
      return Client.fromJson(res.data['client'] as Map<String, dynamic>);
    });
  }

  static Future<Client> update(
    String orgId,
    String clientId, {
    required String name,
    String email = '',
    String phone = '',
    String notes = '',
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(Endpoints.client(orgId, clientId), data: {
        'name': name,
        'email': email,
        'phone': phone,
        'notes': notes,
      });
      // updateClient's RETURNING list doesn't include average_rating/
      // feedback_count (only listClients computes those) — fromJson handles
      // that fine (both stay null), but it does mean the updated Client
      // momentarily "loses" its rating in memory until the list refetches.
      // workers_list_screen.dart's pattern of invalidating the list provider
      // after every mutation (rather than patching the in-memory item) is
      // what actually fixes this — see clients_list_screen.dart.
      return Client.fromJson(res.data['client'] as Map<String, dynamic>);
    });
  }

  static Future<void> delete(String orgId, String clientId) {
    return ApiClient.guard(() async {
      await _dio.delete(Endpoints.client(orgId, clientId));
    });
  }

  // ------------------------------------------------------------------
  // Feedback endpoints — intentionally left untyped (raw Map/List) and
  // unused by this batch's screens, same as WorkerApi.updateAsset/
  // hoursSummary were left in batch 4: they belong to a Client detail page,
  // not the list+form slice this batch covers. Typing them now would mean
  // guessing at a ClientFeedback model's shape without a screen to prove it
  // against.
  // ------------------------------------------------------------------

  static Future<void> addFeedback(
    String orgId,
    String clientId, {
    required String jobId,
    int? rating,
    String? comment,
  }) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.clientFeedback(orgId, clientId), data: {
        'jobId': jobId,
        if (rating != null) 'rating': rating,
        if (comment != null) 'comment': comment,
      });
    });
  }

  static Future<List<dynamic>> listFeedback(String orgId, String clientId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.clientFeedback(orgId, clientId));
      return res.data['feedback'] as List<dynamic>;
    });
  }
}
