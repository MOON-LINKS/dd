import '../api_client.dart';
import '../endpoints.dart';
import '../models/user_info.dart';
import '../../core/storage/secure_storage.dart';

class AuthApi {
  AuthApi._();
  static final _dio = ApiClient.instance;

  /// Returns the verificationId needed for verifyOtp.
  static Future<String> register({
    required String email,
    required String password,
    String? fullName,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.register, data: {
        'email': email,
        'password': password,
        'fullName': fullName,
      });
      return res.data['verificationId'] as String;
    });
  }

  /// On success, stores the token via SecureStorage automatically —
  /// callers don't need to touch addToken themselves after this.
  static Future<void> verifyOtp({
    required String otp,
    required String verificationId,
    required String deviceName,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.verifyOtp, data: {
        'otp': otp,
        'verificationId': verificationId,
        'deviceName': deviceName,
      });
      await SecureStorage.addToken(res.data['token'] as String);
    });
  }

  static Future<void> login({
    required String email,
    required String password,
    required String deviceName,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.login, data: {
        'email': email,
        'password': password,
        'deviceName': deviceName,
      });
      await SecureStorage.addToken(res.data['token'] as String);
    });
  }

  static Future<void> logout() {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.logout);
      await SecureStorage.deleteToken();
    });
  }

  static Future<void> logoutAll({required String password}) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.logoutAll, data: {'password': password});
      await SecureStorage.deleteToken();
    });
  }

  /// Typed as of this batch — was `Future<Map<String, dynamic>>` before,
  /// the one API service still returning a raw map. Not a bug fix (the
  /// old shape was correct), just consistency: this batch's Settings
  /// screen is the first real caller, and every other service in the app
  /// already returns a typed model. See user_info.dart's doc comment.
  static Future<UserInfo> getMe() {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.me);
      return UserInfo.fromJson(res.data['user'] as Map<String, dynamic>);
    });
  }

  /// Returns resetId needed for resetPasswordVerify.
  static Future<String> resetPasswordRequest({required String email}) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.resetPasswordRequest, data: {'email': email});
      return res.data['resetId'] as String;
    });
  }

  /// Returns resetToken needed for resetPasswordConfirm.
  static Future<String> resetPasswordVerify({
    required String resetId,
    required String otp,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.resetPasswordVerify, data: {
        'resetId': resetId,
        'otp': otp,
      });
      return res.data['resetToken'] as String;
    });
  }

  static Future<void> resetPasswordConfirm({
    required String newPass,
    required String resetToken,
  }) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.resetPasswordConfirm, data: {
        'newPass': newPass,
        'resetToken': resetToken,
      });
    });
  }

  static Future<void> deleteAccount({
    required String email,
    required String password,
  }) {
    return ApiClient.guard(() async {
      await _dio.delete(Endpoints.deleteAccount, data: {
        'email': email,
        'password': password,
      });
      await SecureStorage.deleteToken();
    });
  }

  // changePassword: NOT implemented here — authController.js defines and
  // exports a `changePassword` handler, but authRoutes.js never mounts it
  // on a route (no `router.post('/change-password', ...)` or similar
  // exists anywhere in that file). There is currently no backend endpoint
  // this method could call. Adding a client method against a route that
  // doesn't exist would just be a different flavor of the "silently
  // broken" bugs fixed in batches 7–9 — see this batch's notes on why
  // Settings' Account section doesn't have a "Change password" action.
  // Once a route is added (mirroring resetPass3's shape —
  // currentPassword/newPassword in the body, requireAuth, then this same
  // `invalidateAllSessions` pattern the controller already implements),
  // this is a two-minute addition: mirror logoutAll's shape above.
}
