import '../api_client.dart';
import '../endpoints.dart';
import '../models/bio_page.dart';

class BioPageApi {
  BioPageApi._();
  static final _dio = ApiClient.instance;

  static Future<BioPageEditorData> getEditorData(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.bioPage(orgId));
      return BioPageEditorData.fromJson(res.data as Map<String, dynamic>);
    });
  }

  static Future<BioPage> updateDraft(
    String orgId, {
    String? title,
    String? shortBio,
    String? colorPreset,
    String? slug,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(Endpoints.bioPage(orgId), data: {
        if (title != null) 'title': title,
        if (shortBio != null) 'shortBio': shortBio,
        if (colorPreset != null) 'colorPreset': colorPreset,
        if (slug != null) 'slug': slug,
      });
      return BioPage.fromJson(res.data['bioPage'] as Map<String, dynamic>);
    });
  }

  /// `updateBioPageLogo`'s response is `{ id, logo_asset_id }` only — far
  /// too sparse to build a full `BioPage` from (missing `slug`,
  /// `is_published`, everything else `BioPage` treats as required). Same
  /// "sparse response -> void + invalidate" convention as
  /// `InvoiceApi.recordPayment` (Batch 9). Always sends the `assetId` key,
  /// even when clearing the logo (`assetId: null`) — `updateBioPageLogo`
  /// destructures `req.body.assetId` directly with no COALESCE fallback,
  /// so an *omitted* key would bind `undefined` into the query and error,
  /// where an explicit JSON `null` correctly clears `logo_asset_id`. This
  /// endpoint is never called to mean "leave the logo alone" — that's
  /// simply not calling it at all — so there's no third state to represent.
  static Future<void> updateLogo(String orgId, {required String? assetId}) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.bioPageLogo(orgId), data: {'assetId': assetId});
    });
  }

  /// Slug availability lets the editor check as the manager types, without
  /// needing to attempt a save first — `checkSlugAvailability` is public
  /// (no auth), same route the create-org-style live-validation elsewhere
  /// in this app already uses the pattern for. This method existed nowhere
  /// in the previous stub even though its endpoint (`Endpoints.bioSlugCheck`)
  /// was already defined — the slug field had no live-check at all before
  /// this batch.
  static Future<bool> checkSlugAvailability(String slug, {String? excludeOrganizationId}) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.bioSlugCheck, queryParameters: {
        'slug': slug,
        if (excludeOrganizationId != null) 'excludeOrganizationId': excludeOrganizationId,
      });
      return res.data['available'] as bool;
    });
  }

  static Future<BioPageButton> addButton(
    String orgId, {
    required String label,
    required String url,
    required String buttonType, // 'call' | 'link' | 'social'
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.bioPageButtons(orgId), data: {
        'label': label,
        'url': url,
        'buttonType': buttonType,
      });
      return BioPageButton.fromJson(res.data['button'] as Map<String, dynamic>);
    });
  }

  static Future<BioPageButton> updateButton(
    String orgId,
    String buttonId, {
    String? label,
    String? url,
    String? buttonType,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(Endpoints.bioPageButton(orgId, buttonId), data: {
        if (label != null) 'label': label,
        if (url != null) 'url': url,
        if (buttonType != null) 'buttonType': buttonType,
      });
      return BioPageButton.fromJson(res.data['button'] as Map<String, dynamic>);
    });
  }

  static Future<void> deleteButton(String orgId, String buttonId) {
    return ApiClient.guard(() async {
      await _dio.delete(Endpoints.bioPageButton(orgId, buttonId));
    });
  }

  static Future<void> reorderButtons(String orgId, {required List<String> orderedButtonIds}) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.bioPageButtonsReorder(orgId), data: {
        'orderedButtonIds': orderedButtonIds,
      });
    });
  }

  // ---- Publish / versions — Batch 13. `publish`/`unpublish`/
  // `rollbackToVersion` were carried over unchanged from the old stub
  // (their shapes already lined up with the convention every other mutator
  // in this file follows: sparse response -> primitive or void + caller
  // invalidates). `listVersions` is the one method actually changed this
  // batch, from an unparsed `List<dynamic>` to typed `BioPageVersion`s now
  // that a screen exists to render them. ----

  static Future<int> publish(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.bioPagePublish(orgId));
      return res.data['version'] as int;
    });
  }

  static Future<void> unpublish(String orgId) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.bioPageUnpublish(orgId));
    });
  }

  static Future<List<BioPageVersion>> listVersions(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.bioPageVersions(orgId));
      return (res.data['versions'] as List<dynamic>)
          .map((v) => BioPageVersion.fromJson(v as Map<String, dynamic>))
          .toList();
    });
  }

  static Future<void> rollbackToVersion(String orgId, int version) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.bioPageRollback(orgId, version));
    });
  }
}
