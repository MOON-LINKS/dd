import '../api_client.dart';
import '../endpoints.dart';
import '../models/invoice.dart';

class InvoiceApi {
  InvoiceApi._();
  static final _dio = ApiClient.instance;

  /// `listInvoices` paginates (default pageSize 25, capped at 100
  /// server-side) — this pass fetches one generous page (100) and doesn't
  /// build pagination UI on top, same scope call Jobs/Clients/Expenses
  /// made for their own unused list-filter params. `clientId`/`startDate`/
  /// `endDate` are exposed here since the backend already supports them,
  /// even though this batch's list screen doesn't wire a filter UI yet.
  static Future<List<Invoice>> list(
    String orgId, {
    String? clientId,
    DateTime? startDate,
    DateTime? endDate,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.invoices(orgId), queryParameters: {
        if (clientId != null) 'clientId': clientId,
        if (startDate != null) 'startDate': startDate.toIso8601String().split('T').first,
        if (endDate != null) 'endDate': endDate.toIso8601String().split('T').first,
        'pageSize': 100,
      });
      final rows = res.data['invoices'] as List<dynamic>;
      return rows.map((row) => Invoice.fromJson(row as Map<String, dynamic>)).toList();
    });
  }

  /// periodStart/periodEnd both optional — omitted entirely (not sent as
  /// null) so the backend's own "defaults to previous full calendar month"
  /// logic in `previousCalendarMonth()` actually runs; sending an explicit
  /// null here would take a different code path than sending nothing.
  static Future<GenerateInvoicesResult> generateNow(
    String orgId, {
    DateTime? periodStart,
    DateTime? periodEnd,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.generateInvoices(orgId), data: {
        if (periodStart != null) 'periodStart': periodStart.toIso8601String().split('T').first,
        if (periodEnd != null) 'periodEnd': periodEnd.toIso8601String().split('T').first,
      });
      final rows = res.data['invoices'] as List<dynamic>;
      return GenerateInvoicesResult(
        message: res.data['message'] as String,
        invoices: rows.map((row) => Invoice.fromJson(row as Map<String, dynamic>)).toList(),
      );
    });
  }

  /// Fixes a real bug in the previous stub: it read
  /// `res.data['invoice']` and silently dropped `lineItems` entirely —
  /// the per-worker/per-job breakdown that's the actual point of an
  /// invoice detail screen. `getInvoice` returns both; this now parses
  /// both into `InvoiceDetail`.
  static Future<InvoiceDetail> get(String orgId, String invoiceId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.invoice(orgId, invoiceId));
      final lineItemRows = res.data['lineItems'] as List<dynamic>;
      return InvoiceDetail(
        invoice: Invoice.fromJson(res.data['invoice'] as Map<String, dynamic>),
        lineItems: lineItemRows
            .map((row) => InvoiceLineItem.fromJson(row as Map<String, dynamic>))
            .toList(),
      );
    });
  }

  /// Returns void rather than a parsed `Invoice` — `recordPayment`'s
  /// response (`{ invoice: { id, total_amount, amount_paid, amount_owed } }`)
  /// is missing `period_start`, which this model treats as required. Same
  /// precedent Batch 8 set for `JobApi.postpone`: the call site invalidates
  /// `invoiceDetailProvider`/`invoicesProvider` afterward instead of
  /// patching an in-memory item from a response too sparse to fully parse.
  static Future<void> recordPayment(
    String orgId,
    String invoiceId, {
    required double amountPaid,
  }) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.invoicePayment(orgId, invoiceId), data: {
        'amountPaid': amountPaid,
      });
    });
  }

  /// Returns the PDF URL directly rather than the whole raw response body
  /// — `pdfUrl` is the only thing this endpoint returns and the only thing
  /// any screen needs from it.
  static Future<String> generatePdf(String orgId, String invoiceId) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.invoicePdf(orgId, invoiceId));
      return res.data['pdfUrl'] as String;
    });
  }

  static Future<void> sendEmail(String orgId, String invoiceId) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.invoiceSend(orgId, invoiceId));
    });
  }

  static Future<void> resendEmail(String orgId, String invoiceId) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.invoiceResend(orgId, invoiceId));
    });
  }

  // ---- Design tab — Batch 14. Previously typed-but-unused
  // `Map<String, dynamic>` pass-throughs (Batch 9 had already fixed the
  // response-unwrapping bug); now returns the typed `InvoiceBranding`
  // this batch's screen actually renders. ----

  static Future<InvoiceBranding> getBranding(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.invoiceBranding(orgId));
      return InvoiceBranding.fromJson(res.data['branding'] as Map<String, dynamic>);
    });
  }

  /// Always sends `logoAssetId` as an explicit key (including `null` to
  /// clear) — same "no COALESCE fallback, so omission binds `undefined`"
  /// reasoning `BioPageApi.updateLogo`'s doc comment lays out for the
  /// structurally identical bio-page-logo endpoint. Unlike that endpoint,
  /// this one is called for color-only saves too, so `logoAssetId` isn't
  /// itself optional the way `primaryColor`/`secondaryColor` are — pass
  /// the current value back through on saves that don't touch the logo.
  static Future<InvoiceBranding> updateBranding(
    String orgId, {
    String? primaryColor,
    String? secondaryColor,
    required String? logoAssetId,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(Endpoints.invoiceBranding(orgId), data: {
        if (primaryColor != null) 'primaryColor': primaryColor,
        if (secondaryColor != null) 'secondaryColor': secondaryColor,
        'logoAssetId': logoAssetId,
      });
      return InvoiceBranding.fromJson(res.data['branding'] as Map<String, dynamic>);
    });
  }

  // ---- History tab — Batch 15. Previously typed-but-unused
  // `List<dynamic>` (Batch 9 had already fixed the response-unwrapping
  // bug); now returns the typed `InvoiceEmailLogEntry`s this batch's
  // screen renders. ----

  static Future<List<InvoiceEmailLogEntry>> historyLog(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.invoiceHistoryLog(orgId));
      final rows = res.data['emailLog'] as List<dynamic>;
      return rows.map((row) => InvoiceEmailLogEntry.fromJson(row as Map<String, dynamic>)).toList();
    });
  }

  // ---- Analytics tab — Batch 16. The previous comment here claimed this
  // method "already reads the response correctly, verified against
  // invoiceAnalyticsController.js" — that claim was wrong. Rewritten
  // below; see BATCH_NOTES for what was actually broken. ----

  /// `startDate`/`endDate` are both **required** by `getInvoiceAnalytics`
  /// (it 400s with "startDate and endDate are required" if either is
  /// missing) — the previous version sent optional `from`/`to` plus a
  /// `groupBy` the backend has never read, so every call under the old
  /// signature would have 400'd every time. There's no `groupBy` param on
  /// this endpoint at all — one call already returns every breakdown
  /// (`revenueTrend`, `byClient`, `byJob`) the analytics tab needs.
  static Future<InvoiceAnalytics> analytics(
    String orgId, {
    required DateTime startDate,
    required DateTime endDate,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.invoiceAnalytics(orgId), queryParameters: {
        'startDate': startDate.toIso8601String().split('T').first,
        'endDate': endDate.toIso8601String().split('T').first,
      });
      return InvoiceAnalytics.fromJson(res.data as Map<String, dynamic>);
    });
  }
}
