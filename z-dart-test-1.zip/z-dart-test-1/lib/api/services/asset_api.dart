import 'dart:typed_data';
import 'package:dio/dio.dart';
import '../api_client.dart';
import '../endpoints.dart';

class AssetApi {
  AssetApi._();
  static final _dio = ApiClient.instance;

  /// Generic upload used by every picker in the app (logo, worker profile
  /// pic, worker ID doc, bill proof, invoice attachment, bio page images) —
  /// mirrors the backend's ASSET_PRESETS table (assetController.js).
  ///
  /// [quality] is optional and can only lower the server's preset ceiling,
  /// never raise it (see the backend's Math.min clamp) — pass it for a
  /// slow-connection fallback, omit it to use the preset default.
  static Future<Map<String, String>> upload({
    required Uint8List bytes,
    required String fileName,
    required String assetType, // 'logo' | 'profile_pic' | 'worker_id' | 'bill' | 'invoice_attachment' | 'bio_page'
    required String ownerType, // 'organization' | 'worker' | 'bio_page' | 'upcoming_bill'
    required String ownerId,
    int? quality,
  }) {
    return ApiClient.guard(() async {
      final formData = FormData.fromMap({
        'file': MultipartFile.fromBytes(bytes, filename: fileName),
        'ownerType': ownerType,
        'ownerId': ownerId,
        'assetType': assetType,
        if (quality != null) 'quality': quality.toString(),
      });
      final res = await _dio.post(Endpoints.assets, data: formData);
      return {
        'assetId': res.data['assetId'] as String,
        'filename': res.data['filename'] as String,
      };
    });
  }

  static Future<void> delete(String assetId) {
    return ApiClient.guard(() async {
      await _dio.delete(Endpoints.asset(assetId));
    });
  }
}
