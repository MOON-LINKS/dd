import '../api_client.dart';
import '../endpoints.dart';
import '../models/job_template.dart';

class JobTemplateApi {
  JobTemplateApi._();
  static final _dio = ApiClient.instance;

  /// Bug fixed in this batch: the previous version read
  /// `res.data['jobTemplates']`, but `listJobTemplates` in
  /// jobTemplateController.js wraps its response as `{ templates: rows }`
  /// — every call would have thrown a null-cast exception. Never caught
  /// before now because nothing called this method until the job-creation
  /// form (this batch) needed the template dropdown.
  static Future<List<JobTemplate>> list(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.jobTemplates(orgId));
      final rows = res.data['templates'] as List<dynamic>;
      return rows.map((row) => JobTemplate.fromJson(row as Map<String, dynamic>)).toList();
    });
  }

  // Admin-only — not expected to be called from the manager-facing app,
  // included for completeness / a future internal admin tool. Untouched
  // by this batch.
  static Future<void> adminCreate({
    required String name,
    String? description,
    String? industry,
  }) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.adminCreateJobTemplate, data: {
        'name': name,
        if (description != null) 'description': description,
        if (industry != null) 'industry': industry,
      });
    });
  }

  static Future<void> adminUpdate(
    String templateId, {
    String? name,
    String? description,
    bool? isActive,
  }) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.adminUpdateJobTemplate(templateId), data: {
        if (name != null) 'name': name,
        if (description != null) 'description': description,
        if (isActive != null) 'isActive': isActive,
      });
    });
  }
}
