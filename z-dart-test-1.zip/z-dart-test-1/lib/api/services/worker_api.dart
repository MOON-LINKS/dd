import '../api_client.dart';
import '../endpoints.dart';
import '../models/worker.dart';
import '../models/worker_hours_summary.dart';

class WorkerApi {
  WorkerApi._();
  static final _dio = ApiClient.instance;

  static Future<Worker> create(
    String orgId, {
    required String name,
    required WorkerPayType payType,
    double? monthlyAmount,
    double? hourlyRate,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.workers(orgId), data: {
        'name': name,
        'payType': payType.toJson(),
        // Only the rate matching payType is sent — mirrors
        // validatePayTypeFields on the backend, which requires exactly one
        // of these depending on payType and doesn't care about the other.
        if (payType == WorkerPayType.monthly && monthlyAmount != null)
          'monthlyAmount': monthlyAmount,
        if (payType == WorkerPayType.hourly && hourlyRate != null)
          'hourlyRate': hourlyRate,
      });
      return Worker.fromJson(res.data['worker'] as Map<String, dynamic>);
    });
  }

  static Future<List<Worker>> list(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.workers(orgId));
      final rows = res.data['workers'] as List<dynamic>;
      return rows.map((row) => Worker.fromJson(row as Map<String, dynamic>)).toList();
    });
  }

  static Future<Worker> get(String orgId, String workerId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.worker(orgId, workerId));
      return Worker.fromJson(res.data['worker'] as Map<String, dynamic>);
    });
  }

  /// PATCH semantics on the backend (COALESCE-based) — only send the fields
  /// that changed. Building the request body here rather than reusing
  /// Worker.toJson() (which always emits name+payType+one rate) is
  /// deliberate: an edit screen that only touched the name shouldn't also
  /// resend payType/rate just because Worker.toJson() always includes them.
  static Future<Worker> update(
    String orgId,
    String workerId, {
    String? name,
    WorkerPayType? payType,
    double? monthlyAmount,
    double? hourlyRate,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(Endpoints.worker(orgId, workerId), data: {
        if (name != null) 'name': name,
        if (payType != null) 'payType': payType.toJson(),
        if (monthlyAmount != null) 'monthlyAmount': monthlyAmount,
        if (hourlyRate != null) 'hourlyRate': hourlyRate,
      });
      return Worker.fromJson(res.data['worker'] as Map<String, dynamic>);
    });
  }

  /// field: 'profile_image_id' | 'id_document_id'
  static Future<void> updateAsset(
    String orgId,
    String workerId, {
    required String assetId,
    required String field,
  }) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.workerAsset(orgId, workerId), data: {
        'assetId': assetId,
        'field': field,
      });
    });
  }

  static Future<void> delete(String orgId, String workerId) {
    return ApiClient.guard(() async {
      await _dio.delete(Endpoints.worker(orgId, workerId));
    });
  }

  static Future<WorkerHoursSummary> hoursSummary(
    String orgId,
    String workerId, {
    DateTime? from,
    DateTime? to,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.get(
        Endpoints.workerHoursSummary(orgId, workerId),
        queryParameters: {
          if (from != null) 'from': from.toIso8601String().split('T').first,
          if (to != null) 'to': to.toIso8601String().split('T').first,
        },
      );
      return WorkerHoursSummary.fromJson(res.data as Map<String, dynamic>);
    });
  }
}
