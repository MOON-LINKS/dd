import '../api_client.dart';
import '../endpoints.dart';
import '../models/organization_profile.dart';

class OrganizationApi {
  OrganizationApi._();
  static final _dio = ApiClient.instance;

  static Future<Map<String, dynamic>> create({
    required String name,
    required String organizationType,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.organizations, data: {
        'name': name,
        'organizationType': organizationType,
      });
      return res.data['organization'] as Map<String, dynamic>;
    });
  }

  /// Left as raw `List<dynamic>` deliberately — `myOrganizationsProvider`
  /// and `app_shell_screen.dart`'s org-existence gate both already read
  /// this as `Map<String, dynamic>` (`orgs.first['id']`,
  /// `org['organization_type']`), predating this batch. Typing this
  /// return value would mean also touching that gating code, which is
  /// working and outside what this batch set out to change — same
  /// "don't widen the blast radius" call made throughout. `get()` below
  /// (this batch's actual new caller) is typed properly instead.
  static Future<List<dynamic>> listMine() {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.organizations);
      return res.data['organizations'] as List<dynamic>;
    });
  }

  static Future<OrganizationProfile> get(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.organization(orgId));
      return OrganizationProfile.fromJson(res.data['organization'] as Map<String, dynamic>);
    });
  }

  static Future<OrganizationProfile> update(
    String orgId, {
    String? name,
    String? organizationType,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(Endpoints.organization(orgId), data: {
        if (name != null) 'name': name,
        if (organizationType != null) 'organizationType': organizationType,
      });
      return OrganizationProfile.fromJson(res.data['organization'] as Map<String, dynamic>);
    });
  }

  /// Bug fixed in this batch: the previous version sent
  /// `{'assetId': assetId}`, but `updateOrganizationLogo` in
  /// `organizationController.js` reads `req.body.filename` — every call
  /// would have hit `if (!filename) return res.status(400)...` and
  /// failed. Never caught before now because nothing called this method
  /// until Settings' logo uploader (this batch) needed it. Renamed the
  /// parameter from `assetId` to `filename` to match — callers pass the
  /// `filename` field `AssetApi.upload()` already returns (its `assetId`
  /// field is a different value, the `assets` table row id, which this
  /// endpoint doesn't want).
  static Future<void> updateLogo(String orgId, {required String filename}) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.organizationLogo(orgId), data: {'filename': filename});
    });
  }

  /// Returns the `warning` field when present — `deleteOrganization`
  /// still succeeds (200) even when it couldn't auto-cancel an active
  /// Stripe/Apple subscription, but surfaces a warning message in that
  /// case (see organizationController.js's comments on why it doesn't
  /// block deletion on that failure). Worth showing rather than
  /// discarding — a null return means no warning, deletion was clean.
  static Future<String?> delete(String orgId, {required String password}) {
    return ApiClient.guard(() async {
      final res = await _dio.delete(Endpoints.organization(orgId), data: {'password': password});
      return res.data['warning'] as String?;
    });
  }
}
