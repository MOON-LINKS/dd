import '../api_client.dart';
import '../endpoints.dart';

class PlanApi {
  PlanApi._();
  static final _dio = ApiClient.instance;

  /// Public, no auth — used both on a pre-login pricing page and inside
  /// the app's plan-selection/upgrade screens.
  static Future<List<dynamic>> listActive() {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.plans);
      return res.data['plans'] as List<dynamic>;
    });
  }
}
