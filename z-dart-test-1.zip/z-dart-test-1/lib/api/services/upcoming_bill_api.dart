import '../api_client.dart';
import '../endpoints.dart';
import '../models/upcoming_bill.dart';

class UpcomingBillApi {
  UpcomingBillApi._();
  static final _dio = ApiClient.instance;

  /// Fixes a real bug in the previous version of this file: it read
  /// `res.data['upcomingBill']` here (and `'upcomingBills'` in list()) —
  /// but `upcomingBillController.js` wraps every response as `{ bill: ... }`
  /// / `{ bills: ... }`, not `{ upcomingBill: ... }`. That mismatch would
  /// have thrown a null-cast exception on every call except delete —
  /// caught now because this pass is the first time these methods actually
  /// get exercised by a real screen.
  static Future<UpcomingBill> create(
    String orgId, {
    required String title,
    required double amount,
    required DateTime dueDate,
    int reminderDaysBefore = 7,
    String? proofAssetId,
    String? linkedWorkerId,
    String? linkedJobId,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(
        Endpoints.upcomingBills(orgId),
        data: UpcomingBill(
          id: '',
          title: title,
          amount: amount,
          dueDate: dueDate,
          reminderDaysBefore: reminderDaysBefore,
          isPaid: false,
          proofAssetId: proofAssetId,
          linkedWorkerId: linkedWorkerId,
          linkedJobId: linkedJobId,
        ).toJson(),
      );
      return UpcomingBill.fromJson(res.data['bill'] as Map<String, dynamic>);
    });
  }

  static Future<List<UpcomingBill>> list(String orgId, {bool? isPaid}) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.upcomingBills(orgId), queryParameters: {
        if (isPaid != null) 'isPaid': isPaid,
      });
      final rows = res.data['bills'] as List<dynamic>;
      return rows.map((row) => UpcomingBill.fromJson(row as Map<String, dynamic>)).toList();
    });
  }

  static Future<UpcomingBill> get(String orgId, String billId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.upcomingBill(orgId, billId));
      return UpcomingBill.fromJson(res.data['bill'] as Map<String, dynamic>);
    });
  }

  static Future<UpcomingBill> update(
    String orgId,
    String billId, {
    required String title,
    required double amount,
    required DateTime dueDate,
    required int reminderDaysBefore,
    String? proofAssetId,
    String? linkedWorkerId,
    String? linkedJobId,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(
        Endpoints.upcomingBill(orgId, billId),
        data: UpcomingBill(
          id: billId,
          title: title,
          amount: amount,
          dueDate: dueDate,
          reminderDaysBefore: reminderDaysBefore,
          isPaid: false, // not sent by toJson() — is_paid only changes via markPaid
          proofAssetId: proofAssetId,
          linkedWorkerId: linkedWorkerId,
          linkedJobId: linkedJobId,
        ).toJson(),
      );
      return UpcomingBill.fromJson(res.data['bill'] as Map<String, dynamic>);
    });
  }

  static Future<void> delete(String orgId, String billId) {
    return ApiClient.guard(() async {
      await _dio.delete(Endpoints.upcomingBill(orgId, billId));
    });
  }

  /// Returns void rather than a parsed `UpcomingBill` — markBillPaid's
  /// response (`{ bill: { id, title, amount, is_paid } }`) is missing
  /// `due_date`, which this model treats as required. Every screen in this
  /// codebase already invalidates its list provider after a mutation
  /// instead of patching the in-memory item, so there's no real need to
  /// parse this response at all — see upcoming_bills_list_screen.dart.
  static Future<void> markPaid(String orgId, String billId) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.markBillPaid(orgId, billId));
    });
  }

  /// Same reasoning as markPaid — convertBillToExpense's bill payload is
  /// too sparse to build a full UpcomingBill from. The one piece of that
  /// response worth returning is `expenseId`, since that's a real new
  /// entity the caller might reasonably want (e.g. to navigate straight to
  /// it) that a plain list-invalidate wouldn't otherwise surface.
  static Future<String> convertToExpense(String orgId, String billId) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.convertBillToExpense(orgId, billId));
      return res.data['expenseId'] as String;
    });
  }
}
