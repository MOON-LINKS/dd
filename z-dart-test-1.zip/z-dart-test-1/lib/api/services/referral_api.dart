import '../api_client.dart';
import '../endpoints.dart';
import '../models/referral.dart';

class ReferralApi {
  ReferralApi._();
  static final _dio = ApiClient.instance;

  /// Review pass note (kept brief since there's nothing to fix): unlike
  /// batches 7–10, every method below already matched its controller's
  /// actual response shape — no request-key or response-key bugs found
  /// here. Rewritten to typed models anyway since this batch is the first
  /// real caller and every other service in the app already returns typed
  /// models rather than raw `Map`/`List<dynamic>`.
  static Future<ReferralCode> getMyCode(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.myReferralCode(orgId));
      return ReferralCode.fromJson(res.data as Map<String, dynamic>);
    });
  }

  static Future<ReferralEarningsSummary> getEarnings(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.referralEarnings(orgId));
      return ReferralEarningsSummary.fromJson(res.data as Map<String, dynamic>);
    });
  }

  static Future<ReferralHistory> getHistory(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.referralHistory(orgId));
      return ReferralHistory.fromJson(res.data as Map<String, dynamic>);
    });
  }

  /// Public — no auth. Used for live-validating a code on the signup/
  /// checkout screen before submitting. Untouched by this batch (that
  /// screen already exists from earlier batches); kept here unchanged.
  static Future<bool> validateCode(String code) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.validateReferralCode, queryParameters: {'code': code});
      return res.data['valid'] as bool;
    });
  }

  // ---- Admin-only — untouched, out of scope for this batch's org-facing
  // screen, same "kept correct, not yet consumed" precedent left for
  // JobTemplateApi.adminCreate/adminUpdate (Batch 8) and
  // InvoiceApi.getBranding/historyLog (Batch 9). ----
  static Future<Map<String, dynamic>> adminIssuePayout({
    required String organizationId,
    required int amountCents,
    String? notes,
    bool allowBelowThreshold = false,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.adminIssuePayout, data: {
        'organizationId': organizationId,
        'amountCents': amountCents,
        if (notes != null) 'notes': notes,
        'allowBelowThreshold': allowBelowThreshold,
      });
      return res.data as Map<String, dynamic>;
    });
  }

  static Future<List<dynamic>> adminPendingPayouts() {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.adminPendingPayouts);
      return res.data['balances'] as List<dynamic>;
    });
  }
}
