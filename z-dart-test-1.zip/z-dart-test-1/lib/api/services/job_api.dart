import '../api_client.dart';
import '../endpoints.dart';
import '../models/job.dart';
import '../models/job_day.dart';

class JobApi {
  JobApi._();
  static final _dio = ApiClient.instance;

  static Future<Job> create(
    String orgId, {
    required String title,
    String? clientId,
    String? templateId,
    required DateTime dueDate,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.jobs(orgId), data: {
        'title': title,
        if (clientId != null) 'clientId': clientId,
        if (templateId != null) 'templateId': templateId,
        'dueDate': dueDate.toIso8601String().split('T').first,
      });
      return Job.fromJson(res.data['job'] as Map<String, dynamic>);
    });
  }

  static Future<List<Job>> list(
    String orgId, {
    JobStatus? status,
    String? clientId,
    DateTime? dueFrom,
    DateTime? dueTo,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.jobs(orgId), queryParameters: {
        if (status != null) 'status': status.toJson(),
        if (clientId != null) 'clientId': clientId,
        if (dueFrom != null) 'dueFrom': dueFrom.toIso8601String().split('T').first,
        if (dueTo != null) 'dueTo': dueTo.toIso8601String().split('T').first,
      });
      final rows = res.data['jobs'] as List<dynamic>;
      return rows.map((row) => Job.fromJson(row as Map<String, dynamic>)).toList();
    });
  }

  /// PATCH semantics (COALESCE-based) — only send fields that changed, same
  /// convention as WorkerApi.update. `dueDate` is deliberately not a
  /// parameter here at all: updateJob's SQL doesn't touch due_date, only
  /// postpone() below does — see jobController.js's comment on why (keeps
  /// the postponed_at/postponed_by audit trail from being bypassable via a
  /// plain update).
  static Future<Job> update(
    String orgId,
    String jobId, {
    String? title,
    String? clientId,
    String? templateId,
    JobStatus? status,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(Endpoints.job(orgId, jobId), data: {
        if (title != null) 'title': title,
        if (clientId != null) 'clientId': clientId,
        if (templateId != null) 'templateId': templateId,
        if (status != null) 'status': status.toJson(),
      });
      return Job.fromJson(res.data['job'] as Map<String, dynamic>);
    });
  }

  /// The only path that changes due_date; original_due_date is untouched
  /// server-side. Returns void rather than a parsed Job — postponeJob's
  /// response is missing status/client_id/template_id (see job.dart's doc
  /// comment on Job's four inconsistent response shapes), too sparse to
  /// build a full Job from, same call Batch 7 made for
  /// markPaid/convertToExpense. Callers invalidate jobsProvider afterward,
  /// which is already this codebase's standard post-mutation pattern.
  ///
  /// Bug fixed in this batch: the previous version of this method sent
  /// `{'dueDate': ...}`, but `postponeJob` in jobController.js reads
  /// `req.body.newDueDate` — every postpone call would have silently hit
  /// `if (!newDueDate) return res.status(400)...` and failed. Never caught
  /// before now because nothing called this method until this batch's
  /// screens did.
  static Future<void> postpone(
    String orgId,
    String jobId, {
    required DateTime newDueDate,
  }) {
    return ApiClient.guard(() async {
      await _dio.patch(Endpoints.jobPostpone(orgId, jobId), data: {
        'newDueDate': newDueDate.toIso8601String().split('T').first,
      });
    });
  }

  static Future<void> delete(String orgId, String jobId) {
    return ApiClient.guard(() async {
      await _dio.delete(Endpoints.job(orgId, jobId));
    });
  }

  /// Hydrates job + all its days + all assignments in one call (Section 14's
  /// pattern) — loaded into JobSnapshotNotifier's local state on open, then
  /// edited entirely client-side until saveSnapshot below.
  static Future<JobSnapshot> getSnapshot(String orgId, String jobId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.jobSnapshot(orgId, jobId));
      return JobSnapshot.fromJson(res.data as Map<String, dynamic>);
    });
  }

  /// The single Save button. `skippedDays` in the response lists any date
  /// that already had `invoiced = true` server-side and so was left
  /// untouched — the day-grid UI already locks invoiced days so this
  /// should normally be empty, but it's surfaced (not discarded) in case
  /// a day was invoiced by someone else between load and save.
  static Future<JobSnapshot> saveSnapshot(
    String orgId,
    String jobId, {
    required List<JobDay> days,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.put(Endpoints.jobSnapshot(orgId, jobId), data: {
        'days': days.map((d) => d.toJson()).toList(),
      });
      return JobSnapshot.fromJson(res.data as Map<String, dynamic>);
    });
  }
}

/// getJobSnapshot/saveJobSnapshot's response shape: `{ job, days,
/// skippedDays? }`. `job` here is the sparse row `fetchJobSnapshotData`
/// selects (id, title, status, client_id, template_id, original_due_date,
/// due_date, postponed_at — no client_name, no created_at), which is why
/// this isn't reused as a plain `Job` — parsing it as one would silently
/// carry two more null fields than the earlier four-shapes doc comment
/// accounts for. Kept as a raw map for the handful of fields the day-grid
/// screen actually needs (title, status), rather than growing Job with a
/// fifth response shape for a screen that never edits those fields anyway.
class JobSnapshot {
  final Map<String, dynamic> job;
  final List<JobDay> days;
  final List<String> skippedDays;

  const JobSnapshot({required this.job, required this.days, this.skippedDays = const []});

  factory JobSnapshot.fromJson(Map<String, dynamic> json) {
    return JobSnapshot(
      job: json['job'] as Map<String, dynamic>,
      days: (json['days'] as List<dynamic>? ?? [])
          .map((d) => JobDay.fromJson(d as Map<String, dynamic>))
          .toList(),
      skippedDays: (json['skippedDays'] as List<dynamic>? ?? []).map((d) => d.toString()).toList(),
    );
  }
}
