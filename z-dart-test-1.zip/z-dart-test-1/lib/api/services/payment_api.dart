import '../api_client.dart';
import '../endpoints.dart';

class PaymentApi {
  PaymentApi._();
  static final _dio = ApiClient.instance;

  /// Returns the Stripe Checkout URL to open (web/Android per Section 10).
  /// referralCode is optional — Batch 9's paymentController patch applies
  /// the 10% signup discount when present.
  static Future<String> createCheckoutSession(
    String orgId, {
    required String planId,
    required String billingCadence, // 'monthly' | 'yearly'
    String? referralCode,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.billingCheckout(orgId), data: {
        'planId': planId,
        'billingCadence': billingCadence,
        if (referralCode != null) 'referralCode': referralCode,
      });
      return res.data['url'] as String;
    });
  }

  static Future<void> changePlan(
    String orgId, {
    required String planId,
    required String billingCadence,
  }) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.billingChangePlan(orgId), data: {
        'planId': planId,
        'billingCadence': billingCadence,
      });
    });
  }

  static Future<void> cancelSubscription(String orgId, {required bool autoRenew}) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.billingCancel(orgId), data: {'autoRenew': autoRenew});
    });
  }

  /// Returns the Stripe billing portal URL (payment method updates, invoice
  /// history — all Stripe-hosted per Section 10).
  static Future<String> getBillingPortalUrl(String orgId) {
    return ApiClient.guard(() async {
      final res = await _dio.post(Endpoints.billingPortal(orgId));
      return res.data['url'] as String;
    });
  }

  /// iOS only — called right after StoreKit 2 reports a successful
  /// purchase, per Section 10's dual payment path.
  static Future<void> registerAppleTransaction(
    String orgId, {
    required String signedTransactionInfo,
  }) {
    return ApiClient.guard(() async {
      await _dio.post(Endpoints.billingAppleRegister(orgId), data: {
        'signedTransactionInfo': signedTransactionInfo,
      });
    });
  }
}
