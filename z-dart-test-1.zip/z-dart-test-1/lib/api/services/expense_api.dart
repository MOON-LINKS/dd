import '../api_client.dart';
import '../endpoints.dart';
import '../models/expense.dart';

class ExpenseApi {
  ExpenseApi._();
  static final _dio = ApiClient.instance;

  /// Uses Expense.toJson() for both create and update — see that method's
  /// doc comment for why `linkedWorkerId` is always sent explicitly (as a
  /// string or null) rather than omitted, which matters specifically for
  /// update.
  static Future<Expense> create(
    String orgId, {
    required ExpenseCategory category,
    required double amount,
    required DateTime date,
    required bool recurring,
    String? notes,
    String? linkedWorkerId,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.post(
        Endpoints.expenses(orgId),
        data: Expense(
          id: '',
          category: category,
          amount: amount,
          date: date,
          recurring: recurring,
          notes: notes,
          linkedWorkerId: linkedWorkerId,
        ).toJson(),
      );
      return Expense.fromJson(res.data['expense'] as Map<String, dynamic>);
    });
  }

  static Future<List<Expense>> list(
    String orgId, {
    ExpenseCategory? category,
    DateTime? from,
    DateTime? to,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.expenses(orgId), queryParameters: {
        if (category != null) 'category': category.toJson(),
        if (from != null) 'dateFrom': from.toIso8601String().split('T').first,
        if (to != null) 'dateTo': to.toIso8601String().split('T').first,
      });
      final rows = res.data['expenses'] as List<dynamic>;
      return rows.map((row) => Expense.fromJson(row as Map<String, dynamic>)).toList();
    });
  }

  static Future<Expense> get(String orgId, String expenseId) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.expense(orgId, expenseId));
      return Expense.fromJson(res.data['expense'] as Map<String, dynamic>);
    });
  }

  static Future<Expense> update(
    String orgId,
    String expenseId, {
    required ExpenseCategory category,
    required double amount,
    required DateTime date,
    required bool recurring,
    String? notes,
    String? linkedWorkerId,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.patch(
        Endpoints.expense(orgId, expenseId),
        data: Expense(
          id: expenseId,
          category: category,
          amount: amount,
          date: date,
          recurring: recurring,
          notes: notes,
          linkedWorkerId: linkedWorkerId,
        ).toJson(),
      );
      return Expense.fromJson(res.data['expense'] as Map<String, dynamic>);
    });
  }

  static Future<void> delete(String orgId, String expenseId) {
    return ApiClient.guard(() async {
      await _dio.delete(Endpoints.expense(orgId, expenseId));
    });
  }
}
