import 'package:dio/dio.dart';
import '../api_client.dart';
import '../endpoints.dart';

/// No requireAuth on any of these — used for the public-facing bio page
/// view (if the app itself ever renders someone's published page) and for
/// the live slug-check while a manager is editing in the builder.
class PublicBioPageApi {
  PublicBioPageApi._();
  static final _dio = ApiClient.instance;

  static Future<bool> checkSlugAvailability(
    String slug, {
    String? excludeOrganizationId,
  }) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.bioSlugCheck, queryParameters: {
        'slug': slug,
        if (excludeOrganizationId != null) 'excludeOrganizationId': excludeOrganizationId,
      });
      return res.data['available'] as bool;
    });
  }

  /// JSON data for native rendering — use this in-app rather than
  /// publicBioPageHtml, which is the raw HTML meant for a browser/webview.
  static Future<Map<String, dynamic>> getPublicData(String slug) {
    return ApiClient.guard(() async {
      final res = await _dio.get(Endpoints.publicBioPageData(slug));
      return res.data as Map<String, dynamic>;
    });
  }

  /// Returns the raw cached HTML string — only useful if you're loading it
  /// into a WebView. Prefer getPublicData for native Flutter rendering.
  static Future<String> getPublicHtml(String slug) {
    return ApiClient.guard(() async {
      final res = await _dio.get<String>(
        Endpoints.publicBioPageHtml(slug),
        options: Options(responseType: ResponseType.plain),
      );
      return res.data ?? '';
    });
  }
}
