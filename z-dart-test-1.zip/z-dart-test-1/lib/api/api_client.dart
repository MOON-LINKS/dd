import 'package:dio/dio.dart';
import '../core/storage/secure_storage.dart';
import 'api_exception.dart';

/// Single Dio instance for the whole app. Every service class in
/// api/services/ goes through this — nothing should construct its own Dio.
class ApiClient {
  ApiClient._();

  /// Override at build time: flutter run --dart-define=API_BASE_URL=https://api.yourapp.com
  /// Defaults to the local backend's PORT (see .env) for development.
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://localhost:4000',
  );

  static Dio? _dio;

  static Dio get instance {
    _dio ??= _build();
    return _dio!;
  }

  static Dio _build() {
    final dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 20),
      // x-client-type: 'app' is what tells the backend to return the token
      // in the JSON body instead of an httpOnly cookie — see
      // authController.js's sendAuthResponse. Every request from this app
      // needs this header, not just auth ones, since requireAuth checks it
      // too when deciding how a 401 should be communicated.
      headers: const {'x-client-type': 'app'},
    ));

    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await SecureStorage.readToken();
        if (token != null) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        handler.next(options);
      },
      onError: (DioException error, handler) {
        handler.next(error);
      },
    ));

    return dio;
  }

  /// Wraps any Dio call, converting DioException into ApiException with the
  /// backend's own message field (every controller responds with
  /// { message: '...' } on error) rather than Dio's generic description.
  static Future<T> guard<T>(Future<T> Function() call) async {
    try {
      return await call();
    } on DioException catch (e) {
      final data = e.response?.data;
      final message = (data is Map && data['message'] != null)
          ? data['message'].toString()
          : (e.message ?? 'network error');
      throw ApiException(message: message, statusCode: e.response?.statusCode);
    }
  }
}
