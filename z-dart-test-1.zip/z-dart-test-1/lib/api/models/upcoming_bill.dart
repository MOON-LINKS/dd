/// Response shapes are inconsistent across upcomingBillController.js's
/// endpoints, the same situation Client.fromJson documents — worth reading
/// before extending this further:
///
///   createUpcomingBill  -> ...created_at (no converted_expense_id)
///   listUpcomingBills   -> ...converted_expense_id, created_at
///   getUpcomingBill     -> SELECT *  (everything)
///   updateUpcomingBill  -> neither created_at NOR converted_expense_id
///   markBillPaid        -> id, title, amount, is_paid ONLY — far too sparse
///                           to build a full UpcomingBill from
///   convertBillToExpense -> id, title, amount, is_paid, converted_expense_id
///                           — also too sparse
///
/// `createdAt` and `convertedExpenseId` are nullable here for the same
/// reason Client leaves fields nullable rather than hiding the
/// inconsistency: an update() response will correctly parse into an
/// UpcomingBill with both null, which is momentarily "wrong" in memory
/// until the list re-fetches. That's fine — every screen in this codebase
/// invalidates the list provider after a mutation rather than patching the
/// in-memory item (see workers_provider.dart's doc comment), so this
/// momentary gap is never actually visible.
///
/// markBillPaid and convertBillToExpense are different in kind, not just
/// degree — they're missing `due_date`, which this model treats as
/// required (every bill has one). Rather than make `dueDate` nullable
/// everywhere just to accommodate two sparse endpoints,
/// `UpcomingBillApi.markPaid`/`convertToExpense` don't attempt to parse
/// their responses into `UpcomingBill` at all — see that file.
class UpcomingBill {
  final String id;
  final String title;
  final double amount;
  final DateTime dueDate;
  final int reminderDaysBefore;
  final bool isPaid;
  final String? proofAssetId;
  final String? linkedWorkerId;
  final String? linkedJobId;
  final String? convertedExpenseId;
  final DateTime? createdAt;

  const UpcomingBill({
    required this.id,
    required this.title,
    required this.amount,
    required this.dueDate,
    required this.reminderDaysBefore,
    required this.isPaid,
    this.proofAssetId,
    this.linkedWorkerId,
    this.linkedJobId,
    this.convertedExpenseId,
    this.createdAt,
  });

  factory UpcomingBill.fromJson(Map<String, dynamic> json) {
    return UpcomingBill(
      id: json['id'] as String,
      title: json['title'] as String,
      amount: _toDouble(json['amount']),
      dueDate: DateTime.parse(json['due_date'] as String),
      // COALESCE($5, 7) on the backend means this is never actually null on
      // the wire, but tolerate it anyway rather than trust that blindly.
      reminderDaysBefore: json['reminder_days_before'] == null
          ? 7
          : int.parse(json['reminder_days_before'].toString()),
      isPaid: json['is_paid'] as bool,
      proofAssetId: json['proof_asset_id'] as String?,
      linkedWorkerId: json['linked_worker_id'] as String?,
      linkedJobId: json['linked_job_id'] as String?,
      convertedExpenseId: json['converted_expense_id'] as String?,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'].toString())
          : null,
    );
  }

  /// Same NUMERIC-comes-back-as-a-JSON-string situation as Worker/Expense.
  static double _toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.parse(value.toString());
  }

  /// Always includes `linkedWorkerId` and `linkedJobId` explicitly (as a
  /// string or null), never omitted — same fix Expense.toJson() needed and
  /// for the identical reason: `updateUpcomingBill`'s SQL uses
  /// `linked_worker_id = COALESCE($6, linked_worker_id)` and
  /// `linked_job_id = COALESCE($7, linked_job_id)`, both UUID columns, so an
  /// omitted key becomes `undefined` in Express and pg's driver rejects an
  /// undefined bind parameter outright.
  ///
  /// This form has no job-linking or proof-document UI (Jobs is still a
  /// placeholder, and asset upload is out of scope the same way it was for
  /// Worker/Expense) — `linkedJobId` and `proofAssetId` are always the
  /// pass-through values from the bill being edited (or null on create),
  /// never something the form itself sets. That pass-through is what makes
  /// it safe to always send these keys: editing a bill that already has a
  /// linked job won't accidentally wipe it just because this form has
  /// nowhere to display or change it.
  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'amount': amount,
      'dueDate': dueDate.toIso8601String().split('T').first,
      'reminderDaysBefore': reminderDaysBefore,
      'proofAssetId': proofAssetId,
      'linkedWorkerId': linkedWorkerId,
      'linkedJobId': linkedJobId,
    };
  }
}
