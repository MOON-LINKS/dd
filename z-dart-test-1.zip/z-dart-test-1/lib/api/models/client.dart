/// Deliberately does NOT include createdAt/updatedAt. Worth knowing why if
/// you extend this model later (e.g. a "member since" field on a client
/// detail page): clientController.js's four endpoints return inconsistent
/// shapes around these two columns —
///   createClient  -> ...created_at
///   listClients   -> ...created_at, average_rating, feedback_count
///   getClient     -> SELECT * (created_at AND updated_at)
///   updateClient  -> ...updated_at   (no created_at at all)
/// so a single `createdAt` field would come back null after every edit
/// (updateClient never returns it), which is exactly the kind of thing that
/// looks fine in testing and then quietly breaks a "member since" label the
/// first time someone edits a client. Simplest correct fix is on the backend
/// (add created_at to updateClient's RETURNING list) — flagging it here
/// rather than allowing a nullable field to paper over it, since this batch's
/// screens don't display it and have no reason to carry the inconsistency
/// forward.
class Client {
  final String id;
  final String name;
  final String? email;
  final String? phone;
  final String? notes;

  /// Only ever populated by ClientApi.list() — listClients is the one
  /// endpoint that joins client_feedback to compute these. create/get/update
  /// responses don't include them, so both are null after those calls; the
  /// list screen is the only place these are read.
  final double? averageRating;
  final int? feedbackCount;

  const Client({
    required this.id,
    required this.name,
    this.email,
    this.phone,
    this.notes,
    this.averageRating,
    this.feedbackCount,
  });

  factory Client.fromJson(Map<String, dynamic> json) {
    return Client(
      id: json['id'] as String,
      name: json['name'] as String,
      email: json['email'] as String?,
      phone: json['phone'] as String?,
      notes: json['notes'] as String?,
      averageRating:
          json['average_rating'] == null ? null : (json['average_rating'] as num).toDouble(),
      feedbackCount: json['feedback_count'] == null ? null : json['feedback_count'] as int,
    );
  }

  /// Always emits all three optional fields (as '' rather than omitting the
  /// key when blank) — see client_api.dart's doc comment on why that matters
  /// here specifically, not just as a style choice.
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email ?? '',
      'phone': phone ?? '',
      'notes': notes ?? '',
    };
  }

  Client copyWith({
    String? name,
    String? email,
    String? phone,
    String? notes,
  }) {
    return Client(
      id: id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      notes: notes ?? this.notes,
      averageRating: averageRating,
      feedbackCount: feedbackCount,
    );
  }
}
