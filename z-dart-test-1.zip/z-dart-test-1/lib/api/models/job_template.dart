/// Read-only from the app's perspective — templates are admin-managed
/// (jobTemplateController.js's create/update are gated behind requireAdmin
/// and mounted at /admin/job-templates, not under an organization), the
/// manager-facing app only ever lists them for the job-creation dropdown.
class JobTemplate {
  final String id;
  final String name;
  final String? description;
  final String? industry;

  const JobTemplate({
    required this.id,
    required this.name,
    this.description,
    this.industry,
  });

  factory JobTemplate.fromJson(Map<String, dynamic> json) {
    return JobTemplate(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String?,
      industry: json['industry'] as String?,
    );
  }
}
