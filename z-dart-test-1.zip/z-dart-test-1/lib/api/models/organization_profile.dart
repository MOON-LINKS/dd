/// `getOrganization` and `updateOrganization` return different subsets of
/// this, same category of inconsistency `Job`/`Invoice`/`Client` already
/// document:
///
///   getOrganization    -> id, name, organization_type, logo_filename,
///                         plan_id, created_at, plan_name, max_workers,
///                         modules (joined against `plans`)
///   updateOrganization -> id, name, organization_type   (only)
///   updateOrganizationLogo -> id, logo_filename          (only)
///
/// Every field beyond `id`/`name`/`organizationType` is nullable here for
/// exactly that reason. `SettingsScreen` re-fetches via `get()` after any
/// update rather than trying to merge a sparse response into the existing
/// model — same "invalidate and refetch" convention every list screen in
/// this app already uses for its own provider.
class OrganizationProfile {
  final String id;
  final String name;
  final String organizationType;
  final String? logoFilename;
  final String? planId;
  final String? planName;
  final int? maxWorkers;

  /// Raw `modules` JSON from `plans` — a plan-defined feature list
  /// (e.g. which nav destinations are enabled). Kept as `List<dynamic>`
  /// rather than a typed enum list since this app doesn't gate any UI on
  /// it yet (no screen reads `modules` before this one), so inventing a
  /// closed type for values nothing consumes felt like the wrong kind of
  /// thoroughness — shown to the user as-is, revisit if/when feature
  /// gating by module is actually built.
  final List<dynamic>? modules;
  final DateTime? createdAt;

  const OrganizationProfile({
    required this.id,
    required this.name,
    required this.organizationType,
    this.logoFilename,
    this.planId,
    this.planName,
    this.maxWorkers,
    this.modules,
    this.createdAt,
  });

  factory OrganizationProfile.fromJson(Map<String, dynamic> json) {
    return OrganizationProfile(
      id: json['id'] as String,
      name: json['name'] as String,
      organizationType: json['organization_type'] as String,
      logoFilename: json['logo_filename'] as String?,
      planId: json['plan_id'] as String?,
      planName: json['plan_name'] as String?,
      maxWorkers: json['max_workers'] as int?,
      modules: json['modules'] as List<dynamic>?,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'].toString())
          : null,
    );
  }

  bool get hasActivePlan => planId != null;
}
