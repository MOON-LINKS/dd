/// `getBioPageEditorData` and `updateBioPageDraft` both return a full
/// `bio_pages` row (`SELECT *` / `RETURNING *`) — every field here is
/// populated by those two calls. `updateBioPageLogo`'s response
/// (`{ id, logo_asset_id }` only) is deliberately NOT parsed into this
/// model — see `BioPageApi.updateLogo`'s doc comment for why — so nothing
/// here needs to be nullable to accommodate a sparse endpoint the way
/// `Invoice`/`Job` do.
///
/// `renderedHtml` is still not modeled — the editor never needs the cached
/// HTML string itself (that's what the public route serves). `lastRenderedAt`
/// *is* modeled as of Batch 13: it's the "last published" timestamp the
/// publish section shows next to the status chip, nullable since a page
/// that's never been published has no render to report.
class BioPage {
  final String id;
  final String organizationId;
  final String slug;
  final String? title;
  final String? shortBio;
  final String? colorPreset;
  final String? logoAssetId;
  final bool isPublished;
  final DateTime? lastRenderedAt;

  const BioPage({
    required this.id,
    required this.organizationId,
    required this.slug,
    this.title,
    this.shortBio,
    this.colorPreset,
    this.logoAssetId,
    required this.isPublished,
    this.lastRenderedAt,
  });

  factory BioPage.fromJson(Map<String, dynamic> json) {
    return BioPage(
      id: json['id'] as String,
      organizationId: json['organization_id'] as String,
      slug: json['slug'] as String,
      title: json['title'] as String?,
      shortBio: json['short_bio'] as String?,
      colorPreset: json['color_preset'] as String?,
      logoAssetId: json['logo_asset_id'] as String?,
      isPublished: json['is_published'] as bool? ?? false,
      lastRenderedAt: json['last_rendered_at'] != null
          ? DateTime.tryParse(json['last_rendered_at'].toString())
          : null,
    );
  }
}

/// One row of `listBioPageVersions`' array. Mirrors the same "bare `int`
/// version number is the identifier, not a UUID" shape `BioPageApi.publish`
/// (returns `version` as `int`) and `.rollbackToVersion` (takes `version`
/// as `int` in the URL) already commit to — `version`/`createdAt` are the
/// two fields every row needs to be listable and rollback-able, and are
/// kept required rather than nullable since a version row that's missing
/// either isn't renderable as a list item at all.
class BioPageVersion {
  final int version;
  final DateTime createdAt;

  const BioPageVersion({required this.version, required this.createdAt});

  factory BioPageVersion.fromJson(Map<String, dynamic> json) {
    return BioPageVersion(
      version: json['version'] as int,
      createdAt: DateTime.parse((json['created_at'] ?? json['createdAt']).toString()),
    );
  }
}

/// One row shape only — `addBioPageButton`, `updateBioPageButton`, and
/// `getBioPageEditorData`'s list all return the exact same five columns,
/// no variants to document here unlike most other models in this app.
class BioPageButton {
  final String id;
  final String label;
  final String url;
  final String buttonType; // 'call' | 'link' | 'social'
  final int sortOrder;

  const BioPageButton({
    required this.id,
    required this.label,
    required this.url,
    required this.buttonType,
    required this.sortOrder,
  });

  factory BioPageButton.fromJson(Map<String, dynamic> json) {
    return BioPageButton(
      id: json['id'] as String,
      label: json['label'] as String,
      url: json['url'] as String,
      buttonType: json['button_type'] as String,
      sortOrder: json['sort_order'] as int? ?? 0,
    );
  }
}

/// `getBioPageFeatureFlags`' resolved result (plan defaults merged with any
/// per-plan `feature_limits` override) — every key in the backend's
/// `DEFAULTS` object is guaranteed present, so nothing here is nullable.
/// `bannerEnabled`/`animationsEnabled` are read and kept even though
/// nothing in this batch's UI gates on them yet (no banner/animation
/// controls built this batch) — they're part of the same flags payload and
/// cost nothing to carry through now rather than re-adding this model's
/// fields piecemeal later.
class BioPageFeatureFlags {
  final int maxButtons;
  final int maxSocialIcons;
  final bool animationsEnabled;
  final bool bannerEnabled;

  const BioPageFeatureFlags({
    required this.maxButtons,
    required this.maxSocialIcons,
    required this.animationsEnabled,
    required this.bannerEnabled,
  });

  factory BioPageFeatureFlags.fromJson(Map<String, dynamic> json) {
    return BioPageFeatureFlags(
      maxButtons: json['bio_page_max_buttons'] as int? ?? 6,
      maxSocialIcons: json['bio_page_max_social_icons'] as int? ?? 4,
      animationsEnabled: json['bio_page_animations_enabled'] as bool? ?? false,
      bannerEnabled: json['bio_page_banner_enabled'] as bool? ?? false,
    );
  }
}

/// Pairs `getBioPageEditorData`'s three top-level keys — same "always
/// fetched and used together, so wrap it" reasoning as `InvoiceDetail`
/// (Batch 9) and `JobSnapshot` (Batch 8).
class BioPageEditorData {
  final BioPage bioPage;
  final List<BioPageButton> buttons;
  final BioPageFeatureFlags featureFlags;

  const BioPageEditorData({required this.bioPage, required this.buttons, required this.featureFlags});

  factory BioPageEditorData.fromJson(Map<String, dynamic> json) {
    return BioPageEditorData(
      bioPage: BioPage.fromJson(json['bioPage'] as Map<String, dynamic>),
      buttons: (json['buttons'] as List<dynamic>)
          .map((e) => BioPageButton.fromJson(e as Map<String, dynamic>))
          .toList(),
      featureFlags: BioPageFeatureFlags.fromJson(json['featureFlags'] as Map<String, dynamic>),
    );
  }
}
