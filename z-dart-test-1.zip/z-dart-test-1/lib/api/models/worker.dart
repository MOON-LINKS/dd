/// 'monthly' | 'hourly' — matches workers.pay_type's CHECK constraint on the
/// backend exactly. An enum here (rather than a bare String, as the raw-Map
/// version effectively had) is the whole point of this pass: every call site
/// that switches on pay type gets exhaustiveness-checked by the analyzer
/// instead of trusting a string comparison to be spelled right.
enum WorkerPayType {
  monthly,
  hourly;

  static WorkerPayType fromJson(String value) => switch (value) {
        'monthly' => WorkerPayType.monthly,
        'hourly' => WorkerPayType.hourly,
        _ => throw FormatException('Unknown pay_type "$value" from API'),
      };

  String toJson() => switch (this) {
        WorkerPayType.monthly => 'monthly',
        WorkerPayType.hourly => 'hourly',
      };
}

class Worker {
  final String id;
  final String name;
  final WorkerPayType payType;

  /// Only one of these is ever non-null for a given worker — which one is
  /// determined by [payType], not by which field happens to be set. The
  /// backend enforces this the same way (workerController.js's
  /// validatePayTypeFields), so a Worker with payType == hourly and a
  /// non-null monthlyAmount should never actually come back from the API —
  /// but both stay nullable here rather than trusting that invariant blindly.
  final double? monthlyAmount;
  final double? hourlyRate;

  final DateTime createdAt;

  const Worker({
    required this.id,
    required this.name,
    required this.payType,
    this.monthlyAmount,
    this.hourlyRate,
    required this.createdAt,
  });

  /// Reads the backend's response shape directly — every worker* endpoint
  /// (createWorker, listWorkers, getWorker, updateWorker in
  /// controllers/workerController.js) returns raw Postgres column names
  /// (snake_case), not camelCase. That's different from what this same data
  /// looks like going the other way — see toJson() below.
  factory Worker.fromJson(Map<String, dynamic> json) {
    return Worker(
      id: json['id'] as String,
      name: json['name'] as String,
      payType: WorkerPayType.fromJson(json['pay_type'] as String),
      monthlyAmount: _toDoubleOrNull(json['monthly_amount']),
      hourlyRate: _toDoubleOrNull(json['hourly_rate']),
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }

  /// Postgres NUMERIC columns come back through the API as JSON strings
  /// (e.g. "1200.00"), not numbers — pg's driver does this to avoid float
  /// precision loss on money columns. num.tryParse handles both that and a
  /// plain JSON number, in case that ever changes server-side.
  static double? _toDoubleOrNull(dynamic value) {
    if (value == null) return null;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString());
  }

  /// The shape createWorker/updateWorker's request bodies expect — camelCase
  /// keys, and only ever the field matching [payType] included (the backend
  /// doesn't need — and updateWorker's COALESCE logic is written around not
  /// receiving — the other rate field on every call).
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'payType': payType.toJson(),
      if (payType == WorkerPayType.monthly && monthlyAmount != null)
        'monthlyAmount': monthlyAmount,
      if (payType == WorkerPayType.hourly && hourlyRate != null)
        'hourlyRate': hourlyRate,
    };
  }

  Worker copyWith({
    String? name,
    WorkerPayType? payType,
    double? monthlyAmount,
    double? hourlyRate,
  }) {
    return Worker(
      id: id,
      name: name ?? this.name,
      payType: payType ?? this.payType,
      // Deliberately NOT `monthlyAmount ?? this.monthlyAmount` — switching
      // payType should clear the other field's stale value rather than
      // silently carrying it along, e.g. editing a monthly worker to hourly
      // shouldn't leave the old monthlyAmount sitting around unused.
      monthlyAmount: payType == WorkerPayType.monthly
          ? (monthlyAmount ?? this.monthlyAmount)
          : null,
      hourlyRate: payType == WorkerPayType.hourly
          ? (hourlyRate ?? this.hourlyRate)
          : null,
      createdAt: createdAt,
    );
  }
}
