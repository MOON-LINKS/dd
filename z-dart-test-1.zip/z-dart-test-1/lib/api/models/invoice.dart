/// `invoiceController.js` returns invoices in five different shapes, one
/// more variant than Batch 8's `Job` had to deal with — worth reading
/// before extending this further:
///
///   listInvoices        -> id, client_id, client_name, period_start,
///                           period_end, total_hours, total_amount,
///                           amount_paid, amount_owed, pdf_asset_id,
///                           sent_at, created_at
///   getInvoice /
///   generateInvoicePdf  -> i.* (everything, incl. updated_at) PLUS
///                           client_name, client_email, client_phone
///   generateInvoicesNow -> id, organization_id, client_id, period_start,
///                           period_end, total_hours, total_amount,
///                           amount_paid, amount_owed, created_at
///                           (NO client_name, NO pdf_asset_id, NO sent_at)
///   recordPayment       -> id, total_amount, amount_paid, amount_owed
///                           ONLY (no period_start!)
///
/// `recordPayment`'s response is the `postponeJob`/`markBillPaid`
/// situation again — too sparse to build a full `Invoice` from (missing
/// `period_start`, which this model treats as required). Same fix as
/// those two: `InvoiceApi.recordPayment` doesn't try to parse its
/// response into an `Invoice` at all; see that file.
///
/// Every other nullable field here (`clientName`, `clientEmail`,
/// `clientPhone`, `pdfAssetId`, `sentAt`) is nullable for the routine
/// reason Client/Job/UpcomingBill already established: some endpoints
/// just don't return it, and every screen in this codebase invalidates
/// its provider after a mutation instead of trusting an in-memory patch,
/// so a momentarily-incomplete object from a narrow endpoint is never
/// actually rendered.
class Invoice {
  final String id;
  final String? clientId;
  final String? clientName;
  final String? clientEmail;
  final String? clientPhone;
  final DateTime periodStart;
  final DateTime periodEnd;
  final double totalHours;
  final double totalAmount;
  final double amountPaid;
  final double amountOwed;
  final String? pdfAssetId;
  final DateTime? sentAt;
  final DateTime? createdAt;

  const Invoice({
    required this.id,
    this.clientId,
    this.clientName,
    this.clientEmail,
    this.clientPhone,
    required this.periodStart,
    required this.periodEnd,
    required this.totalHours,
    required this.totalAmount,
    required this.amountPaid,
    required this.amountOwed,
    this.pdfAssetId,
    this.sentAt,
    this.createdAt,
  });

  factory Invoice.fromJson(Map<String, dynamic> json) {
    return Invoice(
      id: json['id'] as String,
      clientId: json['client_id'] as String?,
      clientName: json['client_name'] as String?,
      clientEmail: json['client_email'] as String?,
      clientPhone: json['client_phone'] as String?,
      periodStart: DateTime.parse(json['period_start'] as String),
      periodEnd: DateTime.parse(json['period_end'] as String),
      totalHours: _toDouble(json['total_hours']),
      totalAmount: _toDouble(json['total_amount']),
      amountPaid: _toDouble(json['amount_paid']),
      amountOwed: _toDouble(json['amount_owed']),
      pdfAssetId: json['pdf_asset_id'] as String?,
      sentAt: json['sent_at'] != null ? DateTime.tryParse(json['sent_at'].toString()) : null,
      createdAt:
          json['created_at'] != null ? DateTime.tryParse(json['created_at'].toString()) : null,
    );
  }

  bool get isPaidInFull => amountOwed <= 0;
  bool get hasBeenSent => sentAt != null;

  static double _toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.parse(value.toString());
  }
}

/// Line items come back the same way across both endpoints that return
/// them (`getInvoice` and `generatePdf`'s internal query) — one shape,
/// unlike `Invoice` itself. `workerName`/`jobTitle` are nullable because
/// both `worker_id`/`job_id` are `ON DELETE SET NULL` — a line item can
/// outlive the worker or job it was billed against.
class InvoiceLineItem {
  final String id;
  final String? workerId;
  final String? workerName;
  final String? jobId;
  final String? jobTitle;
  final String description;
  final double? hours;
  final double? rate;
  final double amount;

  const InvoiceLineItem({
    required this.id,
    this.workerId,
    this.workerName,
    this.jobId,
    this.jobTitle,
    required this.description,
    this.hours,
    this.rate,
    required this.amount,
  });

  factory InvoiceLineItem.fromJson(Map<String, dynamic> json) {
    return InvoiceLineItem(
      id: json['id'] as String,
      workerId: json['worker_id'] as String?,
      workerName: json['worker_name'] as String?,
      jobId: json['job_id'] as String?,
      jobTitle: json['job_title'] as String?,
      description: json['description'] as String,
      hours: json['hours'] != null ? Invoice._toDouble(json['hours']) : null,
      rate: json['rate'] != null ? Invoice._toDouble(json['rate']) : null,
      amount: Invoice._toDouble(json['amount']),
    );
  }
}

/// Wrapper for `getInvoice`'s two-part response — same small-wrapper
/// approach Batch 8's `JobSnapshot` used for `getJobSnapshot`, rather than
/// stretching `Invoice.fromJson` to sometimes carry line items.
class InvoiceDetail {
  final Invoice invoice;
  final List<InvoiceLineItem> lineItems;

  const InvoiceDetail({required this.invoice, required this.lineItems});
}

/// `generateInvoicesNow`'s response — the count/skip message is the part
/// worth surfacing to the person who just tapped "Generate," the
/// `invoices` list itself is only used to invalidate/refresh the main list
/// rather than displayed directly.
class GenerateInvoicesResult {
  final String message;
  final List<Invoice> invoices;

  const GenerateInvoicesResult({required this.message, required this.invoices});
}

/// One row of `listEmailLog`'s `emailLog` array, scoped to invoice-related
/// email for this route (`/invoices/history/log`) even though the
/// underlying `email_log` table is generic across email types — Batch 9's
/// notes on this table said `email_type` + `reference_id` are its two
/// purpose-built columns, kept generic so the same table eventually backs
/// upcoming-bill reminder history too. `id`/`emailType`/`createdAt` are
/// the three fields a list row needs to be renderable and sortable, kept
/// required; the rest are genuinely optional per-message details (a
/// failed send may have no `sentAt`, an old row may predate a
/// `recipientEmail` column) so stay nullable rather than guessed at.
///
/// Field casing is inferred, not verified against a controller (no
/// backend present in this project) — falls back across the plausible
/// snake_case/camelCase spellings per key, same defensive shape
/// `InvoiceBranding.fromJson` used in Batch 14.
class InvoiceEmailLogEntry {
  final String id;
  final String emailType;
  final String? referenceId;
  final String? recipientEmail;
  final String? status;
  final DateTime createdAt;

  const InvoiceEmailLogEntry({
    required this.id,
    required this.emailType,
    this.referenceId,
    this.recipientEmail,
    this.status,
    required this.createdAt,
  });

  factory InvoiceEmailLogEntry.fromJson(Map<String, dynamic> json) {
    return InvoiceEmailLogEntry(
      id: json['id'] as String,
      emailType: (json['email_type'] ?? json['emailType']) as String,
      referenceId: (json['reference_id'] ?? json['referenceId']) as String?,
      recipientEmail: (json['recipient_email'] ?? json['recipientEmail'] ?? json['to_email'] ?? json['to']) as String?,
      status: json['status'] as String?,
      createdAt: DateTime.parse(
        (json['created_at'] ?? json['createdAt'] ?? json['sent_at'] ?? json['sentAt']).toString(),
      ),
    );
  }
}

/// `getInvoiceBranding`'s response — per Batch 12's notes (found while
/// building Bio Page's logo section), this is the one asset-owning
/// endpoint in the app that *does* resolve its logo into a displayable
/// URL server-side (joins `assets`, returns `logoUrl` directly), unlike
/// `getBioPageEditorData`. All four fields nullable: an org that's never
/// touched its invoice branding has no row (or an all-null row) yet, same
/// "not configured" case `BioPage.colorPreset` handles with a client-side
/// default rather than a required field.
///
/// Field casing is inferred, not verified against a controller (no
/// backend present in this project) — falls back across the plausible
/// snake_case/camelCase spellings for each key rather than committing to
/// one, same defensive shape `BioPageVersion.fromJson` used for
/// `created_at`/`createdAt` in Batch 13.
class InvoiceBranding {
  final String? primaryColor;
  final String? secondaryColor;
  final String? logoAssetId;
  final String? logoUrl;

  const InvoiceBranding({this.primaryColor, this.secondaryColor, this.logoAssetId, this.logoUrl});

  factory InvoiceBranding.fromJson(Map<String, dynamic> json) {
    return InvoiceBranding(
      primaryColor: (json['primary_color'] ?? json['primaryColor']) as String?,
      secondaryColor: (json['secondary_color'] ?? json['secondaryColor']) as String?,
      logoAssetId: (json['logo_asset_id'] ?? json['logoAssetId']) as String?,
      logoUrl: (json['logo_url'] ?? json['logoUrl']) as String?,
    );
  }
}

/// Batch 16. Unlike `InvoiceBranding`/`InvoiceEmailLogEntry` above, this
/// one's field casing is *not* inferred — `invoiceAnalyticsController.js`
/// was actually read earlier in this project's history (it's quoted in
/// full in Batch 16's notes), and its response is camelCase top-to-bottom
/// with no snake_case fallback needed anywhere in this model.
///
/// One bucket per calendar month touched by the requested range.
class InvoiceRevenueTrendPoint {
  final DateTime month;
  final double revenue;
  final double hours;

  const InvoiceRevenueTrendPoint({required this.month, required this.revenue, required this.hours});

  factory InvoiceRevenueTrendPoint.fromJson(Map<String, dynamic> json) {
    return InvoiceRevenueTrendPoint(
      month: DateTime.parse(json['month'] as String),
      revenue: Invoice._toDouble(json['revenue']),
      hours: Invoice._toDouble(json['hours']),
    );
  }
}

/// `totalAmount` here is a real `SUM`, not the `FILTER`'d/nullable one
/// `InvoiceAnalyticsByJob` has below — every invoice has a client (even if
/// that client was later deleted, `clientId`/`clientName` go null but the
/// row itself, and its amount, still exists), so there's no "not billable"
/// case to represent the way a salaried worker's line item has.
class InvoiceAnalyticsByClient {
  final String? clientId;
  final String? clientName;
  final double totalHours;
  final double totalAmount;
  final double amountPaid;
  final double amountOwed;

  const InvoiceAnalyticsByClient({
    this.clientId,
    this.clientName,
    required this.totalHours,
    required this.totalAmount,
    required this.amountPaid,
    required this.amountOwed,
  });

  factory InvoiceAnalyticsByClient.fromJson(Map<String, dynamic> json) {
    return InvoiceAnalyticsByClient(
      clientId: json['clientId'] as String?,
      clientName: json['clientName'] as String?,
      totalHours: Invoice._toDouble(json['totalHours']),
      totalAmount: Invoice._toDouble(json['totalAmount']),
      amountPaid: Invoice._toDouble(json['amountPaid']),
      amountOwed: Invoice._toDouble(json['amountOwed']),
    );
  }
}

/// `totalAmount` is nullable here for the same reason `InvoiceLineItem
/// .amount` is nullable — a job whose every logged hour belongs to a
/// salaried worker has `SUM(...) FILTER (WHERE amount IS NOT NULL)` come
/// back as SQL `NULL`, not `0`, and the controller's `res.json` sends that
/// through as JSON `null` (no `?? 0` coercion on this one field, unlike
/// `paidVsOwed`'s `COALESCE`s at the SQL layer). A job like that is
/// genuinely "not billable this period," not "billed at $0" — same
/// distinction `InvoiceLineItem.amount == null` already draws, worth
/// rendering the same way (this batch's screen uses `notBilledLabel`... a
/// key that doesn't exist yet — see BATCH_NOTES for why this reuses
/// `noneOptionLabel` instead of adding one).
class InvoiceAnalyticsByJob {
  final String? jobId;
  final String? jobTitle;
  final double totalHours;
  final double? totalAmount;

  const InvoiceAnalyticsByJob({
    this.jobId,
    this.jobTitle,
    required this.totalHours,
    this.totalAmount,
  });

  factory InvoiceAnalyticsByJob.fromJson(Map<String, dynamic> json) {
    return InvoiceAnalyticsByJob(
      jobId: json['jobId'] as String?,
      jobTitle: json['jobTitle'] as String?,
      totalHours: Invoice._toDouble(json['totalHours']),
      totalAmount: json['totalAmount'] == null ? null : Invoice._toDouble(json['totalAmount']),
    );
  }
}

/// The whole Analytics tab in one response — `getInvoiceAnalytics` returns
/// `revenueTrend`, `paidVsOwed`, `hoursLoggedVsBilled`, `byClient`, and
/// `byJob` together specifically so the frontend renders the entire tab
/// from one request, per that controller's own doc comment. `rangeStart`/
/// `rangeEnd` echo back the request's `startDate`/`endDate` — useful to
/// display without holding onto the request params separately client-side.
class InvoiceAnalytics {
  final DateTime rangeStart;
  final DateTime rangeEnd;
  final List<InvoiceRevenueTrendPoint> revenueTrend;
  final double totalPaid;
  final double totalOwed;
  final double hoursLogged;
  final double hoursBilled;
  final List<InvoiceAnalyticsByClient> byClient;
  final List<InvoiceAnalyticsByJob> byJob;

  const InvoiceAnalytics({
    required this.rangeStart,
    required this.rangeEnd,
    required this.revenueTrend,
    required this.totalPaid,
    required this.totalOwed,
    required this.hoursLogged,
    required this.hoursBilled,
    required this.byClient,
    required this.byJob,
  });

  factory InvoiceAnalytics.fromJson(Map<String, dynamic> json) {
    final range = json['range'] as Map<String, dynamic>;
    final paidVsOwed = json['paidVsOwed'] as Map<String, dynamic>;
    final hoursLoggedVsBilled = json['hoursLoggedVsBilled'] as Map<String, dynamic>;
    return InvoiceAnalytics(
      rangeStart: DateTime.parse(range['startDate'] as String),
      rangeEnd: DateTime.parse(range['endDate'] as String),
      revenueTrend: (json['revenueTrend'] as List<dynamic>)
          .map((e) => InvoiceRevenueTrendPoint.fromJson(e as Map<String, dynamic>))
          .toList(),
      totalPaid: Invoice._toDouble(paidVsOwed['totalPaid']),
      totalOwed: Invoice._toDouble(paidVsOwed['totalOwed']),
      hoursLogged: Invoice._toDouble(hoursLoggedVsBilled['hoursLogged']),
      hoursBilled: Invoice._toDouble(hoursLoggedVsBilled['hoursBilled']),
      byClient: (json['byClient'] as List<dynamic>)
          .map((e) => InvoiceAnalyticsByClient.fromJson(e as Map<String, dynamic>))
          .toList(),
      byJob: (json['byJob'] as List<dynamic>)
          .map((e) => InvoiceAnalyticsByJob.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}
