import 'worker.dart';

/// Unlike Worker.fromJson, this reads camelCase — getWorkerHoursSummary in
/// workerController.js builds this response object by hand rather than
/// returning raw query rows, so it's already camelCase on the wire.
class WorkerHoursSummary {
  final double totalHours;
  final int jobsWorked;
  final WorkerPayType payType;

  /// Null for monthly-pay workers — hours are tracked for analytics/job
  /// costing only, never used to calculate what a salaried worker is owed
  /// (see workerController.js's comment on this exact field).
  final double? amountOwed;

  const WorkerHoursSummary({
    required this.totalHours,
    required this.jobsWorked,
    required this.payType,
    this.amountOwed,
  });

  factory WorkerHoursSummary.fromJson(Map<String, dynamic> json) {
    return WorkerHoursSummary(
      totalHours: (json['totalHours'] as num).toDouble(),
      jobsWorked: json['jobsWorked'] as int,
      payType: WorkerPayType.fromJson(json['payType'] as String),
      amountOwed: json['amountOwed'] == null ? null : (json['amountOwed'] as num).toDouble(),
    );
  }
}
