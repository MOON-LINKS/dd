/// Matches EXPENSE_CATEGORIES in expenseController.js exactly. Kept as an
/// enum (not a bare String) for the same reason as WorkerPayType — the
/// analyzer catches an unhandled category everywhere this is switched on,
/// instead of a typo only surfacing at runtime against the backend's CHECK.
enum ExpenseCategory {
  hospital,
  tax,
  electricity,
  rent,
  fuel,
  transportation,
  other;

  static ExpenseCategory fromJson(String value) => switch (value) {
        'hospital' => ExpenseCategory.hospital,
        'tax' => ExpenseCategory.tax,
        'electricity' => ExpenseCategory.electricity,
        'rent' => ExpenseCategory.rent,
        'fuel' => ExpenseCategory.fuel,
        'transportation' => ExpenseCategory.transportation,
        'other' => ExpenseCategory.other,
        _ => throw FormatException('Unknown expense category "$value" from API'),
      };

  String toJson() => switch (this) {
        ExpenseCategory.hospital => 'hospital',
        ExpenseCategory.tax => 'tax',
        ExpenseCategory.electricity => 'electricity',
        ExpenseCategory.rent => 'rent',
        ExpenseCategory.fuel => 'fuel',
        ExpenseCategory.transportation => 'transportation',
        ExpenseCategory.other => 'other',
      };
}

class Expense {
  final String id;
  final ExpenseCategory category;
  final double amount;
  final DateTime date;
  final bool recurring;
  final String? notes;
  final String? linkedWorkerId;
  final String? linkedJobId;

  const Expense({
    required this.id,
    required this.category,
    required this.amount,
    required this.date,
    required this.recurring,
    this.notes,
    this.linkedWorkerId,
    this.linkedJobId,
  });

  /// Deliberately built around `date` (the expense's own date, always
  /// present on every response) rather than `created_at` — same
  /// inconsistency Client.fromJson hit: expenseController.js's
  /// `updateExpense` doesn't return `created_at` in its RETURNING list,
  /// while create/list/get do. `date` doesn't have that problem — every
  /// endpoint returns it, since it's the field the UI actually cares about
  /// (when the expense happened, not when the row was inserted).
  factory Expense.fromJson(Map<String, dynamic> json) {
    return Expense(
      id: json['id'] as String,
      category: ExpenseCategory.fromJson(json['category'] as String),
      amount: _toDouble(json['amount']),
      date: DateTime.parse(json['date'] as String),
      recurring: json['recurring'] as bool,
      notes: json['notes'] as String?,
      linkedWorkerId: json['linked_worker_id'] as String?,
      linkedJobId: json['linked_job_id'] as String?,
    );
  }

  /// Same NUMERIC-comes-back-as-a-JSON-string situation as Worker's rates.
  static double _toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.parse(value.toString());
  }

  /// `linkedWorkerId` is ALWAYS included, even when null — this matters
  /// more here than it did for Client's text fields. `updateExpense`'s SQL
  /// (`linked_worker_id = COALESCE($6, linked_worker_id)`) reads this bind
  /// parameter raw from req.body with no `|| null` fallback (unlike
  /// createExpense, which does coalesce undefined -> null in JS before the
  /// query). An omitted key becomes `undefined` in Express, and pg's driver
  /// throws on an undefined bind parameter rather than treating it as NULL.
  /// A real JSON `null` is fine — pg treats that as SQL NULL correctly —
  /// so always sending the key (as a string or as null) sidesteps the crash
  /// entirely, the same way Client's always-send-empty-string approach did
  /// for its text fields. The difference here: `linked_worker_id` is a UUID
  /// column, so '' isn't a valid substitute for "unset" the way it is for a
  /// text field — it has to be a real null, not an empty string.
  ///
  /// `linkedJobId` is left out of this entirely (never sent, create or
  /// update) — this batch's form has no job picker since Jobs doesn't exist
  /// yet, and omitting it is safe here specifically because
  /// expenseController.js only reads it during `create` (which safely
  /// coalesces undefined -> null), never during `update`.
  Map<String, dynamic> toJson() {
    return {
      'category': category.toJson(),
      'amount': amount,
      'date': date.toIso8601String().split('T').first,
      'recurring': recurring,
      'notes': notes ?? '',
      'linkedWorkerId': linkedWorkerId,
    };
  }
}
