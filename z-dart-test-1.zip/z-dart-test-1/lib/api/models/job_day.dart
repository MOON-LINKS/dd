/// One worker's hours on one job day. Unlike Worker/Client/UpcomingBill,
/// this reads camelCase straight off the wire — not an inconsistency to
/// work around, just a different (correct) situation: jobController.js's
/// `fetchJobSnapshotData` builds this via `json_build_object('workerId',
/// da.worker_id, ...)` by hand rather than returning a raw row, the exact
/// same reason WorkerHoursSummary.fromJson is camelCase-both-ways while
/// Worker.fromJson is snake_case (see that file's doc comment).
class DayAssignment {
  final String? id;
  final String workerId;

  /// Only ever populated by the GET/PUT snapshot response (joined against
  /// `workers` server-side so the UI doesn't need an extra call). Never
  /// sent back — see toJson().
  final String? workerName;
  final double hours;
  final DateTime? editedAt;

  const DayAssignment({
    this.id,
    required this.workerId,
    this.workerName,
    required this.hours,
    this.editedAt,
  });

  factory DayAssignment.fromJson(Map<String, dynamic> json) {
    return DayAssignment(
      id: json['id'] as String?,
      workerId: json['workerId'] as String,
      workerName: json['workerName'] as String?,
      hours: _toDouble(json['hours']),
      editedAt: json['editedAt'] != null
          ? DateTime.tryParse(json['editedAt'].toString())
          : null,
    );
  }

  static double _toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.parse(value.toString());
  }

  /// Only `id` (when present, so the backend updates rather than inserts),
  /// `workerId`, and `hours` — exactly the shape `saveJobSnapshot` expects
  /// per its own doc comment in jobController.js. `workerName`/`editedAt`
  /// are read-only display data, never sent.
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'workerId': workerId,
      'hours': hours,
    };
  }

  DayAssignment copyWith({double? hours}) {
    return DayAssignment(
      id: id,
      workerId: workerId,
      workerName: workerName,
      hours: hours ?? this.hours,
      editedAt: editedAt,
    );
  }

  /// Used when pasting from the clipboard onto a different day: keeps the
  /// worker + hours, drops the id/editedAt so the backend treats it as a
  /// fresh upsert for *that* day rather than trying to move the original
  /// row (job_day_id is part of day_assignments' identity, an id from a
  /// different day is meaningless here).
  DayAssignment forPaste() {
    return DayAssignment(workerId: workerId, workerName: workerName, hours: hours);
  }
}

/// One calendar day of a job. `id` is null for a day that only exists
/// locally so far (added in this session, never saved) — same "omit to
/// create, include to update" convention `saveJobSnapshot` documents for
/// both days and assignments.
class JobDay {
  final String? id;
  final DateTime date;
  final bool invoiced;
  final List<DayAssignment> assignments;

  const JobDay({
    this.id,
    required this.date,
    required this.invoiced,
    required this.assignments,
  });

  factory JobDay.fromJson(Map<String, dynamic> json) {
    return JobDay(
      id: json['id'] as String?,
      date: DateTime.parse(json['date'] as String),
      invoiced: json['invoiced'] as bool,
      assignments: (json['assignments'] as List<dynamic>? ?? [])
          .map((a) => DayAssignment.fromJson(a as Map<String, dynamic>))
          .toList(),
    );
  }

  /// `date` as YYYY-MM-DD, `assignments` via each's own toJson(). `invoiced`
  /// is deliberately NOT sent — it's server-derived (set by whatever
  /// generates invoices, not by this form), and the backend already
  /// ignores/ blocks edits to invoiced days on its own regardless of what
  /// the client sends.
  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'date': date.toIso8601String().split('T').first,
      'assignments': assignments.map((a) => a.toJson()).toList(),
    };
  }

  JobDay copyWith({List<DayAssignment>? assignments}) {
    return JobDay(
      id: id,
      date: date,
      invoiced: invoiced,
      assignments: assignments ?? this.assignments,
    );
  }
}
