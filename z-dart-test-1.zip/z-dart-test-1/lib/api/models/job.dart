/// 'pending' | 'in_progress' | 'done' — matches jobs.status's CHECK
/// constraint (see jobController.js's updateJob) exactly. Same
/// exhaustiveness-checking motivation as Worker.payType.
enum JobStatus {
  pending,
  inProgress,
  done;

  static JobStatus fromJson(String value) => switch (value) {
        'pending' => JobStatus.pending,
        'in_progress' => JobStatus.inProgress,
        'done' => JobStatus.done,
        _ => throw FormatException('Unknown job status "$value" from API'),
      };

  String toJson() => switch (this) {
        JobStatus.pending => 'pending',
        JobStatus.inProgress => 'in_progress',
        JobStatus.done => 'done',
      };
}

/// jobController.js's four endpoints return genuinely different shapes —
/// same class of inconsistency Client/UpcomingBill already document, worth
/// reading before extending this further:
///
///   createJob   -> id, title, status, client_id, template_id,
///                  original_due_date, due_date, created_at
///                  (no client_name — that's a join, only listJobs does it)
///   listJobs    -> id, title, status, client_id, client_name, template_id,
///                  original_due_date, due_date, postponed_at, created_at
///   updateJob   -> id, title, status, client_id, template_id,
///                  original_due_date, due_date
///                  (no created_at, no client_name, no postponed_at)
///   postponeJob -> id, title, original_due_date, due_date, postponed_at,
///                  postponed_by
///                  (NO status, NO client_id, NO template_id — this is not
///                  just "missing a couple of optional fields" the way
///                  update is, it's missing fields this model treats as
///                  required)
///
/// Rather than make `status` nullable everywhere just to accommodate one
/// sparse endpoint, `postponeJob`'s response is never parsed into a `Job`
/// at all — see job_api.dart's `postpone()`, which mirrors the precedent
/// UpcomingBillApi.markPaid/convertToExpense already set for exactly this
/// situation (Batch 7's notes). `clientName` and `createdAt` stay nullable
/// here since only listJobs/createJob populate them respectively — every
/// screen in this codebase invalidates the list provider after a mutation
/// rather than patching an in-memory item, so a momentarily-null
/// `clientName` right after create is never actually visible.
class Job {
  final String id;
  final String title;
  final JobStatus status;
  final String? clientId;
  final String? clientName;
  final String? templateId;
  final DateTime originalDueDate;
  final DateTime dueDate;
  final DateTime? postponedAt;
  final DateTime? createdAt;

  const Job({
    required this.id,
    required this.title,
    required this.status,
    this.clientId,
    this.clientName,
    this.templateId,
    required this.originalDueDate,
    required this.dueDate,
    this.postponedAt,
    this.createdAt,
  });

  factory Job.fromJson(Map<String, dynamic> json) {
    return Job(
      id: json['id'] as String,
      title: json['title'] as String,
      status: JobStatus.fromJson(json['status'] as String),
      clientId: json['client_id'] as String?,
      clientName: json['client_name'] as String?,
      templateId: json['template_id'] as String?,
      originalDueDate: DateTime.parse(json['original_due_date'] as String),
      dueDate: DateTime.parse(json['due_date'] as String),
      postponedAt: json['postponed_at'] != null
          ? DateTime.tryParse(json['postponed_at'].toString())
          : null,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'].toString())
          : null,
    );
  }

  bool get isPostponed => postponedAt != null;
}
