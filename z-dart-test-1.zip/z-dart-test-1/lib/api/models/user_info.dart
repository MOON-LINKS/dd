/// getUserInfo's response, already camelCase on the wire —
/// `authController.js`'s `getUserInfo` builds this object by hand
/// (`id: rows[0].user_id`, `fullName: rows[0].full_name`, ...) rather than
/// returning a raw row, the same situation `job_day.dart` flags for
/// `DayAssignment`. Not read snake_case for that reason.
class UserSession {
  final String sessionId;
  final String? deviceName;
  final DateTime? lastActive;

  const UserSession({required this.sessionId, this.deviceName, this.lastActive});

  factory UserSession.fromJson(Map<String, dynamic> json) {
    return UserSession(
      sessionId: json['sessionId'] as String,
      deviceName: json['deviceName'] as String?,
      lastActive: json['lastActive'] != null
          ? DateTime.tryParse(json['lastActive'].toString())
          : null,
    );
  }
}

class UserOrganizationSummary {
  final String id;
  final String name;
  final String organizationType;
  final String? stripeCustomerId;

  const UserOrganizationSummary({
    required this.id,
    required this.name,
    required this.organizationType,
    this.stripeCustomerId,
  });

  factory UserOrganizationSummary.fromJson(Map<String, dynamic> json) {
    return UserOrganizationSummary(
      id: json['id'] as String,
      name: json['name'] as String,
      organizationType: json['organizationType'] as String,
      stripeCustomerId: json['stripeCustomerId'] as String?,
    );
  }
}

/// Was returned as a raw `Map<String, dynamic>` from `AuthApi.getMe()`
/// before this batch — every other API service in the app returns a typed
/// model, and this batch's Settings screen is the first real caller, so
/// this felt like the right moment to type it rather than leave the one
/// remaining raw-map service in the codebase. Not a bug fix (the old
/// stub's shape was correct), just consistency.
class UserInfo {
  final String id;
  final String email;
  final String? fullName;
  final bool otpVerified;
  final List<UserOrganizationSummary> organizations;
  final List<UserSession> sessions;

  const UserInfo({
    required this.id,
    required this.email,
    this.fullName,
    required this.otpVerified,
    required this.organizations,
    required this.sessions,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) {
    return UserInfo(
      id: json['id'] as String,
      email: json['email'] as String,
      fullName: json['fullName'] as String?,
      otpVerified: json['otpVerified'] as bool? ?? false,
      organizations: (json['organizations'] as List<dynamic>? ?? [])
          .map((o) => UserOrganizationSummary.fromJson(o as Map<String, dynamic>))
          .toList(),
      sessions: (json['sessions'] as List<dynamic>? ?? [])
          .map((s) => UserSession.fromJson(s as Map<String, dynamic>))
          .toList(),
    );
  }
}
