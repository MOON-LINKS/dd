/// `getMyReferralCode` returns the raw `referral_codes` row directly (no
/// wrapper object) when one exists — snake_case, per this app's usual
/// convention for un-hand-built controller responses. When the org hasn't
/// made its first payment yet, the code is legitimately null
/// (`referralEngine.ensureReferralCodeForOrganization` only creates it on
/// first successful payment) — `code`/`discountPct`/`createdAt` are all
/// nullable for exactly that reason, not because the field is ever
/// partially missing once a code exists.
class ReferralCode {
  final String? code;
  final int? discountPct;
  final DateTime? createdAt;

  const ReferralCode({this.code, this.discountPct, this.createdAt});

  factory ReferralCode.fromJson(Map<String, dynamic> json) {
    return ReferralCode(
      code: json['code'] as String?,
      discountPct: json['discount_pct'] as int?,
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'].toString())
          : null,
    );
  }

  bool get hasCode => code != null;
}

/// `getReferralEarnings` builds this by hand (camelCase, all four fields
/// always present via COALESCE/COUNT — none nullable, unlike ReferralCode).
class ReferralEarningsSummary {
  final int totalEarnedCents;
  final int totalPaidCents;
  final int pendingBalanceCents;
  final int referredOrganizationsCount;

  const ReferralEarningsSummary({
    required this.totalEarnedCents,
    required this.totalPaidCents,
    required this.pendingBalanceCents,
    required this.referredOrganizationsCount,
  });

  factory ReferralEarningsSummary.fromJson(Map<String, dynamic> json) {
    return ReferralEarningsSummary(
      totalEarnedCents: json['totalEarnedCents'] as int,
      totalPaidCents: json['totalPaidCents'] as int,
      pendingBalanceCents: json['pendingBalanceCents'] as int,
      referredOrganizationsCount: json['referredOrganizationsCount'] as int,
    );
  }
}

/// One row of `listReferralHistory`'s `referredOrganizations` array — who
/// used your code and when, joined against `organizations` for the name.
class ReferralUse {
  final String id;
  final String referredOrganizationId;
  final String referredOrganizationName;
  final int discountAppliedPct;
  final DateTime usedAt;

  const ReferralUse({
    required this.id,
    required this.referredOrganizationId,
    required this.referredOrganizationName,
    required this.discountAppliedPct,
    required this.usedAt,
  });

  factory ReferralUse.fromJson(Map<String, dynamic> json) {
    return ReferralUse(
      id: json['id'] as String,
      referredOrganizationId: json['referred_organization_id'] as String,
      referredOrganizationName: json['referred_organization_name'] as String,
      discountAppliedPct: json['discount_applied_pct'] as int,
      usedAt: DateTime.parse(json['used_at'].toString()),
    );
  }
}

/// One row of `listReferralHistory`'s `earnings` array — the commission
/// ledger. `payoutId` is null until an admin issues a payout covering it
/// (see `ReferralApi.adminIssuePayout`) — that's the same distinction
/// `getReferralEarnings`' `pendingBalanceCents` sums over, just visible
/// per-entry here instead of only as a total.
class ReferralEarningEntry {
  final String id;
  final String referredOrganizationId;
  final int sourceAmountCents;
  final int commissionCents;
  final String? payoutId;
  final DateTime createdAt;

  const ReferralEarningEntry({
    required this.id,
    required this.referredOrganizationId,
    required this.sourceAmountCents,
    required this.commissionCents,
    this.payoutId,
    required this.createdAt,
  });

  factory ReferralEarningEntry.fromJson(Map<String, dynamic> json) {
    return ReferralEarningEntry(
      id: json['id'] as String,
      referredOrganizationId: json['referred_organization_id'] as String,
      sourceAmountCents: json['source_amount_cents'] as int,
      commissionCents: json['commission_cents'] as int,
      payoutId: json['payout_id'] as String?,
      createdAt: DateTime.parse(json['created_at'].toString()),
    );
  }

  bool get isPaidOut => payoutId != null;
}

class ReferralHistory {
  final List<ReferralUse> referredOrganizations;
  final List<ReferralEarningEntry> earnings;

  const ReferralHistory({required this.referredOrganizations, required this.earnings});

  factory ReferralHistory.fromJson(Map<String, dynamic> json) {
    return ReferralHistory(
      referredOrganizations: (json['referredOrganizations'] as List<dynamic>? ?? [])
          .map((u) => ReferralUse.fromJson(u as Map<String, dynamic>))
          .toList(),
      earnings: (json['earnings'] as List<dynamic>? ?? [])
          .map((e) => ReferralEarningEntry.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}
