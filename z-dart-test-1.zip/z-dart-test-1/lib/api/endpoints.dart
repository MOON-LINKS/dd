/// Every path here mirrors 12.testing/routes.md exactly — that file is the
/// source of truth for what the backend actually exposes. If a route
/// changes there, it changes here, nowhere else.
class Endpoints {
  Endpoints._();

  // ---- Auth ----
  static const register = '/auth/register';
  static const verifyOtp = '/auth/verify-otp';
  static const login = '/auth/login';
  static const logout = '/auth/logout';
  static const logoutAll = '/auth/logout-all';
  static const me = '/auth/me';
  static const resetPasswordRequest = '/auth/reset-password/request';
  static const resetPasswordVerify = '/auth/reset-password/verify';
  static const resetPasswordConfirm = '/auth/reset-password/confirm';
  static const deleteAccount = '/auth/account';

  // ---- Organizations ----
  static const organizations = '/organizations';
  static String organization(String orgId) => '/organizations/$orgId';
  static String organizationLogo(String orgId) => '/organizations/$orgId/logo';

  // ---- Workers ----
  static String workers(String orgId) => '/organizations/$orgId/workers';
  static String worker(String orgId, String workerId) =>
      '/organizations/$orgId/workers/$workerId';
  static String workerAsset(String orgId, String workerId) =>
      '/organizations/$orgId/workers/$workerId/asset';
  static String workerHoursSummary(String orgId, String workerId) =>
      '/organizations/$orgId/workers/$workerId/hours-summary';

  // ---- Clients ----
  static String clients(String orgId) => '/organizations/$orgId/clients';
  static String client(String orgId, String clientId) =>
      '/organizations/$orgId/clients/$clientId';
  static String clientFeedback(String orgId, String clientId) =>
      '/organizations/$orgId/clients/$clientId/feedback';

  // ---- Job Templates ----
  static String jobTemplates(String orgId) =>
      '/organizations/$orgId/job-templates';
  static const adminCreateJobTemplate = '/admin/job-templates';
  static String adminUpdateJobTemplate(String templateId) =>
      '/admin/job-templates/$templateId';

  // ---- Jobs ----
  static String jobs(String orgId) => '/organizations/$orgId/jobs';
  static String job(String orgId, String jobId) =>
      '/organizations/$orgId/jobs/$jobId';
  static String jobPostpone(String orgId, String jobId) =>
      '/organizations/$orgId/jobs/$jobId/postpone';
  static String jobSnapshot(String orgId, String jobId) =>
      '/organizations/$orgId/jobs/$jobId/snapshot';

  // ---- Expenses ----
  static String expenses(String orgId) => '/organizations/$orgId/expenses';
  static String expense(String orgId, String expenseId) =>
      '/organizations/$orgId/expenses/$expenseId';

  // ---- Upcoming Bills ----
  static String upcomingBills(String orgId) =>
      '/organizations/$orgId/upcoming-bills';
  static String upcomingBill(String orgId, String billId) =>
      '/organizations/$orgId/upcoming-bills/$billId';
  static String markBillPaid(String orgId, String billId) =>
      '/organizations/$orgId/upcoming-bills/$billId/mark-paid';
  static String convertBillToExpense(String orgId, String billId) =>
      '/organizations/$orgId/upcoming-bills/$billId/convert-to-expense';

  // ---- Billing / Payments ----
  static String billingCheckout(String orgId) =>
      '/organizations/$orgId/billing/checkout';
  static String billingChangePlan(String orgId) =>
      '/organizations/$orgId/billing/change-plan';
  static String billingCancel(String orgId) =>
      '/organizations/$orgId/billing/cancel';
  static String billingPortal(String orgId) =>
      '/organizations/$orgId/billing/portal';
  static String billingAppleRegister(String orgId) =>
      '/organizations/$orgId/billing/apple/register';

  // ---- Invoices ----
  static String invoices(String orgId) => '/organizations/$orgId/invoices';
  static String generateInvoices(String orgId) =>
      '/organizations/$orgId/invoices/generate';
  static String invoiceAnalytics(String orgId) =>
      '/organizations/$orgId/invoices/analytics';
  static String invoice(String orgId, String invoiceId) =>
      '/organizations/$orgId/invoices/$invoiceId';
  static String invoicePayment(String orgId, String invoiceId) =>
      '/organizations/$orgId/invoices/$invoiceId/payment';
  static String invoicePdf(String orgId, String invoiceId) =>
      '/organizations/$orgId/invoices/$invoiceId/pdf';
  static String invoiceSend(String orgId, String invoiceId) =>
      '/organizations/$orgId/invoices/$invoiceId/send';
  static String invoiceResend(String orgId, String invoiceId) =>
      '/organizations/$orgId/invoices/$invoiceId/resend';
  static String invoiceBranding(String orgId) =>
      '/organizations/$orgId/invoices/branding/design';
  static String invoiceHistoryLog(String orgId) =>
      '/organizations/$orgId/invoices/history/log';

  // ---- Referrals ----
  static String myReferralCode(String orgId) =>
      '/organizations/$orgId/referrals';
  static String referralEarnings(String orgId) =>
      '/organizations/$orgId/referrals/earnings';
  static String referralHistory(String orgId) =>
      '/organizations/$orgId/referrals/history';
  static const validateReferralCode = '/referrals/validate';
  static const adminIssuePayout = '/admin/referrals/payouts';
  static const adminPendingPayouts = '/admin/referrals/payouts/pending';

  // ---- Bio Page (editor) ----
  static String bioPage(String orgId) => '/organizations/$orgId/bio-page';
  static String bioPageLogo(String orgId) =>
      '/organizations/$orgId/bio-page/logo';
  static String bioPageButtons(String orgId) =>
      '/organizations/$orgId/bio-page/buttons';
  static String bioPageButtonsReorder(String orgId) =>
      '/organizations/$orgId/bio-page/buttons/reorder';
  static String bioPageButton(String orgId, String buttonId) =>
      '/organizations/$orgId/bio-page/buttons/$buttonId';
  static String bioPagePublish(String orgId) =>
      '/organizations/$orgId/bio-page/publish';
  static String bioPageUnpublish(String orgId) =>
      '/organizations/$orgId/bio-page/unpublish';
  static String bioPageVersions(String orgId) =>
      '/organizations/$orgId/bio-page/versions';
  static String bioPageRollback(String orgId, int version) =>
      '/organizations/$orgId/bio-page/versions/$version/rollback';

  // ---- Bio Page (public) ----
  static const bioSlugCheck = '/bio/slug-check';
  static String publicBioPageData(String slug) => '/bio/$slug/data';
  static String publicBioPageHtml(String slug) => '/bio/$slug';

  // ---- Assets ----
  static const assets = '/assets';
  static String asset(String assetId) => '/assets/$assetId';

  // ---- Plans ----
  static const plans = '/plans';

  // ---- Health ----
  static const health = '/health';
}
