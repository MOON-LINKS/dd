import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../l10n/app_localizations.dart';
import '../../workers/providers/workers_provider.dart';
import '../providers/job_clipboard_provider.dart';
import '../providers/job_snapshot_provider.dart';
import '../utils/job_status_labels.dart';
import '../widgets/day_card.dart';

/// Section 14's hydrate-edit-save pattern: one GET loads the whole job +
/// days + assignments into JobSnapshotNotifier's local state, every edit
/// on this screen only touches that in-memory copy, and the single Save
/// button in the app bar is the only thing that talks to the network again
/// (aside from the initial load). Nothing here is a StatelessWidget-per-row
/// autosave — that was a deliberate non-goal per spec Section 14.
class JobDayGridScreen extends ConsumerWidget {
  final String orgId;
  final String jobId;

  const JobDayGridScreen({super.key, required this.orgId, required this.jobId});

  JobSnapshotKey get _key => (orgId: orgId, jobId: jobId);

  Future<void> _addDay(BuildContext context, WidgetRef ref) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2015),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
    );
    if (picked != null) {
      ref.read(jobSnapshotProvider(_key).notifier).addDay(picked);
    }
  }

  Future<void> _addAssignment(
    BuildContext context,
    WidgetRef ref,
    int dayIndex,
    List<({String id, String name})> availableWorkers,
    List<String> alreadyAssignedWorkerIds,
  ) async {
    final l10n = AppLocalizations.of(context)!;
    final candidates =
        availableWorkers.where((w) => !alreadyAssignedWorkerIds.contains(w.id)).toList();
    if (candidates.isEmpty) return;

    final selected = await showDialog<({String id, String name})>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: Text(l10n.addAssignmentAction),
        children: candidates
            .map((w) => SimpleDialogOption(
                  onPressed: () => Navigator.of(dialogContext).pop(w),
                  child: Text(w.name),
                ))
            .toList(),
      ),
    );
    if (selected == null) return;
    ref
        .read(jobSnapshotProvider(_key).notifier)
        .setAssignmentHours(dayIndex, selected.id, selected.name, 0);
  }

  Future<void> _save(BuildContext context, WidgetRef ref) async {
    final l10n = AppLocalizations.of(context)!;
    final ok = await ref.read(jobSnapshotProvider(_key).notifier).save();
    if (!context.mounted) return;
    final state = ref.read(jobSnapshotProvider(_key));
    if (ok) {
      final message = state.lastSkippedDays.isEmpty
          ? l10n.savedMessage
          : '${l10n.savedMessage} ${l10n.someDaysSkippedInvoicedMessage}';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(state.saveError ?? l10n.errorGeneric)));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final state = ref.watch(jobSnapshotProvider(_key));
    final workersAsync = ref.watch(workersProvider(orgId));
    final availableWorkers = (workersAsync.valueOrNull ?? [])
        .map((w) => (id: w.id, name: w.name))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(state.jobTitle ?? l10n.jobs),
        actions: [
          if (state.jobStatus != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Center(
                child: Chip(
                  label: Text(jobStatusLabel(context, state.jobStatus!)),
                  backgroundColor: jobStatusColor(context, state.jobStatus!),
                ),
              ),
            ),
          IconButton(
            tooltip: l10n.save,
            icon: state.isSaving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2.2),
                  )
                : const Icon(Icons.save_outlined),
            onPressed: state.isSaving ? null : () => _save(context, ref),
          ),
        ],
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : state.loadError != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(state.loadError!),
                      const SizedBox(height: 12),
                      OutlinedButton(
                        onPressed: () => ref.read(jobSnapshotProvider(_key).notifier).load(),
                        child: Text(l10n.retry),
                      ),
                    ],
                  ),
                )
              : state.days.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.calendar_today_outlined,
                              size: 40, color: Theme.of(context).colorScheme.outline),
                          const SizedBox(height: 16),
                          Text(l10n.noDaysYetLabel,
                              style: Theme.of(context).textTheme.titleMedium),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.only(top: 8, bottom: 96),
                      itemCount: state.days.length,
                      itemBuilder: (context, index) {
                        final day = state.days[index];
                        final assignedIds = day.assignments.map((a) => a.workerId).toList();
                        return DayCard(
                          day: day,
                          availableWorkers: availableWorkers,
                          onCopyDay: () {
                            ref.read(jobClipboardProvider.notifier).state =
                                day.assignments.toList();
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text(l10n.copiedToClipboardMessage)));
                          },
                          onCopyAssignment: (assignment) {
                            ref.read(jobClipboardProvider.notifier).state = [assignment];
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text(l10n.copiedToClipboardMessage)));
                          },
                          onPaste: () {
                            final clipboard = ref.read(jobClipboardProvider);
                            if (clipboard == null) return;
                            ref.read(jobSnapshotProvider(_key).notifier).pasteInto(index, clipboard);
                          },
                          onHoursChanged: (workerId, workerName, hours) => ref
                              .read(jobSnapshotProvider(_key).notifier)
                              .setAssignmentHours(index, workerId, workerName, hours),
                          onRemoveAssignment: (workerId) => ref
                              .read(jobSnapshotProvider(_key).notifier)
                              .removeUnsavedAssignment(index, workerId),
                          onAddAssignment: () =>
                              _addAssignment(context, ref, index, availableWorkers, assignedIds),
                        );
                      },
                    ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addDay(context, ref),
        icon: const Icon(Icons.add),
        label: Text(l10n.addDayAction),
      ),
    );
  }
}
