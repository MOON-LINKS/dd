import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/job.dart';
import '../../../api/services/job_api.dart';
import '../../../l10n/app_localizations.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../clients/providers/clients_provider.dart';
import '../providers/job_templates_provider.dart';

class JobFormScreen extends ConsumerStatefulWidget {
  final String orgId;

  /// null => create. Non-null => edit, pre-filled from this job.
  /// Due date is intentionally not editable from either mode here — see
  /// jobController.js/job_api.dart's comments on why postpone is the only
  /// path that changes it.
  final Job? job;

  const JobFormScreen({super.key, required this.orgId, this.job});

  bool get isEditing => job != null;

  @override
  ConsumerState<JobFormScreen> createState() => _JobFormScreenState();
}

class _JobFormScreenState extends ConsumerState<JobFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleController;
  String? _clientId;
  String? _templateId;
  late JobStatus _status;
  late DateTime _dueDate;

  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    final job = widget.job;
    _titleController = TextEditingController(text: job?.title ?? '');
    _clientId = job?.clientId;
    _templateId = job?.templateId;
    _status = job?.status ?? JobStatus.pending;
    _dueDate = job?.dueDate ?? DateTime.now();
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  Future<void> _pickDueDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _dueDate,
      firstDate: DateTime(2015),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
    );
    if (picked != null) setState(() => _dueDate = picked);
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      if (widget.isEditing) {
        final updated = await JobApi.update(
          widget.orgId,
          widget.job!.id,
          title: _titleController.text.trim(),
          clientId: _clientId,
          templateId: _templateId,
          status: _status,
        );
        if (!mounted) return;
        Navigator.of(context).pop(updated);
      } else {
        final created = await JobApi.create(
          widget.orgId,
          title: _titleController.text.trim(),
          clientId: _clientId,
          templateId: _templateId,
          dueDate: _dueDate,
        );
        if (!mounted) return;
        Navigator.of(context).pop(created);
      }
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString());

    // Same "degrade quietly" pattern ExpenseFormScreen uses for its worker
    // dropdown — clientId/templateId are both optional on the backend, so
    // a slow or failed fetch here shouldn't block creating/editing a job.
    final clients = ref.watch(clientsProvider(widget.orgId)).valueOrNull ?? [];
    final templates = ref.watch(jobTemplatesProvider(widget.orgId)).valueOrNull ?? [];

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isEditing ? '${l10n.edit} ${l10n.jobs}' : '${l10n.add} ${l10n.jobs}'),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    AppTextField(
                      controller: _titleController,
                      label: l10n.titleLabel,
                      validator: (value) =>
                          (value == null || value.trim().isEmpty) ? l10n.nameRequiredError : null,
                    ),
                    const SizedBox(height: 20),
                    Text(l10n.clientOptionalLabel, style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String?>(
                      initialValue: _clientId,
                      items: [
                        DropdownMenuItem(value: null, child: Text(l10n.noneOptionLabel)),
                        ...clients.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))),
                      ],
                      onChanged: (value) => setState(() => _clientId = value),
                    ),
                    const SizedBox(height: 20),
                    Text(l10n.jobTemplateOptionalLabel, style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String?>(
                      initialValue: _templateId,
                      items: [
                        DropdownMenuItem(value: null, child: Text(l10n.noneOptionLabel)),
                        ...templates.map((t) => DropdownMenuItem(value: t.id, child: Text(t.name))),
                      ],
                      onChanged: (value) => setState(() => _templateId = value),
                    ),
                    if (widget.isEditing) ...[
                      const SizedBox(height: 20),
                      Text(l10n.statusLabel, style: Theme.of(context).textTheme.labelLarge),
                      const SizedBox(height: 8),
                      DropdownButtonFormField<JobStatus>(
                        initialValue: _status,
                        items: JobStatus.values
                            .map((s) => DropdownMenuItem(
                                  value: s,
                                  child: Text(switch (s) {
                                    JobStatus.pending => l10n.jobStatusPending,
                                    JobStatus.inProgress => l10n.jobStatusInProgress,
                                    JobStatus.done => l10n.jobStatusDone,
                                  }),
                                ))
                            .toList(),
                        onChanged: (value) {
                          if (value != null) setState(() => _status = value);
                        },
                      ),
                    ] else ...[
                      const SizedBox(height: 20),
                      Text(l10n.dueDateLabel, style: Theme.of(context).textTheme.labelLarge),
                      const SizedBox(height: 8),
                      OutlinedButton(
                        onPressed: _pickDueDate,
                        style: OutlinedButton.styleFrom(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        ),
                        child: Text(dateFormat.format(_dueDate)),
                      ),
                    ],
                    if (_errorMessage != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        _errorMessage!,
                        style: TextStyle(color: Theme.of(context).colorScheme.error),
                      ),
                    ],
                    const SizedBox(height: 24),
                    PrimaryButton(label: l10n.save, onPressed: _submit, isLoading: _isLoading),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
