import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/job.dart';
import '../../../api/services/job_api.dart';
import '../../../l10n/app_localizations.dart';
import '../../shell/providers/current_organization_provider.dart';
import '../providers/jobs_provider.dart';
import '../utils/job_status_labels.dart';
import '../widgets/job_list_tile.dart';
import 'job_day_grid_screen.dart';
import 'job_form_screen.dart';

/// Status filter is client-side only (over the single unfiltered fetch from
/// jobsProvider) rather than round-tripping JobApi.list's status param on
/// every tap — same "server supports it, this batch's screen doesn't wire
/// it up yet" scope call every other list screen in this codebase made for
/// its own filters (Expenses' category/date range, Upcoming Bills'
/// isPaid). Cheap follow-up if the list ever gets large enough to matter.
class JobsListScreen extends ConsumerStatefulWidget {
  const JobsListScreen({super.key});

  @override
  ConsumerState<JobsListScreen> createState() => _JobsListScreenState();
}

class _JobsListScreenState extends ConsumerState<JobsListScreen> {
  JobStatus? _statusFilter;

  Future<void> _confirmDelete(String orgId, String jobId) async {
    final l10n = AppLocalizations.of(context)!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(l10n.delete),
        content: Text(l10n.confirmDeleteGeneric),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(l10n.delete),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await JobApi.delete(orgId, jobId);
      ref.invalidate(jobsProvider(orgId));
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _postpone(String orgId, Job job) async {
    final l10n = AppLocalizations.of(context)!;
    final picked = await showDatePicker(
      context: context,
      initialDate: job.dueDate.isBefore(DateTime.now()) ? DateTime.now() : job.dueDate,
      firstDate: DateTime(2015),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
      helpText: l10n.newDueDateLabel,
    );
    if (picked == null) return;

    try {
      await JobApi.postpone(orgId, job.id, newDueDate: picked);
      ref.invalidate(jobsProvider(orgId));
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final orgId = ref.watch(currentOrganizationIdProvider);

    // Same narrow window AppShellScreen's gate already covers for every
    // other org-scoped screen (see workers_list_screen.dart's comment) —
    // not a real "no org" state.
    if (orgId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final jobsAsync = ref.watch(jobsProvider(orgId));

    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ChoiceChip(
                    label: Text(l10n.allStatusesLabel),
                    selected: _statusFilter == null,
                    onSelected: (_) => setState(() => _statusFilter = null),
                  ),
                  const SizedBox(width: 8),
                  for (final status in JobStatus.values) ...[
                    ChoiceChip(
                      label: Text(jobStatusLabel(context, status)),
                      selected: _statusFilter == status,
                      onSelected: (_) => setState(() => _statusFilter = status),
                    ),
                    const SizedBox(width: 8),
                  ],
                ],
              ),
            ),
          ),
          Expanded(
            child: jobsAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, __) => Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(err is ApiException ? err.message : l10n.errorGeneric),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      onPressed: () => ref.invalidate(jobsProvider(orgId)),
                      child: Text(l10n.retry),
                    ),
                  ],
                ),
              ),
              data: (allJobs) {
                final jobs = _statusFilter == null
                    ? allJobs
                    : allJobs.where((j) => j.status == _statusFilter).toList();

                if (jobs.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.work_outline,
                            size: 40, color: Theme.of(context).colorScheme.outline),
                        const SizedBox(height: 16),
                        Text(l10n.emptyListTitleGeneric,
                            style: Theme.of(context).textTheme.titleMedium),
                      ],
                    ),
                  );
                }
                return RefreshIndicator(
                  onRefresh: () async => ref.invalidate(jobsProvider(orgId)),
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    itemCount: jobs.length,
                    itemBuilder: (context, index) {
                      final job = jobs[index];
                      return JobListTile(
                        job: job,
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => JobDayGridScreen(orgId: orgId, jobId: job.id),
                          ),
                        ),
                        onEdit: () async {
                          final updated = await Navigator.of(context).push<Job>(
                            MaterialPageRoute(
                              builder: (_) => JobFormScreen(orgId: orgId, job: job),
                            ),
                          );
                          if (updated != null) ref.invalidate(jobsProvider(orgId));
                        },
                        onPostpone: () => _postpone(orgId, job),
                        onDelete: () => _confirmDelete(orgId, job.id),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await Navigator.of(context).push<Job>(
            MaterialPageRoute(builder: (_) => JobFormScreen(orgId: orgId)),
          );
          if (created != null) ref.invalidate(jobsProvider(orgId));
        },
        icon: const Icon(Icons.add),
        label: Text('${l10n.add} ${l10n.jobs}'),
      ),
    );
  }
}
