import 'package:flutter/material.dart';
import '../../../api/models/job.dart';
import '../../../l10n/app_localizations.dart';

String jobStatusLabel(BuildContext context, JobStatus status) {
  final l10n = AppLocalizations.of(context)!;
  return switch (status) {
    JobStatus.pending => l10n.jobStatusPending,
    JobStatus.inProgress => l10n.jobStatusInProgress,
    JobStatus.done => l10n.jobStatusDone,
  };
}

/// Same "outline"/"container" color pairing UpcomingBillListTile already
/// uses for its paid/overdue states — kept consistent rather than
/// inventing a second status-color convention.
Color jobStatusColor(BuildContext context, JobStatus status) {
  final colorScheme = Theme.of(context).colorScheme;
  return switch (status) {
    JobStatus.pending => colorScheme.surfaceContainerHighest,
    JobStatus.inProgress => colorScheme.primaryContainer,
    JobStatus.done => colorScheme.tertiaryContainer,
  };
}
