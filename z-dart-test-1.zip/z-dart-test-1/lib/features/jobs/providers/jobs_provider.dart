import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/job.dart';
import '../../../api/services/job_api.dart';

/// Same style as workers/clients/expenses/upcoming_bills providers — plain
/// FutureProvider.family, re-triggered via
/// `ref.invalidate(jobsProvider(orgId))` after any create/update/postpone/
/// delete. Deliberately unfiltered (status/client/date-range filtering is
/// server-supported via JobApi.list's optional params but unused here) —
/// same scope call every other list screen in this codebase made; a filter
/// bar is a clean follow-up, not a structural change.
final jobsProvider =
    FutureProvider.family<List<Job>, String>((ref, organizationId) {
  return JobApi.list(organizationId);
});
