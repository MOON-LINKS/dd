import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/job_template.dart';
import '../../../api/services/job_template_api.dart';

/// Read-only list, never invalidated by this app (templates are admin-
/// managed, not editable from here) — still a FutureProvider.family for
/// consistency with every other org-scoped list in this codebase, and so
/// JobFormScreen can `.valueOrNull ?? []` it the same "degrade quietly"
/// way ExpenseFormScreen does for workersProvider (Batch 6): a slow/failed
/// template fetch shouldn't block creating a job, since templateId is
/// optional on the backend.
final jobTemplatesProvider =
    FutureProvider.family<List<JobTemplate>, String>((ref, organizationId) {
  return JobTemplateApi.list(organizationId);
});
