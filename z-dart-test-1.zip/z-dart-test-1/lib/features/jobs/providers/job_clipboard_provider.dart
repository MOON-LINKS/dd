import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/job_day.dart';

/// Spec Section 4, verbatim: "the manager can copy an entire day's worker
/// assignments (or a single worker's assignment) to another day... state
/// provider (Riverpod) to hold the clipboard." This is that provider.
///
/// Holds either a full day's assignments (copyDay) or a single one
/// (copyAssignment) — the UI doesn't need to distinguish the two cases
/// once copied, pasting always means "upsert every assignment currently
/// on the clipboard into the target day." Scoped globally (not per-job)
/// deliberately: nothing in the spec restricts copy/paste to within the
/// same job, and a plain top-level provider is simpler than threading a
/// job-scoped clipboard through every day-grid instance for a restriction
/// nobody asked for.
final jobClipboardProvider = StateProvider<List<DayAssignment>?>((ref) => null);
