import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/job.dart';
import '../../../api/models/job_day.dart';
import '../../../api/services/job_api.dart';

/// Family key — a plain record works fine as a Riverpod family param since
/// records get value-based `==`/`hashCode` for free; no need for a
/// hand-written class just to combine two strings.
typedef JobSnapshotKey = ({String orgId, String jobId});

class JobSnapshotState {
  final bool isLoading;
  final bool isSaving;
  final String? loadError;
  final String? saveError;
  final JobStatus? jobStatus;
  final String? jobTitle;
  final List<JobDay> days;

  /// Set after a save that skipped one or more already-invoiced days (a
  /// race — this UI already locks invoiced days from being edited, so this
  /// is normally empty; surfaced rather than silently dropped in case one
  /// was invoiced by someone else between load and save).
  final List<String> lastSkippedDays;

  const JobSnapshotState({
    this.isLoading = true,
    this.isSaving = false,
    this.loadError,
    this.saveError,
    this.jobStatus,
    this.jobTitle,
    this.days = const [],
    this.lastSkippedDays = const [],
  });

  JobSnapshotState copyWith({
    bool? isLoading,
    bool? isSaving,
    String? loadError,
    bool clearLoadError = false,
    String? saveError,
    bool clearSaveError = false,
    JobStatus? jobStatus,
    String? jobTitle,
    List<JobDay>? days,
    List<String>? lastSkippedDays,
  }) {
    return JobSnapshotState(
      isLoading: isLoading ?? this.isLoading,
      isSaving: isSaving ?? this.isSaving,
      loadError: clearLoadError ? null : (loadError ?? this.loadError),
      saveError: clearSaveError ? null : (saveError ?? this.saveError),
      jobStatus: jobStatus ?? this.jobStatus,
      jobTitle: jobTitle ?? this.jobTitle,
      days: days ?? this.days,
      lastSkippedDays: lastSkippedDays ?? this.lastSkippedDays,
    );
  }
}

/// Everything below happens against in-memory state until save() is
/// called — matches Section 14's "one request loads, edit locally, one
/// Save button sends it all back" pattern exactly, and Step 1's original
/// notes flagging this as loose-typed/deferred work this batch now
/// resolves.
class JobSnapshotNotifier extends StateNotifier<JobSnapshotState> {
  final String orgId;
  final String jobId;

  JobSnapshotNotifier(this.orgId, this.jobId) : super(const JobSnapshotState()) {
    load();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true, clearLoadError: true);
    try {
      final snapshot = await JobApi.getSnapshot(orgId, jobId);
      state = state.copyWith(
        isLoading: false,
        jobTitle: snapshot.job['title'] as String?,
        jobStatus: snapshot.job['status'] != null
            ? JobStatus.fromJson(snapshot.job['status'] as String)
            : null,
        days: snapshot.days,
      );
    } on ApiException catch (e) {
      state = state.copyWith(isLoading: false, loadError: e.message);
    }
  }

  /// No-op if a day with this date already exists — adding a day the user
  /// already added (or that the backend already returned) shouldn't create
  /// a visible duplicate; the existing card is where they should be
  /// editing already.
  void addDay(DateTime date) {
    final normalized = DateTime(date.year, date.month, date.day);
    if (state.days.any((d) => _sameDate(d.date, normalized))) return;
    final days = [...state.days, JobDay(date: normalized, invoiced: false, assignments: [])];
    days.sort((a, b) => a.date.compareTo(b.date));
    state = state.copyWith(days: days);
  }

  bool _sameDate(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  /// Upserts by workerId within the day — matches the backend's own
  /// `(job_day_id, worker_id)` uniqueness constraint, so a worker can't
  /// end up double-assigned to the same day even transiently in local state.
  void setAssignmentHours(int dayIndex, String workerId, String? workerName, double hours) {
    final day = state.days[dayIndex];
    final existingIndex = day.assignments.indexWhere((a) => a.workerId == workerId);
    final updated = [...day.assignments];
    if (existingIndex >= 0) {
      updated[existingIndex] = updated[existingIndex].copyWith(hours: hours);
    } else {
      updated.add(DayAssignment(workerId: workerId, workerName: workerName, hours: hours));
    }
    _replaceDay(dayIndex, day.copyWith(assignments: updated));
  }

  /// Local-only removal. Flagging rather than pretending this is a full
  /// delete: `saveJobSnapshot` only ever upserts assignments (see
  /// jobController.js's doc comment on its expected body shape) — there is
  /// no backend path to delete a `day_assignments` row. Removing it here
  /// and saving does NOT delete it server-side; it would simply not be
  /// included in this save, and the *next* load would bring it right back.
  /// Kept as a same-session "undo an accidental add" action only — a real
  /// delete needs a backend endpoint first, not a client-side workaround.
  void removeUnsavedAssignment(int dayIndex, String workerId) {
    final day = state.days[dayIndex];
    final updated = day.assignments.where((a) => a.workerId != workerId).toList();
    _replaceDay(dayIndex, day.copyWith(assignments: updated));
  }

  void _replaceDay(int dayIndex, JobDay newDay) {
    final days = [...state.days];
    days[dayIndex] = newDay;
    state = state.copyWith(days: days);
  }

  /// Applies the clipboard's assignments onto the target day — each one
  /// upserted by workerId, same rule as setAssignmentHours. Hours stay
  /// editable after pasting, per spec.
  void pasteInto(int dayIndex, List<DayAssignment> clipboard) {
    var day = state.days[dayIndex];
    var updated = [...day.assignments];
    for (final copied in clipboard) {
      final existingIndex = updated.indexWhere((a) => a.workerId == copied.workerId);
      if (existingIndex >= 0) {
        updated[existingIndex] = updated[existingIndex].copyWith(hours: copied.hours);
      } else {
        updated.add(copied.forPaste());
      }
    }
    _replaceDay(dayIndex, day.copyWith(assignments: updated));
  }

  Future<bool> save() async {
    state = state.copyWith(isSaving: true, clearSaveError: true);
    try {
      final snapshot = await JobApi.saveSnapshot(orgId, jobId, days: state.days);
      state = state.copyWith(
        isSaving: false,
        days: snapshot.days,
        lastSkippedDays: snapshot.skippedDays,
      );
      return true;
    } on ApiException catch (e) {
      state = state.copyWith(isSaving: false, saveError: e.message);
      return false;
    }
  }
}

final jobSnapshotProvider =
    StateNotifierProvider.autoDispose.family<JobSnapshotNotifier, JobSnapshotState, JobSnapshotKey>(
  (ref, key) => JobSnapshotNotifier(key.orgId, key.jobId),
);
