import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../api/models/job_day.dart';
import '../../../l10n/app_localizations.dart';
import '../providers/job_clipboard_provider.dart';

/// One job_day, rendered as a card: date header, one row per assignment
/// (worker name + editable hours), an "add worker" action, and copy/paste.
/// All the actual state mutation (hours changes, copy/paste, add) is owned
/// by the parent screen's JobSnapshotNotifier — this widget only reads the
/// clipboard (to enable/disable Paste) and forwards taps via callbacks, so
/// it stays a plain display/input widget rather than a second place that
/// knows how to mutate day-grid state.
///
/// Invoiced days render everything read-only — per spec Section 4, once a
/// day is part of an already-sent invoice it should be "blocked or clearly
/// flagged." The backend enforces this either way (saveJobSnapshot silently
/// skips invoiced days server-side, see jobController.js), but disabling
/// the controls here means the manager sees *why* nothing happened instead
/// of a confusing no-op after tapping Save.
class DayCard extends ConsumerWidget {
  final JobDay day;
  final List<({String id, String name})> availableWorkers;
  final VoidCallback onCopyDay;
  final void Function(DayAssignment assignment) onCopyAssignment;
  final VoidCallback onPaste;
  final void Function(String workerId, String? workerName, double hours) onHoursChanged;
  final void Function(String workerId) onRemoveAssignment;
  final VoidCallback onAddAssignment;

  const DayCard({
    super.key,
    required this.day,
    required this.availableWorkers,
    required this.onCopyDay,
    required this.onCopyAssignment,
    required this.onPaste,
    required this.onHoursChanged,
    required this.onRemoveAssignment,
    required this.onAddAssignment,
  });

  String _workerName(DayAssignment a) {
    if (a.workerName != null) return a.workerName!;
    final match = availableWorkers.where((w) => w.id == a.workerId);
    return match.isEmpty ? a.workerId : match.first.name;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final dateFormat = DateFormat.yMMMEd(Localizations.localeOf(context).toString());
    final clipboard = ref.watch(jobClipboardProvider);
    final colorScheme = Theme.of(context).colorScheme;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    dateFormat.format(day.date),
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                if (day.invoiced)
                  Chip(
                    label: Text(l10n.dayInvoicedLockedLabel),
                    backgroundColor: colorScheme.errorContainer,
                    labelStyle: TextStyle(color: colorScheme.onErrorContainer),
                  )
                else ...[
                  IconButton(
                    tooltip: l10n.copyDayAction,
                    icon: const Icon(Icons.copy_all_outlined),
                    onPressed: day.assignments.isEmpty ? null : onCopyDay,
                  ),
                  IconButton(
                    tooltip: l10n.pasteAction,
                    icon: const Icon(Icons.paste_outlined),
                    onPressed: (clipboard == null || clipboard.isEmpty) ? null : onPaste,
                  ),
                ],
              ],
            ),
            const Divider(),
            if (day.assignments.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  l10n.noAssignmentsYetLabel,
                  style: TextStyle(color: colorScheme.onSurfaceVariant),
                ),
              )
            else
              for (final assignment in day.assignments)
                _AssignmentRow(
                  // Keyed by date (not day.id, which is null for a day
                  // that only exists locally so far) + workerId — unique
                  // per row regardless of save state.
                  key: ValueKey('${day.date.toIso8601String()}-${assignment.workerId}'),
                  workerName: _workerName(assignment),
                  hours: assignment.hours,
                  readOnly: day.invoiced,
                  onCopy: () => onCopyAssignment(assignment),
                  onHoursChanged: (hours) =>
                      onHoursChanged(assignment.workerId, assignment.workerName, hours),
                  onRemove: () => onRemoveAssignment(assignment.workerId),
                ),
            if (!day.invoiced) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.person_add_alt_outlined),
                label: Text(l10n.addAssignmentAction),
                onPressed: availableWorkers.isEmpty ? null : onAddAssignment,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _AssignmentRow extends StatefulWidget {
  final String workerName;
  final double hours;
  final bool readOnly;
  final VoidCallback onCopy;
  final ValueChanged<double> onHoursChanged;
  final VoidCallback onRemove;

  const _AssignmentRow({
    super.key,
    required this.workerName,
    required this.hours,
    required this.readOnly,
    required this.onCopy,
    required this.onHoursChanged,
    required this.onRemove,
  });

  @override
  State<_AssignmentRow> createState() => _AssignmentRowState();
}

class _AssignmentRowState extends State<_AssignmentRow> {
  late final TextEditingController _hoursController;

  @override
  void initState() {
    super.initState();
    _hoursController = TextEditingController(text: _formatHours(widget.hours));
  }

  String _formatHours(double hours) =>
      hours == hours.roundToDouble() ? hours.toInt().toString() : hours.toString();

  @override
  void dispose() {
    _hoursController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(widget.workerName)),
          SizedBox(
            width: 90,
            child: TextField(
              controller: _hoursController,
              enabled: !widget.readOnly,
              textAlign: TextAlign.center,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                isDense: true,
                suffixText: l10n.hoursUnitSuffix,
                border: const OutlineInputBorder(),
              ),
              onChanged: (value) {
                final parsed = double.tryParse(value.trim());
                if (parsed != null && parsed >= 0) widget.onHoursChanged(parsed);
              },
            ),
          ),
          if (!widget.readOnly) ...[
            IconButton(
              tooltip: l10n.copyAssignmentAction,
              icon: const Icon(Icons.copy_outlined, size: 20),
              onPressed: widget.onCopy,
            ),
            IconButton(
              tooltip: l10n.delete,
              icon: const Icon(Icons.close, size: 20),
              onPressed: widget.onRemove,
            ),
          ],
        ],
      ),
    );
  }
}
