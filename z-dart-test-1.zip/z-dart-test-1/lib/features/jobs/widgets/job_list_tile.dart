import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../api/models/job.dart';
import '../../../l10n/app_localizations.dart';
import '../utils/job_status_labels.dart';

class JobListTile extends StatelessWidget {
  final Job job;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onPostpone;
  final VoidCallback onDelete;

  const JobListTile({
    super.key,
    required this.job,
    required this.onTap,
    required this.onEdit,
    required this.onPostpone,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString());

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: jobStatusColor(context, job.status),
          child: const Icon(Icons.work_outline),
        ),
        title: Text(job.title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(
          [
            if (job.clientName != null) job.clientName!,
            dateFormat.format(job.dueDate),
            jobStatusLabel(context, job.status),
            if (job.isPostponed) l10n.postponedLabel,
          ].join(' · '),
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (value) {
            switch (value) {
              case 'edit':
                onEdit();
                break;
              case 'postpone':
                onPostpone();
                break;
              case 'delete':
                onDelete();
                break;
            }
          },
          itemBuilder: (context) => [
            PopupMenuItem(value: 'edit', child: Text(l10n.editJobDetailsAction)),
            PopupMenuItem(value: 'postpone', child: Text(l10n.postponeAction)),
            PopupMenuItem(value: 'delete', child: Text(l10n.delete)),
          ],
        ),
      ),
    );
  }
}
