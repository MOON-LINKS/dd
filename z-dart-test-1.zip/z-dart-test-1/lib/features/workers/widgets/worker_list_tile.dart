import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../api/models/worker.dart';
import '../../../l10n/app_localizations.dart';

class WorkerListTile extends StatelessWidget {
  final Worker worker;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const WorkerListTile({
    super.key,
    required this.worker,
    required this.onTap,
    required this.onDelete,
  });

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1)).toUpperCase();
  }

  String _paySummary(BuildContext context) {
    final currency = NumberFormat.simpleCurrency(locale: Localizations.localeOf(context).toString());
    return switch (worker.payType) {
      WorkerPayType.monthly =>
        '${AppLocalizations.of(context)!.payTypeMonthly} · ${currency.format(worker.monthlyAmount ?? 0)}',
      WorkerPayType.hourly =>
        '${AppLocalizations.of(context)!.payTypeHourly} · ${currency.format(worker.hourlyRate ?? 0)}/hr',
    };
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: colorScheme.primaryContainer,
          foregroundColor: colorScheme.onPrimaryContainer,
          child: Text(_initials(worker.name), style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
        title: Text(worker.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(_paySummary(context)),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline),
          tooltip: AppLocalizations.of(context)!.delete,
          onPressed: onDelete,
        ),
      ),
    );
  }
}
