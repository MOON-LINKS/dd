import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/worker.dart';
import '../../../api/services/worker_api.dart';

/// Keyed by organizationId. No custom Notifier/mutation methods here on
/// purpose — matches the existing myOrganizationsProvider's style (a plain
/// FutureProvider the screen re-triggers), rather than introducing a second
/// state-management pattern for one feature. After create/update/delete,
/// call `ref.invalidate(workersProvider(orgId))` — see workers_list_screen.dart
/// and worker_form_screen.dart.
final workersProvider =
    FutureProvider.family<List<Worker>, String>((ref, organizationId) {
  return WorkerApi.list(organizationId);
});
