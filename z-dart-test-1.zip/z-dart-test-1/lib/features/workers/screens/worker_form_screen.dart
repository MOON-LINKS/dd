import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/worker.dart';
import '../../../api/services/worker_api.dart';
import '../../../core/providers/vertical_labels_provider.dart';
import '../../../l10n/app_localizations.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';

class WorkerFormScreen extends ConsumerStatefulWidget {
  final String orgId;

  /// null => create. Non-null => edit, pre-filled from this worker.
  final Worker? worker;

  const WorkerFormScreen({super.key, required this.orgId, this.worker});

  bool get isEditing => worker != null;

  @override
  ConsumerState<WorkerFormScreen> createState() => _WorkerFormScreenState();
}

class _WorkerFormScreenState extends ConsumerState<WorkerFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _rateController;
  late WorkerPayType _payType;

  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    final worker = widget.worker;
    _nameController = TextEditingController(text: worker?.name ?? '');
    _payType = worker?.payType ?? WorkerPayType.hourly;
    final existingRate = worker == null
        ? null
        : (worker.payType == WorkerPayType.monthly ? worker.monthlyAmount : worker.hourlyRate);
    _rateController = TextEditingController(text: existingRate?.toString() ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _rateController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final l10n = AppLocalizations.of(context)!;
    if (!(_formKey.currentState?.validate() ?? false)) return;

    final rate = double.parse(_rateController.text.trim());
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      if (widget.isEditing) {
        await WorkerApi.update(
          widget.orgId,
          widget.worker!.id,
          name: _nameController.text.trim(),
          payType: _payType,
          monthlyAmount: _payType == WorkerPayType.monthly ? rate : null,
          hourlyRate: _payType == WorkerPayType.hourly ? rate : null,
        );
      } else {
        await WorkerApi.create(
          widget.orgId,
          name: _nameController.text.trim(),
          payType: _payType,
          monthlyAmount: _payType == WorkerPayType.monthly ? rate : null,
          hourlyRate: _payType == WorkerPayType.hourly ? rate : null,
        );
      }
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      // 402 from canAddWorker (planLimits.js) — worth its own message rather
      // than falling into the generic error line, since "add a worker"
      // failing silently-looking-like-a-bug vs. failing because the plan
      // is full are very different things for the user to understand.
      setState(() => _errorMessage = e.isPlanLimitError ? l10n.planLimitReachedTitle : e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final workerLabel = ref.watch(verticalLabelProvider('worker_title'));

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isEditing ? '${l10n.edit} $workerLabel' : '${l10n.add} $workerLabel'),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    AppTextField(
                      controller: _nameController,
                      label: workerLabel,
                      validator: (value) =>
                          (value == null || value.trim().isEmpty) ? l10n.nameRequiredError : null,
                    ),
                    const SizedBox(height: 20),
                    Text(l10n.payTypeLabel, style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    SegmentedButton<WorkerPayType>(
                      segments: [
                        ButtonSegment(
                          value: WorkerPayType.hourly,
                          label: Text(l10n.payTypeHourly),
                        ),
                        ButtonSegment(
                          value: WorkerPayType.monthly,
                          label: Text(l10n.payTypeMonthly),
                        ),
                      ],
                      selected: {_payType},
                      onSelectionChanged: (selection) =>
                          setState(() => _payType = selection.first),
                    ),
                    const SizedBox(height: 20),
                    AppTextField(
                      controller: _rateController,
                      label: _payType == WorkerPayType.hourly
                          ? l10n.hourlyRateLabel
                          : l10n.monthlyAmountLabel,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (value) {
                        final trimmed = value?.trim() ?? '';
                        if (trimmed.isEmpty) return l10n.amountRequiredError;
                        final parsed = double.tryParse(trimmed);
                        if (parsed == null || parsed < 0) return l10n.amountRequiredError;
                        return null;
                      },
                    ),
                    if (_errorMessage != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        _errorMessage!,
                        style: TextStyle(color: Theme.of(context).colorScheme.error),
                      ),
                    ],
                    const SizedBox(height: 24),
                    PrimaryButton(
                      label: l10n.save,
                      onPressed: _submit,
                      isLoading: _isLoading,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
