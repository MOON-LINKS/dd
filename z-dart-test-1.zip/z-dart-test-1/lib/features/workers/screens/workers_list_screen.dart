import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/api_exception.dart';
import '../../../api/services/worker_api.dart';
import '../../../core/providers/vertical_labels_provider.dart';
import '../../../l10n/app_localizations.dart';
import '../../shell/providers/current_organization_provider.dart';
import '../providers/workers_provider.dart';
import '../widgets/worker_list_tile.dart';
import 'worker_form_screen.dart';

class WorkersListScreen extends ConsumerWidget {
  const WorkersListScreen({super.key});

  Future<void> _confirmDelete(
    BuildContext context,
    WidgetRef ref,
    String orgId,
    String workerId,
  ) async {
    final l10n = AppLocalizations.of(context)!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(l10n.delete),
        content: Text(l10n.confirmDeleteGeneric),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(l10n.delete),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await WorkerApi.delete(orgId, workerId);
      ref.invalidate(workersProvider(orgId));
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final orgId = ref.watch(currentOrganizationIdProvider);
    final workerLabel = ref.watch(verticalLabelProvider('worker_title'));

    // AppShellScreen already gates every branch on an organization existing
    // before rendering this far, but the type is still nullable — this is
    // the narrow window between that gate resolving and this provider
    // re-deriving from the same underlying data, not a real "no org" state.
    if (orgId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final workersAsync = ref.watch(workersProvider(orgId));

    return Scaffold(
      body: workersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, __) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(err is ApiException ? err.message : l10n.errorGeneric),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => ref.invalidate(workersProvider(orgId)),
                child: Text(l10n.retry),
              ),
            ],
          ),
        ),
        data: (workers) {
          if (workers.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.groups_outlined, size: 40, color: Theme.of(context).colorScheme.outline),
                  const SizedBox(height: 16),
                  Text(l10n.emptyListTitleGeneric, style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(workersProvider(orgId)),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12),
              itemCount: workers.length,
              itemBuilder: (context, index) {
                final worker = workers[index];
                return WorkerListTile(
                  worker: worker,
                  onTap: () async {
                    final changed = await Navigator.of(context).push<bool>(
                      MaterialPageRoute(builder: (_) => WorkerFormScreen(orgId: orgId, worker: worker)),
                    );
                    if (changed == true) ref.invalidate(workersProvider(orgId));
                  },
                  onDelete: () => _confirmDelete(context, ref, orgId, worker.id),
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await Navigator.of(context).push<bool>(
            MaterialPageRoute(builder: (_) => WorkerFormScreen(orgId: orgId)),
          );
          if (created == true) ref.invalidate(workersProvider(orgId));
        },
        icon: const Icon(Icons.add),
        label: Text('${l10n.add} $workerLabel'),
      ),
    );
  }
}
