import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../api/services/organization_api.dart';
import '../../../api/api_exception.dart';
import '../../../core/providers/organization_type_provider.dart';
import '../../../core/constants/organization_types.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';

/// Section 2: on registration, before payment, the user is asked what
/// type of organization they run. Sets organizationType (drives all
/// localized labels via Section 6) but does NOT restrict features by
/// itself — that's controlled by plan, handled later at checkout.
class CreateOrganizationScreen extends ConsumerStatefulWidget {
  const CreateOrganizationScreen({super.key});

  @override
  ConsumerState<CreateOrganizationScreen> createState() =>
      _CreateOrganizationScreenState();
}

// Moved to core/constants/organization_types.dart in Batch 10 so
// Settings' organization-type editor can reuse the exact same list
// instead of duplicating it — see that file's doc comment.

class _CreateOrganizationScreenState
    extends ConsumerState<CreateOrganizationScreen> {
  final _nameController = TextEditingController();
  String? _selectedType;
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_nameController.text.trim().isEmpty) {
      setState(() => _errorMessage = 'Enter your organization name');
      return;
    }
    if (_selectedType == null) {
      setState(() => _errorMessage = 'Choose the type of work you do');
      return;
    }
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final org = await OrganizationApi.create(
        name: _nameController.text.trim(),
        organizationType: _selectedType!,
      );
      await ref.read(organizationTypeProvider.notifier).set(_selectedType!);
      if (!mounted) return;
      context.go('/dashboard', extra: {'organizationId': org['id']});
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    "Let's set up your workspace",
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    "This determines the wording you'll see throughout the app — "
                    "you can change it later in Settings.",
                  ),
                  const SizedBox(height: 28),
                  AppTextField(
                    controller: _nameController,
                    label: 'Organization name',
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'What kind of work do you do?',
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                  const SizedBox(height: 8),
                  ...organizationTypes.map(
                    (entry) => RadioListTile<String>(
                      value: entry.$1,
                      groupValue: _selectedType,
                      title: Text(entry.$2),
                      contentPadding: EdgeInsets.zero,
                      onChanged: (value) =>
                          setState(() => _selectedType = value),
                    ),
                  ),
                  if (_errorMessage != null) ...[
                    const SizedBox(height: 6),
                    Text(
                      _errorMessage!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  PrimaryButton(
                    label: 'Continue',
                    onPressed: _submit,
                    isLoading: _isLoading,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
