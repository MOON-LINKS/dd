import 'package:flutter/material.dart';

/// One visual wrapper for every settings group (Appearance, Organization,
/// Account, Danger zone) — a titled card, consistent spacing, rather than
/// each section in SettingsScreen hand-rolling its own Container/Padding.
class SettingsSection extends StatelessWidget {
  final String title;
  final List<Widget> children;
  final Color? titleColor;

  const SettingsSection({
    super.key,
    required this.title,
    required this.children,
    this.titleColor,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: titleColor,
                  ),
            ),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }
}
