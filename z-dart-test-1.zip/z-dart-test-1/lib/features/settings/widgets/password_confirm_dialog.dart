import 'package:flutter/material.dart';
import '../../../l10n/app_localizations.dart';

/// One dialog shared by every "re-enter your password to confirm"
/// action — logoutAll, deleteAccount, deleteOrganization all require this
/// server-side (see authController.js/organizationController.js), so one
/// dialog widget instead of three near-identical ones. `requireEmail`
/// adds a second field for deleteAccount specifically, which checks both.
Future<({String? email, String password})?> showPasswordConfirmDialog(
  BuildContext context, {
  required String title,
  required String body,
  bool requireEmail = false,
}) {
  final passwordController = TextEditingController();
  final emailController = TextEditingController();
  return showDialog<({String? email, String password})>(
    context: context,
    builder: (dialogContext) {
      final l10n = AppLocalizations.of(dialogContext)!;
      return AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(body),
            const SizedBox(height: 16),
            if (requireEmail) ...[
              TextField(
                controller: emailController,
                decoration: InputDecoration(labelText: l10n.email),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 12),
            ],
            TextField(
              controller: passwordController,
              decoration: InputDecoration(labelText: l10n.password),
              obscureText: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop((
              email: requireEmail ? emailController.text.trim() : null,
              password: passwordController.text,
            )),
            child: Text(l10n.confirmAction),
          ),
        ],
      );
    },
  );
}
