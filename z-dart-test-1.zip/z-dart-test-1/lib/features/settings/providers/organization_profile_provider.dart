import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/organization_profile.dart';
import '../../../api/services/organization_api.dart';

/// Deliberately separate from `myOrganizationsProvider` (which backs the
/// org-existence gate in `app_shell_screen.dart` and stays untouched by
/// this batch) — this one calls `OrganizationApi.get()`, the richer
/// endpoint with plan/logo/created_at joined in, which only this screen
/// needs. Same family-by-orgId, invalidate-after-mutation style as every
/// other provider in the app.
final organizationProfileProvider =
    FutureProvider.family<OrganizationProfile, String>((ref, organizationId) {
  return OrganizationApi.get(organizationId);
});
