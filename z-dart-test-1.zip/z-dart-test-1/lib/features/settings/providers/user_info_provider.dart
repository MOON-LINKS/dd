import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/user_info.dart';
import '../../../api/services/auth_api.dart';

/// Plain FutureProvider (not org-scoped — a user, not an organization) —
/// re-triggered via `ref.invalidate(userInfoProvider)` on demand. Nothing
/// in this batch's screens currently mutates the user record itself (no
/// "edit full name" endpoint exists server-side to invalidate this after),
/// but the sessions list is worth refreshing after logoutAll, so the
/// invalidate hook is here from day one rather than bolted on later.
final userInfoProvider = FutureProvider<UserInfo>((ref) {
  return AuthApi.getMe();
});
