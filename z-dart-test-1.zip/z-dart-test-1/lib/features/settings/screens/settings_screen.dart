import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../api/api_exception.dart';
import '../../../api/services/auth_api.dart';
import '../../../api/services/organization_api.dart';
import '../../../api/services/payment_api.dart';
import '../../../core/constants/organization_types.dart';
import '../../../core/providers/auth_state_provider.dart';
import '../../../core/providers/locale_provider.dart';
import '../../../core/providers/organization_type_provider.dart';
import '../../../core/providers/theme_provider.dart';
import '../../../core/storage/secure_storage.dart';
import '../../../l10n/app_localizations.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../shell/providers/current_organization_provider.dart';
import '../../shell/providers/my_organizations_provider.dart';
import '../providers/organization_profile_provider.dart';
import '../providers/user_info_provider.dart';
import '../widgets/password_confirm_dialog.dart';
import '../widgets/settings_section.dart';

const _localeNames = {'en': 'English', 'ar': 'العربية', 'fr': 'Français'};

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orgId = ref.watch(currentOrganizationIdProvider);
    if (orgId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const _AppearanceSection(),
              _OrganizationSection(orgId: orgId),
              const _AccountSection(),
              _DangerZoneSection(orgId: orgId),
            ],
          ),
        ),
      ),
    );
  }
}

class _AppearanceSection extends ConsumerWidget {
  const _AppearanceSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final themeMode = ref.watch(themeModeProvider);
    final locale = ref.watch(localeProvider);

    return SettingsSection(
      title: l10n.appearanceSectionTitle,
      children: [
        Text(l10n.themeLabel, style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 4),
        SegmentedButton<ThemeMode>(
          segments: [
            ButtonSegment(value: ThemeMode.light, label: Text(l10n.lightThemeLabel)),
            ButtonSegment(value: ThemeMode.dark, label: Text(l10n.darkThemeLabel)),
            ButtonSegment(value: ThemeMode.system, label: Text(l10n.systemThemeLabel)),
          ],
          selected: {themeMode},
          onSelectionChanged: (selected) {
            final notifier = ref.read(themeModeProvider.notifier);
            switch (selected.first) {
              case ThemeMode.light:
                notifier.setLight();
                break;
              case ThemeMode.dark:
                notifier.setDark();
                break;
              case ThemeMode.system:
                notifier.setSystem();
                break;
            }
          },
        ),
        const SizedBox(height: 20),
        Text(l10n.languageLabel, style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 4),
        DropdownButtonFormField<Locale>(
          initialValue: locale,
          items: supportedLocales
              .map((l) => DropdownMenuItem(
                    value: l,
                    child: Text(_localeNames[l.languageCode] ?? l.languageCode),
                  ))
              .toList(),
          onChanged: (value) {
            if (value != null) ref.read(localeProvider.notifier).setLocale(value);
          },
        ),
      ],
    );
  }
}

class _OrganizationSection extends ConsumerStatefulWidget {
  final String orgId;
  const _OrganizationSection({required this.orgId});

  @override
  ConsumerState<_OrganizationSection> createState() => _OrganizationSectionState();
}

class _OrganizationSectionState extends ConsumerState<_OrganizationSection> {
  final _nameController = TextEditingController();
  String? _selectedType;
  bool _isSaving = false;
  bool _isOpeningPortal = false;
  String? _initializedForOrgId;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _save(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    setState(() => _isSaving = true);
    try {
      await OrganizationApi.update(
        widget.orgId,
        name: _nameController.text.trim(),
        organizationType: _selectedType,
      );
      if (_selectedType != null) {
        await ref.read(organizationTypeProvider.notifier).set(_selectedType!);
      }
      ref.invalidate(organizationProfileProvider(widget.orgId));
      ref.invalidate(myOrganizationsProvider);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.savedMessage)));
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _openBillingPortal(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    setState(() => _isOpeningPortal = true);
    try {
      final url = await PaymentApi.getBillingPortalUrl(widget.orgId);
      final uri = Uri.parse(url);
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(l10n.couldNotOpenPdfError)));
      }
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isOpeningPortal = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final profileAsync = ref.watch(organizationProfileProvider(widget.orgId));

    return SettingsSection(
      title: l10n.organizationSectionTitle,
      children: [
        profileAsync.when(
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (err, __) => Text(err is ApiException ? err.message : l10n.errorGeneric),
          data: (profile) {
            // Only seed the controllers once per org, on first successful
            // load — re-running this on every rebuild (e.g. after Save
            // triggers a refetch) would stomp on-screen edits the user
            // hasn't submitted yet with whatever the server just echoed
            // back, which happens to be identical right after a save but
            // would be actively wrong the moment this section supports
            // anything with more latency.
            if (_initializedForOrgId != widget.orgId) {
              _nameController.text = profile.name;
              _selectedType = profile.organizationType;
              _initializedForOrgId = widget.orgId;
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                AppTextField(controller: _nameController, label: l10n.organizationNameLabel),
                const SizedBox(height: 16),
                Text(l10n.organizationTypeLabel, style: Theme.of(context).textTheme.labelLarge),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  initialValue: _selectedType,
                  items: organizationTypes
                      .map((t) => DropdownMenuItem(value: t.$1, child: Text(t.$2)))
                      .toList(),
                  onChanged: (value) => setState(() => _selectedType = value),
                ),
                const SizedBox(height: 16),
                OutlinedButton(
                  onPressed: _isSaving ? null : () => _save(context),
                  child: _isSaving
                      ? const SizedBox(
                          width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(l10n.save),
                ),
                const Divider(height: 32),
                Text(l10n.planSectionLabel, style: Theme.of(context).textTheme.labelLarge),
                const SizedBox(height: 8),
                if (!profile.hasActivePlan)
                  Text(l10n.noActivePlanLabel)
                else ...[
                  Text('${profile.planName ?? profile.planId}'),
                  if (profile.maxWorkers != null)
                    Text('${l10n.maxWorkersLabel}: ${profile.maxWorkers}'),
                ],
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  icon: const Icon(Icons.open_in_new, size: 18),
                  label: Text(l10n.manageSubscriptionAction),
                  onPressed: _isOpeningPortal ? null : () => _openBillingPortal(context),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _AccountSection extends ConsumerStatefulWidget {
  const _AccountSection();

  @override
  ConsumerState<_AccountSection> createState() => _AccountSectionState();
}

class _AccountSectionState extends ConsumerState<_AccountSection> {
  bool _isLoggingOutAll = false;

  Future<void> _logoutAll(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    final result = await showPasswordConfirmDialog(
      context,
      title: l10n.logoutAllDevicesAction,
      body: l10n.logoutAllConfirmBody,
    );
    if (result == null || result.password.isEmpty) return;

    setState(() => _isLoggingOutAll = true);
    try {
      // Note: this also ends the current session (see authController.js's
      // invalidateAllSessions — it wipes every user_sessions row for this
      // user, current device included, not just "other" devices), so
      // markLoggedOut() below is correct, not just a UI-side courtesy.
      await AuthApi.logoutAll(password: result.password);
      if (!context.mounted) return;
      ref.read(authStateProvider.notifier).markLoggedOut();
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isLoggingOutAll = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final userAsync = ref.watch(userInfoProvider);

    return SettingsSection(
      title: l10n.accountSectionTitle,
      children: [
        userAsync.when(
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (err, __) => Text(err is ApiException ? err.message : l10n.errorGeneric),
          data: (user) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (user.fullName != null) Text(user.fullName!, style: Theme.of(context).textTheme.titleSmall),
              Text(user.email),
              const SizedBox(height: 12),
              Text(l10n.sessionsLabel, style: Theme.of(context).textTheme.labelLarge),
              const SizedBox(height: 4),
              for (final session in user.sessions)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    '${session.deviceName ?? session.sessionId}'
                    '${session.lastActive != null ? ' · ${session.lastActive}' : ''}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // "Change password" is deliberately not here — authController.js
        // defines a changePassword handler, but authRoutes.js never
        // mounts it on a route, so there is currently nothing this button
        // could call. See BATCH_NOTES.md.
        OutlinedButton(
          onPressed: _isLoggingOutAll ? null : () => _logoutAll(context),
          child: _isLoggingOutAll
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : Text(l10n.logoutAllDevicesAction),
        ),
      ],
    );
  }
}

class _DangerZoneSection extends ConsumerStatefulWidget {
  final String orgId;
  const _DangerZoneSection({required this.orgId});

  @override
  ConsumerState<_DangerZoneSection> createState() => _DangerZoneSectionState();
}

class _DangerZoneSectionState extends ConsumerState<_DangerZoneSection> {
  bool _isDeletingOrg = false;
  bool _isDeletingAccount = false;

  Future<void> _deleteOrganization(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    final result = await showPasswordConfirmDialog(
      context,
      title: l10n.deleteOrganizationAction,
      body: l10n.deleteOrganizationConfirmBody,
    );
    if (result == null || result.password.isEmpty) return;

    setState(() => _isDeletingOrg = true);
    try {
      final warning = await OrganizationApi.delete(widget.orgId, password: result.password);
      if (!context.mounted) return;
      // No manual navigation needed — invalidating myOrganizationsProvider
      // makes it refetch as empty, and app_shell_screen.dart's existing
      // org-existence gate already redirects to /onboarding/organization
      // on its own the moment that happens (see that file's `if
      // (orgs.isEmpty)` branch). Same reason Batch 8/9 never had to touch
      // routing for their own mutations.
      ref.invalidate(myOrganizationsProvider);
      if (warning != null) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(warning)));
      }
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isDeletingOrg = false);
    }
  }

  Future<void> _deleteAccount(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    final result = await showPasswordConfirmDialog(
      context,
      title: l10n.deleteAccountAction,
      body: l10n.deleteAccountConfirmBody,
      requireEmail: true,
    );
    if (result == null || result.password.isEmpty || (result.email?.isEmpty ?? true)) return;

    setState(() => _isDeletingAccount = true);
    try {
      await AuthApi.deleteAccount(email: result.email!, password: result.password);
      if (!context.mounted) return;
      ref.read(authStateProvider.notifier).markLoggedOut();
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isDeletingAccount = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final errorColor = Theme.of(context).colorScheme.error;

    return SettingsSection(
      title: l10n.dangerZoneTitle,
      titleColor: errorColor,
      children: [
        OutlinedButton(
          style: OutlinedButton.styleFrom(foregroundColor: errorColor, side: BorderSide(color: errorColor)),
          onPressed: _isDeletingOrg ? null : () => _deleteOrganization(context),
          child: _isDeletingOrg
              ? SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: errorColor))
              : Text(l10n.deleteOrganizationAction),
        ),
        const SizedBox(height: 12),
        OutlinedButton(
          style: OutlinedButton.styleFrom(foregroundColor: errorColor, side: BorderSide(color: errorColor)),
          onPressed: _isDeletingAccount ? null : () => _deleteAccount(context),
          child: _isDeletingAccount
              ? SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: errorColor))
              : Text(l10n.deleteAccountAction),
        ),
      ],
    );
  }
}
