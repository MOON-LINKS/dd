import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../api/services/auth_api.dart';
import '../../../api/api_exception.dart';
import '../../../core/device/device_name.dart';
import '../../../core/providers/auth_state_provider.dart';
import '../../../shared/widgets/auth_scaffold.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';

class VerifyOtpScreen extends ConsumerStatefulWidget {
  final String email;
  final String verificationId;

  const VerifyOtpScreen({super.key, required this.email, required this.verificationId});

  @override
  ConsumerState<VerifyOtpScreen> createState() => _VerifyOtpScreenState();
}

class _VerifyOtpScreenState extends ConsumerState<VerifyOtpScreen> {
  final _otpController = TextEditingController();
  bool _isLoading = false;
  bool _verified = false;
  String? _errorMessage;

  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_otpController.text.trim().length < 4) {
      setState(() => _errorMessage = 'Enter the code from your email');
      return;
    }
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      await AuthApi.verifyOtp(
        otp: _otpController.text.trim(),
        verificationId: widget.verificationId,
        deviceName: getDeviceName(),
      );
      // The one deliberate animated moment in this flow — a brief success
      // state before the router carries the user onward via authStateProvider.
      setState(() => _verified = true);
      await Future.delayed(const Duration(milliseconds: 500));
      ref.read(authStateProvider.notifier).markLoggedIn();
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted && !_verified) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      title: 'Verify your email',
      subtitle: 'Enter the code sent to ${widget.email}.',
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: _verified
            ? Column(
                key: const ValueKey('verified'),
                children: [
                  Icon(Icons.check_circle, color: Theme.of(context).colorScheme.primary, size: 56),
                  const SizedBox(height: 12),
                  const Text('Verified'),
                ],
              )
            : Column(
                key: const ValueKey('form'),
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  AppTextField(
                    controller: _otpController,
                    label: 'Verification code',
                    keyboardType: TextInputType.number,
                  ),
                  if (_errorMessage != null) ...[
                    const SizedBox(height: 10),
                    Text(_errorMessage!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  ],
                  const SizedBox(height: 20),
                  PrimaryButton(label: 'Verify', onPressed: _submit, isLoading: _isLoading),
                  const SizedBox(height: 12),
                  Center(
                    child: TextButton(
                      onPressed: () => context.go('/register'),
                      child: const Text('Code expired? Register again'),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
