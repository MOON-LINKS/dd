import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../api/services/auth_api.dart';
import '../../../api/api_exception.dart';
import '../../../shared/widgets/auth_scaffold.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';

/// One screen, three steps — mirrors the backend's resetPass1/2/3 exactly:
/// request OTP -> verify OTP (get resetToken) -> set new password.
/// Kept as a single stateful screen rather than three routes since the
/// user never needs to navigate back mid-flow or deep-link into step 2.
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

enum _Step { requestEmail, enterOtp, newPassword, done }

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  _Step _step = _Step.requestEmail;
  bool _isLoading = false;
  String? _errorMessage;

  final _emailController = TextEditingController();
  final _otpController = TextEditingController();
  final _newPasswordController = TextEditingController();

  String? _resetId;
  String? _resetToken;

  @override
  void dispose() {
    _emailController.dispose();
    _otpController.dispose();
    _newPasswordController.dispose();
    super.dispose();
  }

  Future<void> _requestOtp() async {
    if (!_emailController.text.contains('@')) {
      setState(() => _errorMessage = 'Enter a valid email');
      return;
    }
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      _resetId = await AuthApi.resetPasswordRequest(email: _emailController.text.trim());
      setState(() => _step = _Step.enterOtp);
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _verifyOtp() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      _resetToken = await AuthApi.resetPasswordVerify(
        resetId: _resetId!,
        otp: _otpController.text.trim(),
      );
      setState(() => _step = _Step.newPassword);
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _confirmNewPassword() async {
    if (_newPasswordController.text.length < 8) {
      setState(() => _errorMessage = 'At least 8 characters');
      return;
    }
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      await AuthApi.resetPasswordConfirm(
        newPass: _newPasswordController.text,
        resetToken: _resetToken!,
      );
      setState(() => _step = _Step.done);
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      title: 'Reset your password',
      subtitle: _subtitleForStep(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ..._fieldsForStep(),
          if (_errorMessage != null) ...[
            const SizedBox(height: 10),
            Text(_errorMessage!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 20),
          if (_step != _Step.done) _buttonForStep(),
        ],
      ),
      footer: _step == _Step.done
          ? Center(
              child: TextButton(
                onPressed: () => context.go('/login'),
                child: const Text('Back to login'),
              ),
            )
          : null,
    );
  }

  String _subtitleForStep() {
    switch (_step) {
      case _Step.requestEmail:
        return "Enter your email and we'll send a verification code.";
      case _Step.enterOtp:
        return 'Enter the code sent to ${_emailController.text}.';
      case _Step.newPassword:
        return 'Choose a new password.';
      case _Step.done:
        return "Your password has been changed. You've been logged out of all other sessions.";
    }
  }

  List<Widget> _fieldsForStep() {
    switch (_step) {
      case _Step.requestEmail:
        return [
          AppTextField(
            controller: _emailController,
            label: 'Email',
            keyboardType: TextInputType.emailAddress,
          ),
        ];
      case _Step.enterOtp:
        return [
          AppTextField(
            controller: _otpController,
            label: 'Verification code',
            keyboardType: TextInputType.number,
          ),
        ];
      case _Step.newPassword:
        return [
          AppTextField(
            controller: _newPasswordController,
            label: 'New password',
            obscureText: true,
          ),
        ];
      case _Step.done:
        return [];
    }
  }

  Widget _buttonForStep() {
    switch (_step) {
      case _Step.requestEmail:
        return PrimaryButton(label: 'Send code', onPressed: _requestOtp, isLoading: _isLoading);
      case _Step.enterOtp:
        return PrimaryButton(label: 'Verify code', onPressed: _verifyOtp, isLoading: _isLoading);
      case _Step.newPassword:
        return PrimaryButton(
          label: 'Change password',
          onPressed: _confirmNewPassword,
          isLoading: _isLoading,
        );
      case _Step.done:
        return const SizedBox.shrink();
    }
  }
}
