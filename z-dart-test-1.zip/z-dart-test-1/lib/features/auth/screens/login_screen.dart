import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../api/services/auth_api.dart';
import '../../../api/api_exception.dart';
import '../../../core/device/device_name.dart';
import '../../../core/providers/auth_state_provider.dart';
import '../../../shared/widgets/auth_scaffold.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      await AuthApi.login(
        email: _emailController.text.trim(),
        password: _passwordController.text,
        deviceName: getDeviceName(),
      );
      ref.read(authStateProvider.notifier).markLoggedIn();
      // No explicit navigation call needed — router.redirect reacts to
      // authStateProvider changing and sends us to /home automatically.
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      title: 'Log in',
      subtitle: 'Welcome back — enter your details to continue.',
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            AppTextField(
              controller: _emailController,
              label: 'Email',
              keyboardType: TextInputType.emailAddress,
              validator: (v) => (v == null || !v.contains('@')) ? 'Enter a valid email' : null,
            ),
            const SizedBox(height: 14),
            AppTextField(
              controller: _passwordController,
              label: 'Password',
              obscureText: true,
              validator: (v) => (v == null || v.isEmpty) ? 'Enter your password' : null,
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => context.push('/forgot-password'),
                child: const Text('Forgot password?'),
              ),
            ),
            if (_errorMessage != null) ...[
              const SizedBox(height: 4),
              Text(_errorMessage!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              const SizedBox(height: 10),
            ] else
              const SizedBox(height: 14),
            PrimaryButton(label: 'Log in', onPressed: _submit, isLoading: _isLoading),
          ],
        ),
      ),
      footer: Center(
        child: TextButton(
          onPressed: () => context.push('/register'),
          child: const Text("Don't have an account? Register"),
        ),
      ),
    );
  }
}
