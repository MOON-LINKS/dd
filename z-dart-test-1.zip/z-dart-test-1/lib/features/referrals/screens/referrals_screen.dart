import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../api/api_exception.dart';
import '../../../l10n/app_localizations.dart';
import '../../shell/providers/current_organization_provider.dart';
import '../providers/referral_providers.dart';

class ReferralsScreen extends ConsumerWidget {
  const ReferralsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orgId = ref.watch(currentOrganizationIdProvider);
    if (orgId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return RefreshIndicator(
      onRefresh: () async {
        ref.invalidate(referralCodeProvider(orgId));
        ref.invalidate(referralEarningsProvider(orgId));
        ref.invalidate(referralHistoryProvider(orgId));
      },
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _CodeCard(orgId: orgId),
          const SizedBox(height: 16),
          _EarningsCard(orgId: orgId),
          const SizedBox(height: 16),
          _HistorySection(orgId: orgId),
        ],
      ),
    );
  }
}

class _CodeCard extends ConsumerWidget {
  final String orgId;
  const _CodeCard({required this.orgId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final codeAsync = ref.watch(referralCodeProvider(orgId));

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: codeAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, __) => Text(err is ApiException ? err.message : l10n.errorGeneric),
          data: (referralCode) {
            if (!referralCode.hasCode) {
              // Generated lazily on first successful payment (see
              // referralEngine.js) — not a loading state or an error, a
              // real "not yet" the org-facing UI should explain rather
              // than hide.
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(l10n.referralCodeLabel, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(l10n.referralCodeNotYetLabel),
                ],
              );
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l10n.referralCodeLabel, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        referralCode.code!,
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.5,
                            ),
                      ),
                    ),
                    IconButton(
                      tooltip: l10n.copyAssignmentAction,
                      icon: const Icon(Icons.copy_outlined),
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: referralCode.code!));
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text(l10n.copiedToClipboardMessage)));
                      },
                    ),
                  ],
                ),
                if (referralCode.discountPct != null) ...[
                  const SizedBox(height: 4),
                  Text(l10n.referralDiscountHint(referralCode.discountPct!)),
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}

class _EarningsCard extends ConsumerWidget {
  final String orgId;
  const _EarningsCard({required this.orgId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final earningsAsync = ref.watch(referralEarningsProvider(orgId));
    final currency = NumberFormat.simpleCurrency(locale: Localizations.localeOf(context).toString());

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: earningsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, __) => Text(err is ApiException ? err.message : l10n.errorGeneric),
          data: (earnings) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(l10n.earningsLabel, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              _statRow(l10n.totalEarnedLabel, currency.format(earnings.totalEarnedCents / 100)),
              _statRow(l10n.pendingBalanceLabel, currency.format(earnings.pendingBalanceCents / 100)),
              _statRow(l10n.totalPaidOutLabel, currency.format(earnings.totalPaidCents / 100)),
              _statRow(
                l10n.referredOrganizationsCountLabel,
                earnings.referredOrganizationsCount.toString(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _HistorySection extends ConsumerWidget {
  final String orgId;
  const _HistorySection({required this.orgId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final historyAsync = ref.watch(referralHistoryProvider(orgId));
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString());
    final currency = NumberFormat.simpleCurrency(locale: Localizations.localeOf(context).toString());

    return historyAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (err, __) => Text(err is ApiException ? err.message : l10n.errorGeneric),
      data: (history) {
        if (history.referredOrganizations.isEmpty) {
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text(l10n.emptyListTitleGeneric),
            ),
          );
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
              child: Text(l10n.referralHistoryLabel, style: Theme.of(context).textTheme.titleMedium),
            ),
            for (final use in history.referredOrganizations)
              Card(
                margin: const EdgeInsets.symmetric(vertical: 4),
                child: ListTile(
                  leading: const Icon(Icons.handshake_outlined),
                  title: Text(use.referredOrganizationName),
                  subtitle: Text(
                    '${dateFormat.format(use.usedAt)} · ${use.discountAppliedPct}% ${l10n.discountAppliedSuffix}',
                  ),
                ),
              ),
            if (history.earnings.isNotEmpty) ...[
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                child: Text(l10n.earningsLedgerLabel, style: Theme.of(context).textTheme.titleMedium),
              ),
              for (final entry in history.earnings)
                Card(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: ListTile(
                    leading: Icon(
                      entry.isPaidOut ? Icons.check_circle_outline : Icons.hourglass_empty,
                      color: entry.isPaidOut
                          ? Theme.of(context).colorScheme.tertiary
                          : Theme.of(context).colorScheme.outline,
                    ),
                    title: Text(currency.format(entry.commissionCents / 100)),
                    subtitle: Text(dateFormat.format(entry.createdAt)),
                    trailing: Text(
                      entry.isPaidOut ? l10n.paidStatusLabel : l10n.pendingStatusLabel,
                    ),
                  ),
                ),
            ],
          ],
        );
      },
    );
  }
}
