import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/referral.dart';
import '../../../api/services/referral_api.dart';

/// Three plain FutureProvider.family, same style as every other org-scoped
/// provider in the app. Nothing on this screen mutates server state (no
/// create/edit/delete — a referral code is generated server-side, not
/// user-editable), so unlike most other providers in this app these are
/// never invalidated by a screen action; they're only re-fetched via
/// pull-to-refresh.
final referralCodeProvider =
    FutureProvider.family<ReferralCode, String>((ref, organizationId) {
  return ReferralApi.getMyCode(organizationId);
});

final referralEarningsProvider =
    FutureProvider.family<ReferralEarningsSummary, String>((ref, organizationId) {
  return ReferralApi.getEarnings(organizationId);
});

final referralHistoryProvider =
    FutureProvider.family<ReferralHistory, String>((ref, organizationId) {
  return ReferralApi.getHistory(organizationId);
});
