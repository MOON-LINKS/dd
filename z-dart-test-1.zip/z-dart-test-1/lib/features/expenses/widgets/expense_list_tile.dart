import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../api/models/expense.dart';
import '../../../l10n/app_localizations.dart';
import '../utils/expense_category_labels.dart';

class ExpenseListTile extends StatelessWidget {
  final Expense expense;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const ExpenseListTile({
    super.key,
    required this.expense,
    required this.onTap,
    required this.onDelete,
  });

  static const _categoryIcons = {
    ExpenseCategory.hospital: Icons.local_hospital_outlined,
    ExpenseCategory.tax: Icons.receipt_long_outlined,
    ExpenseCategory.electricity: Icons.bolt_outlined,
    ExpenseCategory.rent: Icons.home_outlined,
    ExpenseCategory.fuel: Icons.local_gas_station_outlined,
    ExpenseCategory.transportation: Icons.local_shipping_outlined,
    ExpenseCategory.other: Icons.category_outlined,
  };

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final currency = NumberFormat.simpleCurrency(locale: Localizations.localeOf(context).toString());
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString());

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: colorScheme.tertiaryContainer,
          foregroundColor: colorScheme.onTertiaryContainer,
          child: Icon(_categoryIcons[expense.category] ?? Icons.category_outlined),
        ),
        title: Text(
          expenseCategoryLabel(context, expense.category),
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          expense.recurring
              ? '${dateFormat.format(expense.date)} · ${AppLocalizations.of(context)!.recurringLabel}'
              : dateFormat.format(expense.date),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              currency.format(expense.amount),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline),
              tooltip: AppLocalizations.of(context)!.delete,
              onPressed: onDelete,
            ),
          ],
        ),
      ),
    );
  }
}
