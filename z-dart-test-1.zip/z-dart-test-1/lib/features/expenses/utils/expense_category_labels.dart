import 'package:flutter/widgets.dart';
import '../../../api/models/expense.dart';
import '../../../l10n/app_localizations.dart';

/// Small and self-contained on purpose — both expenses_list_screen.dart
/// (list tile category chip) and expense_form_screen.dart (category
/// dropdown) need the same enum -> localized string mapping, so it lives
/// here once rather than being duplicated in both files.
String expenseCategoryLabel(BuildContext context, ExpenseCategory category) {
  final l10n = AppLocalizations.of(context)!;
  return switch (category) {
    ExpenseCategory.hospital => l10n.expenseCategoryHospital,
    ExpenseCategory.tax => l10n.expenseCategoryTax,
    ExpenseCategory.electricity => l10n.expenseCategoryElectricity,
    ExpenseCategory.rent => l10n.expenseCategoryRent,
    ExpenseCategory.fuel => l10n.expenseCategoryFuel,
    ExpenseCategory.transportation => l10n.expenseCategoryTransportation,
    ExpenseCategory.other => l10n.expenseCategoryOther,
  };
}
