import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/expense.dart';
import '../../../api/services/expense_api.dart';

/// No filter params exposed here — this batch's list screen shows
/// everything unfiltered, same scope call as Workers/Clients. ExpenseApi.list
/// already supports category/date filtering server-side whenever a future
/// batch adds filter UI; nothing here needs to change for that, a new
/// provider taking the filter args as part of the family key would sit
/// alongside this one.
final expensesProvider =
    FutureProvider.family<List<Expense>, String>((ref, organizationId) {
  return ExpenseApi.list(organizationId);
});
