import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/expense.dart';
import '../../../api/services/expense_api.dart';
import '../../../l10n/app_localizations.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../workers/providers/workers_provider.dart';
import '../utils/expense_category_labels.dart';

class ExpenseFormScreen extends ConsumerStatefulWidget {
  final String orgId;

  /// null => create. Non-null => edit, pre-filled from this expense.
  final Expense? expense;

  const ExpenseFormScreen({super.key, required this.orgId, this.expense});

  bool get isEditing => expense != null;

  @override
  ConsumerState<ExpenseFormScreen> createState() => _ExpenseFormScreenState();
}

class _ExpenseFormScreenState extends ConsumerState<ExpenseFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _amountController;
  late final TextEditingController _notesController;
  late ExpenseCategory _category;
  late DateTime _date;
  late bool _recurring;
  String? _linkedWorkerId;

  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    final expense = widget.expense;
    _amountController = TextEditingController(text: expense?.amount.toString() ?? '');
    _notesController = TextEditingController(text: expense?.notes ?? '');
    _category = expense?.category ?? ExpenseCategory.other;
    _date = expense?.date ?? DateTime.now();
    _recurring = expense?.recurring ?? false;
    _linkedWorkerId = expense?.linkedWorkerId;
  }

  @override
  void dispose() {
    _amountController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2015),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _submit() async {
    final l10n = AppLocalizations.of(context)!;
    if (!(_formKey.currentState?.validate() ?? false)) return;

    final amount = double.parse(_amountController.text.trim());
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      if (widget.isEditing) {
        await ExpenseApi.update(
          widget.orgId,
          widget.expense!.id,
          category: _category,
          amount: amount,
          date: _date,
          recurring: _recurring,
          notes: _notesController.text.trim(),
          linkedWorkerId: _linkedWorkerId,
        );
      } else {
        await ExpenseApi.create(
          widget.orgId,
          category: _category,
          amount: amount,
          date: _date,
          recurring: _recurring,
          notes: _notesController.text.trim(),
          linkedWorkerId: _linkedWorkerId,
        );
      }
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString());

    // Loading/error states for the worker list collapse to "no workers to
    // link yet" rather than blocking the whole form — linking a worker is
    // optional, so a slow or failed fetch here shouldn't stop someone from
    // logging an expense.
    final workers = ref.watch(workersProvider(widget.orgId)).valueOrNull ?? [];

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isEditing ? '${l10n.edit} ${l10n.expenses}' : '${l10n.add} ${l10n.expenses}'),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(l10n.categoryLabel, style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<ExpenseCategory>(
                      initialValue: _category,
                      items: ExpenseCategory.values
                          .map((c) => DropdownMenuItem(
                                value: c,
                                child: Text(expenseCategoryLabel(context, c)),
                              ))
                          .toList(),
                      onChanged: (value) {
                        if (value != null) setState(() => _category = value);
                      },
                    ),
                    const SizedBox(height: 20),
                    AppTextField(
                      controller: _amountController,
                      label: l10n.amountLabel,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (value) {
                        final trimmed = value?.trim() ?? '';
                        if (trimmed.isEmpty) return l10n.amountRequiredError;
                        final parsed = double.tryParse(trimmed);
                        if (parsed == null || parsed < 0) return l10n.amountRequiredError;
                        return null;
                      },
                    ),
                    const SizedBox(height: 20),
                    Text(l10n.dateLabel, style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    OutlinedButton(
                      onPressed: _pickDate,
                      style: OutlinedButton.styleFrom(
                        alignment: Alignment.centerLeft,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      ),
                      child: Text(dateFormat.format(_date)),
                    ),
                    const SizedBox(height: 12),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(l10n.recurringLabel),
                      value: _recurring,
                      onChanged: (value) => setState(() => _recurring = value),
                    ),
                    const SizedBox(height: 8),
                    Text(l10n.linkedWorkerOptionalLabel, style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String?>(
                      initialValue: _linkedWorkerId,
                      items: [
                        DropdownMenuItem(value: null, child: Text(l10n.noneOptionLabel)),
                        ...workers.map((w) => DropdownMenuItem(value: w.id, child: Text(w.name))),
                      ],
                      onChanged: (value) => setState(() => _linkedWorkerId = value),
                    ),
                    const SizedBox(height: 20),
                    AppTextField(
                      controller: _notesController,
                      label: l10n.notesLabel,
                      isOptional: true,
                    ),
                    if (_errorMessage != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        _errorMessage!,
                        style: TextStyle(color: Theme.of(context).colorScheme.error),
                      ),
                    ],
                    const SizedBox(height: 24),
                    PrimaryButton(
                      label: l10n.save,
                      onPressed: _submit,
                      isLoading: _isLoading,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
