import 'package:flutter/material.dart';
import '../../../api/models/client.dart';
import '../../../l10n/app_localizations.dart';

class ClientListTile extends StatelessWidget {
  final Client client;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const ClientListTile({
    super.key,
    required this.client,
    required this.onTap,
    required this.onDelete,
  });

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1)).toUpperCase();
  }

  /// email and phone are shown together, comma-separated, when both exist —
  /// there's no dedicated second line for each, this list is meant to stay
  /// scannable rather than turn into a mini contact card per row.
  String? _contactLine() {
    final parts = [client.email, client.phone].where((p) => p != null && p.isNotEmpty);
    return parts.isEmpty ? null : parts.join(' · ');
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final contactLine = _contactLine();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: colorScheme.secondaryContainer,
          foregroundColor: colorScheme.onSecondaryContainer,
          child: Text(_initials(client.name), style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
        title: Text(client.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: contactLine == null ? null : Text(contactLine),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (client.averageRating != null) ...[
              Icon(Icons.star_rounded, size: 18, color: Colors.amber.shade700),
              const SizedBox(width: 2),
              Text(client.averageRating!.toStringAsFixed(1)),
              const SizedBox(width: 8),
            ],
            IconButton(
              icon: const Icon(Icons.delete_outline),
              tooltip: AppLocalizations.of(context)!.delete,
              onPressed: onDelete,
            ),
          ],
        ),
      ),
    );
  }
}
