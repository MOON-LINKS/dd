import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/api_exception.dart';
import '../../../api/services/client_api.dart';
import '../../../core/providers/vertical_labels_provider.dart';
import '../../../l10n/app_localizations.dart';
import '../../shell/providers/current_organization_provider.dart';
import '../providers/clients_provider.dart';
import '../widgets/client_list_tile.dart';
import 'client_form_screen.dart';

class ClientsListScreen extends ConsumerWidget {
  const ClientsListScreen({super.key});

  Future<void> _confirmDelete(
    BuildContext context,
    WidgetRef ref,
    String orgId,
    String clientId,
  ) async {
    final l10n = AppLocalizations.of(context)!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(l10n.delete),
        content: Text(l10n.confirmDeleteGeneric),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(l10n.delete),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await ClientApi.delete(orgId, clientId);
      ref.invalidate(clientsProvider(orgId));
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final orgId = ref.watch(currentOrganizationIdProvider);
    final clientLabel = ref.watch(verticalLabelProvider('client_title'));

    if (orgId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final clientsAsync = ref.watch(clientsProvider(orgId));

    return Scaffold(
      body: clientsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, __) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(err is ApiException ? err.message : l10n.errorGeneric),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => ref.invalidate(clientsProvider(orgId)),
                child: Text(l10n.retry),
              ),
            ],
          ),
        ),
        data: (clients) {
          if (clients.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.people_outline, size: 40, color: Theme.of(context).colorScheme.outline),
                  const SizedBox(height: 16),
                  Text(l10n.emptyListTitleGeneric, style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(clientsProvider(orgId)),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12),
              itemCount: clients.length,
              itemBuilder: (context, index) {
                final client = clients[index];
                return ClientListTile(
                  client: client,
                  onTap: () async {
                    final changed = await Navigator.of(context).push<bool>(
                      MaterialPageRoute(builder: (_) => ClientFormScreen(orgId: orgId, client: client)),
                    );
                    if (changed == true) ref.invalidate(clientsProvider(orgId));
                  },
                  onDelete: () => _confirmDelete(context, ref, orgId, client.id),
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await Navigator.of(context).push<bool>(
            MaterialPageRoute(builder: (_) => ClientFormScreen(orgId: orgId)),
          );
          if (created == true) ref.invalidate(clientsProvider(orgId));
        },
        icon: const Icon(Icons.add),
        label: Text('${l10n.add} $clientLabel'),
      ),
    );
  }
}
