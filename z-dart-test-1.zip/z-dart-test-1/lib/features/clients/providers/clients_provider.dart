import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/client.dart';
import '../../../api/services/client_api.dart';

/// Same style as workers_provider.dart — plain FutureProvider.family,
/// re-triggered via `ref.invalidate(clientsProvider(orgId))` after any
/// create/update/delete rather than a custom Notifier. Keeping this
/// consistent across entities matters more than either style being "better."
final clientsProvider =
    FutureProvider.family<List<Client>, String>((ref, organizationId) {
  return ClientApi.list(organizationId);
});
