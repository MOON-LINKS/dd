import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/upcoming_bill.dart';
import '../../../api/services/upcoming_bill_api.dart';

/// Same style as workers/clients/expenses providers — plain
/// FutureProvider.family, re-triggered via
/// `ref.invalidate(upcomingBillsProvider(orgId))` after create/update/
/// delete/markPaid/convertToExpense rather than a custom Notifier.
///
/// No `isPaid` filter param in the family key — this batch's list screen
/// shows everything unfiltered (same scope call as Workers/Clients/
/// Expenses), distinguishing paid/unpaid visually instead. UpcomingBillApi
/// .list already accepts `isPaid` server-side whenever a filter tab is
/// wanted later.
final upcomingBillsProvider =
    FutureProvider.family<List<UpcomingBill>, String>((ref, organizationId) {
  return UpcomingBillApi.list(organizationId);
});
