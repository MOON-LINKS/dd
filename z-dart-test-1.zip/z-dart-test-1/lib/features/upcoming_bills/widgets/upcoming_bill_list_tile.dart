import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../api/models/upcoming_bill.dart';
import '../../../l10n/app_localizations.dart';

class UpcomingBillListTile extends StatelessWidget {
  final UpcomingBill bill;
  final VoidCallback onTap;
  final VoidCallback onMarkPaid;
  final VoidCallback onConvertToExpense;
  final VoidCallback onDelete;

  const UpcomingBillListTile({
    super.key,
    required this.bill,
    required this.onTap,
    required this.onMarkPaid,
    required this.onConvertToExpense,
    required this.onDelete,
  });

  bool get _isOverdue =>
      !bill.isPaid && bill.dueDate.isBefore(DateTime.now().subtract(const Duration(days: 1)));

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;
    final currency = NumberFormat.simpleCurrency(locale: Localizations.localeOf(context).toString());
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString());
    final alreadyConverted = bill.convertedExpenseId != null;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: _isOverdue
              ? colorScheme.errorContainer
              : (bill.isPaid ? colorScheme.primaryContainer : colorScheme.surfaceContainerHighest),
          foregroundColor: _isOverdue ? colorScheme.onErrorContainer : colorScheme.onSurfaceVariant,
          child: Icon(bill.isPaid ? Icons.check_circle_outline : Icons.event_outlined),
        ),
        title: Text(bill.title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(
          '${dateFormat.format(bill.dueDate)} · '
          '${bill.isPaid ? l10n.paidStatusLabel : l10n.unpaidStatusLabel}'
          '${alreadyConverted ? ' · ${l10n.billConvertedLabel}' : ''}',
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              currency.format(bill.amount),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                switch (value) {
                  case 'markPaid':
                    onMarkPaid();
                    break;
                  case 'convert':
                    onConvertToExpense();
                    break;
                  case 'delete':
                    onDelete();
                    break;
                }
              },
              itemBuilder: (context) => [
                if (!bill.isPaid)
                  PopupMenuItem(value: 'markPaid', child: Text(l10n.markPaidAction)),
                if (!alreadyConverted)
                  PopupMenuItem(value: 'convert', child: Text(l10n.convertToExpenseAction)),
                PopupMenuItem(value: 'delete', child: Text(l10n.delete)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
