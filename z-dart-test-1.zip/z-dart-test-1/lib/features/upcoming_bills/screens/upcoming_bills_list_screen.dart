import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/api_exception.dart';
import '../../../api/services/upcoming_bill_api.dart';
import '../../../l10n/app_localizations.dart';
import '../../shell/providers/current_organization_provider.dart';
import '../providers/upcoming_bills_provider.dart';
import '../widgets/upcoming_bill_list_tile.dart';
import 'upcoming_bill_form_screen.dart';

class UpcomingBillsListScreen extends ConsumerWidget {
  const UpcomingBillsListScreen({super.key});

  Future<void> _confirmDelete(
    BuildContext context,
    WidgetRef ref,
    String orgId,
    String billId,
  ) async {
    final l10n = AppLocalizations.of(context)!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(l10n.delete),
        content: Text(l10n.confirmDeleteGeneric),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(l10n.delete),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await UpcomingBillApi.delete(orgId, billId);
      ref.invalidate(upcomingBillsProvider(orgId));
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _markPaid(BuildContext context, WidgetRef ref, String orgId, String billId) async {
    try {
      await UpcomingBillApi.markPaid(orgId, billId);
      ref.invalidate(upcomingBillsProvider(orgId));
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  /// Backend doesn't require a bill to be marked paid before it can be
  /// converted (convertBillToExpense only checks converted_expense_id is
  /// still null) — so the UI doesn't invent that ordering constraint
  /// either. Confirmed first since it creates a new record the person
  /// can't undo from here.
  Future<void> _convertToExpense(
    BuildContext context,
    WidgetRef ref,
    String orgId,
    String billId,
  ) async {
    final l10n = AppLocalizations.of(context)!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(l10n.convertConfirmTitle),
        content: Text(l10n.convertConfirmBody),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(l10n.convertToExpenseAction),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await UpcomingBillApi.convertToExpense(orgId, billId);
      ref.invalidate(upcomingBillsProvider(orgId));
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final orgId = ref.watch(currentOrganizationIdProvider);

    if (orgId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final billsAsync = ref.watch(upcomingBillsProvider(orgId));

    return Scaffold(
      body: billsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, __) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(err is ApiException ? err.message : l10n.errorGeneric),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => ref.invalidate(upcomingBillsProvider(orgId)),
                child: Text(l10n.retry),
              ),
            ],
          ),
        ),
        data: (bills) {
          if (bills.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.event_outlined, size: 40, color: Theme.of(context).colorScheme.outline),
                  const SizedBox(height: 16),
                  Text(l10n.emptyListTitleGeneric, style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(upcomingBillsProvider(orgId)),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12),
              itemCount: bills.length,
              itemBuilder: (context, index) {
                final bill = bills[index];
                return UpcomingBillListTile(
                  bill: bill,
                  onTap: () async {
                    final changed = await Navigator.of(context).push<bool>(
                      MaterialPageRoute(builder: (_) => UpcomingBillFormScreen(orgId: orgId, bill: bill)),
                    );
                    if (changed == true) ref.invalidate(upcomingBillsProvider(orgId));
                  },
                  onMarkPaid: () => _markPaid(context, ref, orgId, bill.id),
                  onConvertToExpense: () => _convertToExpense(context, ref, orgId, bill.id),
                  onDelete: () => _confirmDelete(context, ref, orgId, bill.id),
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await Navigator.of(context).push<bool>(
            MaterialPageRoute(builder: (_) => UpcomingBillFormScreen(orgId: orgId)),
          );
          if (created == true) ref.invalidate(upcomingBillsProvider(orgId));
        },
        icon: const Icon(Icons.add),
        label: Text('${l10n.add} ${l10n.upcomingBills}'),
      ),
    );
  }
}
