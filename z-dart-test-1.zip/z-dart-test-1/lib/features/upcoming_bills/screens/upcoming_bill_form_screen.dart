import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/upcoming_bill.dart';
import '../../../api/services/upcoming_bill_api.dart';
import '../../../l10n/app_localizations.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../workers/providers/workers_provider.dart';

class UpcomingBillFormScreen extends ConsumerStatefulWidget {
  final String orgId;

  /// null => create. Non-null => edit, pre-filled from this bill.
  final UpcomingBill? bill;

  const UpcomingBillFormScreen({super.key, required this.orgId, this.bill});

  bool get isEditing => bill != null;

  @override
  ConsumerState<UpcomingBillFormScreen> createState() => _UpcomingBillFormScreenState();
}

class _UpcomingBillFormScreenState extends ConsumerState<UpcomingBillFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleController;
  late final TextEditingController _amountController;
  late final TextEditingController _reminderController;
  late DateTime _dueDate;
  String? _linkedWorkerId;

  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    final bill = widget.bill;
    _titleController = TextEditingController(text: bill?.title ?? '');
    _amountController = TextEditingController(text: bill?.amount.toString() ?? '');
    _reminderController = TextEditingController(text: (bill?.reminderDaysBefore ?? 7).toString());
    _dueDate = bill?.dueDate ?? DateTime.now().add(const Duration(days: 7));
    _linkedWorkerId = bill?.linkedWorkerId;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _amountController.dispose();
    _reminderController.dispose();
    super.dispose();
  }

  Future<void> _pickDueDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _dueDate,
      firstDate: DateTime(2015),
      lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
    );
    if (picked != null) setState(() => _dueDate = picked);
  }

  Future<void> _submit() async {
    final l10n = AppLocalizations.of(context)!;
    if (!(_formKey.currentState?.validate() ?? false)) return;

    final amount = double.parse(_amountController.text.trim());
    final reminderDays = int.parse(_reminderController.text.trim());
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      if (widget.isEditing) {
        await UpcomingBillApi.update(
          widget.orgId,
          widget.bill!.id,
          title: _titleController.text.trim(),
          amount: amount,
          dueDate: _dueDate,
          reminderDaysBefore: reminderDays,
          // This form has no job-linking or proof-document UI (same
          // "belongs to a detail page / needs Jobs to exist first" scope
          // call as Worker's photo upload and Expense's linkedJobId) — pass
          // both straight through unchanged rather than omitting them,
          // since omitting is what would actually risk clearing them (see
          // UpcomingBill.toJson()'s doc comment).
          proofAssetId: widget.bill!.proofAssetId,
          linkedWorkerId: _linkedWorkerId,
          linkedJobId: widget.bill!.linkedJobId,
        );
      } else {
        await UpcomingBillApi.create(
          widget.orgId,
          title: _titleController.text.trim(),
          amount: amount,
          dueDate: _dueDate,
          reminderDaysBefore: reminderDays,
          linkedWorkerId: _linkedWorkerId,
        );
      }
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      setState(() => _errorMessage = e.message);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString());

    // Same "degrade quietly, don't block" pattern as expense_form_screen.dart
    // — linking a worker is optional, so a slow/failed worker fetch
    // shouldn't stop someone from logging a bill.
    final workers = ref.watch(workersProvider(widget.orgId)).valueOrNull ?? [];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.isEditing
              ? '${l10n.edit} ${l10n.upcomingBills}'
              : '${l10n.add} ${l10n.upcomingBills}',
        ),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    AppTextField(
                      controller: _titleController,
                      label: l10n.titleLabel,
                      validator: (value) =>
                          (value == null || value.trim().isEmpty) ? l10n.nameRequiredError : null,
                    ),
                    const SizedBox(height: 16),
                    AppTextField(
                      controller: _amountController,
                      label: l10n.amountLabel,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (value) {
                        final trimmed = value?.trim() ?? '';
                        if (trimmed.isEmpty) return l10n.amountRequiredError;
                        final parsed = double.tryParse(trimmed);
                        if (parsed == null || parsed < 0) return l10n.amountRequiredError;
                        return null;
                      },
                    ),
                    const SizedBox(height: 20),
                    Text(l10n.dueDateLabel, style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    OutlinedButton(
                      onPressed: _pickDueDate,
                      style: OutlinedButton.styleFrom(
                        alignment: Alignment.centerLeft,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      ),
                      child: Text(dateFormat.format(_dueDate)),
                    ),
                    const SizedBox(height: 16),
                    AppTextField(
                      controller: _reminderController,
                      label: l10n.reminderDaysBeforeLabel,
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        final trimmed = value?.trim() ?? '';
                        final parsed = int.tryParse(trimmed);
                        if (parsed == null || parsed < 0) return l10n.amountRequiredError;
                        return null;
                      },
                    ),
                    const SizedBox(height: 20),
                    Text(l10n.linkedWorkerOptionalLabel, style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String?>(
                      initialValue: _linkedWorkerId,
                      items: [
                        DropdownMenuItem(value: null, child: Text(l10n.noneOptionLabel)),
                        ...workers.map((w) => DropdownMenuItem(value: w.id, child: Text(w.name))),
                      ],
                      onChanged: (value) => setState(() => _linkedWorkerId = value),
                    ),
                    if (_errorMessage != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        _errorMessage!,
                        style: TextStyle(color: Theme.of(context).colorScheme.error),
                      ),
                    ],
                    const SizedBox(height: 24),
                    PrimaryButton(
                      label: l10n.save,
                      onPressed: _submit,
                      isLoading: _isLoading,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
