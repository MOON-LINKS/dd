import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../shell/providers/my_organizations_provider.dart';

/// First tab behind the shell. The org-existence check and the
/// onboarding redirect that used to live in `HomeShellScreen` now live
/// one level up in `AppShellScreen`, so by the time this screen builds
/// an organization is already known to exist — this just displays it.
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orgsAsync = ref.watch(myOrganizationsProvider);

    return orgsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (err, __) => Center(child: Text('Could not load your organization: $err')),
      data: (orgs) {
        if (orgs.isEmpty) {
          // AppShellScreen is already redirecting in this case — avoid a
          // null-pointer flash while that redirect lands.
          return const Center(child: CircularProgressIndicator());
        }
        final org = orgs.first as Map<String, dynamic>;
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                org['name'] as String? ?? '',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
            ],
          ),
        );
      },
    );
  }
}
