import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/bio_page.dart';
import '../../../api/services/bio_page_api.dart';

/// Single provider for the whole editor screen — `getBioPageEditorData`
/// already returns the draft, buttons, and feature flags together, and
/// every mutation this batch makes (draft save, logo change, button
/// add/update/delete/reorder) invalidates this one provider afterward
/// rather than trying to patch any of it in memory, same "sparse response,
/// full re-fetch" convention as Batch 9's `invoiceDetailProvider`.
final bioPageEditorDataProvider = FutureProvider.family<BioPageEditorData, String>((ref, organizationId) {
  return BioPageApi.getEditorData(organizationId);
});
