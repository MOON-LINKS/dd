import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/bio_page.dart';
import '../../../api/services/bio_page_api.dart';
import '../../../l10n/app_localizations.dart';
import '../providers/bio_page_provider.dart';

const _buttonTypes = ['call', 'link', 'social'];
const _buttonTypeIcons = {
  'call': Icons.call_outlined,
  'link': Icons.link,
  'social': Icons.star_outline,
};

/// Spec's button model: call / link / social, manually reordered
/// (`sort_order`), gated by two separate plan limits (`bio_page_max_buttons`
/// overall, `bio_page_max_social_icons` specifically for `social`-typed
/// ones) — `addBioPageButton` checks both at add-time so the "Add" control
/// here mirrors that same pair of checks to give the manager the same
/// feedback before they even try, not just a server error after.
class BioPageButtonsSection extends ConsumerStatefulWidget {
  final String orgId;
  final List<BioPageButton> buttons;
  final BioPageFeatureFlags featureFlags;

  const BioPageButtonsSection({
    super.key,
    required this.orgId,
    required this.buttons,
    required this.featureFlags,
  });

  @override
  ConsumerState<BioPageButtonsSection> createState() => _BioPageButtonsSectionState();
}

class _BioPageButtonsSectionState extends ConsumerState<BioPageButtonsSection> {
  bool _reordering = false;

  void _refresh() => ref.invalidate(bioPageEditorDataProvider(widget.orgId));

  int get _socialCount => widget.buttons.where((b) => b.buttonType == 'social').length;

  Future<void> _openButtonDialog({BioPageButton? existing}) async {
    final l10n = AppLocalizations.of(context)!;
    final labelController = TextEditingController(text: existing?.label ?? '');
    final urlController = TextEditingController(text: existing?.url ?? '');
    String buttonType = existing?.buttonType ?? 'link';
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text(existing == null ? l10n.addButtonAction : l10n.editButtonAction),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SegmentedButton<String>(
                    segments: [
                      ButtonSegment(value: 'call', label: Text(l10n.buttonTypeCall), icon: const Icon(Icons.call_outlined)),
                      ButtonSegment(value: 'link', label: Text(l10n.buttonTypeLink), icon: const Icon(Icons.link)),
                      ButtonSegment(value: 'social', label: Text(l10n.buttonTypeSocial), icon: const Icon(Icons.star_outline)),
                    ],
                    selected: {buttonType},
                    onSelectionChanged: (selection) => setDialogState(() => buttonType = selection.first),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: labelController,
                    decoration: InputDecoration(labelText: l10n.buttonLabelField),
                    validator: (v) => (v == null || v.trim().isEmpty) ? l10n.nameRequiredError : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: urlController,
                    decoration: InputDecoration(
                      labelText: buttonType == 'call' ? l10n.phoneNumberField : l10n.buttonUrlField,
                    ),
                    keyboardType: buttonType == 'call' ? TextInputType.phone : TextInputType.url,
                    validator: (v) => (v == null || v.trim().isEmpty) ? l10n.amountRequiredError : null,
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: Text(l10n.cancel)),
            TextButton(
              onPressed: () {
                if (formKey.currentState?.validate() ?? false) Navigator.of(dialogContext).pop(true);
              },
              child: Text(l10n.save),
            ),
          ],
        ),
      ),
    );
    if (result != true) return;

    try {
      if (existing == null) {
        await BioPageApi.addButton(
          widget.orgId,
          label: labelController.text.trim(),
          url: urlController.text.trim(),
          buttonType: buttonType,
        );
      } else {
        await BioPageApi.updateButton(
          widget.orgId,
          existing.id,
          label: labelController.text.trim(),
          url: urlController.text.trim(),
          buttonType: buttonType,
        );
      }
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _deleteButton(BioPageButton button) async {
    final l10n = AppLocalizations.of(context)!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        content: Text(l10n.confirmDeleteGeneric),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: Text(l10n.cancel)),
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(true), child: Text(l10n.delete)),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await BioPageApi.deleteButton(widget.orgId, button.id);
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _onReorder(int oldIndex, int newIndex) async {
    final sorted = [...widget.buttons];
    if (newIndex > oldIndex) newIndex -= 1;
    final moved = sorted.removeAt(oldIndex);
    sorted.insert(newIndex, moved);

    setState(() => _reordering = true);
    try {
      await BioPageApi.reorderButtons(widget.orgId, orderedButtonIds: sorted.map((b) => b.id).toList());
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _reordering = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final atButtonLimit = widget.buttons.length >= widget.featureFlags.maxButtons;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(l10n.buttonsTitle, style: Theme.of(context).textTheme.titleSmall),
                TextButton.icon(
                  onPressed: (atButtonLimit || _reordering) ? null : () => _openButtonDialog(),
                  icon: const Icon(Icons.add, size: 18),
                  label: Text(l10n.addButtonAction),
                ),
              ],
            ),
            Text(
              l10n.buttonsLimitHelper(widget.buttons.length, widget.featureFlags.maxButtons, _socialCount, widget.featureFlags.maxSocialIcons),
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            if (widget.buttons.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Center(child: Text(l10n.emptyListTitleGeneric)),
              )
            else
              ReorderableListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.buttons.length,
                onReorder: _reordering ? (_, __) {} : _onReorder,
                itemBuilder: (context, index) {
                  final button = widget.buttons[index];
                  return ListTile(
                    key: ValueKey(button.id),
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(_buttonTypeIcons[button.buttonType] ?? Icons.link),
                    title: Text(button.label),
                    subtitle: Text(button.url, maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit_outlined, size: 20),
                          onPressed: () => _openButtonDialog(existing: button),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline, size: 20),
                          onPressed: () => _deleteButton(button),
                        ),
                        ReorderableDragStartListener(index: index, child: const Icon(Icons.drag_handle, size: 20)),
                      ],
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
