import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../api/api_client.dart';
import '../../../api/api_exception.dart';
import '../../../api/endpoints.dart';
import '../../../api/models/bio_page.dart';
import '../../../api/services/bio_page_api.dart';
import '../../../l10n/app_localizations.dart';
import '../providers/bio_page_provider.dart';

/// Batch 13: the second half of Bio Page. Publish/unpublish toggle the
/// `is_published` flag the editor's status chip already reads; version
/// history + rollback and the "view live page" link are new surfaces on
/// top of the same `BioPage`/`BioPageVersion` data. The public renderer
/// itself (the HTML the `/bio/:slug` route serves) isn't a Flutter
/// screen — "view live page" opens it externally, same convention
/// `InvoiceDetailScreen._viewOrGeneratePdf` uses for the generated PDF.
class BioPagePublishSection extends ConsumerStatefulWidget {
  final String orgId;
  final BioPage bioPage;

  const BioPagePublishSection({super.key, required this.orgId, required this.bioPage});

  @override
  ConsumerState<BioPagePublishSection> createState() => _BioPagePublishSectionState();
}

class _BioPagePublishSectionState extends ConsumerState<BioPagePublishSection> {
  bool _busy = false;

  void _refresh() => ref.invalidate(bioPageEditorDataProvider(widget.orgId));

  Future<void> _publish() async {
    final l10n = AppLocalizations.of(context)!;
    setState(() => _busy = true);
    try {
      await BioPageApi.publish(widget.orgId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.pagePublishedMessage)));
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _unpublish() async {
    final l10n = AppLocalizations.of(context)!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        content: Text(l10n.confirmUnpublishMessage),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: Text(l10n.cancel)),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(l10n.unpublishBioPageAction),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _busy = true);
    try {
      await BioPageApi.unpublish(widget.orgId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.pageUnpublishedMessage)));
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _viewLivePage() async {
    final l10n = AppLocalizations.of(context)!;
    final uri = Uri.tryParse('${ApiClient.baseUrl}${Endpoints.publicBioPageHtml(widget.bioPage.slug)}');
    final opened = uri != null && await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.couldNotOpenLinkError)));
    }
  }

  Future<void> _openVersionHistory() async {
    await showDialog<void>(
      context: context,
      builder: (_) => _VersionHistoryDialog(
        orgId: widget.orgId,
        onRolledBack: _refresh,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final isPublished = widget.bioPage.isPublished;
    final lastRenderedAt = widget.bioPage.lastRenderedAt;
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString()).add_jm();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(l10n.publishSectionTitle, style: Theme.of(context).textTheme.titleSmall),
            if (lastRenderedAt != null) ...[
              const SizedBox(height: 4),
              Text(
                l10n.lastPublishedLabel(dateFormat.format(lastRenderedAt.toLocal())),
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton(
                  onPressed: _busy ? null : _publish,
                  child: Text(isPublished ? l10n.republishBioPageAction : l10n.publishBioPageAction),
                ),
                if (isPublished)
                  OutlinedButton(
                    onPressed: _busy ? null : _unpublish,
                    child: Text(l10n.unpublishBioPageAction),
                  ),
                if (isPublished)
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _viewLivePage,
                    icon: const Icon(Icons.open_in_new, size: 18),
                    label: Text(l10n.viewLivePageAction),
                  ),
                TextButton.icon(
                  onPressed: _busy ? null : _openVersionHistory,
                  icon: const Icon(Icons.history, size: 18),
                  label: Text(l10n.versionHistoryAction),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _VersionHistoryDialog extends StatefulWidget {
  final String orgId;
  final VoidCallback onRolledBack;

  const _VersionHistoryDialog({required this.orgId, required this.onRolledBack});

  @override
  State<_VersionHistoryDialog> createState() => _VersionHistoryDialogState();
}

class _VersionHistoryDialogState extends State<_VersionHistoryDialog> {
  late Future<List<BioPageVersion>> _future;
  int? _rollingBackVersion;

  @override
  void initState() {
    super.initState();
    _future = BioPageApi.listVersions(widget.orgId);
  }

  Future<void> _rollback(int version) async {
    final l10n = AppLocalizations.of(context)!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        content: Text(l10n.confirmRollbackMessage),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: Text(l10n.cancel)),
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(true), child: Text(l10n.rollbackAction)),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _rollingBackVersion = version);
    try {
      await BioPageApi.rollbackToVersion(widget.orgId, version);
      widget.onRolledBack();
      if (!mounted) return;
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.rolledBackMessage)));
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      setState(() => _rollingBackVersion = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString()).add_jm();
    return AlertDialog(
      title: Text(l10n.versionHistoryAction),
      content: SizedBox(
        width: 360,
        child: FutureBuilder<List<BioPageVersion>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              );
            }
            if (snapshot.hasError) {
              final err = snapshot.error;
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(err is ApiException ? err.message : l10n.errorGeneric),
                  const SizedBox(height: 12),
                  OutlinedButton(
                    onPressed: () => setState(() => _future = BioPageApi.listVersions(widget.orgId)),
                    child: Text(l10n.retry),
                  ),
                ],
              );
            }
            final versions = snapshot.data ?? const [];
            if (versions.isEmpty) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Center(child: Text(l10n.emptyListTitleGeneric)),
              );
            }
            return SizedBox(
              height: 320,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: versions.length,
                itemBuilder: (context, index) {
                  final v = versions[index];
                  final isBusy = _rollingBackVersion == v.version;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.description_outlined),
                    title: Text(l10n.versionLabel(v.version)),
                    subtitle: Text(dateFormat.format(v.createdAt.toLocal())),
                    trailing: isBusy
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                        : TextButton(
                            onPressed: _rollingBackVersion != null ? null : () => _rollback(v.version),
                            child: Text(l10n.rollbackAction),
                          ),
                  );
                },
              ),
            );
          },
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(l10n.cancel)),
      ],
    );
  }
}
