import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/bio_page.dart';
import '../../../api/services/asset_api.dart';
import '../../../api/services/bio_page_api.dart';
import '../../../core/constants/bio_page_color_presets.dart';
import '../../../core/utils/cdn.dart';
import '../../../l10n/app_localizations.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../../../shared/widgets/primary_button.dart';
import '../../shell/providers/current_organization_provider.dart';
import '../providers/bio_page_provider.dart';
import '../widgets/bio_page_buttons_section.dart';
import '../widgets/bio_page_publish_section.dart';

/// Spec: the manager builds a public bio/link-in-bio page — title, short
/// bio, a curated color theme, a logo, a reorderable set of call/link/
/// social buttons, and (as of Batch 13) publish/unpublish plus version
/// history + rollback. The public-facing HTML renderer itself lives
/// server-side (`/bio/:slug`) — this screen only links out to it.
class BioPageScreen extends ConsumerWidget {
  const BioPageScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final orgId = ref.watch(currentOrganizationIdProvider);

    // Same narrow post-gate/pre-rebuild window every other tab screen
    // guards against (see WorkersListScreen's identical comment).
    if (orgId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final editorAsync = ref.watch(bioPageEditorDataProvider(orgId));

    return editorAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (err, __) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(err is ApiException ? err.message : l10n.errorGeneric),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () => ref.invalidate(bioPageEditorDataProvider(orgId)),
              child: Text(l10n.retry),
            ),
          ],
        ),
      ),
      data: (data) => _BioPageEditor(orgId: orgId, data: data),
    );
  }
}

class _BioPageEditor extends ConsumerStatefulWidget {
  final String orgId;
  final BioPageEditorData data;

  const _BioPageEditor({required this.orgId, required this.data});

  @override
  ConsumerState<_BioPageEditor> createState() => _BioPageEditorState();
}

class _BioPageEditorState extends ConsumerState<_BioPageEditor> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _slugController;
  late TextEditingController _shortBioController;
  String? _selectedColorPreset;
  bool _initializedForBioPageId = false;
  bool _saving = false;
  bool _uploadingLogo = false;

  // Slug live-check state.
  bool? _slugAvailable;
  bool _checkingSlug = false;
  String? _lastCheckedSlug;

  // See `_LogoSection`'s doc comment — the editor GET response never
  // resolves `logo_asset_id` into a displayable filename/URL (unlike
  // `getInvoiceBranding`, which does exactly this for its own logo). This
  // caches whatever filename this session's own upload just produced, so a
  // freshly-picked logo previews immediately.
  String? _sessionLogoFilename;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController();
    _slugController = TextEditingController();
    _shortBioController = TextEditingController();
    _seedFrom(widget.data.bioPage);
  }

  void _seedFrom(BioPage bioPage) {
    _titleController.text = bioPage.title ?? '';
    _slugController.text = bioPage.slug;
    _shortBioController.text = bioPage.shortBio ?? '';
    _selectedColorPreset = bioPage.colorPreset ?? 'default';
    _initializedForBioPageId = true;
  }

  @override
  void didUpdateWidget(covariant _BioPageEditor oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Re-seed only the first time a given bio page's data arrives, same
    // "don't stomp an in-progress edit on refetch" guard Settings'
    // `_OrganizationSectionState` (Batch 10) uses.
    if (!_initializedForBioPageId || oldWidget.data.bioPage.id != widget.data.bioPage.id) {
      _seedFrom(widget.data.bioPage);
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _slugController.dispose();
    _shortBioController.dispose();
    super.dispose();
  }

  void _refresh() => ref.invalidate(bioPageEditorDataProvider(widget.orgId));

  Future<void> _checkSlug(String slug) async {
    if (slug == widget.data.bioPage.slug) {
      setState(() {
        _slugAvailable = true;
        _lastCheckedSlug = slug;
      });
      return;
    }
    setState(() => _checkingSlug = true);
    try {
      final available = await BioPageApi.checkSlugAvailability(slug, excludeOrganizationId: widget.orgId);
      if (!mounted) return;
      setState(() {
        _slugAvailable = available;
        _lastCheckedSlug = slug;
      });
    } on ApiException {
      // Live-check failing isn't worth surfacing as an error — the real
      // validation happens again server-side on save regardless.
    } finally {
      if (mounted) setState(() => _checkingSlug = false);
    }
  }

  Future<void> _saveDraft() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final l10n = AppLocalizations.of(context)!;
    setState(() => _saving = true);
    try {
      await BioPageApi.updateDraft(
        widget.orgId,
        title: _titleController.text.trim(),
        shortBio: _shortBioController.text.trim(),
        colorPreset: _selectedColorPreset,
        slug: _slugController.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.savedMessage)));
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _pickAndUploadLogo() async {
    final l10n = AppLocalizations.of(context)!;
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked == null) return;

    setState(() => _uploadingLogo = true);
    final previousAssetId = widget.data.bioPage.logoAssetId;
    try {
      final Uint8List bytes = await picked.readAsBytes();
      final uploaded = await AssetApi.upload(
        bytes: bytes,
        fileName: picked.name,
        assetType: 'bio_page',
        ownerType: 'bio_page',
        ownerId: widget.data.bioPage.id,
      );
      await BioPageApi.updateLogo(widget.orgId, assetId: uploaded['assetId']);
      _sessionLogoFilename = uploaded['filename'];

      // Best-effort cleanup of the old logo file — failure here doesn't
      // block anything the manager cares about (the new logo is already
      // live), so it's not surfaced as an error.
      if (previousAssetId != null) {
        AssetApi.delete(previousAssetId).catchError((_) {});
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.savedMessage)));
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _uploadingLogo = false);
    }
  }

  Future<void> _removeLogo() async {
    final currentAssetId = widget.data.bioPage.logoAssetId;
    if (currentAssetId == null) return;
    setState(() => _uploadingLogo = true);
    try {
      await BioPageApi.updateLogo(widget.orgId, assetId: null);
      await AssetApi.delete(currentAssetId).catchError((_) {});
      _sessionLogoFilename = null;
      if (!mounted) return;
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _uploadingLogo = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final bioPage = widget.data.bioPage;
    final slug = _slugController.text.trim();
    final slugLooksClean = slug != _lastCheckedSlug ? null : _slugAvailable;

    return Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Chip(
                avatar: Icon(
                  bioPage.isPublished ? Icons.public : Icons.edit_note,
                  size: 16,
                  color: bioPage.isPublished ? Colors.white : null,
                ),
                label: Text(bioPage.isPublished ? l10n.publishedStatusLabel : l10n.draftStatusLabel),
                backgroundColor: bioPage.isPublished ? Colors.green : null,
                labelStyle: bioPage.isPublished ? const TextStyle(color: Colors.white) : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  '/${bioPage.slug}',
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
              IconButton(
                tooltip: l10n.copyAssignmentAction,
                icon: const Icon(Icons.copy_outlined, size: 18),
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: bioPage.slug));
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.copiedToClipboardMessage)));
                },
              ),
            ],
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(l10n.basicInfoTitle, style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 12),
                  AppTextField(controller: _titleController, label: l10n.bioPageTitleLabel),
                  const SizedBox(height: 12),
                  AppTextField(
                    controller: _slugController,
                    label: l10n.bioPageSlugLabel,
                    helperText: _checkingSlug
                        ? l10n.checkingSlugMessage
                        : slugLooksClean == false
                            ? l10n.slugTakenError
                            : l10n.bioPageSlugHelper,
                    onChanged: (value) {
                      final trimmed = value.trim().toLowerCase();
                      Future.delayed(const Duration(milliseconds: 500), () {
                        if (!mounted || _slugController.text.trim().toLowerCase() != trimmed) return;
                        _checkSlug(trimmed);
                      });
                    },
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) return l10n.nameRequiredError;
                      if (slugLooksClean == false) return l10n.slugTakenError;
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  AppTextField(
                    controller: _shortBioController,
                    label: l10n.bioPageShortBioLabel,
                    isOptional: true,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(l10n.appearanceTitle, style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      for (final preset in bioPageColorPresets)
                        _ColorPresetSwatch(
                          preset: preset,
                          selected: preset.key == _selectedColorPreset,
                          onTap: () => setState(() => _selectedColorPreset = preset.key),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          _LogoSection(
            bioPage: bioPage,
            sessionLogoFilename: _sessionLogoFilename,
            uploading: _uploadingLogo,
            onPick: _pickAndUploadLogo,
            onRemove: _removeLogo,
          ),
          const SizedBox(height: 16),
          PrimaryButton(label: l10n.save, onPressed: _saveDraft, isLoading: _saving),
          const SizedBox(height: 24),
          BioPageButtonsSection(orgId: widget.orgId, buttons: widget.data.buttons, featureFlags: widget.data.featureFlags),
          const SizedBox(height: 24),
          BioPagePublishSection(orgId: widget.orgId, bioPage: bioPage),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _ColorPresetSwatch extends StatelessWidget {
  final BioPageColorPreset preset;
  final bool selected;
  final VoidCallback onTap;

  const _ColorPresetSwatch({required this.preset, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 76,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outlineVariant,
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Container(
              height: 36,
              decoration: BoxDecoration(
                color: preset.background,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.black12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(width: 10, height: 10, margin: const EdgeInsets.symmetric(horizontal: 2), decoration: BoxDecoration(color: preset.primary, shape: BoxShape.circle)),
                  Container(width: 10, height: 10, margin: const EdgeInsets.symmetric(horizontal: 2), decoration: BoxDecoration(color: preset.secondary, shape: BoxShape.circle)),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Text(preset.label, style: Theme.of(context).textTheme.bodySmall, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

/// `getBioPageEditorData` returns `logo_asset_id` (a bare UUID) but never
/// resolves it into a filename/URL the way `getInvoiceBranding` does for
/// its own logo (`invoiceBrandingController.js` joins `assets` and returns
/// `logoUrl` directly) — an asymmetry between two structurally identical
/// features, not a deliberate design difference. There's also no
/// `GET /assets/:id` endpoint to resolve one on demand client-side.
///
/// Net effect: a logo picked *this session* previews correctly
/// (`sessionLogoFilename`, set the moment `AssetApi.upload()` returns —
/// that response already includes the filename, no extra round trip
/// needed). A logo set in a *previous* session has no filename available
/// to build a preview URL from at all, so this falls back to a plain
/// "logo saved" placeholder rather than a broken `Image.network` — no
/// amount of client-side cleverness fixes a value the API never sends.
/// Worth fixing backend-side (mirror `getInvoiceBranding`'s join) before
/// the next batch needs the same pattern for worker profile pictures.
class _LogoSection extends StatelessWidget {
  final BioPage bioPage;
  final String? sessionLogoFilename;
  final bool uploading;
  final VoidCallback onPick;
  final VoidCallback onRemove;

  const _LogoSection({
    required this.bioPage,
    required this.sessionLogoFilename,
    required this.uploading,
    required this.onPick,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final previewUrl = resolveAssetUrl(sessionLogoFilename);
    final hasUnresolvableLogo = bioPage.logoAssetId != null && previewUrl == null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(l10n.logoTitle, style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 12),
            Row(
              children: [
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: previewUrl != null
                      ? Image.network(previewUrl, fit: BoxFit.cover)
                      : Icon(
                          hasUnresolvableLogo ? Icons.image_outlined : Icons.add_a_photo_outlined,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (hasUnresolvableLogo)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(l10n.logoSavedNoPreviewMessage, style: Theme.of(context).textTheme.bodySmall),
                        ),
                      Wrap(
                        spacing: 8,
                        children: [
                          OutlinedButton(
                            onPressed: uploading ? null : onPick,
                            child: Text(bioPage.logoAssetId == null ? l10n.uploadLogoAction : l10n.replaceLogoAction),
                          ),
                          if (bioPage.logoAssetId != null)
                            TextButton(
                              onPressed: uploading ? null : onRemove,
                              child: Text(l10n.removeLogoAction),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (uploading) const Padding(padding: EdgeInsets.only(left: 8), child: CircularProgressIndicator(strokeWidth: 2)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
