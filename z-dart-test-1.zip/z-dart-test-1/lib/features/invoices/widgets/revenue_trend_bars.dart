import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../api/models/invoice.dart';

/// A `Row` of proportionally-sized bars, not a real charting package.
/// `pubspec.yaml` has no chart dependency (`fl_chart` or similar)
/// anywhere in this project, and adding one is a real decision — a new
/// package, new transitive deps, a version to pin — not something to fold
/// into this batch as a side effect of one screen. Same call
/// `InvoiceDesignScreen` already made choosing a plain hex `TextFormField`
/// over a color-picker package for two fields (Batch 14) — this is that
/// same reasoning applied to the trend chart instead. Gets "revenue over
/// time, visually" on screen correctly today; swapping in a real charting
/// package later only touches this one file.
class RevenueTrendBars extends StatelessWidget {
  final List<InvoiceRevenueTrendPoint> points;

  const RevenueTrendBars({super.key, required this.points});

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) return const SizedBox.shrink();
    final colorScheme = Theme.of(context).colorScheme;
    final currency = NumberFormat.simpleCurrency(locale: Localizations.localeOf(context).toString());
    final monthFormat = DateFormat.MMM(Localizations.localeOf(context).toString());
    final maxRevenue = points.map((p) => p.revenue).fold<double>(0, (a, b) => a > b ? a : b);

    return SizedBox(
      height: 170,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (final point in points)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      currency.format(point.revenue),
                      style: Theme.of(context).textTheme.labelSmall,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Container(
                      height: maxRevenue <= 0 ? 4 : (120 * (point.revenue / maxRevenue)).clamp(4, 120),
                      decoration: BoxDecoration(
                        color: colorScheme.primary,
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(monthFormat.format(point.month), style: Theme.of(context).textTheme.labelSmall),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
