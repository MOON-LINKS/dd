import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../api/models/invoice.dart';
import '../../../l10n/app_localizations.dart';

class InvoiceListTile extends StatelessWidget {
  final Invoice invoice;
  final VoidCallback onTap;

  const InvoiceListTile({super.key, required this.invoice, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;
    final locale = Localizations.localeOf(context).toString();
    final currency = NumberFormat.simpleCurrency(locale: locale);
    final dateFormat = DateFormat.yMMMd(locale);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: invoice.isPaidInFull
              ? colorScheme.primaryContainer
              : colorScheme.surfaceContainerHighest,
          foregroundColor: colorScheme.onSurfaceVariant,
          child: Icon(invoice.isPaidInFull ? Icons.check_circle_outline : Icons.receipt_long_outlined),
        ),
        title: Text(
          invoice.clientName ?? l10n.noneOptionLabel,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          '${dateFormat.format(invoice.periodStart)} – ${dateFormat.format(invoice.periodEnd)} · '
          '${invoice.hasBeenSent ? l10n.invoiceSentLabel : l10n.invoiceNotSentLabel}',
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(currency.format(invoice.totalAmount), style: const TextStyle(fontWeight: FontWeight.w700)),
            if (!invoice.isPaidInFull)
              Text(
                currency.format(invoice.amountOwed),
                style: TextStyle(fontSize: 12, color: colorScheme.error),
              ),
          ],
        ),
      ),
    );
  }
}
