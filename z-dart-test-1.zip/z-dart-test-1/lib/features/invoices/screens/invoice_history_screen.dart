import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../api/api_exception.dart';
import '../../../l10n/app_localizations.dart';
import '../providers/invoice_history_log_provider.dart';

/// Batch 15: the last of Billing & Invoices' unbuilt tabs besides
/// Analytics. Same "own screen, pushed via Navigator, no real tab bar"
/// call Batch 14 made for Design — see that batch's notes for why.
class InvoiceHistoryScreen extends ConsumerWidget {
  final String orgId;

  const InvoiceHistoryScreen({super.key, required this.orgId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final historyAsync = ref.watch(invoiceHistoryLogProvider(orgId));
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString()).add_jm();

    return Scaffold(
      appBar: AppBar(title: Text(l10n.invoiceHistoryTitle)),
      body: historyAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, __) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(err is ApiException ? err.message : l10n.errorGeneric),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => ref.invalidate(invoiceHistoryLogProvider(orgId)),
                child: Text(l10n.retry),
              ),
            ],
          ),
        ),
        data: (entries) {
          if (entries.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.mark_email_read_outlined, size: 40, color: Theme.of(context).colorScheme.outline),
                  const SizedBox(height: 16),
                  Text(l10n.emptyListTitleGeneric, style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(invoiceHistoryLogProvider(orgId)),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12),
              itemCount: entries.length,
              itemBuilder: (context, index) {
                final entry = entries[index];
                final failed = entry.status?.toLowerCase() == 'failed';
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: ListTile(
                    leading: Icon(
                      failed ? Icons.error_outline : Icons.mark_email_read_outlined,
                      color: failed ? Theme.of(context).colorScheme.error : Theme.of(context).colorScheme.tertiary,
                    ),
                    title: Text(entry.emailType),
                    subtitle: Text([
                      if (entry.recipientEmail != null) entry.recipientEmail!,
                      dateFormat.format(entry.createdAt.toLocal()),
                    ].join(' · ')),
                    trailing: entry.status != null ? Text(entry.status!) : null,
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
