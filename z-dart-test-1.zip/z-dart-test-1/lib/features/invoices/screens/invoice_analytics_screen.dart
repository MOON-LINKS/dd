import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../api/api_exception.dart';
import '../../../l10n/app_localizations.dart';
import '../providers/invoice_analytics_provider.dart';
import '../widgets/revenue_trend_bars.dart';

/// Batch 16 — the last unbuilt piece of Billing & Invoices. Section 3
/// calls the Invoices/analytics view "the main tab" of the three (Invoices,
/// Design, History); Design (Batch 14) and History (Batch 15) are both
/// already pushed screens rather than real `TabBar` tabs (see Batch 14's
/// "Not a tab bar" note for why), so this follows the identical shape —
/// its own `Scaffold`, pushed from a third header button on
/// `InvoicesListScreen`, not a fourth tab bolted onto something that was
/// never a tab bar to begin with.
class InvoiceAnalyticsScreen extends ConsumerWidget {
  final String orgId;

  const InvoiceAnalyticsScreen({super.key, required this.orgId});

  Future<void> _pickDate(BuildContext context, WidgetRef ref, {required bool isStart}) async {
    final range = ref.read(invoiceAnalyticsRangeProvider(orgId));
    final picked = await showDatePicker(
      context: context,
      initialDate: isStart ? range.start : range.end,
      firstDate: DateTime(2015),
      lastDate: DateTime.now(),
    );
    if (picked == null) return;
    final newRange = isStart
        ? DateTimeRange(start: picked, end: range.end.isBefore(picked) ? picked : range.end)
        : DateTimeRange(start: range.start.isAfter(picked) ? picked : range.start, end: picked);
    ref.read(invoiceAnalyticsRangeProvider(orgId).notifier).state = newRange;
  }

  void _selectThisMonth(WidgetRef ref) {
    final now = DateTime.now();
    ref.read(invoiceAnalyticsRangeProvider(orgId).notifier).state =
        DateTimeRange(start: DateTime(now.year, now.month, 1), end: now);
  }

  void _selectLastMonth(WidgetRef ref) {
    final now = DateTime.now();
    final firstOfThisMonth = DateTime(now.year, now.month, 1);
    final lastMonthEnd = firstOfThisMonth.subtract(const Duration(days: 1));
    final lastMonthStart = DateTime(lastMonthEnd.year, lastMonthEnd.month, 1);
    ref.read(invoiceAnalyticsRangeProvider(orgId).notifier).state =
        DateTimeRange(start: lastMonthStart, end: lastMonthEnd);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final dateFormat = DateFormat.yMMMd(Localizations.localeOf(context).toString());
    final currency = NumberFormat.simpleCurrency(locale: Localizations.localeOf(context).toString());
    final range = ref.watch(invoiceAnalyticsRangeProvider(orgId));
    final analyticsAsync = ref.watch(
      invoiceAnalyticsProvider((organizationId: orgId, start: range.start, end: range.end)),
    );

    return Scaffold(
      appBar: AppBar(title: Text(l10n.invoiceAnalyticsTitle)),
      body: RefreshIndicator(
        onRefresh: () async => ref
            .invalidate(invoiceAnalyticsProvider((organizationId: orgId, start: range.start, end: range.end))),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                OutlinedButton(
                  onPressed: () => _pickDate(context, ref, isStart: true),
                  child: Text('${l10n.fromDateLabel}: ${dateFormat.format(range.start)}'),
                ),
                OutlinedButton(
                  onPressed: () => _pickDate(context, ref, isStart: false),
                  child: Text('${l10n.toDateLabel}: ${dateFormat.format(range.end)}'),
                ),
                TextButton(onPressed: () => _selectThisMonth(ref), child: Text(l10n.thisMonthLabel)),
                TextButton(onPressed: () => _selectLastMonth(ref), child: Text(l10n.lastMonthLabel)),
              ],
            ),
            const SizedBox(height: 16),
            analyticsAsync.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 48),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (err, __) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Column(
                  children: [
                    Text(err is ApiException ? err.message : l10n.errorGeneric, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      onPressed: () => ref.invalidate(
                          invoiceAnalyticsProvider((organizationId: orgId, start: range.start, end: range.end))),
                      child: Text(l10n.retry),
                    ),
                  ],
                ),
              ),
              data: (analytics) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: _StatCard(label: l10n.amountPaidLabel, value: currency.format(analytics.totalPaid)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _StatCard(label: l10n.amountOwedLabel, value: currency.format(analytics.totalOwed)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: _StatCard(
                            label: l10n.hoursLoggedLabel,
                            value: '${analytics.hoursLogged.toStringAsFixed(1)} ${l10n.hoursUnitSuffix}',
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _StatCard(
                            label: l10n.hoursBilledLabel,
                            value: '${analytics.hoursBilled.toStringAsFixed(1)} ${l10n.hoursUnitSuffix}',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Text(l10n.revenueLabel, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    if (analytics.revenueTrend.isEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Text(l10n.noDataForRangeLabel),
                      )
                    else
                      RevenueTrendBars(points: analytics.revenueTrend),
                    const SizedBox(height: 24),
                    if (analytics.byClient.isNotEmpty) ...[
                      Text(l10n.byClientLabel, style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Card(
                        child: Column(
                          children: [
                            for (final client in analytics.byClient)
                              ListTile(
                                dense: true,
                                title: Text(client.clientName ?? l10n.noneOptionLabel),
                                subtitle: Text(
                                  '${client.totalHours.toStringAsFixed(1)} ${l10n.hoursUnitSuffix} \u00b7 '
                                  '${l10n.amountOwedLabel}: ${currency.format(client.amountOwed)}',
                                ),
                                trailing: Text(
                                  currency.format(client.totalAmount),
                                  style: const TextStyle(fontWeight: FontWeight.w700),
                                ),
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                    if (analytics.byJob.isNotEmpty) ...[
                      Text(l10n.byJobLabel, style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Card(
                        child: Column(
                          children: [
                            for (final job in analytics.byJob)
                              Builder(builder: (context) {
                                // Read into a local first — flow-analysis
                                // promotion of a `double?` after a null check
                                // isn't reliable across a property access
                                // (`job.totalAmount`) the way it is for a plain
                                // local variable, so this avoids leaning on it.
                                final amount = job.totalAmount;
                                return ListTile(
                                  dense: true,
                                  title: Text(job.jobTitle ?? l10n.noneOptionLabel),
                                  subtitle: Text('${job.totalHours.toStringAsFixed(1)} ${l10n.hoursUnitSuffix}'),
                                  // `amount == null` means every hour on this
                                  // job belongs to a salaried worker —
                                  // genuinely "not billable," not "billed at
                                  // $0." See `InvoiceAnalyticsByJob`'s doc
                                  // comment.
                                  trailing: Text(
                                    amount != null ? currency.format(amount) : l10n.noneOptionLabel,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      color: amount == null ? Theme.of(context).colorScheme.outline : null,
                                    ),
                                  ),
                                );
                              }),
                          ],
                        ),
                      ),
                    ],
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;

  const _StatCard({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: Theme.of(context).textTheme.labelMedium),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.headlineSmall),
          ],
        ),
      ),
    );
  }
}
