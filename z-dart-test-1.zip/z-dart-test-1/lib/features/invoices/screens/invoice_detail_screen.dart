import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../api/api_exception.dart';
import '../../../api/services/invoice_api.dart';
import '../../../l10n/app_localizations.dart';
import '../providers/invoice_detail_provider.dart';
import '../providers/invoices_provider.dart';

class InvoiceDetailScreen extends ConsumerStatefulWidget {
  final String orgId;
  final String invoiceId;

  const InvoiceDetailScreen({super.key, required this.orgId, required this.invoiceId});

  @override
  ConsumerState<InvoiceDetailScreen> createState() => _InvoiceDetailScreenState();
}

class _InvoiceDetailScreenState extends ConsumerState<InvoiceDetailScreen> {
  bool _isBusy = false;

  ({String orgId, String invoiceId}) get _key =>
      (orgId: widget.orgId, invoiceId: widget.invoiceId);

  void _refresh() {
    ref.invalidate(invoiceDetailProvider(_key));
    ref.invalidate(invoicesProvider(widget.orgId));
  }

  Future<void> _recordPayment(double currentAmountPaid) async {
    final l10n = AppLocalizations.of(context)!;
    final controller = TextEditingController(text: currentAmountPaid.toString());

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(l10n.recordPaymentAction),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: l10n.amountPaidLabel),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(l10n.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(l10n.save),
          ),
        ],
      ),
    );
    final enteredText = controller.text.trim();
    controller.dispose();
    if (confirmed != true) return;

    final amount = double.tryParse(enteredText);
    if (amount == null || amount < 0) return;

    setState(() => _isBusy = true);
    try {
      await InvoiceApi.recordPayment(widget.orgId, widget.invoiceId, amountPaid: amount);
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isBusy = false);
    }
  }

  Future<void> _viewOrGeneratePdf() async {
    final l10n = AppLocalizations.of(context)!;
    setState(() => _isBusy = true);
    try {
      // generatePdf always (re)builds the PDF — simpler than tracking
      // whether the existing one is stale (e.g. after a payment was
      // recorded since it was last generated), and the backend already
      // does this same "build if needed" step internally for send/resend.
      final pdfUrl = await InvoiceApi.generatePdf(widget.orgId, widget.invoiceId);
      final uri = Uri.tryParse(pdfUrl);
      final opened = uri != null && await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.couldNotOpenPdfError)));
      }
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isBusy = false);
    }
  }

  Future<void> _sendOrResend(bool alreadySent) async {
    setState(() => _isBusy = true);
    try {
      if (alreadySent) {
        await InvoiceApi.resendEmail(widget.orgId, widget.invoiceId);
      } else {
        await InvoiceApi.sendEmail(widget.orgId, widget.invoiceId);
      }
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _isBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final detailAsync = ref.watch(invoiceDetailProvider(_key));
    final locale = Localizations.localeOf(context).toString();
    final currency = NumberFormat.simpleCurrency(locale: locale);
    final dateFormat = DateFormat.yMMMd(locale);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.billingAndInvoices)),
      body: detailAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, __) => Center(child: Text(err is ApiException ? err.message : l10n.errorGeneric)),
        data: (detail) {
          final invoice = detail.invoice;
          return AbsorbPointer(
            absorbing: _isBusy,
            child: Opacity(
              opacity: _isBusy ? 0.6 : 1,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    invoice.clientName ?? l10n.noneOptionLabel,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${l10n.periodLabel}: ${dateFormat.format(invoice.periodStart)} – ${dateFormat.format(invoice.periodEnd)}',
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _summaryRow(l10n.totalAmountLabel, currency.format(invoice.totalAmount)),
                          _summaryRow(l10n.amountPaidLabel, currency.format(invoice.amountPaid)),
                          _summaryRow(
                            l10n.amountOwedLabel,
                            currency.format(invoice.amountOwed),
                            emphasize: !invoice.isPaidInFull,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () => _recordPayment(invoice.amountPaid),
                        icon: const Icon(Icons.payments_outlined),
                        label: Text(l10n.recordPaymentAction),
                      ),
                      OutlinedButton.icon(
                        onPressed: () => _viewOrGeneratePdf(),
                        icon: const Icon(Icons.picture_as_pdf_outlined),
                        label: Text(l10n.viewPdfAction),
                      ),
                      OutlinedButton.icon(
                        onPressed: () => _sendOrResend(invoice.hasBeenSent),
                        icon: const Icon(Icons.send_outlined),
                        label: Text(invoice.hasBeenSent ? l10n.resendInvoiceAction : l10n.sendInvoiceAction),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Text(l10n.lineItemsLabel, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  ...detail.lineItems.map(
                    (item) => Card(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      child: ListTile(
                        title: Text(item.description),
                        subtitle: Text([
                          if (item.workerName != null) item.workerName!,
                          if (item.jobTitle != null) item.jobTitle!,
                          if (item.hours != null) '${item.hours} ${l10n.hoursUnitSuffix}',
                        ].join(' · ')),
                        trailing: Text(currency.format(item.amount)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool emphasize = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            value,
            style: TextStyle(
              fontWeight: emphasize ? FontWeight.w700 : FontWeight.w500,
              color: emphasize ? Theme.of(context).colorScheme.error : null,
            ),
          ),
        ],
      ),
    );
  }
}
