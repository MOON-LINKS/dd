import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/api_exception.dart';
import '../../../api/services/invoice_api.dart';
import '../../../l10n/app_localizations.dart';
import '../../shell/providers/current_organization_provider.dart';
import '../providers/invoices_provider.dart';
import '../widgets/invoice_list_tile.dart';
import 'invoice_analytics_screen.dart';
import 'invoice_design_screen.dart';
import 'invoice_detail_screen.dart';
import 'invoice_history_screen.dart';

class InvoicesListScreen extends ConsumerWidget {
  const InvoicesListScreen({super.key});

  Future<void> _generateInvoices(BuildContext context, WidgetRef ref, String orgId) async {
    final l10n = AppLocalizations.of(context)!;
    DateTime? periodStart;
    DateTime? periodEnd;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setState) => AlertDialog(
          title: Text(l10n.generateInvoicesAction),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(l10n.generateInvoicesDialogBody),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () async {
                  final picked = await showDatePicker(
                    context: dialogContext,
                    initialDate: periodStart ?? DateTime.now(),
                    firstDate: DateTime(2015),
                    lastDate: DateTime.now(),
                  );
                  if (picked != null) setState(() => periodStart = picked);
                },
                child: Text(
                  periodStart == null
                      ? l10n.periodStartOptionalLabel
                      : periodStart!.toIso8601String().split('T').first,
                ),
              ),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () async {
                  final picked = await showDatePicker(
                    context: dialogContext,
                    initialDate: periodEnd ?? DateTime.now(),
                    firstDate: DateTime(2015),
                    lastDate: DateTime.now(),
                  );
                  if (picked != null) setState(() => periodEnd = picked);
                },
                child: Text(
                  periodEnd == null
                      ? l10n.periodEndOptionalLabel
                      : periodEnd!.toIso8601String().split('T').first,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: Text(l10n.cancel),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(l10n.generateInvoicesAction),
            ),
          ],
        ),
      ),
    );
    if (confirmed != true) return;

    try {
      final result = await InvoiceApi.generateNow(
        orgId,
        periodStart: periodStart,
        periodEnd: periodEnd,
      );
      ref.invalidate(invoicesProvider(orgId));
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.message)));
    } on ApiException catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final orgId = ref.watch(currentOrganizationIdProvider);

    if (orgId == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final invoicesAsync = ref.watch(invoicesProvider(orgId));

    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            // `Wrap`, not `Row` — this held 2 buttons before this batch,
            // which already fit tightly on a narrow phone width; adding
            // this batch's third (Analytics) button pushed it over into
            // real overflow-on-mobile territory. `Wrap` drops the third
            // button to its own line on a narrow screen instead of
            // clipping/erroring.
            child: Wrap(
              alignment: WrapAlignment.end,
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => InvoiceAnalyticsScreen(orgId: orgId)),
                  ),
                  icon: const Icon(Icons.insights_outlined, size: 18),
                  label: Text(l10n.invoiceAnalyticsAction),
                ),
                OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => InvoiceHistoryScreen(orgId: orgId)),
                  ),
                  icon: const Icon(Icons.history, size: 18),
                  label: Text(l10n.invoiceHistoryAction),
                ),
                OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => InvoiceDesignScreen(orgId: orgId)),
                  ),
                  icon: const Icon(Icons.palette_outlined, size: 18),
                  label: Text(l10n.invoiceDesignAction),
                ),
              ],
            ),
          ),
          Expanded(
            child: invoicesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, __) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(err is ApiException ? err.message : l10n.errorGeneric),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => ref.invalidate(invoicesProvider(orgId)),
                child: Text(l10n.retry),
              ),
            ],
          ),
        ),
        data: (invoices) {
          if (invoices.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.receipt_long_outlined, size: 40, color: Theme.of(context).colorScheme.outline),
                  const SizedBox(height: 16),
                  Text(l10n.emptyListTitleGeneric, style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(invoicesProvider(orgId)),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12),
              itemCount: invoices.length,
              itemBuilder: (context, index) {
                final invoice = invoices[index];
                return InvoiceListTile(
                  invoice: invoice,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => InvoiceDetailScreen(orgId: orgId, invoiceId: invoice.id),
                    ),
                  ),
                );
              },
            ),
          );
        },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _generateInvoices(context, ref, orgId),
        icon: const Icon(Icons.add),
        label: Text(l10n.generateInvoicesAction),
      ),
    );
  }
}
