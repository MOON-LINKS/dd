import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../../api/api_exception.dart';
import '../../../api/models/invoice.dart';
import '../../../api/services/asset_api.dart';
import '../../../api/services/invoice_api.dart';
import '../../../l10n/app_localizations.dart';
import '../providers/invoice_branding_provider.dart';

/// Batch 14: the Design tab Batch 9 deliberately left for a follow-up —
/// primary/secondary brand colors plus a logo, applied to generated
/// invoice PDFs. Pushed from `InvoicesListScreen` as its own screen
/// (Navigator.push, own `Scaffold`/`AppBar`) rather than a real tab bar,
/// same "smallest useful slice" call Batch 4 made for Worker detail —
/// a `TabBar` here would mean restructuring `InvoicesListScreen`'s shell
/// placement for a feature that's otherwise self-contained.
///
/// No color-picker package in this project (checked `pubspec.yaml`) —
/// colors are entered as a 6-digit hex code with a live swatch preview
/// rather than adding a new dependency for one field pair.
class InvoiceDesignScreen extends ConsumerStatefulWidget {
  final String orgId;

  const InvoiceDesignScreen({super.key, required this.orgId});

  @override
  ConsumerState<InvoiceDesignScreen> createState() => _InvoiceDesignScreenState();
}

class _InvoiceDesignScreenState extends ConsumerState<InvoiceDesignScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _primaryController;
  late TextEditingController _secondaryController;
  bool _initialized = false;
  bool _saving = false;
  bool _uploadingLogo = false;

  static final _hexPattern = RegExp(r'^#?[0-9A-Fa-f]{6}$');

  @override
  void initState() {
    super.initState();
    _primaryController = TextEditingController();
    _secondaryController = TextEditingController();
  }

  @override
  void dispose() {
    _primaryController.dispose();
    _secondaryController.dispose();
    super.dispose();
  }

  void _seedFrom(InvoiceBranding branding) {
    _primaryController.text = (branding.primaryColor ?? '').replaceFirst('#', '');
    _secondaryController.text = (branding.secondaryColor ?? '').replaceFirst('#', '');
    _initialized = true;
  }

  void _refresh() => ref.invalidate(invoiceBrandingProvider(widget.orgId));

  Color? _parseColor(String hex) {
    final cleaned = hex.replaceFirst('#', '');
    if (!_hexPattern.hasMatch(hex)) return null;
    return Color(int.parse('FF$cleaned', radix: 16));
  }

  Future<void> _save(String? currentLogoAssetId) async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final l10n = AppLocalizations.of(context)!;
    setState(() => _saving = true);
    try {
      await InvoiceApi.updateBranding(
        widget.orgId,
        primaryColor: _primaryController.text.trim(),
        secondaryColor: _secondaryController.text.trim(),
        logoAssetId: currentLogoAssetId,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.savedMessage)));
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _pickAndUploadLogo(String? previousAssetId) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked == null) return;

    final l10n = AppLocalizations.of(context)!;
    setState(() => _uploadingLogo = true);
    try {
      final Uint8List bytes = await picked.readAsBytes();
      final uploaded = await AssetApi.upload(
        bytes: bytes,
        fileName: picked.name,
        assetType: 'logo',
        ownerType: 'organization',
        ownerId: widget.orgId,
      );
      await InvoiceApi.updateBranding(widget.orgId, logoAssetId: uploaded['assetId']);

      if (previousAssetId != null) {
        AssetApi.delete(previousAssetId).catchError((_) {});
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.savedMessage)));
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _uploadingLogo = false);
    }
  }

  Future<void> _removeLogo(String? currentAssetId) async {
    if (currentAssetId == null) return;
    setState(() => _uploadingLogo = true);
    try {
      await InvoiceApi.updateBranding(widget.orgId, logoAssetId: null);
      await AssetApi.delete(currentAssetId).catchError((_) {});
      if (!mounted) return;
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _uploadingLogo = false);
    }
  }

  Widget _colorField({
    required TextEditingController controller,
    required String label,
  }) {
    final l10n = AppLocalizations.of(context)!;
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        helperText: l10n.colorHexHelper,
        prefixText: '#',
        suffixIcon: Padding(
          padding: const EdgeInsets.all(10),
          child: Container(
            width: 20,
            decoration: BoxDecoration(
              color: _parseColor(controller.text) ?? Colors.transparent,
              shape: BoxShape.circle,
              border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
            ),
          ),
        ),
        border: const OutlineInputBorder(),
      ),
      onChanged: (_) => setState(() {}),
      validator: (v) {
        if (v == null || v.trim().isEmpty) return null;
        return _hexPattern.hasMatch(v.trim()) ? null : l10n.invalidColorError;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final brandingAsync = ref.watch(invoiceBrandingProvider(widget.orgId));

    return Scaffold(
      appBar: AppBar(title: Text(l10n.invoiceDesignTitle)),
      body: brandingAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, __) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(err is ApiException ? err.message : l10n.errorGeneric),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => ref.invalidate(invoiceBrandingProvider(widget.orgId)),
                child: Text(l10n.retry),
              ),
            ],
          ),
        ),
        data: (branding) {
          if (!_initialized) _seedFrom(branding);

          return Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l10n.colorsTitle, style: Theme.of(context).textTheme.titleSmall),
                        const SizedBox(height: 12),
                        _colorField(controller: _primaryController, label: l10n.primaryColorLabel),
                        const SizedBox(height: 12),
                        _colorField(controller: _secondaryController, label: l10n.secondaryColorLabel),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l10n.logoTitle, style: Theme.of(context).textTheme.titleSmall),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Container(
                              width: 72,
                              height: 72,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                              ),
                              clipBehavior: Clip.antiAlias,
                              child: branding.logoUrl != null
                                  ? Image.network(branding.logoUrl!, fit: BoxFit.cover)
                                  : Icon(Icons.add_a_photo_outlined, color: Theme.of(context).colorScheme.onSurfaceVariant),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Wrap(
                                spacing: 8,
                                children: [
                                  OutlinedButton(
                                    onPressed: _uploadingLogo ? null : () => _pickAndUploadLogo(branding.logoAssetId),
                                    child: Text(branding.logoAssetId == null ? l10n.uploadLogoAction : l10n.replaceLogoAction),
                                  ),
                                  if (branding.logoAssetId != null)
                                    TextButton(
                                      onPressed: _uploadingLogo ? null : () => _removeLogo(branding.logoAssetId),
                                      child: Text(l10n.removeLogoAction),
                                    ),
                                ],
                              ),
                            ),
                            if (_uploadingLogo)
                              const Padding(padding: EdgeInsets.only(left: 8), child: CircularProgressIndicator(strokeWidth: 2)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: _saving ? null : () => _save(branding.logoAssetId),
                  child: _saving
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(l10n.save),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
