import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/invoice.dart';
import '../../../api/services/invoice_api.dart';

/// Plain FutureProvider.family, same style as `invoiceBrandingProvider`
/// (Batch 14) — its own screen, no shared-load benefit from bundling with
/// the invoice list or detail providers.
final invoiceHistoryLogProvider = FutureProvider.family<List<InvoiceEmailLogEntry>, String>((ref, organizationId) {
  return InvoiceApi.historyLog(organizationId);
});
