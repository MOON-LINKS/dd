import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/invoice.dart';
import '../../../api/services/invoice_api.dart';

/// Same style as every other list provider in this codebase — plain
/// FutureProvider.family, re-triggered via
/// `ref.invalidate(invoicesProvider(orgId))` after generate/record-payment
/// rather than a custom Notifier.
final invoicesProvider = FutureProvider.family<List<Invoice>, String>((ref, organizationId) {
  return InvoiceApi.list(organizationId);
});
