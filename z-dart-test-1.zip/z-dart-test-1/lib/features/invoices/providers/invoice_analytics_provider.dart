import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/invoice.dart';
import '../../../api/services/invoice_api.dart';

/// The Analytics tab's currently-selected date range, per organization.
/// `getInvoiceAnalytics` requires both `startDate`/`endDate` — there's no
/// "nothing selected yet" state this screen needs to design for, so this
/// defaults to the current calendar month (same default
/// `generateInvoicesDialogBody`'s "previous month" wording already trains
/// the manager to expect from this feature) rather than opening on an
/// empty picker.
final invoiceAnalyticsRangeProvider = StateProvider.family<DateTimeRange, String>((ref, organizationId) {
  final now = DateTime.now();
  return DateTimeRange(start: DateTime(now.year, now.month, 1), end: now);
});

/// Keyed by a `(organizationId, start, end)` record — Dart 3 records
/// implement `==`/`hashCode` structurally, so two calls with the same
/// three values hit the same cached family instance, and changing
/// `invoiceAnalyticsRangeProvider` (read via `.watch` inside the screen)
/// naturally produces a new key here without a second manual invalidation
/// call.
final invoiceAnalyticsProvider =
    FutureProvider.family<InvoiceAnalytics, ({String organizationId, DateTime start, DateTime end})>((ref, args) {
  return InvoiceApi.analytics(args.organizationId, startDate: args.start, endDate: args.end);
});
