import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/invoice.dart';
import '../../../api/services/invoice_api.dart';

/// Keyed by a (orgId, invoiceId) record — Dart 3 records have built-in
/// structural equality, so this works as a Riverpod family key the same
/// way a single String does elsewhere in this codebase, without needing
/// a custom class just to hold two IDs.
final invoiceDetailProvider =
    FutureProvider.family<InvoiceDetail, ({String orgId, String invoiceId})>((ref, key) {
  return InvoiceApi.get(key.orgId, key.invoiceId);
});
