import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../api/models/invoice.dart';
import '../../../api/services/invoice_api.dart';

/// Plain FutureProvider.family, same style as every other org-scoped
/// provider in the app (`referralCodeProvider`, `bioPageEditorDataProvider`).
/// Kept separate from `invoicesProvider` rather than folded into one
/// combined fetch — branding is opened as its own screen, not shown
/// alongside the invoice list, so there's no shared-load benefit the way
/// `BioPageEditorData` gets from bundling draft+buttons+flags.
final invoiceBrandingProvider = FutureProvider.family<InvoiceBranding, String>((ref, organizationId) {
  return InvoiceApi.getBranding(organizationId);
});
