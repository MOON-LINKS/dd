import 'package:flutter/material.dart';
import '../../../l10n/app_localizations.dart';

/// One entry in the sidebar. `label` takes `BuildContext` rather than a
/// plain String so every destination resolves through `AppLocalizations`
/// at render time — Section 6's static app-chrome layer, not the
/// per-organization-type `VerticalLabelsService`. Nav chrome ("Workers",
/// "Clients"...) is fixed UI text, not a dynamic field label, so ARB is
/// the right system here; VerticalLabelsService stays reserved for actual
/// per-org field labels inside the screens themselves.
class NavItem {
  final String path;
  final IconData icon;
  final IconData selectedIcon;
  final String Function(BuildContext context) label;

  const NavItem({
    required this.path,
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });
}

/// Middle section of the sidebar, grouped the way Step 2's "suggested
/// next" notes laid out (Overview / Operations / Money / Growth).
/// Settings is deliberately NOT in here — it's pinned separately at the
/// bottom of the sidebar per the brief, not part of the scrollable list.
class NavGroup {
  final String Function(BuildContext context)? label;
  final List<NavItem> items;

  const NavGroup({this.label, required this.items});
}

final List<NavGroup> navGroups = [
  NavGroup(
    items: [
      NavItem(
        path: '/dashboard',
        icon: Icons.dashboard_outlined,
        selectedIcon: Icons.dashboard,
        label: (c) => AppLocalizations.of(c)!.dashboard,
      ),
    ],
  ),
  NavGroup(
    label: (c) => AppLocalizations.of(c)!.navGroupOperations,
    items: [
      NavItem(
        path: '/workers',
        icon: Icons.groups_outlined,
        selectedIcon: Icons.groups,
        label: (c) => AppLocalizations.of(c)!.workers,
      ),
      NavItem(
        path: '/jobs',
        icon: Icons.work_outline,
        selectedIcon: Icons.work,
        label: (c) => AppLocalizations.of(c)!.jobs,
      ),
      NavItem(
        path: '/clients',
        icon: Icons.handshake_outlined,
        selectedIcon: Icons.handshake,
        label: (c) => AppLocalizations.of(c)!.clients,
      ),
    ],
  ),
  NavGroup(
    label: (c) => AppLocalizations.of(c)!.navGroupMoney,
    items: [
      NavItem(
        path: '/billing',
        icon: Icons.receipt_long_outlined,
        selectedIcon: Icons.receipt_long,
        label: (c) => AppLocalizations.of(c)!.billingAndInvoices,
      ),
      NavItem(
        path: '/expenses',
        icon: Icons.account_balance_wallet_outlined,
        selectedIcon: Icons.account_balance_wallet,
        label: (c) => AppLocalizations.of(c)!.expenses,
      ),
      NavItem(
        path: '/upcoming-bills',
        icon: Icons.event_outlined,
        selectedIcon: Icons.event,
        label: (c) => AppLocalizations.of(c)!.upcomingBills,
      ),
    ],
  ),
  NavGroup(
    label: (c) => AppLocalizations.of(c)!.navGroupGrowth,
    items: [
      NavItem(
        path: '/bio-page',
        icon: Icons.public_outlined,
        selectedIcon: Icons.public,
        label: (c) => AppLocalizations.of(c)!.bioPage,
      ),
      NavItem(
        path: '/referrals',
        icon: Icons.card_giftcard_outlined,
        selectedIcon: Icons.card_giftcard,
        label: (c) => AppLocalizations.of(c)!.referrals,
      ),
    ],
  ),
];

/// Settings — pinned at the bottom of the sidebar, outside `navGroups`.
final settingsNavItem = NavItem(
  path: '/settings',
  icon: Icons.settings_outlined,
  selectedIcon: Icons.settings,
  label: (c) => AppLocalizations.of(c)!.settings,
);

/// Flat list of every branch path, in the exact order the router's
/// StatefulShellRoute branches must be declared in — dashboard first,
/// then each group in order, settings last. Keeping this derived from
/// `navGroups`/`settingsNavItem` (rather than hand-duplicated in
/// router.dart) means the sidebar and the router can never drift apart.
List<NavItem> get allNavItems => [
      for (final group in navGroups) ...group.items,
      settingsNavItem,
    ];
