import 'package:flutter/material.dart';

import '../../../l10n/app_localizations.dart';

/// Stand-in body for every nav destination that doesn't have a real
/// screen yet (Workers, Jobs, Clients, Billing & invoices, Expenses,
/// Upcoming bills, Bio page, Referrals, Settings). Each one gets real
/// content in its own future pass — this just proves the sidebar/router
/// wiring reaches every destination end to end, same spirit as the
/// Step 1 environment-check placeholder.
class PlaceholderScreen extends StatelessWidget {
  final String title;

  const PlaceholderScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.construction_outlined, size: 40, color: theme.colorScheme.outline),
          const SizedBox(height: 16),
          Text(title, style: theme.textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(
            AppLocalizations.of(context)!.comingSoon,
            style: theme.textTheme.bodyMedium?.copyWith(color: theme.textTheme.bodySmall?.color),
          ),
          const SizedBox(height: 4),
          Text(
            AppLocalizations.of(context)!.comingSoonBody,
            style: theme.textTheme.bodySmall?.copyWith(color: theme.textTheme.bodySmall?.color),
          ),
        ],
      ),
    );
  }
}
