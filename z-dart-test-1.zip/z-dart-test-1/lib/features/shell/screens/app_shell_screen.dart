import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/providers/organization_type_provider.dart';
import '../models/nav_item.dart';
import '../providers/my_organizations_provider.dart';
import '../widgets/app_sidebar.dart';
import '../widgets/theme_toggle_button.dart';

/// Wraps every authenticated, post-onboarding screen. Combines:
///  - the org-existence gate (moved here, unchanged in behavior, from the
///    old HomeShellScreen — still a business-logic check, not a routing
///    concern, per router.dart's existing comments)
///  - the Stripe-style sidebar
///  - a top app bar carrying the page title + the theme toggle
///  - the StatefulNavigationShell body go_router hands us, so each nav
///    destination keeps its own navigation stack (indexed, not rebuilt)
class AppShellScreen extends ConsumerWidget {
  final StatefulNavigationShell navigationShell;

  const AppShellScreen({super.key, required this.navigationShell});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orgsAsync = ref.watch(myOrganizationsProvider);

    return orgsAsync.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (err, __) => Scaffold(
        body: Center(child: Text('Could not load your organizations: $err')),
      ),
      data: (orgs) {
        if (orgs.isEmpty) {
          // No organization yet — same redirect the old HomeShellScreen
          // did, just relocated: send to onboarding instead of rendering
          // a shell with nothing behind it.
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (context.mounted) context.go('/onboarding/organization');
          });
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        final org = orgs.first as Map<String, dynamic>;
        final orgType = org['organization_type'] as String?;
        if (orgType != null && ref.read(organizationTypeProvider) != orgType) {
          Future.microtask(() => ref.read(organizationTypeProvider.notifier).set(orgType));
        }

        final currentItem = allNavItems[navigationShell.currentIndex];

        return Scaffold(
          body: Row(
            children: [
              AppSidebar(
                selectedIndex: navigationShell.currentIndex,
                onSelect: (index) => navigationShell.goBranch(
                  index,
                  initialLocation: index == navigationShell.currentIndex,
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    AppBar(
                      automaticallyImplyLeading: false,
                      title: Text(currentItem.label(context)),
                      actions: const [
                        ThemeToggleButton(),
                        SizedBox(width: 8),
                      ],
                    ),
                    Expanded(child: navigationShell),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
