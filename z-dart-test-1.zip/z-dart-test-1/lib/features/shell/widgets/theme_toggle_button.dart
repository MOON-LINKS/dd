import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/theme_provider.dart';
import '../../../l10n/app_localizations.dart';

/// The only new piece on the theme side — `themeModeProvider` itself
/// (Hive + Riverpod, light/dark/system) already existed from the Step 1
/// environment pass. This just gives it a visible switch, placed in the
/// shell's app bar per the brief. Reads `MediaQuery.platformBrightness`
/// to show the right icon even while state is ThemeMode.system.
class ThemeToggleButton extends ConsumerWidget {
  const ThemeToggleButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(themeModeProvider);
    final platformIsDark =
        MediaQuery.platformBrightnessOf(context) == Brightness.dark;
    final isDark = mode == ThemeMode.dark ||
        (mode == ThemeMode.system && platformIsDark);

    return IconButton(
      tooltip: AppLocalizations.of(context)!.toggleTheme,
      icon: Icon(isDark ? Icons.dark_mode_outlined : Icons.light_mode_outlined),
      onPressed: () => ref.read(themeModeProvider.notifier).toggle(),
    );
  }
}
