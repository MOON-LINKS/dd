import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/auth_state_provider.dart';
import '../../../core/storage/secure_storage.dart';
import '../../../l10n/app_localizations.dart';

/// Pinned at the top of the sidebar per the brief. No account/profile
/// screen exists yet (same "not built yet" situation Step 2 flagged for
/// devices/plan-checkout) — so for now this is a popup with the one
/// working action, logout, same call sequence the old HomeShellScreen
/// used (SecureStorage.deleteToken() then markLoggedOut()). Swap the
/// PopupMenuButton for a real `/account` push once that screen exists.
class SidebarAccountMenu extends ConsumerWidget {
  const SidebarAccountMenu({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final colorScheme = Theme.of(context).colorScheme;

    return PopupMenuButton<String>(
      tooltip: AppLocalizations.of(context)!.myAccount,
      offset: const Offset(0, 44),
      position: PopupMenuPosition.under,
      itemBuilder: (context) => [
        PopupMenuItem(
          value: 'logout',
          child: Row(
            children: [
              const Icon(Icons.logout, size: 18),
              const SizedBox(width: 10),
              Text(AppLocalizations.of(context)!.logout),
            ],
          ),
        ),
      ],
      onSelected: (value) async {
        if (value == 'logout') {
          await SecureStorage.deleteToken();
          ref.read(authStateProvider.notifier).markLoggedOut();
        }
      },
      child: CircleAvatar(
        radius: 20,
        backgroundColor: colorScheme.primary.withValues(alpha: 0.15),
        child: Icon(Icons.person_outline, color: colorScheme.primary),
      ),
    );
  }
}
