import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'my_organizations_provider.dart';

/// Same "first organization" assumption app_shell_screen.dart already made
/// inline (`orgs.first as Map<String, dynamic>`) — this app doesn't have an
/// organization switcher yet, so "the org the signed-in user has" and "the
/// current org" are the same thing for now. Pulled out into its own
/// provider so every org-scoped screen (Workers here, then Clients/Jobs/etc.
/// as those get built) reads it the same way instead of re-deriving
/// orgs.first['id'] by hand each time. When multi-org switching is built,
/// this is the one place that changes.
final currentOrganizationIdProvider = Provider<String?>((ref) {
  final orgsAsync = ref.watch(myOrganizationsProvider);
  return orgsAsync.whenOrNull(
    data: (orgs) => orgs.isEmpty ? null : (orgs.first as Map<String, dynamic>)['id'] as String?,
  );
});
