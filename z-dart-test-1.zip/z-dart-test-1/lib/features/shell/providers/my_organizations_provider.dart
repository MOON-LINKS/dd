import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../api/services/organization_api.dart';

/// Moved here from the old `HomeShellScreen` unchanged — still the same
/// business-logic check (not a routing concern, see router.dart's
/// comments): whether the authenticated user has an organization yet.
/// Now lives at the shell level so it gates the whole app shell once,
/// rather than being re-fetched per nav destination.
final myOrganizationsProvider = FutureProvider<List<dynamic>>((ref) {
  return OrganizationApi.listMine();
});
