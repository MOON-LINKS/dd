import 'dart:convert';
import 'package:flutter/services.dart';

/// Section 6: text keys are namespaced by organization type
/// ({organizationType}_{fieldKey}), with a fallback to default_{fieldKey}
/// if a specific vertical's translation doesn't exist yet. This is
/// deliberately separate from the generated AppLocalizations (ARB) system —
/// ARB is compiled at build time with a fixed key set; this loads JSON at
/// runtime and resolves keys dynamically based on the user-selected
/// organizationType, which ARB has no mechanism for.
class VerticalLabelsService {
  VerticalLabelsService._();

  static final Map<String, Map<String, String>> _cache = {};

  /// Loads (and caches) assets/lang/{languageCode}.json. Call once per
  /// language change — see VerticalLabelsNotifier in
  /// vertical_labels_provider.dart, which calls this whenever locale or
  /// organizationType changes.
  static Future<Map<String, String>> _load(String languageCode) async {
    if (_cache.containsKey(languageCode)) return _cache[languageCode]!;
    try {
      final raw = await rootBundle.loadString('assets/lang/$languageCode.json');
      final decoded = (jsonDecode(raw) as Map<String, dynamic>)
          .map((key, value) => MapEntry(key, value.toString()));
      _cache[languageCode] = decoded;
      return decoded;
    } catch (_) {
      // Missing language file entirely (e.g. a new locale added to
      // supportedLocales before its JSON exists) — fall back to English
      // rather than crashing, same fallback spirit as the per-key rule below.
      if (languageCode != 'en') return _load('en');
      return {};
    }
  }

  /// Public entry point for VerticalLabelsProvider — preloads the full map
  /// for a language so lookups afterward can be synchronous.
  static Future<Map<String, String>> loadAll(String languageCode) => _load(languageCode);

  /// The actual fallback rule from Section 6:
  /// 1. Try {organizationType}_{fieldKey}
  /// 2. Fall back to default_{fieldKey}
  /// 3. Last resort: return fieldKey itself — never show a raw "missing
  ///    key" error to the manager, even if both the vertical-specific AND
  ///    default entries are somehow missing from the JSON.
  static Future<String> resolve({
    required String languageCode,
    required String fieldKey,
    String? organizationType,
  }) async {
    final labels = await _load(languageCode);
    if (organizationType != null) {
      final specific = labels['${organizationType}_$fieldKey'];
      if (specific != null) return specific;
    }
    return labels['default_$fieldKey'] ?? fieldKey;
  }
}
