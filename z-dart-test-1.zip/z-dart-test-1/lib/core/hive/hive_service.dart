import 'package:hive_flutter/hive_flutter.dart';

/// Non-sensitive local persistence — Section 7 of project-spec.md:
/// theme, language, organizationType/registeredType, and cached
/// plan/feature JSON. No custom TypeAdapters needed yet — everything
/// stored here is a primitive (String/bool/Map<String, dynamic> via JSON),
/// so plain Hive boxes are enough without build_runner codegen.
class HiveService {
  HiveService._();

  static const settingsBoxName = 'settings';

  // Keys within the settings box
  static const keyThemeMode = 'themeMode'; // 'light' | 'dark' | 'system'
  static const keyLanguageCode = 'languageCode'; // 'en' | 'ar' | 'fr'
  static const keyOrganizationType = 'organizationType'; // drives Section 6 label resolution
  static const keyRegisteredType = 'registeredType'; // set once at registration, per Section 6
  static const keyCachedPlanFeatures = 'cachedPlanFeatures'; // JSON string, plan.modules/feature_limits

  static late final Box _settingsBox;

  /// Call once in main() before runApp(). Opens the single settings box —
  /// additional boxes can be added here later without touching call sites
  /// elsewhere, since everything goes through the typed getters/setters below.
  static Future<void> init() async {
    await Hive.initFlutter();
    _settingsBox = await Hive.openBox(settingsBoxName);
  }

  static Box get settingsBox => _settingsBox;

  // ---- Typed convenience accessors ----

  static String? get themeMode => _settingsBox.get(keyThemeMode) as String?;
  static Future<void> setThemeMode(String value) =>
      _settingsBox.put(keyThemeMode, value);

  static String? get languageCode => _settingsBox.get(keyLanguageCode) as String?;
  static Future<void> setLanguageCode(String value) =>
      _settingsBox.put(keyLanguageCode, value);

  static String? get organizationType =>
      _settingsBox.get(keyOrganizationType) as String?;
  static Future<void> setOrganizationType(String value) =>
      _settingsBox.put(keyOrganizationType, value);

  static String? get registeredType => _settingsBox.get(keyRegisteredType) as String?;
  static Future<void> setRegisteredType(String value) =>
      _settingsBox.put(keyRegisteredType, value);

  static String? get cachedPlanFeatures =>
      _settingsBox.get(keyCachedPlanFeatures) as String?;
  static Future<void> setCachedPlanFeatures(String jsonString) =>
      _settingsBox.put(keyCachedPlanFeatures, jsonString);

  /// Used on logout — clears local prefs tied to the signed-in org/user.
  /// Deliberately does NOT touch the auth token (that's SecureStorage's job).
  static Future<void> clearOrganizationScopedData() async {
    await _settingsBox.delete(keyOrganizationType);
    await _settingsBox.delete(keyCachedPlanFeatures);
  }
}
