/// Mirrors the backend's `utils/cdn.js` `resolveAssetUrl` exactly: assets
/// are stored as a relative filename only (spec Section 9 — "store only
/// the relative filename/path in the database... the CDN base URL is
/// prefixed at render time in code, not stored in the database"), and the
/// base gets prefixed here the same way it does server-side. Override at
/// build time with `--dart-define=CDN_BASE_URL=...`, same mechanism
/// `ApiClient.baseUrl` already uses for `API_BASE_URL`.
const String _cdnBaseUrl = String.fromEnvironment(
  'CDN_BASE_URL',
  defaultValue: 'https://cdn.mydomain.com/imgs',
);

String? resolveAssetUrl(String? filename) {
  if (filename == null || filename.isEmpty) return null;
  final base = _cdnBaseUrl.endsWith('/') ? _cdnBaseUrl.substring(0, _cdnBaseUrl.length - 1) : _cdnBaseUrl;
  return '$base/$filename';
}
