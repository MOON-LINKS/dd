import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'locale_provider.dart';
import 'organization_type_provider.dart';
import '../localization/vertical_labels_service.dart';

/// Preloads the current language's full label map whenever locale changes.
/// Widgets watch this (it's a FutureProvider, so `.when` handles the
/// loading/error states) and then use `verticalLabelProvider(fieldKey)`
/// below for the actual resolved string.
final verticalLabelsMapProvider = FutureProvider<Map<String, String>>((ref) {
  final locale = ref.watch(localeProvider);
  return VerticalLabelsService.loadAll(locale.languageCode);
});

/// Family provider: `ref.watch(verticalLabelProvider('worker_title'))`
/// returns the resolved label for the CURRENT organizationType, or the
/// fieldKey itself while the map is still loading (avoids UI flicker/
/// layout jump — first frame shows a readable-if-generic word, not a
/// spinner, for something as small as a label string).
final verticalLabelProvider = Provider.family<String, String>((ref, fieldKey) {
  final orgType = ref.watch(organizationTypeProvider);
  final mapAsync = ref.watch(verticalLabelsMapProvider);

  return mapAsync.when(
    data: (labels) {
      if (orgType != null) {
        final specific = labels['${orgType}_$fieldKey'];
        if (specific != null) return specific;
      }
      return labels['default_$fieldKey'] ?? fieldKey;
    },
    loading: () => fieldKey,
    error: (_, __) => fieldKey,
  );
});
