import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../storage/secure_storage.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

final authStateProvider = NotifierProvider<AuthStateNotifier, AuthStatus>(
  AuthStateNotifier.new,
);

/// Reactive wrapper around whether a token exists in SecureStorage — the
/// token itself is never exposed through Riverpod state, only the derived
/// yes/no. Call refresh() after login/verifyOtp succeed and after
/// logout/logoutAll/deleteAccount, since those mutate SecureStorage
/// directly (see api/services/auth_api.dart) without going through this
/// notifier automatically.
class AuthStateNotifier extends Notifier<AuthStatus> {
  @override
  AuthStatus build() {
    // Kick off the async check; state starts as `unknown` so the app can
    // show a splash/loading screen instead of flashing the login screen.
    _check();
    return AuthStatus.unknown;
  }

  Future<void> _check() async {
    final token = await SecureStorage.readToken();
    state = token != null ? AuthStatus.authenticated : AuthStatus.unauthenticated;
  }

  Future<void> refresh() => _check();

  /// Optimistic local sign-out — pairs with AuthApi.logout()/logoutAll()
  /// which already clears SecureStorage; call this right after so the UI
  /// updates immediately rather than waiting on a redundant re-read.
  void markLoggedOut() => state = AuthStatus.unauthenticated;

  void markLoggedIn() => state = AuthStatus.authenticated;
}
