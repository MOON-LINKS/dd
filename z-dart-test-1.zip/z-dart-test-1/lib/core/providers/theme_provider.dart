import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../hive/hive_service.dart';

final themeModeProvider = NotifierProvider<ThemeModeNotifier, ThemeMode>(
  ThemeModeNotifier.new,
);

class ThemeModeNotifier extends Notifier<ThemeMode> {
  @override
  ThemeMode build() {
    final stored = HiveService.themeMode;
    switch (stored) {
      case 'dark':
        return ThemeMode.dark;
      case 'light':
        return ThemeMode.light;
      default:
        return ThemeMode.system;
    }
  }

  Future<void> setLight() => _set(ThemeMode.light, 'light');
  Future<void> setDark() => _set(ThemeMode.dark, 'dark');
  Future<void> setSystem() => _set(ThemeMode.system, 'system');

  Future<void> toggle() {
    final next = state == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    return _set(next, next == ThemeMode.dark ? 'dark' : 'light');
  }

  Future<void> _set(ThemeMode mode, String storedValue) async {
    state = mode;
    await HiveService.setThemeMode(storedValue);
  }
}
