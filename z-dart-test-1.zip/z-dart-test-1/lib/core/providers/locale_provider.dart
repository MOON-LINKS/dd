import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../hive/hive_service.dart';

/// Section 6: en, ar, fr required at launch.
const supportedLocales = [Locale('en'), Locale('ar'), Locale('fr')];

final localeProvider = NotifierProvider<LocaleNotifier, Locale>(LocaleNotifier.new);

class LocaleNotifier extends Notifier<Locale> {
  @override
  Locale build() {
    final stored = HiveService.languageCode;
    if (stored != null && supportedLocales.any((l) => l.languageCode == stored)) {
      return Locale(stored);
    }
    return const Locale('en'); // default until the OS locale is checked at app startup (main.dart)
  }

  Future<void> setLocale(Locale locale) async {
    state = locale;
    await HiveService.setLanguageCode(locale.languageCode);
  }

  /// Arabic is the only RTL language in the supported set.
  bool get isRtl => state.languageCode == 'ar';
}
