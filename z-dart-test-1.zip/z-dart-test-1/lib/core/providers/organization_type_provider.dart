import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../hive/hive_service.dart';

/// Section 2: selected at registration, before payment. Does NOT restrict
/// features — only drives which localized labels get shown (Section 6).
/// This is set once the active organization is known (after login/org
/// selection) — see the Organizations API layer, built in this same pass.
final organizationTypeProvider =
    NotifierProvider<OrganizationTypeNotifier, String?>(OrganizationTypeNotifier.new);

class OrganizationTypeNotifier extends Notifier<String?> {
  @override
  String? build() => HiveService.organizationType;

  Future<void> set(String organizationType) async {
    state = organizationType;
    await HiveService.setOrganizationType(organizationType);
  }

  Future<void> clear() async {
    state = null;
    await HiveService.clearOrganizationScopedData();
  }
}
