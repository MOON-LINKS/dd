import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;

/// Backend's login/verifyOtp/register calls all take a deviceName for the
/// user_sessions table (multi-device logout list). Kept intentionally
/// simple — just the platform name — rather than pulling in device_info_plus
/// for a real device model string; upgrade this later if "manage devices"
/// UI needs more than "Android" / "iOS" / "Web" to be useful.
String getDeviceName() {
  if (kIsWeb) return 'Web';
  if (Platform.isAndroid) return 'Android';
  if (Platform.isIOS) return 'iOS';
  if (Platform.isMacOS) return 'macOS';
  if (Platform.isWindows) return 'Windows';
  if (Platform.isLinux) return 'Linux';
  return 'Unknown device';
}
