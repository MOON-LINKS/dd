import 'package:flutter/material.dart';

/// Mirrors `BIO_PAGE_COLOR_PRESETS` in the backend's `utils/constants.js`
/// exactly (same keys, same hex values) — the manager picks a curated
/// preset, not a raw hex value (schema's own comment on
/// `bio_pages.color_preset`), so this list has to match the backend's
/// one-for-one or the editor's swatch preview would lie about what the
/// published page will actually look like.
class BioPageColorPreset {
  final String key;
  final String label;
  final Color primary;
  final Color secondary;
  final Color background;
  final Color text;

  const BioPageColorPreset({
    required this.key,
    required this.label,
    required this.primary,
    required this.secondary,
    required this.background,
    required this.text,
  });
}

const bioPageColorPresets = <BioPageColorPreset>[
  BioPageColorPreset(
    key: 'default',
    label: 'Default',
    primary: Color(0xFF1D9E75),
    secondary: Color(0xFF0F6E56),
    background: Color(0xFFFFFFFF),
    text: Color(0xFF1A1A1A),
  ),
  BioPageColorPreset(
    key: 'midnight',
    label: 'Midnight',
    primary: Color(0xFF4F46E5),
    secondary: Color(0xFF312E81),
    background: Color(0xFF0B1020),
    text: Color(0xFFF5F5F5),
  ),
  BioPageColorPreset(
    key: 'sunset',
    label: 'Sunset',
    primary: Color(0xFFF97316),
    secondary: Color(0xFFEA580C),
    background: Color(0xFFFFF7ED),
    text: Color(0xFF1A1A1A),
  ),
  BioPageColorPreset(
    key: 'rose',
    label: 'Rose',
    primary: Color(0xFFDB2777),
    secondary: Color(0xFF9D174D),
    background: Color(0xFFFFF1F5),
    text: Color(0xFF1A1A1A),
  ),
  BioPageColorPreset(
    key: 'ocean',
    label: 'Ocean',
    primary: Color(0xFF0891B2),
    secondary: Color(0xFF075985),
    background: Color(0xFFF0FDFF),
    text: Color(0xFF1A1A1A),
  ),
];

BioPageColorPreset resolveBioPageColorPreset(String? key) {
  return bioPageColorPresets.firstWhere(
    (p) => p.key == key,
    orElse: () => bioPageColorPresets.first,
  );
}
