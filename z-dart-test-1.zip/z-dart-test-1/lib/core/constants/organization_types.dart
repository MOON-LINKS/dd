/// Matches `ORGANIZATION_TYPES` in the backend's `utils/constants.js`
/// exactly — keep these two lists in sync if a vertical is ever added or
/// renamed.
///
/// Extracted out of `create_organization_screen.dart` in this batch (it
/// was a private `_organizationTypes` const there, so nothing else could
/// import it) — Settings' organization-type editor needs the exact same
/// list, and duplicating six hardcoded tuples in a second file is exactly
/// the kind of drift this comment above already warns about. Onboarding
/// now imports this instead of defining its own copy; behavior there is
/// unchanged.
const organizationTypes = [
  ('construction', 'Construction'),
  ('tutoring', 'After-school teaching / tutoring'),
  ('gym', 'Gym with coaches'),
  ('contractor', 'Contractor'),
  ('sales', 'Sales agency'),
  ('cleaning', 'Cleaning service agency'),
];

String organizationTypeLabel(String value) {
  final match = organizationTypes.where((t) => t.$1 == value);
  return match.isEmpty ? value : match.first.$2;
}
