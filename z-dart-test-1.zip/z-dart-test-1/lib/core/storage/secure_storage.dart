import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Auth token storage. Deliberately separate from Hive (core/hive/) — Hive
/// is for non-sensitive local prefs (theme, language, organizationType);
/// the JWT goes through the OS keychain/keystore via flutter_secure_storage.
///
/// Matches the backend's dual auth pattern (see authController.js /
/// sendAuthResponse): the Flutter app always sends x-client-type: 'app', so
/// the backend returns the token in the JSON body rather than a cookie —
/// this is what stores that token client-side and reads it back for every
/// subsequent request (see api/api_client.dart's interceptor).
class SecureStorage {
  SecureStorage._();

  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _tokenKey = 'auth_token';

  /// Reads the currently stored token, or null if the user isn't logged in.
  static Future<String?> readToken() => _storage.read(key: _tokenKey);

  /// Stores the token returned by /auth/login, /auth/verify-otp, etc.
  static Future<void> addToken(String token) =>
      _storage.write(key: _tokenKey, value: token);

  /// Clears the token — called on logout, logout-all, and account deletion.
  static Future<void> deleteToken() => _storage.delete(key: _tokenKey);
}
