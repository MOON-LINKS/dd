import 'package:flutter/material.dart';

import '../../l10n/app_localizations.dart';

/// Section 8: most fields in this app are required, so optional ones are
/// marked explicitly with "(optional)" rather than marking required ones
/// with asterisks. Every text field in auth/onboarding goes through this
/// one widget so that convention doesn't have to be repeated by hand.
class AppTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final bool isOptional;
  final bool obscureText;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final String? helperText;
  final Widget? suffixIcon;
  final void Function(String)? onChanged;

  const AppTextField({
    super.key,
    required this.controller,
    required this.label,
    this.isOptional = false,
    this.obscureText = false,
    this.keyboardType,
    this.validator,
    this.helperText,
    this.suffixIcon,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final suffix = AppLocalizations.of(context)!.optionalFieldSuffix;
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      validator: validator,
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: isOptional ? '$label $suffix' : label,
        helperText: helperText,
        suffixIcon: suffixIcon,
      ),
    );
  }
}
