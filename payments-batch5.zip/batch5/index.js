/*
 * REFERENCE FILE — shows how to mount this batch alongside what you already
 * had. Merge the new requires/app.use lines into your real index.js rather
 * than replacing it outright.
 *
 * THE ONE ORDERING RULE THAT MATTERS: webhookRoutes must be mounted BEFORE
 * app.use(express.json()). Stripe's webhook signature check needs the raw
 * request body — once express.json() has consumed and parsed it, the raw
 * bytes are gone and stripe.webhooks.constructEvent() will fail every time.
 */

require('dotenv').config()
const express = require('express')
const cookieParser = require('cookie-parser')

const authRoutes = require('./routes/authRoutes')
const organizationRoutes = require('./routes/organizationRoutes')
const workerRoutes = require('./routes/workerRoutes')
const assetRoutes = require('./routes/assetRoutes')
const clientRoutes = require('./routes/clientRoutes')
const { router: jobTemplateRoutes, adminRouter: jobTemplateAdminRoutes } = require('./routes/jobTemplateRoutes')
const jobRoutes = require('./routes/jobRoutes')
const expenseRoutes = require('./routes/expenseRoutes')
const upcomingBillRoutes = require('./routes/upcomingBillRoutes')
const planRoutes = require('./routes/planRoutes')

// New in this batch
const paymentRoutes = require('./routes/paymentRoutes')
const webhookRoutes = require('./routes/webhookRoutes')

const app = express()

app.use(cookieParser())

// Mounted BEFORE express.json() — see note at top of this file.
app.use('/webhooks', webhookRoutes)

app.use(express.json())

app.use('/auth', authRoutes)
app.use('/organizations', organizationRoutes)

// Nested resources: /organizations/:organizationId/...
app.use('/organizations/:organizationId/workers', workerRoutes)
app.use('/organizations/:organizationId/clients', clientRoutes)
app.use('/organizations/:organizationId/job-templates', jobTemplateRoutes)
app.use('/organizations/:organizationId/jobs', jobRoutes)
app.use('/organizations/:organizationId/expenses', expenseRoutes)
app.use('/organizations/:organizationId/upcoming-bills', upcomingBillRoutes)
app.use('/organizations/:organizationId/billing', paymentRoutes) // new

// Not org-scoped — global resources
app.use('/assets', assetRoutes)
app.use('/admin/job-templates', jobTemplateAdminRoutes) // TODO: swap requireAuth for requireAdmin inside this router
app.use('/plans', planRoutes) // public, no auth — pricing page

app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }))

const PORT = process.env.PORT || 4000
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`))

module.exports = app
