# This Batch — What's In It, What's Still Blocked

## New files, ready to drop into your project structure

| File | Goes in |
|---|---|
| `clientController.js` | `controllers/` |
| `clientRoutes.js` | `routes/` |
| `jobTemplateController.js` | `controllers/` |
| `jobTemplateRoutes.js` | `routes/` |
| `jobController.js` | `controllers/` |
| `jobRoutes.js` | `routes/` |
| `expenseController.js` | `controllers/` |
| `expenseRoutes.js` | `routes/` |
| `upcomingBillController.js` | `controllers/` |
| `upcomingBillRoutes.js` | `routes/` |
| `planController.js` | `controllers/` |
| `planRoutes.js` | `routes/` |
| `authController.additions.js` | **not a drop-in** — paste its one function into your existing `authController.js` (instructions at the top of the file) |
| `index.js` | reference only — merge the new `require`/`app.use` lines into your real `index.js`, don't overwrite it |

## Modules now fully or mostly done this batch
- **Clients** — full CRUD + feedback (create/list)
- **Job Templates** — manager-facing list (filtered by org industry) + admin create/update
- **Jobs** — full CRUD, postpone, and the `getJobSnapshot`/`saveJobSnapshot` pair (transaction-safe, blocks edits to already-invoiced days, verifies worker/client ownership server-side)
- **Expenses** — full CRUD
- **Upcoming Bills** — full CRUD + `markBillPaid` + `convertBillToExpense`
- **Plans** — `listPlans` (public, for a pricing page)
- **Settings** — `changePassword` (logged-in flow, distinct from the OTP-based reset flow)

## Deliberately left out of this batch (the three original blockers)
- **`sendBillReminders`** — the scheduled reminder job. `reminder_days_before` is captured on create/update above, but the cron/worker that reads it and actually fires notifications needs the interval-fields decision finalized first.
- **`generateMonthlyInvoices`, invoice PDF, invoice analytics** — all of Invoices. Can start once Jobs has real data to generate from (which it now can), but analytics specifically is still blocked on scoping exact metrics.
- **All of Payments** — checkout session creation, Stripe/Tap webhook handler, Apple server notification handler, and wiring `subscribed_services` for real. Blocked on the Stripe vs Tap decision.

## Also not started (not blocked, just not built yet)
- Bio Pages (all endpoints)
- Referrals (all endpoints)
- `deleteOrganization` (soft delete)
- `requireAuth` / `requireAdmin` middleware — every route above still references a placeholder `middleware/auth`. Nothing here works end-to-end until that's real.
- Applying `hasModule` checks inside the new controllers where relevant (e.g. gating Upcoming Bills or Bio Pages behind a plan's `modules` array) — the utility already exists (`planLimits.js`), it just isn't called from these new controllers yet.

## Suggested next session
Bio Pages is the largest remaining unblocked chunk — worth doing next since nothing about it depends on the three blockers, and it's the feature we discussed as a distribution channel. After that, Referrals is small and also fully unblocked.
