/*
 * REFERENCE FILE — shows how to mount everything built in this batch
 * alongside what you already had. Merge the new requires/app.use lines
 * into your real index.js rather than replacing it outright, since your
 * real file may have grown since the version you shared.
 */

require('dotenv').config()
const express = require('express')
const cookieParser = require('cookie-parser')

const authRoutes = require('./routes/authRoutes')
const organizationRoutes = require('./routes/organizationRoutes')
const workerRoutes = require('./routes/workerRoutes')
const assetRoutes = require('./routes/assetRoutes')

// New in this batch
const clientRoutes = require('./routes/clientRoutes')
const { router: jobTemplateRoutes, adminRouter: jobTemplateAdminRoutes } = require('./routes/jobTemplateRoutes')
const jobRoutes = require('./routes/jobRoutes')
const expenseRoutes = require('./routes/expenseRoutes')
const upcomingBillRoutes = require('./routes/upcomingBillRoutes')
const planRoutes = require('./routes/planRoutes')

const app = express()

app.use(express.json())
app.use(cookieParser())

app.use('/auth', authRoutes)
app.use('/organizations', organizationRoutes)

// Nested resources: /organizations/:organizationId/...
// mergeParams on each router lets it read :organizationId from this mount.
app.use('/organizations/:organizationId/workers', workerRoutes)
app.use('/organizations/:organizationId/clients', clientRoutes)
app.use('/organizations/:organizationId/job-templates', jobTemplateRoutes)
app.use('/organizations/:organizationId/jobs', jobRoutes)
app.use('/organizations/:organizationId/expenses', expenseRoutes)
app.use('/organizations/:organizationId/upcoming-bills', upcomingBillRoutes)

// Not org-scoped — global resources
app.use('/assets', assetRoutes)
app.use('/admin/job-templates', jobTemplateAdminRoutes) // TODO: swap requireAuth for requireAdmin inside this router
app.use('/plans', planRoutes) // public, no auth — pricing page

app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }))

const PORT = process.env.PORT || 4000
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`))

module.exports = app
