/*
 * PASTE INSTRUCTIONS
 * -------------------
 * This is not a standalone file — it's the one missing piece from
 * Settings (spec Section 3): changePassword, the logged-in flow with an
 * old-password check, distinct from the forgot-password resetPass1/2/3
 * flow already in authController.js.
 *
 * 1. Paste the function below into authController.js, anywhere alongside
 *    the other password-related functions (e.g. right after resetPass3).
 *    It uses db, bcrypt, and invalidateAllSessions — all already imported/
 *    defined at the top of that file, so no new imports needed.
 *
 * 2. Add `changePassword` to the module.exports list at the bottom of
 *    authController.js.
 *
 * 3. Add this route to authRoutes.js:
 *      router.patch('/change-password', requireAuth, changePassword)
 */

// ------------------------------------------------------------------
// CHANGE PASSWORD — logged-in flow. Requires the current password
// (not an OTP) since the user is already authenticated. Wipes all
// other sessions after the change, same as resetPass3, so a change
// made from a compromised or lost device logs everything else out.
// ------------------------------------------------------------------
const changePassword = async (req, res) => {
    const { id } = req.user
    const { currentPassword, newPassword } = req.body
    try {
        if (!currentPassword || !newPassword) {
            return res.status(400).json({ message: 'currentPassword and newPassword are required' })
        }
        if (newPassword.length < 8) {
            return res.status(400).json({ message: 'newPassword must be at least 8 characters' })
        }

        const { rows } = await db.query(
            'SELECT password_hash FROM users WHERE id = $1 AND deleted_at IS NULL',
            [id]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'user not found' })

        const isCurrentPassCorrect = await bcrypt.compare(currentPassword, rows[0].password_hash)
        if (!isCurrentPassCorrect) return res.status(401).json({ message: 'current password is incorrect' })

        const isSameAsOld = await bcrypt.compare(newPassword, rows[0].password_hash)
        if (isSameAsOld) return res.status(400).json({ message: 'new password must be different from the current password' })

        const newPasswordHash = await bcrypt.hash(newPassword, 10)
        await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newPasswordHash, id])

        // Same pattern as resetPass3 — a password change is a good moment
        // to log every other session out, in case the change was prompted
        // by a lost/compromised device.
        await invalidateAllSessions(id)

        res.status(200).json({ message: 'password changed and logged out from other sessions' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not change password' })
    }
}
