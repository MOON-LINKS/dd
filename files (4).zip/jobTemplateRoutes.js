const express = require('express')
const router = express.Router({ mergeParams: true }) // inherits :organizationId
const { listJobTemplates, createJobTemplate, updateJobTemplate } = require('../controllers/jobTemplateController')
const requireAuth = require('../middleware/auth') // TODO: shared once you provide the real middleware

// Manager-facing — filtered by the org's industry inside the controller
router.get('/', requireAuth, listJobTemplates)

// Internal/admin only in v1 — spec Section 3 says not exposed to managers.
// TODO: swap requireAuth for a requireAdmin middleware once that exists;
// these two are mounted separately below (not nested under :organizationId)
// since templates aren't org-scoped.
const adminRouter = express.Router()
adminRouter.post('/', requireAuth, createJobTemplate)
adminRouter.patch('/:templateId', requireAuth, updateJobTemplate)

module.exports = { router, adminRouter }
