// Reference only — merge into your real index.js, don't overwrite it.

const referralRoutes = require('./routes/referralRoutes')

app.use('/organizations/:organizationId/referrals', referralRoutes)
app.use('/referrals', referralRoutes.publicRouter)       // GET /referrals/validate?code=XYZ
app.use('/admin/referrals', referralRoutes.adminRouter)  // POST /admin/referrals/payouts, GET /admin/referrals/payouts/pending

// ============================================================
// PATCH 1 — controllers/paymentController.js
// Two changes inside createCheckoutSession. Exact before/after below.
// ============================================================

/*
--- BEFORE (top of file) ---
const db = require('../utils/db')
const stripe = require('../utils/stripeClient')
const { verifyTransaction } = require('../utils/appleIAP')
const { userOwnsOrganization } = require('../utils/orgAccess')

--- AFTER ---
const db = require('../utils/db')
const stripe = require('../utils/stripeClient')
const { verifyTransaction } = require('../utils/appleIAP')
const { userOwnsOrganization } = require('../utils/orgAccess')
const { validateReferralCodeValue } = require('../utils/referralEngine')
const { getOrCreateReferralCoupon } = require('../utils/referralStripeCoupon')
*/

/*
--- BEFORE (inside createCheckoutSession, right after destructuring req.body) ---
    const { planId, billingCadence } = req.body

--- AFTER ---
    const { planId, billingCadence, referralCode } = req.body
*/

/*
--- BEFORE (right after the price/priceId validation block, before "Reuse the
    org's existing Stripe customer..." comment) ---

        const priceId = billingCadence === 'monthly' ? plan.stripe_price_id_monthly : plan.stripe_price_id_yearly
        if (!priceId) {
            return res.status(400).json({ message: `plan "${plan.name}" has no Stripe price configured for ${billingCadence} billing` })
        }

--- AFTER (insert this block right after the above, before the customer lookup) ---

        const priceId = billingCadence === 'monthly' ? plan.stripe_price_id_monthly : plan.stripe_price_id_yearly
        if (!priceId) {
            return res.status(400).json({ message: `plan "${plan.name}" has no Stripe price configured for ${billingCadence} billing` })
        }

        let discounts
        if (referralCode) {
            const { valid, referring_organization_id, discount_pct } = await validateReferralCodeValue(referralCode)
            if (!valid) return res.status(400).json({ message: 'invalid referral code' })
            if (referring_organization_id === organizationId) {
                return res.status(400).json({ message: 'you cannot use your own referral code' })
            }
            const couponId = await getOrCreateReferralCoupon(discount_pct)
            discounts = [{ coupon: couponId }]
        }
*/

/*
--- BEFORE (the stripe.checkout.sessions.create call) ---

        const session = await stripe.checkout.sessions.create({
            customer: stripeCustomerId,
            mode: 'subscription',
            line_items: [{ price: priceId, quantity: 1 }],
            allow_promotion_codes: true,
            success_url: process.env.STRIPE_CHECKOUT_SUCCESS_URL,
            cancel_url: process.env.STRIPE_CHECKOUT_CANCEL_URL,
            metadata: { organizationId, planId, billingCadence },
            subscription_data: {
                metadata: { organizationId, planId, billingCadence }
            }
        })

--- AFTER (three changes: allow_promotion_codes can't coexist with discounts
    per Stripe's API — only include it when there's no referral discount;
    add discounts; carry referralCode in metadata for the webhook to read) ---

        const session = await stripe.checkout.sessions.create({
            customer: stripeCustomerId,
            mode: 'subscription',
            line_items: [{ price: priceId, quantity: 1 }],
            ...(discounts ? { discounts } : { allow_promotion_codes: true }),
            success_url: process.env.STRIPE_CHECKOUT_SUCCESS_URL,
            cancel_url: process.env.STRIPE_CHECKOUT_CANCEL_URL,
            metadata: { organizationId, planId, billingCadence, referralCode: referralCode || '' },
            subscription_data: {
                metadata: { organizationId, planId, billingCadence }
            }
        })
*/

// ============================================================
// PATCH 2 — controllers/webhookController.js
// Two changes: hook into checkout.session.completed, add a new case.
// ============================================================

/*
--- BEFORE (top of file) ---
const db = require('../utils/db')
const stripe = require('../utils/stripeClient')

--- AFTER ---
const db = require('../utils/db')
const stripe = require('../utils/stripeClient')
const { ensureReferralCodeForOrganization, recordReferralUseIfNew, recordReferralEarning } = require('../utils/referralEngine')
*/

/*
--- BEFORE (the checkout.session.completed case) ---
            case 'checkout.session.completed': {
                const session = event.data.object
                if (session.mode !== 'subscription') break
                const subscription = await stripe.subscriptions.retrieve(session.subscription)
                await syncSubscriptionRow(subscription)
                break
            }

--- AFTER (adds referral code generation for THIS org on their first
    payment, and records the referral USE if this org checked out with
    someone else's code — both no-ops on renewals/repeat calls, by design) ---
            case 'checkout.session.completed': {
                const session = event.data.object
                if (session.mode !== 'subscription') break
                const subscription = await stripe.subscriptions.retrieve(session.subscription)
                await syncSubscriptionRow(subscription)

                const organizationId = session.metadata?.organizationId
                if (organizationId) {
                    await ensureReferralCodeForOrganization(db, organizationId)
                    if (session.metadata?.referralCode) {
                        await recordReferralUseIfNew(db, { code: session.metadata.referralCode, referredOrganizationId: organizationId })
                    }
                }
                break
            }

--- ADD this new case anywhere in the switch (e.g. right after
    checkout.session.completed) — this is what credits the REFERRING org
    on every subsequent payment the referred org makes, not just the first ---
            case 'invoice.payment_succeeded': {
                const invoice = event.data.object
                if (!invoice.subscription) break
                const subscription = await stripe.subscriptions.retrieve(invoice.subscription)
                const organizationId = subscription.metadata?.organizationId
                if (organizationId) {
                    await recordReferralEarning(db, {
                        referredOrganizationId: organizationId,
                        stripeInvoiceId: invoice.id,
                        amountPaidCents: invoice.amount_paid
                    })
                }
                break
            }
*/
