const express = require('express')
const router = express.Router()
const {
    register,
    verifyOTP,
    login,
    logout,
    logoutFromAll,
    getUserInfo,
    resetPass1,
    resetPass2,
    resetPass3,
    deleteAccount,
    changePassword
} = require('../controllers/authController')

// TODO: import the real auth middleware once shared (verifies JWT against Redis
// session:{sessionId}, then sets req.user = { id, sessionId }).
const requireAuth = require('../middleware/auth')

router.post('/register', register)
router.post('/verify-otp', verifyOTP)
router.post('/login', login)
router.post('/logout', requireAuth, logout)
router.post('/logout-all', requireAuth, logoutFromAll)
router.get('/me', requireAuth, getUserInfo)
router.post('/reset-password/request', resetPass1)
router.post('/reset-password/verify', resetPass2)
router.post('/reset-password/confirm', resetPass3)
router.delete('/account', requireAuth, deleteAccount)
router.patch('/change-password', requireAuth, changePassword)

module.exports = router
