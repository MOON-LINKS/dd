# Testing Session — Progress Notes (Postman, via routes.md)

Picks up from `12.testing/routes.md`. This is a running log — update it as
testing continues tomorrow rather than starting a new file, so nothing gets
retested or forgotten.

---

## ✅ FULLY TESTED — passing

| Group | Routes covered | Notes |
|---|---|---|
| **Auth** | register, verify-otp, me | logout, logout-all, delete-account **NOT tested yet** — see below |
| **Organizations** | create, list, get, update | delete + logo **deferred** (logo needs Assets) |
| **Workers** | create, list, get, update, hours-summary | delete + asset upload **deferred** |
| **Clients** | create, list, get, update, add feedback, list feedback | delete **deferred** |
| **Job Templates** | list (manager), create (admin), update (admin) | needed `ADMIN_EMAILS` in `.env` — see Code Changes below |
| **Jobs** | create, list, update, postpone, get snapshot, save snapshot | delete **deferred** |
| **Expenses** | create, list, get, update, delete | delete fully tested — soft-delete confirmed working |
| **Upcoming Bills** | create, list, get, update, mark-paid, convert-to-expense | plain delete not separately tested (bill was consumed by convert) |
| **Invoices** | generate, list, get, analytics, record payment, generate PDF, send email, branding get/update, history log | idempotency confirmed (2nd generate = 0 invoices) |
| **Referrals** | get my code (null, pre-payment — correct), earnings (zeros), history (empty), validate (public, invalid code) | admin payout routes **deferred**, need real Stripe-driven earnings |
| **Bio Page (editor)** | get/create draft, update draft, add button x2, update button, reorder, publish (v1), unpublish, list versions, rollback to v1, republish (v2) | fully exercised including version history |
| **Bio Page (public)** | slug-check, get data (JSON), get rendered HTML, 404 after unpublish | all correct |

---

## ⏳ NOT YET TESTED — pick up here tomorrow

**In suggested order** (dependencies first):

1. **Assets** (`POST /assets`, `DELETE /assets/:assetId`) — multipart file upload via
   Postman form-data. This is the first real test of `sharp` actually
   processing an image (the Node-version fix from session start). Also
   needed to finish:
   - `PATCH /organizations/:id/logo` (deferred from Organizations)
   - `PATCH /workers/:id/asset` (deferred from Workers)
2. **Cron jobs** (`POST /cron/generate-monthly-invoices`,
   `POST /cron/send-bill-reminders`) — need `x-cron-secret` header matching
   `CRON_SECRET` in `.env`. No Stripe dependency, can do anytime.
3. **Stripe test-mode setup** — get API keys + create at least one
   Product/Price in Stripe test mode. Blocks everything below.
4. **Billing/Payments** (`checkout`, `change-plan`, `cancel`, `portal`) —
   needs a real `stripe_price_id_monthly`/`yearly` on a plan row (our
   manually-inserted "Test Unlimited" plan has none — will need a new
   plan row with real Stripe price IDs, or update the existing one).
5. **Webhooks** (`/webhooks/stripe`, `/webhooks/apple`) — can't hit
   directly from Postman (signature verification). Use `stripe listen` /
   `stripe trigger` from the Stripe CLI once keys are set up.
6. **Referrals admin payouts** (`POST /admin/referrals/payouts`,
   `GET /admin/referrals/payouts/pending`) — needs real `referral_earnings`
   rows, which only get created from a real Stripe payment by a referred
   org. Blocked on #3/#4.
7. **Apple IAP** (`POST /billing/apple/register`) — needs real Apple
   Developer credentials + certs (`certs/` folder, `APPLE_*` env vars per
   `11.files/BATCH_NOTES.md`). Likely hardest to test without a real Apple
   account — may end up deferred indefinitely.

**Deletes — do these LAST, in this order** (dependency-safe, and each one
destroys test data other tests rely on):
8. `DELETE /organizations/:id/jobs/:jobId`
9. `DELETE /organizations/:id/workers/:workerId`
10. `DELETE /organizations/:id/clients/:clientId`
11. `DELETE /organizations/:id` (body: `password`)

**Auth session-enders — do these VERY LAST** (each one invalidates your
current session / cookie, so nothing else can be tested after):
12. `POST /auth/logout`
13. `POST /auth/logout-all`
14. `DELETE /auth/account` (body: `email`, `password`) — this deletes the
    test user entirely; only do this once you're fully done, or re-register
    first if you want to keep testing after

---

## 🔑 Test data created (for continuing tomorrow)

```
User:            moonlinksme@gmail.com (password: TestPass123!)
User ID:         02c52e60-b66c-4e74-883a-c8c9bd9b0b88
Organization:    3ab56c23-bc15-4e6b-8526-10583f2a99e0  ("Test Construction Co Updated")
  plan_id:       manually assigned — see "Test Unlimited" plan below
Worker:          c0d02b22-c48e-400d-bf74-6292394d8c7c  ("John Builder Updated", hourly $25)
Client:          5b772391-3ce0-4df2-84f6-3f93ffd6d617  ("Acme Retail")
Job Template:    a0de6770-9e8d-4b83-995d-fc2697727cea  ("Standard Renovation Job")
Job:             b0b79100-2845-4cc2-a5fe-c7ba9ae33f60  (in_progress, due 2026-09-21, 1 day logged: 2026-09-15, 8hrs)
Invoice:         43960564-0632-4ef2-acad-a1d2f72a8735  (paid in full, PDF generated, emailed)
Bio Page:        46eee938-5bc7-432d-839e-8b5866df91cb  (slug: test-construction-co, published v2)
  Buttons:       6706b8ff-8567-4efd-845f-d837cd52a966 (Visit Website)
                 80da764c-54e3-4cfa-b4f1-6296e71524c8 (Call Our Office)
```

Base URL: `http://localhost:3000` (confirm `.env` PORT still matches).

---

## 🗄️ Database changes made THIS SESSION (manual, via pgAdmin)

The live DB was missing several tables/columns from later migration files
that were never actually run. These were applied ad-hoc, in this order, as
errors surfaced. **If you set up a fresh database or a second machine, run
these in this exact order** (or just run `2.files/schema.sql` fresh, then
005, 007, 008, 009 as originally planned — skip 006, it's already inside
schema.sql):

1. `CREATE TABLE user_sessions` (+ 2 indexes) — was in `2.files/schema.sql`
   but hadn't been run against this particular DB yet.
2. `ALTER TABLE organizations ALTER COLUMN plan_id DROP NOT NULL`
3. `ALTER TABLE organizations ADD COLUMN stripe_customer_id VARCHAR(100) UNIQUE`
4. `ALTER TABLE subscribed_services ADD CONSTRAINT uq_subscribed_services_external_id UNIQUE (external_subscription_id)`
5. Manual test data: `INSERT INTO plans (name='Test Unlimited', max_workers=-1, modules=[...], history_months=24)`
   then `UPDATE organizations SET plan_id = <that plan's id> WHERE id = '3ab56c23-...'`
   — **this bypasses the real Stripe checkout flow**, purely for unblocking
   plan-gated routes (Workers, etc.) during testing. Not a real subscription.
6. `CREATE TABLE email_log` (+ 2 indexes) — migration 007
7. `ALTER TABLE plans ADD COLUMN feature_limits JSONB NOT NULL DEFAULT '{}'` — migration 008
8. `CREATE TABLE bio_page_snapshots` (+ index) — migration 008
9. `CREATE TABLE referral_earnings`, `CREATE TABLE referral_payouts` (+ FK + 3 indexes) — migration 009

**Still not run / not needed yet:** nothing else from 005/007/008/009 is
outstanding — all their table-creating statements have now been applied.
Only the Stripe-dependent *usage* of these tables (real subscriptions,
real referral earnings) is still untested — the schema itself is ready.

---

## 🔧 Code / config changes made this session

- **`utils/mailer.js`** — switched from generic `SMTP_*` env vars (never
  worked, `EAUTH`/missing credentials) to Gmail service transport using
  `GMAIL_USER` / `GMAIL_APP_PASSWORD` (matches the Moon Links pattern).
  `.env`'s old `SMTP_*`/`MAIL_FROM` vars are no longer read anywhere —
  safe to remove.
- **`.env`** — added `ADMIN_EMAILS=moonlinksme@gmail.com` (needed for
  Job Template admin routes to pass `requireAdmin`).
- **`.env`** — confirm `PORT` matches whatever you actually run
  (`routes.md` was written assuming 4000; we've been running on 3000).

---

## 🐛 Minor issues noted (not blockers, fix whenever)

- **Invoice email subject line** renders JS's full `Date.toString()`
  output (e.g. `"Tue Sep 01 2026 00:00:00 GMT+0300 (Eastern European
  Summer Time)"`) instead of a formatted date. Cosmetic, in
  `utils/emailTemplates.js`'s `invoiceEmail` builder.
- **Bio page `call`-type button `url`** must be the raw phone number
  only (e.g. `+96170123456`), NOT prefixed with `tel:` — the renderer
  (`utils/bioPageRenderer.js` line ~10) always prepends `tel:` itself.
  Passing an already-prefixed value doubles it (`tel:tel:...`). Worth
  either documenting this clearly for frontend, or making the renderer
  strip an existing `tel:` prefix defensively.
- **"Powered by X" footer** on public bio pages reads `process.env.APP_NAME`
  (currently `YourAppName`) — just update `.env` once a real product name
  is picked.
