# Testing Session — Progress Notes (Postman, via routes.md)

Picks up from `12.testing/routes.md`. This is a running log — update it as
testing continues rather than starting a new file, so nothing gets retested
or forgotten.

---

## ✅ FULLY TESTED — passing

| Group | Routes covered | Notes |
|---|---|---|
| **Auth** | register, verify-otp, me, login (single + multi-session), logout, logout-all, reset-password (request/verify/confirm), delete-account | **all tested day 2**.|
| **Organizations** | create, list, get, update, update logo, **delete** | fully done — delete tested day 2 (password-confirmed, soft-delete) |
| **Workers** | create, list, get, update, hours-summary, update asset, **delete** | fully done — delete tested day 2 (soft-delete, double-delete correctly 404s) |
| **Clients** | create, list, get, update, add feedback, list feedback, **delete** | fully done — delete tested day 2 |
| **Job Templates** | list (manager), create (admin), update (admin) | needed `ADMIN_EMAILS` in `.env` — see Code Changes below |
| **Jobs** | create, list, update, postpone, get snapshot, save snapshot, **delete** | fully done — delete tested day 2 |
| **Expenses** | create, list, get, update, delete | soft-delete confirmed |
| **Upcoming Bills** | create, list, get, update, mark-paid, convert-to-expense | plain delete not separately tested (bill was consumed by convert) |
| **Invoices** | generate, list, get, analytics, record payment, generate PDF, send email, branding get/update, history log | idempotency confirmed (2nd generate = 0 invoices) |
| **Referrals** | get my code (null, pre-payment — correct), earnings (zeros), history (empty), validate (public, invalid code) | admin payout routes **deferred**, need real Stripe-driven earnings |
| **Bio Page (editor)** | get/create draft, update draft, add button x2, update button, reorder, publish (v1), unpublish, list versions, rollback to v1, republish (v2) | fully exercised including version history |
| **Bio Page (public)** | slug-check, get data (JSON), get rendered HTML, 404 after unpublish | all correct |
| **Assets** | upload (org logo + worker profile pic), sharp compression, static file serving, org logo attach, worker asset attach, delete (DB row + disk file) | **tested day 2** — first real sharp test, passed clean |
| **Cron jobs** | generate-monthly-invoices (correctly gated by active subscriptions, 0 processed — expected), send-bill-reminders (real email sent, dedup on 2nd run confirmed) | **tested day 2** — no Stripe dependency |

---

## ⏳ NOT YET TESTED — pick up here next session

**In suggested order** (dependencies first):

1. **Stripe test-mode setup** — get API keys + create at least one
   Product/Price in Stripe test mode. Blocks everything below.
2. **Billing/Payments** (`checkout`, `change-plan`, `cancel`, `portal`) —
   needs a real `stripe_price_id_monthly`/`yearly` on a plan row (the old
   manually-inserted "Test Unlimited" plan had none — that org is gone now
   anyway, see below — a fresh test org will need a plan row with real
   Stripe price IDs).
3. **Webhooks** (`/webhooks/stripe`, `/webhooks/apple`) — can't hit
   directly from Postman (signature verification). Use `stripe listen` /
   `stripe trigger` from the Stripe CLI once keys are set up.
4. **Referrals admin payouts** (`POST /admin/referrals/payouts`,
   `GET /admin/referrals/payouts/pending`) — needs real `referral_earnings`
   rows, which only get created from a real Stripe payment by a referred
   org. Blocked on #1/#2.
5. **Apple IAP** (`POST /billing/apple/register`) — needs real Apple
   Developer credentials + certs (`certs/` folder, `APPLE_*` env vars per
   `11.files/BATCH_NOTES.md`). Likely hardest to test without a real Apple
   account — may end up deferred indefinitely.
6. **Upcoming Bills — plain delete** — never tested standalone (the one
   bill we created got consumed by convert-to-expense). Low priority, code
   already reviewed and is a simple hard delete.

**Also outstanding — bigger, separate pieces of work (not just testing):**
- The `deleteAccount` / `deleteOrganization` cascade rewrite (see Known
  Gaps below) — needs to be *built* before it can be tested.
- Tap Payments integration (parallel to Stripe) — not started.
- Org-count-based pricing plans (Plan 1 = 1 org ... Plan 5 = 5 orgs) —
  schema change not yet designed, see Pricing section below.

---

## 🔑 Test data — ALL DELETED as of end of day 2

Everything below was **intentionally torn down** during today's delete/
auth-session testing (job → worker → client → organization → logout →
logout-all → reset-password → delete-account, all confirmed working).
**None of these IDs are valid anymore:**

```
[deleted] User:          moonlinksme@gmail.com
[deleted] Organization:  3ab56c23-bc15-4e6b-8526-10583f2a99e0
[deleted] Worker:        c0d02b22-c48e-400d-bf74-6292394d8c7c
[deleted] Client:        5b772391-3ce0-4df2-84f6-3f93ffd6d617
[deleted] Job:           b0b79100-2845-4cc2-a5fe-c7ba9ae33f60
(Job Template, Invoice, Bio Page rows may still physically exist in the DB
 since only their parent org was soft-deleted, not a real cascade — see
 Known Gaps. Don't rely on them; they're orphaned, not verified-clean.)
```

**Next session starts from re-registering fresh** on the same Gmail
(`moonlinksme@gmail.com`) — this was the planned next step, not yet
actually re-run/confirmed as of this note.

Base URL: `http://localhost:3000` (confirm `.env` PORT still matches).

---

## 🗄️ Database changes made (manual, via pgAdmin) — cumulative

The live DB was missing several tables/columns from later migration files
that were never actually run. These were applied ad-hoc, in this order, as
errors surfaced. **If you set up a fresh database or a second machine, run
these in this exact order** (or just run `2.files/schema.sql` fresh, then
005, 007, 008, 009 as originally planned — skip 006, it's already inside
schema.sql):

1. `CREATE TABLE user_sessions` (+ 2 indexes) — was in `2.files/schema.sql`
   but hadn't been run against this particular DB yet.
2. `ALTER TABLE organizations ALTER COLUMN plan_id DROP NOT NULL`
3. `ALTER TABLE organizations ADD COLUMN stripe_customer_id VARCHAR(100) UNIQUE`
4. `ALTER TABLE subscribed_services ADD CONSTRAINT uq_subscribed_services_external_id UNIQUE (external_subscription_id)`
5. Manual test data (now deleted along with the rest): `INSERT INTO plans
   (name='Test Unlimited', max_workers=-1, modules=[...], history_months=24)`
   then `UPDATE organizations SET plan_id = ...` — bypassed real Stripe
   checkout purely to unblock plan-gated routes during testing.
6. `CREATE TABLE email_log` (+ 2 indexes) — migration 007
7. `ALTER TABLE plans ADD COLUMN feature_limits JSONB NOT NULL DEFAULT '{}'` — migration 008
8. `CREATE TABLE bio_page_snapshots` (+ index) — migration 008
9. `CREATE TABLE referral_earnings`, `CREATE TABLE referral_payouts` (+ FK + 3 indexes) — migration 009

**Still not run / not needed yet:** nothing else from 005/007/008/009 is
outstanding — all their table-creating statements have now been applied.
Only the Stripe-dependent *usage* of these tables (real subscriptions,
real referral earnings) is still untested — the schema itself is ready.

---

## 🔧 Code / config changes made — cumulative

- **`utils/mailer.js`** — switched from generic `SMTP_*` env vars (never
  worked, `EAUTH`/missing credentials) to Gmail service transport using
  `GMAIL_USER` / `GMAIL_APP_PASSWORD` (matches the Moon Links pattern).
  `.env`'s old `SMTP_*`/`MAIL_FROM` vars are no longer read anywhere —
  safe to remove.
- **`.env`** — added `ADMIN_EMAILS=moonlinksme@gmail.com` (needed for
  Job Template admin routes to pass `requireAdmin`).
- **`.env`** — added `CRON_SECRET=<test value>` (needed for both cron routes).
- **`.env`** — added `CDN_BASE_URL=http://localhost:3000/images` (local static
  serving for uploaded assets).
- **`.env`** — confirm `PORT` matches whatever you actually run
  (`routes.md` was written assuming 4000; we've been running on 3000).
- **`controllers/assetController.js`** — `ASSETS_ROOT` renamed from
  `assets_storage` → `images`; filenames now include a `YYYY-MM-DD` date
  segment, with **underscores** as separators (not hyphens — the owner
  UUID already contains hyphens, so hyphen-only separators made the parts
  impossible to split back apart unambiguously).
- **`utils/invoicePdfStorage.js`** — same two changes, mirrored (it
  deliberately copies `assetController.js`'s storage convention).
- **`index.js`** — added `app.use('/images', express.static(path.join(__dirname,
  'images')))` (+ `const path = require('path')`) so uploaded files are
  actually servable locally during testing.

---
## Password Validation

Unified password validation across `register`, `changePassword`, and `resetPass3` (Node backend) via `utils/validatePassword.js` — single source of truth for the rules instead of each endpoint enforcing its own.

Rules: min 6 characters, no spaces, must contain at least one letter, one number, and one symbol from the allowed set. Disallowed symbols return `"(symbol) is not allowed"` specifically.

**TODO:** implement matching validation in Dart (frontend) — client-side check only, for UX. Backend validation remains the actual enforcement boundary. Keep both in sync manually when rules change (min length, allowed symbols).

## 🚧 Known gaps / design decisions (found during Auth+Delete testing, day 2)

**`DELETE /auth/account` — incomplete, needs a real cascade:**
Currently only stamps `users.deleted_at` — no cascade to owned organizations,
no Stripe/Apple subscription cancellation. If the user owned a paying org,
Stripe would keep billing forever with nobody left to cancel it.

**`DELETE /organizations/:id` — same gap, one level down:**
Only stamps `organizations.deleted_at` — no cascade to that org's workers,
clients, jobs, expenses, bills, invoices, bio pages, or assets/files on disk.

**Agreed design for both, once we build the fix:**
- **Hard-delete** everything owned by the account/org: workers, clients, jobs
  (+ job_days/assignments), expenses, upcoming_bills, invoices (+ line
  items), bio_pages (+ buttons/snapshots), assets — both the DB rows AND the
  physical files on disk (reuse `deleteAsset`'s `fs.unlink` pattern)
- **Keep, never delete**: `subscribed_services` rows — just deactivate them
  (`is_active = FALSE`), same as `deleteOrganization` already does for
  Stripe/Apple. This becomes the permanent "who has ever paid me" ledger —
  needed for accounting/tax/dispute records regardless of what else the user
  asks to erase.
- Frontend must show a terms-and-conditions / "this is permanent"
  confirmation before calling either delete endpoint.
- Both cascades should probably share one extracted helper function rather
  than duplicating the delete-everything logic in two controllers.
- This is real, non-trivial work (safe multi-table cascade in the right FK
  order, inside a transaction) — treat as its own focused session, not a
  quick patch. **Not yet built.**

## 💡 Pricing model decision (new, not yet implemented)

Plans should be gated by **how many organizations a user can create**, not
billed per-org separately: e.g. Plan 1 = 1 org, Plan 2 = 2 orgs,
Plan 3 up to 5 orgs. Current `plans`/`organizations` schema has one `plan_id`
per org, not a per-user org-count cap. Will need a new
`plans.max_organizations`-style column and a check at org-creation time
(similar to how `canAddWorker` already checks `plans.max_workers`). **Open
question not yet resolved:** do all orgs under one user share the same
plan/limits, or could different orgs under the same user have different
tiers? Affects whether the cap lives on the plan itself or needs a more
flexible model.

---

## 🐛 Minor issues noted (not blockers, fix whenever)

- **Invoice email subject line** renders JS's full `Date.toString()`
  output (e.g. `"Tue Sep 01 2026 00:00:00 GMT+0300 (Eastern European
  Summer Time)"`) instead of a formatted date. Same root cause affects the
  bill-reminder email subject too. Cosmetic, in `utils/emailTemplates.js`.
- **Bio page `call`-type button `url`** must be the raw phone number
  only (e.g. `+96170123456`), NOT prefixed with `tel:` — the renderer
  (`utils/bioPageRenderer.js` line ~10) always prepends `tel:` itself.
  Passing an already-prefixed value doubles it (`tel:tel:...`). Worth
  either documenting this clearly for frontend, or making the renderer
  strip an existing `tel:` prefix defensively.
- **"Powered by X" footer** on public bio pages reads `process.env.APP_NAME`
  (currently `YourAppName`) — just update `.env` once a real product name
  is picked.
- **`logout-all`'s error handling** — sending a request with no `password`
  field throws inside `bcrypt.compare(undefined, hash)`, caught by the
  generic catch block as a vague 500 ("There was an error logging out from
  all sessions") instead of a clear 400 "password is required." Not a
  functional bug (the endpoint still requires — and correctly checks —
  the password), just a rough edge on the error message.

  ## 🐛 Minor Issues — Fixed

- **Invoice/bill-reminder email dates** — added `formatDate()` helper in `utils/emailTemplates.js` (outputs `YYYY-MM-DD`), applied to `periodStart`/`periodEnd` in `invoiceEmail` and `dueDate` in `billReminderEmail`. No longer shows raw `Date.toString()` output.
- **Bio page `tel:` double-prefix** — `utils/bioPageRenderer.js` now strips any existing `tel:` prefix before adding its own (`href = tel:${button.url.replace(/^tel:/i, '')}`), defensive against bad frontend data.
- **`logout-all` vague 500 on missing password** — added `if (!password) return res.status(400)...` guard in `logoutFromAll` (`controllers/authController.js`), before the `bcrypt.compare` call. Now returns a clear 400 instead of crashing into the generic catch block.

**Retested:** confirmed all three working after restart — need to re-log in `12.testing/routes.md`'s test log once re-run against fresh data.
