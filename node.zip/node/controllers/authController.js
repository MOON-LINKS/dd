// Adapted from the Moon Links auth pattern: Redis-backed OTP with TTL, dual cookie/bearer
// token support via the x-client-type header, multi-device session tracking via user_sessions.
// Rewritten against Postgres (pg) + schema.sql, standardized to async/await throughout
// (the Moon Links original mixed callback and promise styles).

const db = require('../utils/db')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const crypto = require('crypto')
const { generateOTP } = require('../utils/otp')
const { redisClient } = require('../utils/redis')
const { sendMail } = require('../utils/mailer')
const { registrationOtpEmail, passwordResetOtpEmail, welcomeEmail } = require('../utils/emailTemplates')

const OTP_TTL_SECONDS = 60 * 3        // 3 minutes
const RESET_TOKEN_TTL_SECONDS = 60 * 5 // 5 minutes

// Sends the auth token back either as a bearer-friendly JSON field (mobile app)
// or as an httpOnly cookie (web), matching the Moon Links x-client-type convention.
const sendAuthResponse = (req, res, { statusCode, message, token }) => {
    if (req.headers['x-client-type'] === 'app') {
        return res.status(statusCode).json({ message, token })
    }
    res.cookie('auth_token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'Lax'
    })
    return res.status(statusCode).json({ message, token })
}

// Deletes every active session for a user: decodes each stored JWT to find its
// Redis session key, clears those, then wipes the user_sessions rows.
// Shared by logoutFromAll, resetPass3, and deleteAccount.
const invalidateAllSessions = async (userId) => {
    const { rows: sessions } = await db.query(
        'SELECT jwt_token FROM user_sessions WHERE user_id = $1',
        [userId]
    )
    for (const session of sessions) {
        try {
            const decoded = jwt.decode(session.jwt_token)
            if (decoded?.sessionId) await redisClient.del(`session:${decoded.sessionId}`)
        } catch (err) {
            console.error('Redis delete error for session:', err)
        }
    }
    await db.query('DELETE FROM user_sessions WHERE user_id = $1', [userId])
}

// ------------------------------------------------------------------
// REGISTER — creates (or re-upserts, if not yet verified) a user row,
// issues an OTP via Redis, emails it.
// ------------------------------------------------------------------
const register = async (req, res) => {
    const { email, password, fullName } = req.body
    try {
        const { rows: existing } = await db.query(
            'SELECT id, otp_verified FROM users WHERE email = $1',
            [email]
        )
        if (existing.length > 0 && existing[0].otp_verified) {
            return res.status(401).json({ message: 'this user already registered' })
        }

        const passwordHash = await bcrypt.hash(password, 10)

        // ON CONFLICT lets an unverified registration be retried/updated without erroring
        const { rows: upserted } = await db.query(
            `INSERT INTO users (email, password_hash, full_name)
             VALUES ($1, $2, $3)
             ON CONFLICT (email) DO UPDATE
               SET full_name = EXCLUDED.full_name,
                   password_hash = EXCLUDED.password_hash
             RETURNING id`,
            [email, passwordHash, fullName]
        )
        const userId = upserted[0].id

        const existingOtp = await redisClient.get(`register:${userId}:otp`).catch(() => null)
        const otp = existingOtp || generateOTP()
        const verificationId = crypto.randomUUID()

        await redisClient.set(`register:${userId}:otp`, otp, { EX: OTP_TTL_SECONDS })
        await redisClient.set(`verify:${verificationId}`, userId, { EX: OTP_TTL_SECONDS })

        const { subject, text, html } = registrationOtpEmail({ name: fullName, otp })
        await sendMail({ to: email, subject, text, html })

        res.status(201).json({
            message: existingOtp ? 'new otp sent' : 'please verify',
            verificationId
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'there is an issue registering this user' })
    }
}

// ------------------------------------------------------------------
// VERIFY OTP — confirms registration, creates the first session,
// sends a welcome email.
// ------------------------------------------------------------------
const verifyOTP = async (req, res) => {
    const { otp, deviceName, verificationId } = req.body
    try {
        const userId = await redisClient.get(`verify:${verificationId}`)
        if (!userId) return res.status(400).json({ message: 'Invalid or expired verification' })

        const savedOtp = await redisClient.get(`register:${userId}:otp`)
        if (otp !== savedOtp) return res.status(400).json({ message: 'Invalid OTP' })

        const { rows: userRows } = await db.query(
            'UPDATE users SET otp_verified = TRUE WHERE id = $1 RETURNING email, full_name',
            [userId]
        )

        const sessionId = crypto.randomUUID()
        const token = jwt.sign({ userId, sessionId }, process.env.JWT_SECRET)

        await db.query(
            'INSERT INTO user_sessions (user_id, device_name, jwt_token) VALUES ($1, $2, $3)',
            [userId, deviceName, token]
        )

        await redisClient.set(`session:${sessionId}`, userId)
        await redisClient.del(`verify:${verificationId}`)
        await redisClient.del(`register:${userId}:otp`)

        const { subject, text, html } = welcomeEmail({ name: userRows[0].full_name })
        sendMail({ to: userRows[0].email, subject, text, html }).catch((err) =>
            console.error('welcome email failed to send:', err)
        )

        sendAuthResponse(req, res, { statusCode: 201, message: 'user registered', token })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'error verifying please try again later' })
    }
}

// ------------------------------------------------------------------
// LOGIN
// ------------------------------------------------------------------
const login = async (req, res) => {
    const { email, password, deviceName } = req.body
    try {
        const { rows } = await db.query(
            'SELECT id, password_hash, otp_verified FROM users WHERE email = $1 AND deleted_at IS NULL',
            [email]
        )
        if (rows.length === 0) {
            return res.status(404).json({ message: 'there is no registration on this account' })
        }
        if (!rows[0].otp_verified) {
            return res.status(400).json({ message: 'user must finish registration before accessing his account' })
        }

        const isPassVerified = await bcrypt.compare(password, rows[0].password_hash)
        if (!isPassVerified) return res.status(400).json({ message: 'email or password are not correct' })

        const userId = rows[0].id
        const sessionId = crypto.randomUUID()
        const token = jwt.sign({ userId, sessionId }, process.env.JWT_SECRET)

        await db.query(
            'INSERT INTO user_sessions (user_id, device_name, jwt_token) VALUES ($1, $2, $3)',
            [userId, deviceName, token]
        )
        await redisClient.set(`session:${sessionId}`, userId)

        sendAuthResponse(req, res, { statusCode: 200, message: 'user logged in', token })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'error accessing the database' })
    }
}

// ------------------------------------------------------------------
// LOGOUT — single device. Requires auth middleware to have set req.user
// from the JWT ({ id, sessionId }).
// ------------------------------------------------------------------
const logout = async (req, res) => {
    const { id, sessionId } = req.user
    const token = req.cookies?.auth_token || req.headers['authorization']?.split(' ')[1]
    try {
        await db.query(
            'DELETE FROM user_sessions WHERE user_id = $1 AND jwt_token = $2',
            [id, token]
        )
        await redisClient.del(`session:${sessionId}`)
        res.clearCookie('auth_token', {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'Lax'
        })
        res.status(200).json({ message: 'logged out' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'there was an issue logging out' })
    }
}

// ------------------------------------------------------------------
// LOGOUT FROM ALL DEVICES — requires password re-confirmation.
// ------------------------------------------------------------------
const logoutFromAll = async (req, res) => {
    const { password } = req.body
    const { id } = req.user
    try {
        const { rows } = await db.query('SELECT password_hash FROM users WHERE id = $1', [id])
        if (rows.length === 0) return res.status(404).json({ message: 'User not found' })

        const isPassSame = await bcrypt.compare(password, rows[0].password_hash)
        if (!isPassSame) return res.status(401).json({ message: 'Incorrect password' })

        await invalidateAllSessions(id)
        res.status(200).json({ message: 'Logged out from all devices' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'There was an error logging out from all sessions' })
    }
}

// ------------------------------------------------------------------
// GET USER INFO — used to populate the header org-info dropdown
// (email, organization type/name) plus session list for "manage devices".
// ------------------------------------------------------------------
const getUserInfo = async (req, res) => {
    const id = req.user.id
    try {
        const { rows } = await db.query(
            `SELECT
                u.id AS user_id,
                u.email,
                u.full_name,
                u.otp_verified,
                s.id AS session_id,
                s.device_name,
                s.last_active,
                o.id AS organization_id,
                o.name AS organization_name,
                o.organization_type,
                o.stripe_customer_id
             FROM users u
             LEFT JOIN user_sessions s ON s.user_id = u.id
             LEFT JOIN organizations o ON o.owner_user_id = u.id AND o.deleted_at IS NULL
             WHERE u.id = $1`,
            [id]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'User not found' })

        const user = {
            id: rows[0].user_id,
            email: rows[0].email,
            fullName: rows[0].full_name,
            otpVerified: rows[0].otp_verified,
            // Moved off the top-level user object — a user can own more than one
            // organization, and each has its own Stripe customer, so this only
            // makes sense per-org. (Was `u.stripe_customer_id`, a column that
            // never existed on `users`; it lives on `organizations`. See 10.files
            // BATCH_NOTES.md.)
            organizations: [...new Map(
                rows.filter((r) => r.organization_id).map((r) => [r.organization_id, {
                    id: r.organization_id,
                    name: r.organization_name,
                    organizationType: r.organization_type,
                    stripeCustomerId: r.stripe_customer_id
                }])
            ).values()],
            sessions: [...new Map(
                rows.filter((r) => r.session_id).map((r) => [r.session_id, {
                    sessionId: r.session_id,
                    deviceName: r.device_name,
                    lastActive: r.last_active
                }])
            ).values()]
        }
        res.status(200).json({ user })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'error fetching user info' })
    }
}

// ------------------------------------------------------------------
// RESET PASSWORD — 3-step flow: request OTP, verify OTP -> resetToken,
// consume resetToken -> set new password (and wipe all sessions).
// ------------------------------------------------------------------
const resetPass1 = async (req, res) => {
    const { email } = req.body
    try {
        let id = req.user?.id
        if (!id) {
            const { rows } = await db.query(
                'SELECT id FROM users WHERE email = $1 AND otp_verified = TRUE AND deleted_at IS NULL',
                [email]
            )
            if (rows.length === 0) {
                return res.status(404).json({ message: 'No verified user found with this credential' })
            }
            id = rows[0].id
        }

        const existingOtp = await redisClient.get(`resetPass:${id}:otp`).catch(() => null)
        const otp = existingOtp || generateOTP()
        const resetId = crypto.randomUUID()

        await redisClient.set(`resetPass:${id}:otp`, otp, { EX: OTP_TTL_SECONDS })
        await redisClient.set(`verifyResetPass:${resetId}`, id, { EX: OTP_TTL_SECONDS })

        const { subject, text, html } = passwordResetOtpEmail({ otp })
        await sendMail({ to: email, subject, text, html })

        res.status(201).json({
            message: existingOtp ? 'otp resent, check your inbox' : 'otp generated, please verify',
            resetId
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'error starting password reset' })
    }
}

const resetPass2 = async (req, res) => {
    const { resetId, otp } = req.body
    try {
        const userId = await redisClient.get(`verifyResetPass:${resetId}`)
        const mainOtp = await redisClient.get(`resetPass:${userId}:otp`)
        if (!userId || !mainOtp) return res.status(404).json({ message: 'your otp is expired, send another one' })
        if (String(otp) !== String(mainOtp)) return res.status(400).json({ message: 'your otp does not match' })

        await redisClient.del(`verifyResetPass:${resetId}`)
        await redisClient.del(`resetPass:${userId}:otp`)

        const resetToken = crypto.randomUUID()
        await redisClient.set(`resetToken:${resetToken}`, userId, { EX: RESET_TOKEN_TTL_SECONDS })

        res.status(201).json({ message: 'otp correct, change password', resetToken })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'error verifying reset otp' })
    }
}

const resetPass3 = async (req, res) => {
    const { newPass, resetToken } = req.body
    try {
        const userId = await redisClient.get(`resetToken:${resetToken}`)
        if (!userId) return res.status(400).json({ message: 'reset token invalid or expired' })

        const passwordHash = await bcrypt.hash(newPass, 10)
        await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, userId])
        await redisClient.del(`resetToken:${resetToken}`)

        await invalidateAllSessions(userId)

        res.status(200).json({ message: 'password changed and logged out from previous sessions' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'error resetting password' })
    }
}

// ------------------------------------------------------------------
// DELETE ACCOUNT — spec Section 9: requires re-entering both email
// and password as confirmation. Soft delete + wipe every session.
// ------------------------------------------------------------------
const deleteAccount = async (req, res) => {
    const { email, password } = req.body
    const { id } = req.user
    try {
        const { rows } = await db.query(
            'SELECT email, password_hash FROM users WHERE id = $1 AND deleted_at IS NULL',
            [id]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'User not found' })

        const emailMatches = rows[0].email.toLowerCase() === String(email).toLowerCase()
        const passwordMatches = await bcrypt.compare(password, rows[0].password_hash)
        if (!emailMatches || !passwordMatches) {
            return res.status(401).json({ message: 'email or password confirmation did not match' })
        }

        await db.query('UPDATE users SET deleted_at = NOW() WHERE id = $1', [id])
        await invalidateAllSessions(id)

        res.clearCookie('auth_token', {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'Lax'
        })
        res.status(200).json({ message: 'account deleted' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'error deleting account' })
    }
}
const changePassword = async (req, res) => {
    const { id } = req.user
    const { currentPassword, newPassword } = req.body
    try {
        if (!currentPassword || !newPassword) {
            return res.status(400).json({ message: 'currentPassword and newPassword are required' })
        }
        if (newPassword.length < 8) {
            return res.status(400).json({ message: 'newPassword must be at least 8 characters' })
        }

        const { rows } = await db.query(
            'SELECT password_hash FROM users WHERE id = $1 AND deleted_at IS NULL',
            [id]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'user not found' })

        const isCurrentPassCorrect = await bcrypt.compare(currentPassword, rows[0].password_hash)
        if (!isCurrentPassCorrect) return res.status(401).json({ message: 'current password is incorrect' })

        const isSameAsOld = await bcrypt.compare(newPassword, rows[0].password_hash)
        if (isSameAsOld) return res.status(400).json({ message: 'new password must be different from the current password' })

        const newPasswordHash = await bcrypt.hash(newPassword, 10)
        await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newPasswordHash, id])

        // Same pattern as resetPass3 — a password change is a good moment
        // to log every other session out, in case the change was prompted
        // by a lost/compromised device.
        await invalidateAllSessions(id)

        res.status(200).json({ message: 'password changed and logged out from other sessions' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not change password' })
    }
}
module.exports = {
    register,
    verifyOTP,
    login,
    logout,
    logoutFromAll,
    getUserInfo,
    resetPass1,
    resetPass2,
    resetPass3,
    deleteAccount,
    changePassword
}
