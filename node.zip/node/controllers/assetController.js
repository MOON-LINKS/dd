const sharp = require('sharp')
const fs = require('fs')
const path = require('path')
const db = require('../utils/db')
const { assertOwnedOrganizationId } = require('../utils/orgAccess')
const { ASSET_OWNER_TYPES } = require('../utils/constants')

// One config, one place to tune quality/size per asset type.
// Rationale per type: a profile pic renders small (a circle avatar) so low
// quality is invisible; a bill/invoice photo needs to stay zoomable/legible
// since it's the proof record for a payment.
const ASSET_PRESETS = {
    logo: { quality: 90, width: 512 },
    profile_pic: { quality: 70, width: 300 },
    worker_id: { quality: 85, width: 1000 },
    bill: { quality: 92, width: 1600 },
    invoice_attachment: { quality: 92, width: 1600 },
    bio_page: { quality: 85, width: 1080 }
}

const ASSETS_ROOT = path.join(__dirname, '..', 'images')

// ------------------------------------------------------------------
// UPLOAD ASSET — generic endpoint used by every picker in the app
// (logo, worker profile pic, worker ID doc, bill proof, invoice
// attachment, bio page images). One route, one preset table.
// ------------------------------------------------------------------
const uploadAsset = async (req, res) => {
    try {
        const file = req.file
        const userId = req.user.id
        const { ownerType, ownerId, assetType } = req.body

        if (!file || !ownerType || !ownerId || !assetType) {
            return res.status(400).json({ message: 'file, ownerType, ownerId, and assetType are required' })
        }
        if (!ASSET_OWNER_TYPES.includes(ownerType)) {
            return res.status(400).json({ message: `Unknown ownerType: ${ownerType}` })
        }
        const preset = ASSET_PRESETS[assetType]
        if (!preset) {
            return res.status(400).json({ message: `Unknown assetType: ${assetType}` })
        }

        // Multi-tenancy check: the owner record (worker/bio_page/upcoming_bill/
        // organization) must actually belong to an org this user owns.
        const organizationId = await assertOwnedOrganizationId(userId, ownerType, ownerId)
        if (!organizationId) {
            return res.status(403).json({ message: 'you do not have access to this resource' })
        }

        // Frontend may request a lower quality (e.g. slow connection), but
        // never higher — the server always caps it at the preset ceiling.
        const requestedQuality = parseInt(req.body.quality, 10)
        const quality = Number.isFinite(requestedQuality)
            ? Math.min(requestedQuality, preset.quality)
            : preset.quality

        const orgFolder = path.join(ASSETS_ROOT, organizationId, ownerType)
        if (!fs.existsSync(orgFolder)) fs.mkdirSync(orgFolder, { recursive: true })

        const datePart = new Date().toISOString().slice(0, 10) // YYYY-MM-DD
        const fileName = `${ownerType}_${ownerId}_${datePart}_${Date.now()}_${Math.floor(Math.random() * 10000)}.webp`
        const filePath = path.join(orgFolder, fileName)

        await sharp(file.buffer)
            .resize(preset.width)
            .webp({ quality })
            .toFile(filePath)

        // Stored relative path keeps the CDN base URL out of the DB entirely
        // (spec Section 9) — prefixed as cdn.mydomain.com/imgs/{relativeFilename}
        const relativeFilename = `${organizationId}/${ownerType}/${fileName}`

        const { rows } = await db.query(
            `INSERT INTO assets (owner_type, owner_id, filename, mime_type)
             VALUES ($1, $2, $3, $4)
             RETURNING id, filename`,
            [ownerType, ownerId, relativeFilename, 'image/webp']
        )

        res.status(201).json({ assetId: rows[0].id, filename: rows[0].filename })
    } catch (err) {
        console.error('Upload error:', err)
        res.status(500).json({ message: 'could not upload asset' })
    }
}

// ------------------------------------------------------------------
// DELETE ASSET — removes both the DB row and the file on disk.
// ------------------------------------------------------------------
const deleteAsset = async (req, res) => {
    const { assetId } = req.params
    const userId = req.user.id
    try {
        const { rows } = await db.query(
            'SELECT owner_type, owner_id, filename FROM assets WHERE id = $1',
            [assetId]
        )
        if (rows.length === 0) return res.status(404).json({ message: 'asset not found' })

        const { owner_type, owner_id, filename } = rows[0]
        const organizationId = await assertOwnedOrganizationId(userId, owner_type, owner_id)
        if (!organizationId) return res.status(403).json({ message: 'you do not have access to this resource' })

        const filePath = path.join(ASSETS_ROOT, filename)
        fs.unlink(filePath, (err) => {
            if (err) console.error('Failed to delete file from disk:', err) // non-fatal — DB row still removed
        })

        await db.query('DELETE FROM assets WHERE id = $1', [assetId])
        res.status(200).json({ message: 'asset deleted' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'could not delete asset' })
    }
}

module.exports = { uploadAsset, deleteAsset, ASSET_PRESETS }
