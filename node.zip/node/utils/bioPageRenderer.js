const { resolveAssetUrl } = require('./cdn')
const { BIO_PAGE_COLOR_PRESETS } = require('./constants')

const escapeHtml = (str = '') =>
  String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))

const BUTTON_ICON = { call: '📞', link: '🔗', social: '★' }

const renderButtonHtml = (button) => {
  const href = button.buttonType === 'call'
    ? `tel:${button.url.replace(/^tel:/i, '')}`
    : button.url
  return `
    <a class="bp-button" href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer">
        <span class="bp-button-icon">${BUTTON_ICON[button.buttonType] || '🔗'}</span>
        <span>${escapeHtml(button.label)}</span>
    </a>`
}

// Builds a fully standalone HTML document — no external stylesheet
// dependency beyond a webfont link, so this string is exactly what gets
// cached in bio_pages.rendered_html and served byte-for-byte on every
// public visit (spec Section 3: "NOT live-rendered per visit").
const renderBioPageHtml = ({ title, shortBio, colorPreset, logoFilename, buttons = [] }) => {
  const colors = BIO_PAGE_COLOR_PRESETS[colorPreset] || BIO_PAGE_COLOR_PRESETS.default
  const logoUrl = resolveAssetUrl(logoFilename)
  const sortedButtons = [...buttons].sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0))

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title || 'Bio Page')}</title>
<style>
  :root {
    --bp-primary: ${colors.primary};
    --bp-secondary: ${colors.secondary};
    --bp-bg: ${colors.background};
    --bp-text: ${colors.text};
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif;
    background: var(--bp-bg); color: var(--bp-text);
    display: flex; justify-content: center; padding: 48px 16px;
  }
  .bp-card { max-width: 420px; width: 100%; text-align: center; }
  .bp-logo { width: 96px; height: 96px; border-radius: 50%; object-fit: cover; margin-bottom: 16px; border: 3px solid var(--bp-primary); }
  .bp-title { font-size: 22px; font-weight: 700; margin: 0 0 8px; }
  .bp-bio { font-size: 15px; opacity: 0.85; margin: 0 0 28px; line-height: 1.5; }
  .bp-button {
    display: flex; align-items: center; justify-content: center; gap: 8px;
    padding: 14px 20px; margin-bottom: 12px; border-radius: 12px;
    background: var(--bp-primary); color: #fff; text-decoration: none;
    font-size: 15px; font-weight: 600; transition: opacity 0.15s;
  }
  .bp-button:hover { opacity: 0.85; }
  .bp-button-icon { font-size: 16px; }
  .bp-footer { margin-top: 32px; font-size: 12px; opacity: 0.5; }
</style>
</head>
<body>
  <div class="bp-card">
    ${logoUrl ? `<img class="bp-logo" src="${escapeHtml(logoUrl)}" alt="${escapeHtml(title || '')}" />` : ''}
    <h1 class="bp-title">${escapeHtml(title || '')}</h1>
    ${shortBio ? `<p class="bp-bio">${escapeHtml(shortBio)}</p>` : ''}
    ${sortedButtons.map(renderButtonHtml).join('')}
    <div class="bp-footer">Powered by ${process.env.APP_NAME || 'YOUR_APP_NAME'}</div>
  </div>
</body>
</html>`
}

module.exports = { renderBioPageHtml }
