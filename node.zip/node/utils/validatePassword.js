// Symbols allowed in passwords — deliberately excludes quote/backslash/angle-bracket
// characters commonly used in SQL/HTML/script injection payloads, even though
// parameterized queries already protect the DB layer — this is defense in depth
// plus it keeps passwords safe to log/display without escaping headaches.
const ALLOWED_SYMBOLS = '!@#$%^&*()_+-=~.,?'
const ALLOWED_SYMBOLS_SET = new Set(ALLOWED_SYMBOLS.split(''))

const MIN_LENGTH = 6

const validatePassword = (password) => {
    if (typeof password !== 'string' || password.length === 0) {
        return { valid: false, message: 'password is required' }
    }

    if (/\s/.test(password)) {
        return { valid: false, message: 'no spaces allowed' }
    }

    if (password.length < MIN_LENGTH) {
        return { valid: false, message: `minimum ${MIN_LENGTH} characters` }
    }

    let hasLetter = false
    let hasNumber = false
    let hasSymbol = false

    for (const char of password) {
        if (/[a-zA-Z]/.test(char)) {
            hasLetter = true
        } else if (/[0-9]/.test(char)) {
            hasNumber = true
        } else if (ALLOWED_SYMBOLS_SET.has(char)) {
            hasSymbol = true
        } else {
            return { valid: false, message: `${char} is not allowed` }
        }
    }

    if (!hasLetter) {
        return { valid: false, message: 'at least a letter' }
    }
    if (!hasNumber) {
        return { valid: false, message: 'at least a number' }
    }
    if (!hasSymbol) {
        return { valid: false, message: `at least a symbol (${ALLOWED_SYMBOLS})` }
    }

    return { valid: true, message: null }
}

module.exports = { validatePassword }