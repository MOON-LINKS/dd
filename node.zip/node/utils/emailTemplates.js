// One function per email event type (spec Section 9: "each task/event type has its own template").
// TODO: wire these into the Section 6 localization system (en/ar/fr) once locale JSON files exist —
// each function should accept a `locale` param and pull subject/body strings from the JSON keys
// instead of the hardcoded English below.

const APP_NAME = 'YOUR_APP_NAME' // TODO: replace once product name is finalized

// Dates from Postgres arrive as JS Date objects — interpolating them directly
// into a template string calls .toString() and prints the full timestamp
// (e.g. "Tue Sep 01 2026 00:00:00 GMT+0300 (Eastern European Summer Time)").
// Format defensively here so callers don't have to remember to pre-format.
const formatDate = (date) => {
    if (!date) return ''
    const d = date instanceof Date ? date : new Date(date)
    if (isNaN(d.getTime())) return String(date)
    return d.toISOString().slice(0, 10) // YYYY-MM-DD
}
const wrapper = (title, bodyHtml) => `
<div style="font-family: Arial, sans-serif; background:#f6f6f6; padding:20px;">
    <div style="max-width:500px; margin:auto; background:white; padding:20px; border-radius:10px;">
        <img
            src="https://cdn.mydomain.com/imgs/logo.png"
            alt="${APP_NAME}"
            style="width:140px; margin-bottom:20px;"
        />
        <h2 style="color:#111;">${title}</h2>
        ${bodyHtml}
        <hr>
        <p style="font-size:12px; color:#8d209b;">
            If you did not request this, you can ignore this email.
        </p>
    </div>
</div>`

const otpCodeBlock = (otp) => `
<div style="
    font-size:24px;
    font-weight:bold;
    letter-spacing:4px;
    background:#f0f0f0;
    padding:10px;
    text-align:center;
    border-radius:6px;
">
    ${otp}
</div>`

const registrationOtpEmail = ({ name, otp }) => ({
    subject: `Verify your ${APP_NAME} account`,
    text: `Hello ${name}, your verification code is ${otp}`,
    html: wrapper(
        `${APP_NAME} Verification`,
        `<p>Hello ${name},</p><p>Your verification code is:</p>${otpCodeBlock(otp)}`
    )
})

const passwordResetOtpEmail = ({ otp }) => ({
    subject: `Reset your ${APP_NAME} password`,
    text: `Your password reset code is ${otp}`,
    html: wrapper(
        'Password Reset',
        `<p>Your password reset code is:</p>${otpCodeBlock(otp)}`
    )
})

const welcomeEmail = ({ name }) => ({
    subject: `Welcome to ${APP_NAME}`,
    text: `Hi ${name}, your account is verified and ready to go.`,
    html: wrapper('Welcome!', `<p>Hi ${name}, your account is verified and ready to go.</p>`)
})
const invoiceEmail = ({ organizationName, clientName, periodStart, periodEnd, totalAmount, amountOwed, pdfUrl }) => {
    const start = formatDate(periodStart)
    const end = formatDate(periodEnd)
    return {
        subject: `Invoice for ${clientName} — ${periodStart} to ${periodEnd}`,
        text: `Invoice for ${clientName} covering ${periodStart} to ${periodEnd}. Total: $${totalAmount}. Owed: $${amountOwed}. PDF: ${pdfUrl}`,
        html: wrapper(
            'New Invoice Generated',
            `<p>An invoice was generated for <strong>${clientName}</strong> covering <strong>${periodStart}</strong> to <strong>${periodEnd}</strong>.</p>
         <table style="width:100%; margin:16px 0; font-size:14px;">
             <tr><td style="padding:4px 0; color:#555;">Total amount</td><td style="text-align:right;">$${totalAmount}</td></tr>
             <tr><td style="padding:4px 0; color:#555;">Amount owed</td><td style="text-align:right;">$${amountOwed}</td></tr>
         </table>
         <p><a href="${pdfUrl}" style="display:inline-block; background:#1D9E75; color:white; padding:10px 18px; border-radius:6px; text-decoration:none;">View invoice PDF</a></p>
         <p style="font-size:12px; color:#888;">Organization: ${organizationName}</p>`
        )
    }
}
const billReminderEmail = ({ organizationName, title, amount, dueDate }) => {
    const due = formatDate(dueDate)
    return {
        subject: `Upcoming bill due soon: ${title}`,
        text: `Reminder: "${title}" ($${amount}) is due on ${dueDate} for ${organizationName}.`,
        html: wrapper(
            'Upcoming Bill Reminder',
            `<p>This is a reminder that an upcoming bill is due soon.</p>
         <table style="width:100%; margin:16px 0; font-size:14px;">
             <tr><td style="padding:4px 0; color:#555;">Bill</td><td style="text-align:right;">${title}</td></tr>
             <tr><td style="padding:4px 0; color:#555;">Amount</td><td style="text-align:right;">$${amount}</td></tr>
             <tr><td style="padding:4px 0; color:#555;">Due date</td><td style="text-align:right;">${dueDate}</td></tr>
         </table>
         <p style="font-size:12px; color:#888;">Organization: ${organizationName}</p>`
        )
    }
}

module.exports = { registrationOtpEmail, passwordResetOtpEmail, welcomeEmail, invoiceEmail, billReminderEmail }
